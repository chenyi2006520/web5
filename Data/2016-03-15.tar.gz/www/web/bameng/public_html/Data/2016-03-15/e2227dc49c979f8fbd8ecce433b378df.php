s:19469:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>“好干部”左亭:一心做事 干净做人- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">“好干部”左亭:一心做事 干净做人</h1> <p id="source-and-time"><span id=source>新华网</span><time id=time>2016-03-06 10:59:08</time></p> </header>  <div id="news-body"><p>新华社长沙3月6日电 题:“好干部”<a href="http://m.so.com/s?q=%E5%B7%A6%E4%BA%AD&amp;src=newstranscode" class="qkw">左亭</a>:一心做事 干净做人</p><p class="header">新华社记者邹云、白田田、丁文杰</p><p><a href="http://m.so.com/s?q=%E6%B9%96%E5%8D%97%E7%9C%81&amp;src=newstranscode" class="qkw">湖南省</a>发改委一张办公桌上的台历，留在2015年11月17日那一页。左亭，湖南省发改委原副主任，这位“拼命三郎”，永远停下了他奔忙的脚步，年仅51岁。</p><p>“<a href="http://m.so.com/s?q=%E5%BD%93%E6%88%91%E8%80%81%E4%BA%86&amp;src=newstranscode" class="qkw">当我老了</a>，谈起湖南铁路，希望有得可说。”湖南发改委的同事至今记得，左亭曾经说起这段话时，“自豪感洋溢在眉宇之间”。</p><p>青山在，人已去。左亭用自己的辛勤付出，推动了湖南多条铁路的陆续动工建设，更用自己的一言一行，树立起“一心做事，干净做人”的好干部形象。</p><p class="header">“关键是兢兢业业做事了没有”</p><p>“人呐，官多大都不重要，关键是在现任的职务上，兢兢业业做事了没有。”--左亭对身边的同事说。</p><p>11月17日那天，下班回家后的左亭，还在忙着准备第二天的会议。大约6点30分，左亭感到身体不舒服，随后突发脑溢血瘫倒下去，再也没有醒来。</p><p>早在2015年上半年，<a href="http://m.so.com/s?q=%E6%B9%98%E9%9B%85%E5%8C%BB%E9%99%A2&amp;src=newstranscode" class="qkw">湘雅医院</a>的医生就叮嘱体型偏胖的左亭入院检查，左亭总是说“等忙完这段工作”。然而，病魔没有给他忙完工作的时间。</p><p>在此之前，左亭已经持续多日连轴转。在他的日程安排上，11月18日上午是沪昆动车所征拆协调会，下午是沪昆外电源协调会，晚上还要赶往岳阳开会……</p><p>“现在有些干部为官不为，不在状态，左亭却是认真负责、敢于担当。”湖南省发改委办公室主任<a href="http://m.so.com/s?q=%E9%BE%9A%E6%96%B0%E5%B9%B3&amp;src=newstranscode" class="qkw">龚新平</a>说，左亭“走”之前，还打电话给他交待有关重点项目的事情。“白加黑”“五加二”，是左亭工作的常态。</p><p>同事们经常说起左亭“8天没换衣服”的故事。那是2015年4月，左亭陪同国家稽查组一行到湖南省<a href="http://m.so.com/s?q=%E6%BE%A7%E5%8E%BF&amp;src=newstranscode" class="qkw">澧县</a>、冷水江市稽查，连续8天时间白天到基层看项目，晚上听取反馈意见、部署整改工作，身上的衣服湿了又干，干了又湿。左亭淡然地说:“我们铁路人早就习惯了。”</p><p>由于工作太忙，左亭时常顾不上家里的事。左亭的父亲左承植回忆说，11月14日左亭来看望他，只待了十几分钟电话就响了。左亭把短信给父亲看，说“爸，我有事先走了”。没想到，这一走竟成永诀。</p><p>左亭去世后，不少同事写诗悼念:“重点建设忙，左公扛大梁，积劳成疾撒人寰……”“废寝忘食事躬亲，四处奔波常进京，全为<a href="http://m.so.com/s?q=%E7%99%BE%E5%A7%93%E8%B7%AF&amp;src=newstranscode" class="qkw">百姓路</a>畅行……”</p><p class="header">“既当指挥员，更当战斗员”</p><p>“我要求自己既当指挥员，更当战斗员，经常自己写报告、写纪要、修改图纸，始终以严、细、实的作风对待工作。”--左亭在述职报告中写道。</p><p>左亭的办公室里，没有豪华的陈设，桌上的笔记本里记满了工作纪要和心得，几大箱有关铁路的专业书籍和技术资料，安静地码放在墙边。</p><p>“1984年9月25日，购于<a href="http://m.so.com/s?q=%E5%8C%97%E6%96%B9%E4%BA%A4%E9%80%9A%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">北方交通大学</a>。”在左亭办公室的书堆中，记者翻到一本纸张泛黄的<a href="http://m.so.com/s?q=%E3%80%8A%E9%93%81%E8%B7%AF%E7%AB%99%E5%9C%BA%E5%8F%8A%E6%9E%A2%E7%BA%BD%E3%80%8B&amp;src=newstranscode" class="qkw">《铁路站场及枢纽》</a>。这是左亭读大学时购买的，扉页上留有他的字迹，一直伴随着左亭的“铁路生涯”。</p><p>1986年从北方交通大学毕业后，左亭从技术员做起，最后成为铁路建设管理的专家，并获得过铁道部最高荣誉--“火车头奖章”。</p><p>2012年，左亭从沪昆客专湖南公司调任湖南省发改委工作，主要负责铁路等重大项目的申报和协调。任职期间，湖南省铁路建设完成投产里程近1000公里，完成投资1134亿元，其中2014年开工项目投资规模达1000亿元左右，是历年湖南铁路投资额度最多的，建成铁路和在建铁路投资也一直位列中部六省前列，湖南一跃成为全国的“高铁大省”。</p><p>为了推进<a href="http://m.so.com/s?q=%E6%B9%98%E8%A5%BF&amp;src=newstranscode" class="qkw">湘西</a>地区的铁路建设，左亭创造性地提出“高铁环线”概念，并多次到北京向国家部委汇报，使<a href="http://m.so.com/s?q=%E5%BC%A0%E5%90%89&amp;src=newstranscode" class="qkw">张吉</a>怀铁路、怀邵衡铁路等湖南西部铁路项目成功获批。2016年，连接<a href="http://m.so.com/s?q=%E5%BC%A0%E5%AE%B6%E7%95%8C&amp;src=newstranscode" class="qkw">张家界</a>、吉首和怀化的张吉怀铁路有望正式动工，当地老百姓将迎来期盼已久的扶贫线、致富线。</p><p class="header">“吃碗辣椒炒肉就是幸福”</p><p>“要那么多钱干什么，吃碗<a href="http://m.so.com/s?q=%E8%BE%A3%E6%A4%92%E7%82%92%E8%82%89&amp;src=newstranscode" class="qkw">辣椒炒肉</a>就是幸福，不要追求物质的东西。”--妻子回忆左亭说过的话。</p><p>左亭去世后，到他家吊唁的友人都很惊讶，想不到一位副厅级干部的家如此“简朴”:房子位于老旧小区，面积不足100平方米，客厅里摆放着老旧的沙发、一台老式显像管电视机，厕所的天花板上墙漆已经剥落。</p><p>身为湖南省发改委副主任，左亭在很多人眼中是“位高权重”。但左亭流传最广的却是“三个不得”的<a href="http://m.so.com/s?q=%E5%BB%89%E6%94%BF%E6%95%85%E4%BA%8B&amp;src=newstranscode" class="qkw">廉政故事</a>:一次是某地发改委主任希望左亭牵头邀请省发改委业务处长一起吃饭，他说“这个头牵不得”;一次是高中同学希望他帮忙承包沪昆高铁南站工程，他说“这个忙帮不得”;一次是儿子考上了<a href="http://m.so.com/s?q=%E6%B8%85%E5%8D%8E%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">清华大学</a>，同事们想表示祝贺，他说“这个客请不得”。</p><p>湖南省发改委重点项目办副主任<a href="http://m.so.com/s?q=%E8%83%A1%E5%BB%BA%E7%94%9F&amp;src=newstranscode" class="qkw">胡建生</a>记得，有一次，他看到一名地方发改委干部被左亭从办公室轰了出来。一问才知道，这名干部汇报情况时递送红包，被左亭一顿斥责。左亭当时对他说，“物质利益的来往有经济契约，生活的来往有<a href="http://m.so.com/s?q=%E7%B2%BE%E7%A5%9E%E5%A5%91%E7%BA%A6&amp;src=newstranscode" class="qkw">精神契约</a>，工作上的来往就应该清清白白”。</p><p>左亭的清正廉洁还体现在对家人的严格要求。妻子朱曼君是长沙铁路办事处一名普通会计，有一次跟左亭说想调动工作，左亭说，“你在这里工作挺好的。”朱曼君从此不再提这事。左亭的弟弟回忆说，左亭一直要求作为企业负责人的他“绝对不能收受别人钱财”。</p><p>湖南省发改委重点项目办副主任<a href="http://m.so.com/s?q=%E8%83%A1%E5%8D%97&amp;src=newstranscode" class="qkw">胡南</a>说，重大项目建设领域长期存在不正之风，左亭不仅严于律己，更是积极推动权力在阳光下运行。当前经济下行压力大，改革进入深水区，国家需要更多左亭这样敢于担当、清正廉洁和有家国情怀的好干部。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.xinhuanet.com/politics/2016-03/06/c_1118246222.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='c4dbddd6efd6989d060058c8f1eae2b3'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>左亭</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%B7%A6%E4%BA%AD&amp;pn=1&amp;pos=2&amp;m=b0acf31b41f8f38d889a42dd445cc10ce6389b85&amp;u=http%3A%2F%2Fnews.gmw.cn%2F2016-03%2F07%2Fcontent_19194567.htm" data-pos="1"> <b>左亭</b>的办公室 </a>   <li> <a href="/transcode?q=%E5%B7%A6%E4%BA%AD&amp;pn=1&amp;pos=3&amp;m=5b5778b238beaa9eb22b631473991da4db22b06e&amp;u=http%3A%2F%2Fnews.gmw.cn%2F2016-03%2F03%2Fcontent_19139423.htm" data-pos="2"> <b>左亭</b>留给我们的遗憾 </a>   <li> <a href="/transcode?q=%E5%B7%A6%E4%BA%AD&amp;pn=1&amp;pos=4&amp;m=4eed4f404ae78ad9d689134045bfcad01f4b62d5&amp;u=http%3A%2F%2Fnews.gmw.cn%2F2016-03%2F04%2Fcontent_19157437.htm" data-pos="3"> 读<b>左亭</b> 写<b>左亭</b> 学<b>左亭</b>--作家在行动 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '“好干部”左亭:一心做事 干净做人' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '“好干部”左亭:一心做事 干净做人'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";