s:21054:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>女人吃这物提升卵子质量促生育 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">女人吃这物提升卵子质量促生育 </h1> <p id="source-and-time"><span id=source>中国青年网</span><time id=time>2016-03-11 19:20:26</time></p> </header>  <div id="news-body"><p>每个女性在备孕前，都想要把自己的身体调整到最好的状态，这样才能生出一个漂亮又聪明的宝宝，那么促排卵的食物及促排卵的原理有哪些呢?女性促排卵需要注意什么呢?今天就向大家介绍相关的内容。</p><p>排卵是正常育龄女性都会经历的一个生理现象，卵子每个月只会排出一颗，所以很多的女同胞都会吃一些促排卵的食物，下面就来了解一下吧。</p><p class="header">1.谷类食物</p><p>谷类食物中有大量的天然植物雌激素，是女性促进排卵并提高卵子质量的佳品，另外，茴香、葵花子、洋葱等，都有着丰富的雌激素，<a href="http://m.so.com/s?q=%E4%B8%8D%E6%8E%92%E5%8D%B5&amp;src=newstranscode" class="qkw">不排卵</a>的女性，经常食用也可改善身体状况。</p><p class="header">2.豆类食物</p><p>很多时候，女性不排卵或是卵子质量不高，都与身体里的雌激素水平有关，因此，多吃豆类食物，可以提高雌激素水平，并有效促进卵泡发育，如<a href="http://m.so.com/s?q=%E9%BB%91%E8%B1%86&amp;src=newstranscode" class="qkw">黑豆</a>、黄豆等等，都有着非常强大的促排卵功能。</p><p><img src="http://p33.qhimg.com/t01f80500d0f3725bde.jpg?size=400x294"></p><p>3.水<a href="http://m.so.com/s?q=%E9%B1%BC%E6%B1%A4&amp;src=newstranscode" class="qkw">鱼汤</a></p><p>卵泡的发育不完全，女性便无法正常的排卵，因此平时可以多喝一些水鱼汤，来促进卵泡的发育，即使是不排卵的女性喝过之后，症状都可得到一定的改善，并且没有任何的副作用。</p><p class="header">4.富含锌的食物</p><p>如豆类、花生、小米、牛肉、<a href="http://m.so.com/s?q=%E9%B8%A1%E8%82%9D&amp;src=newstranscode" class="qkw">鸡肝</a>、蛋类、木松鱼、芝麻、花生仁、核桃等。锌可以提高女性的受孕能力，并可以帮助卵子质量的提高，女性在孕期时，因有意识的吃一些含锌的食物。</p><p class="header">促排卵是什么意思</p><p>促排卵，一般是通过药物刺激到卵巢，然后诱发排卵。对于一些有排卵障碍的筒子，或者是不孕的女性，促排卵是一种常见的方法。</p><p>但促排卵也是有一定风险存在的，所以千万不能擅自用药，弄不好很有可能会导致卵泡的发育不成熟，身体出现紊乱的现象。</p><p><img src="http://p34.qhimg.com/t015d60a7ab61986980.jpg?size=400x400"></p><p class="img-title">促排卵的原理</p><p>其实排卵的话是有一个过程的，首先是下丘脑作用于垂体，垂体作用于卵巢轴人，然后卵巢排卵，其中任一环节有问题都有可能会导致排卵障碍或者是不孕。而促排卵能令这个过程得以顺利进行，排卵之后就能愉快怀上宝宝了。</p><p>对于一些高龄的女筒子，可能是有排卵障碍的，但出于一些原因不得不继续生多个宝宝，那么就可以用促排卵方法获取成熟的卵子，顺利的话就能怀上宝宝了。</p><p>但是促排卵也是有一定风险的，可能一下子就怀上多胎了，多胎是对一个准妈咪体质的考验呢，风险比较大。</p><p class="header">促排卵有什么方法呢</p><p>促排卵一般是通过药物进行的，最早是口服促<a href="http://m.so.com/s?q=%E6%8E%92%E5%8D%B5%E8%8D%AF&amp;src=newstranscode" class="qkw">排卵药</a>，这种药会和下丘脑细胞内的雌激素受体结合，然后令其产生更多的<a href="http://m.so.com/s?q=%E4%BF%83%E6%80%A7%E8%85%BA%E6%BF%80%E7%B4%A0%E9%87%8A%E6%94%BE%E6%BF%80%E7%B4%A0&amp;src=newstranscode" class="qkw">促性腺激素释放激素</a>，刺激垂体促卵泡激素、促黄体生成激素，然后进而刺激卵巢内卵泡生长、发育、成熟以及排卵。</p><p>这个过程就是下丘脑-垂体-卵巢轴的反馈机制。不过现在促排卵的药物也是越来越完善的，有口服和针剂这些类型，而且药物纯度也越来越高了，自然效果会更好一些。当然啦，除了药物辅助排卵之外，也可以在日常中吃点促排卵的食物。</p><p>促排卵<a href="http://m.so.com/s?q=%E6%80%80%E5%AD%95&amp;src=newstranscode" class="qkw">怀孕</a>率高不高</p><p>对于想生宝宝但是又生不了宝宝的CP来说，无法怀孕是一件令人十分心塞的事情。不过现在科学比较发达，即使不可以生宝宝，或许通过试管婴儿这些方法怀上宝宝。如果是排卵有障碍，不孕的话，其实也有通过促排卵怀上宝宝。</p><p class="header">那么促排卵怀孕率高不高呢</p><p>促排卵是会募集多个卵泡发育，从而提高受孕的概率，加上药物的纯度越来越高，而且类型也多样化，多样促排卵的怀孕率还是有保障的。</p><p>大家在服用促排卵药物的时候，记住要控制好剂量，因为则要有可能会出现卵巢刺过度刺激综合征，这样卵子成熟就没有规律，还可能造成多胎、内分泌紊乱等问题呢。</p><p>服用药物的话，可能会出现一些不良反应，例如面部潮红、腹胀、腹痛、头痛、恶心呕吐等症状。不过这些不良反应一般会在1~2周消失，大家也不用太过忧心。</p><p class="header">促排卵需要注意什么</p><p>促排卵其实也是有风险的呢，当借助促排卵方法怀上宝宝之后，记住要定时做B超检查，如果是多胎的话，需要联系医生做减胎手术呢。</p><p><img src="http://p35.qhimg.com/t0122f76698a760f1f8.jpg?size=400x400"></p><p>多胎妊娠风险还是蛮大的，可能会后续出现胎膜早破，又或者是早产的，也有些准妈咪会患<a href="http://m.so.com/s?q=%E5%A6%8A%E5%A8%A0%E6%9C%9F%E6%80%A5%E6%80%A7%E8%84%82%E8%82%AA%E8%82%9D&amp;src=newstranscode" class="qkw">妊娠期急性脂肪肝</a>，无论是对胎宝宝还是准妈咪来说风险都很大。</p><p>促排卵也不要擅自用药，一些“多仔丸”、促孕丸、<a href="http://m.so.com/s?q=%E9%B9%BF%E8%83%8E%E8%86%8F&amp;src=newstranscode" class="qkw">鹿胎膏</a>等可能并不具有促排卵导致功效饿，乱吃药的话非但不能起到促排卵效果，可能还会对身体造成一些伤害呢。促排卵的药物是不能擅自服用的，大家要有这种意识呢。</p><p>如果每周两次爱爱，而且持续一段时间了，但肚子就是没有动静的话，最好先去医院检查一番，不自顾自吃药或者采用其它非科学手段促排卵，否则最后伤害的也还是自己。</p><p class="header">促排卵的食物</p><p class="header">1.原理</p><p>很多女性无法正常排卵的最大原因就是宫寒，它会直接诱发<a href="http://m.so.com/s?q=%E6%9C%88%E7%BB%8F%E4%B8%8D%E8%B0%83&amp;src=newstranscode" class="qkw">月经不调</a>。卵巢生产成熟的卵泡需要血营养，而月经不调就使得血营养供应不足，自然就难以排卵。因此在食疗上一定要注意<a href="http://m.so.com/s?q=%E6%9A%96%E5%AE%AB&amp;src=newstranscode" class="qkw">暖宫</a>，市面上也有些暖宫汤，大可以配合排卵药与怀孕药食用。</p><p class="header">2.分类</p><p>女性的饮食上需要多多注意，有些食物可以促进排卵，多多益善，有些食物却是卵子的杀手，需要远离它们。接下来，我们就看看哪些食物可以吃，哪些食物不可以吃。</p><p class="header">多多益善的食物</p><p>豆类特别是黑豆，生姜，醋，薏苡仁，大蒜，板栗，桔子，植物油，呼叫，鸡汤，<a href="http://m.so.com/s?q=%E7%89%9B%E8%82%89%E6%B1%A4&amp;src=newstranscode" class="qkw">牛肉汤</a>等等。</p><p class="header">禁止食用的食物</p><p>辣的，冷的，生的，腌制品，碳酸饮料，白菜，葱，烟酒等等。</p><p class="header">3.食谱</p><p>(1)<a href="http://m.so.com/s?q=%E8%8E%B2%E5%AD%90%E7%8C%AA%E8%82%9A&amp;src=newstranscode" class="qkw">莲子猪肚</a></p><p>食材，猪肚与<a href="http://m.so.com/s?q=%E8%8E%B2%E5%AD%90&amp;src=newstranscode" class="qkw">莲子</a>。</p><p>做法，把<a href="http://m.so.com/s?q=%E7%8C%AA%E8%82%9A&amp;src=newstranscode" class="qkw">猪肚</a>清洗后，放入适量的莲子，把肚子的两端绑牢，接下来把肚子放入到锅中炖，并放入适量调料，煮熟后即可食用。</p><p class="header">作用，促进排卵，同时补气健脾。</p><p>(2)<a href="http://m.so.com/s?q=%E6%9C%A8%E8%80%B3%E7%B2%A5&amp;src=newstranscode" class="qkw">木耳粥</a></p><p>食材，6g<a href="http://m.so.com/s?q=%E9%BB%91%E6%9C%A8%E8%80%B3&amp;src=newstranscode" class="qkw">黑木耳</a>，0.2斤粳米，6颗枣，一把<a href="http://m.so.com/s?q=%E5%86%B0%E7%B3%96&amp;src=newstranscode" class="qkw">冰糖</a>。</p><p>做法，用盆盛满温水，再将黑木耳放进盆中浸泡，泡开后将木耳的蒂摘掉，并洗去杂质捞出，最后用刀切碎。</p><p>接下来淘米，把<a href="http://m.so.com/s?q=%E7%B2%B3%E7%B1%B3&amp;src=newstranscode" class="qkw">粳米</a>清洗干净，再将除冰糖外的所有食材一起放入到锅中，加水开煮，可以先用大火，待到水开后，继续用小火继续煮，煮到粳米开花后，再加入冰糖，等到糖<a href="http://m.so.com/s?q=%E6%BA%B6%E5%8C%96&amp;src=newstranscode" class="qkw">溶化</a>后即可食用。</p><p>作用，主要是对子宫的调节，对于下身无规律出血，并且伴有脸色苍白，浑身无力，食欲差的女性来说，可以起到很好的调理效果。除了养宫促卵，还可以调节肠胃功能，但是这类粥并不适合感冒发烧者，也不适合孕妈饮用。推荐</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.youth.cn/jk/201603/t20160311_7734760.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='b684e27cced8e4ab985f2b0b167af1d8'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>卵细胞</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%8D%B5%E7%BB%86%E8%83%9E&amp;pn=1&amp;pos=3&amp;m=ca415ee585e2c848b24338478f3a65d7d283463e&amp;u=http%3A%2F%2Fnews.youth.cn%2Fjk%2F201603%2Ft20160311_7734760.htm" data-pos="1"> 女人吃这物提升<b>卵子</b>质量促生育 </a>   <li> <a href="/transcode?q=%E5%8D%B5%E7%BB%86%E8%83%9E&amp;pn=1&amp;pos=4&amp;m=35ede8f4b789ad72b6804a9ff0369f8217eacb78&amp;u=http%3A%2F%2Fnews.youth.cn%2Fjk%2F201603%2Ft20160309_7724423.htm" data-pos="2"> 七条生活习惯有助<b>卵子</b>健康 </a>   <li> <a href="/transcode?q=%E5%8D%B5%E7%BB%86%E8%83%9E&amp;pn=1&amp;pos=5&amp;m=44939591d5c2262ad51f8621a02ddcd385072ee7&amp;u=http%3A%2F%2Fwww.china.com.cn%2Flianghui%2Fnews%2F2016-03%2F08%2Fcontent_37969357.htm" data-pos="3"> 卫计委回应"冷冻<b>卵子</b>热":中国技术成熟无需去国外 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '女人吃这物提升卵子质量促生育 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '女人吃这物提升卵子质量促生育 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";