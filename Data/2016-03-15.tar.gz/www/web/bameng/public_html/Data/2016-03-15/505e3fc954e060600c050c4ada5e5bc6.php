s:19773:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>丛林的法则首站马达加斯加,黄子韬中分发型太雷人- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">丛林的法则首站马达加斯加,黄子韬中分发型太雷人</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-10 00:00:00</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t013fcdf37bf3a6fa73.jpg?size=500x398"></p><p>安徽卫视大型野外生存挑战类节目<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%9B%E6%9E%97%E7%9A%84%E6%B3%95%E5%88%99%E3%80%8B&amp;src=newstranscode" class="qkw">《丛林的法则》</a>近日在非洲岛国<a href="http://m.so.com/s?q=%E9%A9%AC%E8%BE%BE%E5%8A%A0%E6%96%AF%E5%8A%A0&amp;src=newstranscode" class="qkw">马达加斯加</a>结束了首站录制，丛林家族七名成员<a href="http://m.so.com/s?q=%E5%90%B4%E5%A5%87%E9%9A%86&amp;src=newstranscode" class="qkw">吴奇隆</a>、李亚鹏、小沈阳、<a href="http://m.so.com/s?q=%E9%BB%84%E5%AD%90%E9%9F%AC&amp;src=newstranscode" class="qkw">黄子韬</a>、孙艺洲、邢傲伟、<a href="http://m.so.com/s?q=%E7%86%8A%E9%BB%9B%E6%9E%97&amp;src=newstranscode" class="qkw">熊黛林</a>目前都已平安归国。根据节目组公布的照片，经过半个多月的丛林体验，丛林家族七位成员集体晒黑，黄子韬甚至丢掉了偶像包袱，凌乱的中分发型，让人捧腹。</p><p class="header">丛林家族集体晒黑，熊黛林女神范依旧</p><p>近日，丛林家族七位成员完成了首站马达加斯加的录制，安全返回。从节目组公布的照片来看，丛林家族成员们无一例外都被非洲的烈日晒黑。斯文儒雅的<a href="http://m.so.com/s?q=%E6%9D%8E%E4%BA%9A%E9%B9%8F&amp;src=newstranscode" class="qkw">李亚鹏</a>与出征前相比黑瘦了不少，一向白净的<a href="http://m.so.com/s?q=%E5%B0%8F%E6%B2%88%E9%98%B3&amp;src=newstranscode" class="qkw">小沈阳</a>也变得黝黑，就连熊黛林也晒黑了不少，但素颜照女神范依旧。</p><p><img src="http://p31.qhimg.com/t01f919a6bf2f84eef5.jpg?size=500x586"></p><p>作为家族的体能担当，奥运冠军<a href="http://m.so.com/s?q=%E9%82%A2%E5%82%B2%E4%BC%9F&amp;src=newstranscode" class="qkw">邢傲伟</a>也是最勤快的合照搬运工，乐此不彼地在微博上分享丛林家族的集体合影，可见其对丛林家族兄弟情之深。而<a href="http://m.so.com/s?q=%E5%AD%99%E8%89%BA%E6%B4%B2&amp;src=newstranscode" class="qkw">孙艺洲</a>是被网友看好的搞怪担当，虽然从照片上看憔悴不少，但从表情上看，乐天派依旧。</p><p>据了解，在首站录制中，丛林家族成员们克服了很多困难，顺利完成了录制任务。在录制期间，小沈阳还不忘为妻子<a href="http://m.so.com/s?q=%E6%B2%88%E6%98%A5%E9%98%B3&amp;src=newstranscode" class="qkw">沈春阳</a>录生日祝福视频。在这段短视频中，丛林家族虽然稍显疲惫，但却全员出镜，齐声送祝福。</p><p><img src="http://p31.qhimg.com/t01cf10621f6e6dcdd4.jpg?size=500x596"></p><p><a href="http://m.so.com/s?q=%E3%80%8A%E6%88%91%E6%98%AF%E6%AD%8C%E6%89%8B%E3%80%8B&amp;src=newstranscode" class="qkw">《我是歌手》</a>第九期将于本周五开场，目前，第九期节目已经录制完成，就目前录制的情况来看，这一期最大的看点应该是前来踢馆的<a href="http://m.so.com/s?q=%E9%87%91%E5%BF%97%E6%96%87&amp;src=newstranscode" class="qkw">金志文</a>，另外《我是歌手》第九期<a href="http://m.so.com/s?q=%E5%AE%B9%E7%A5%96%E5%84%BF&amp;src=newstranscode" class="qkw">容祖儿</a>放大招唱《煞科》，现场热舞秀美腿，容祖儿能否逆袭拿冠军呢?</p><p>日前，《我是歌手》第九期节目录制完毕，早前因在<a href="http://m.so.com/s?q=%E3%80%8A%E8%B0%81%E6%9D%A5%E8%B8%A2%E9%A6%86%E3%80%8B&amp;src=newstranscode" class="qkw">《谁来踢馆》</a>中夺冠而备受关注的第三位踢馆歌手金志文终于亮相，给其他在线歌手带来压力不小，尤其是自参赛以来首次面对踢馆歌手的容祖儿[微博]更是严阵以待。</p><p>据悉，为准备此次竞演，连唱了两场<a href="http://m.so.com/s?q=%E6%8A%92%E6%83%85%E6%9B%B2&amp;src=newstranscode" class="qkw">抒情曲</a>的容祖儿将携军队登场，用一首<a href="http://m.so.com/s?q=%E3%80%8A%E7%85%9E%E7%A7%91%E3%80%8B&amp;src=newstranscode" class="qkw">《煞科》</a>在舞台展示唱跳全能大秀美腿，此外，她精心挑选的闪耀战袍更是锦上添花，令现场观众直呼女神。</p><p><img src="http://p31.qhimg.com/t01adc56500c8f00329.jpg?size=500x615"></p><p>容祖儿挑战<a href="http://m.so.com/s?q=%E8%BF%88%E5%85%8B%E6%9D%B0%E5%85%8B%E9%80%8A&amp;src=newstranscode" class="qkw">迈克杰克逊</a> 三曲风结合超劲爆</p><p>由于在前面两场唱的都是慢歌，本周第三次站上竞演舞台的容祖儿有了转变观众认知的念头。此次选择了郑秀文的《煞科》的她坦言:我觉得大家对我的认知不应该只是单唱慢歌，其实快歌跟我的性格比较相符，所以虽然唱快歌的时候要顾虑比较多，但我还是想试试看，然后在第三集给大家看不一样的容祖儿。</p><p>在竞演当晚，容祖儿一身blingbling连身裙惹得观众直呼女神，起初慵懒而后动感的舞姿加上一双美腿分外撩人，投入的眼神和表情将性感元素串街在一起，中途加入的<a href="http://m.so.com/s?q=%E8%BF%88%E5%85%8B%E5%B0%94%E6%9D%B0%E5%85%8B%E9%80%8A&amp;src=newstranscode" class="qkw">迈克尔杰克逊</a>创造的斜身动作，更是在很大程度上增添了表演难度。</p><p>为了让观众得到视、听双重享受，容祖儿在歌唱方面也有所发挥，不但将性感、爽朗等情绪融入在一首歌曲里，还结合爵士、电子等多曲风，轻松讲气氛带动起来，掀起当晚一个小高潮。</p><p><img src="http://p32.qhimg.com/t01d8f168de740c54de.jpg?size=500x345"></p><p>黄子韬发型雷人，发微博想念那里的一切</p><p>在丛林家族七位成员中，黄子韬是晒得最黑的一位，但合照中，他却笑容满面，完全不顾凌乱雷人的中分发型，放下了偶像包袱，显得真实自然。</p><p><img src="http://p31.qhimg.com/t01ccc7a3f59fc31b37.jpg?size=500x587"></p><p>在为期半个多月的丛林生存中，丛林家族成员们<a href="http://m.so.com/s?q=%E5%9B%9E%E5%BD%92%E4%B8%9B%E6%9E%97&amp;src=newstranscode" class="qkw">回归丛林</a>，经历了一场没有雾霾、没有破坏、没有工作压力的纯粹之旅，尽管吃和住都面临着巨大挑战，但不失为一种重新寻找自我的方式。</p><p>回归之后，黄子韬在微博发声:现在离开了却也还在想念着那里的一切，并隔空呼喊丛林家族其他六名成员，可见短短半月行程，丛林家族已经结下了深厚的友谊。</p><p><img src="http://p33.qhimg.com/t015b2cb3baa8c55885.jpg?size=500x352"></p><p>小沈阳发视频给老婆庆生，并发文什么也不说了生日快乐老婆，视频中，丛林家族的所有成员均素颜亮相祝福。小沈阳表示:今天是一个喜庆的日子，今天是一个大喜的日子，老婆，今天你过生日了，往年都是我们两个在一起，我陪你过生日，但是这几年，我们不是在飞机上就是在路上。今年又赶上我在马达加斯加录《丛林的法则》，所以老公真的很亏欠你，不说了，真的不说了。老婆我只想说一句话，<a href="http://m.so.com/s?q=%E8%80%81%E5%A9%86%EF%BC%8C%E6%88%91%E7%88%B1%E4%BD%A0&amp;src=newstranscode" class="qkw">老婆，我爱你</a>!</p><p><img src="http://p35.qhimg.com/t01fedc44a336708b82.jpg?size=500x348"></p><p>随后丛林家族的所有成员十分搞怪的跳进了画面，包围住了小沈阳，一同祝福沈春阳，看上去真是一个非常有爱的丛林家族。说完之后几个竟一起逗比的喊着:哎呀，猛地站起来，头好晕!几位瞬间都变成了逗比。</p><p><img src="http://p35.qhimg.com/t01f9e9b652cbe5d000.jpg?size=500x343"></p><p>丛林家族大哥李亚鹏还开玩笑地一直拍打小沈阳的头，十足像个小顽童，与其平日里认真的形象大相径庭。吴奇隆则默默的站在身后，像一个贴心大哥一般。而孙艺洲则全程被挡脸，也是忧伤。黄子韬的完美发型则不再，有些风中凌乱了，皮肤也黑了不少，被网友调侃成黑桃了。从视频中可见，丛林家族之间的关系极好，短短时间就已经有了很深的感情。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/article/3895187.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='a2dc731d4fa019c435b9d25f10bec1d7'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>丛林的法则</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%B8%9B%E6%9E%97%E7%9A%84%E6%B3%95%E5%88%99&amp;pn=1&amp;pos=8&amp;m=bd7bb7bde64b725117d7e421bc23d8a5e2b96fa2&amp;u=http%3A%2F%2Fwww.zj.xinhuanet.com%2F2016-03%2F10%2Fc_1118288009.htm" data-pos="1"> 《<b>丛林的法则</b>》七明星集体晒黑 黄子韬中分发型雷人 </a>   <li> <a href="/transcode?q=%E4%B8%9B%E6%9E%97%E7%9A%84%E6%B3%95%E5%88%99&amp;pn=1&amp;pos=9&amp;m=f4202d0e1ecf160b2bac2c43aed1c639e26e3a37&amp;u=http%3A%2F%2Fwww.ceconline.com%2Fstrategy%2Fma%2F8800080335%2F01%2F%3Fcf%3DFocus_Today" data-pos="2"> 电老虎:工业互联网的<b>丛林法则</b> </a>   <li> <a href="/transcode?q=%E4%B8%9B%E6%9E%97%E7%9A%84%E6%B3%95%E5%88%99&amp;pn=1&amp;pos=10&amp;m=afa649a58f78b10d89448608d3189d8b0b7561c5&amp;u=http%3A%2F%2Fwww.zj.xinhuanet.com%2F2016-03%2F10%2Fc_1118292724.htm" data-pos="3"> 熊黛林报喜将出嫁 《<b>丛林的法则</b>》黄子韬丢偶像包袱 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '丛林的法则首站马达加斯加,黄子韬中分发型太雷人' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '丛林的法则首站马达加斯加,黄子韬中分发型太雷人'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";