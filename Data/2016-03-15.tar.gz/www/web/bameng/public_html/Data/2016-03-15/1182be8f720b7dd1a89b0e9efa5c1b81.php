s:39732:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>群众路线面临的实践困境及破解路径- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">群众路线面临的实践困境及破解路径</h1> <p id="source-and-time"><span id=source>中国社会科学网</span><time id=time>2016-03-10 10:15:00</time></p> </header>  <div id="news-body"><p>作者简介:<a href="http://m.so.com/s?q=%E5%AD%99%E6%9D%A5%E6%96%8C&amp;src=newstranscode" class="qkw">孙来斌</a>，王会民，武汉大学 马克思主义学院，武汉 430072 孙来斌(1967- )，男，湖北黄冈人，教授，博士研究生导师，博士，<a href="http://m.so.com/s?q=%E6%AD%A6%E6%B1%89%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">武汉大学</a>珞珈学者，从事<a href="http://m.so.com/s?q=%E9%A9%AC%E5%85%8B%E6%80%9D%E4%B8%BB%E4%B9%89%E5%8F%91%E5%B1%95%E5%8F%B2&amp;src=newstranscode" class="qkw">马克思主义发展史</a>研究; 王会民(1983- )，男，河南长垣人，博士研究生，从事马克思主义发展史研究。</p><p>内容提要:群众路线教育实践活动虽然已经结束，但是作风建设永远在路上。从历史和现实的情况来看，群众路线“说起来容易做起来难”，在实践过程中遇到许多困难和问题。社会分工的限制、小农文化的影响、市场机制的缺陷、用人体制的短板、长期执政的惰性等因素，无不对群众路线的实践造成各种阻碍。因此，要清除这些阻碍，必须从多方面发力。只有坚持群众本体、培养<a href="http://m.so.com/s?q=%E6%A0%B8%E5%BF%83%E4%BB%B7%E5%80%BC%E8%A7%82&amp;src=newstranscode" class="qkw">核心价值观</a>、消除资源配置特权、优化用人体制、增强忧患意识，才能增强群众路线实践的有效性和针对性，才能真正凝聚实现<a href="http://m.so.com/s?q=%E4%B8%AD%E5%8D%8E%E6%B0%91%E6%97%8F&amp;src=newstranscode" class="qkw">中华民族</a>伟大复兴的中国力量。</p><p>关 键 词:群众路线/实践困境/破解路径</p><p>标题注释:国家社科基金重大项目“实现中华民族伟大复兴中国梦的基本问题研究”(13&ZD006)阶段性成果</p><p>坚持群众路线，始终保持与广大人民群众的血肉联系，是中国共产党的优良传统和政治优势。经过<a href="http://m.so.com/s?q=%E5%8E%86%E5%8F%B2%E4%B8%8E%E5%AE%9E%E8%B7%B5&amp;src=newstranscode" class="qkw">历史与实践</a>的洗礼，在此问题上既有值得弘扬的时代传承，也有令人惋惜的资源流失。2013年6月启动的群众路线教育实践活动，受到各方面高度重视、积极响应，整个活动进展有序、扎实深入，取得了一系列丰硕成果。然而，这次活动当中也存在问题和不足。正如习近平总书记在党的群众路线教育实践活动总结大会上的讲话中指出:“有些问题的整改还没有完全到位，一些深层次问题还没有从根本上破解，上下联动解决问题还没有真正形成合力。”“广大干部群众最担心的是问题反弹、雨过地皮湿、活动一阵风”[1]。应该说，这些认识是清醒而深刻的。那么，为什么中央下了坚定的决心、全党花了巨大的精力，群众路线的践行还会存在问题呢?从理论上讲，群众路线并不是晦涩难解、深奥莫测的，而是通俗易懂、简约明了的，其理论基础无外乎马克思主义的群众史观和认识论，其基本内涵就是一切为了群众，一切依靠群众，从群众中来，到群众中去，把党的正确主张变为群众的自觉行动。然而，就实践而言，群众路线落实到位并不容易，往往会遭遇到“说起来容易做起来难”的困境。目前，群众路线教育实践活动虽然已经结束，但是作风建设永远在路上，群众路线实践必须常抓不懈。因此，反思群众路线面临的实践困境，并努力找到破解办法，无疑具有极其重要的意义。</p><p class="header">一、当前群众路线面临的实践困境</p><p>从现象与成因的角度来看，当前群众路线遭遇的实践难题主要表现在以下方面。</p><p>(一)由社会分工导致的领导干部的英雄主义幻想</p><p><a href="http://m.so.com/s?q=%E9%A9%AC%E5%85%8B%E6%80%9D&amp;src=newstranscode" class="qkw">马克思</a>曾说:“如爱尔维修所说的，每一个社会时代都需要有自己的大人物，如果没有这样的人物，它就要把他们创造出来。”[2]137这与中国人“时势造英雄”之说不谋而合。大人物的出现，关键在于“个人力量(关系)由于分工而转化为物的力量”[3]570。消除这一现象并使得每个人重新驾驭物质力量，要“靠消灭分工的办法来解决”[3]571。依据唯物史观的基本原理，社会分工的消灭是以生产力的高度发达、公有制的彻底实施等为前提条件的。只有到共产主义，社会分工的限制性将不再存在，每个人都是自己的、同时也是社会的“大人物”。</p><p>毫无疑问，现代社会离消灭分工的理想社会还有很大的距离。在我国社会主义市场经济中，商品经济仍是最重要的经济形式，社会分工成为不可或缺的前提条件。我们所处的社会阶段仍然处于“以物的依赖性为基础的人的独立性”[4]阶段。社会分工的积极因素和消极因素并存，它对个人发展的限制性影响难以回避。在这种环境之下，一些人基于自己的社会关系和对物质财富的控制，容易获得较高的社会地位。</p><p>由于社会分工、职业性质等原因，我们的党员干部不得不经常现身于各种党务活动、政务活动之中，集中群众意见并且代表人民群众做出一些决策，由此经常被各种媒体关注、报道，这本来是很正常的事情。但是，一些地方、一些部门的党员干部，由此迷失在鲜花掌声之中，得意而忘形，开始自觉不自觉地将自己视为左右地方和部门发展的决定力量，而将群众史观抛到九霄云外。他们依靠人民赋予的权力，拥有丰富的社会关系，执掌大量的社会资源，很容易导致英雄主义幻想。在与人民群众打交道时，这种幻想具体表现为高高在上、颐指气使的工作作风，救世主姿态的赐福与说教，乐于接受歌功颂德，善于进行自我标榜。正是这种英雄主义幻想，使得学习教育流于形式、浅尝辄止，查摆问题避重就轻、避实就虚，自我批评怕损形象，听取意见怕损权威，整改落实瞻前顾后，给群众路线的有效推进造成极大障碍。</p><p>(二)由小农文化影响导致的皇权等级崇拜</p><p><a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E4%BC%A0%E7%BB%9F%E6%96%87%E5%8C%96&amp;src=newstranscode" class="qkw">中国传统文化</a>意蕴致广大而尽精微，其中有值得我们发扬光大的优秀因素，也有需要着力克服的消极因素。其中，小农文化根植于自给自足的<a href="http://m.so.com/s?q=%E5%B0%8F%E5%86%9C%E7%BB%8F%E6%B5%8E&amp;src=newstranscode" class="qkw">小农经济</a>和社会结构，以其自给性、孤立性和封闭性滋养出皇权心理;以其阶级依附性和自我安全性支撑着皇权倾向;同时，中国封建社会讲求道统的文化形态名为伦理主义，实为等级主义;名为人伦本位，实为皇权本位。正如马克思对小农文化的描绘:“小农彼此之间只存在地域的联系，他们利益的统一性并不使他们彼此形成共同关系”，“他们不能代表自己，一定要别人代表自己。他们的代表同时是他们的主宰，是高高站在他们上面的权威。”[2]567</p><p>中国社会主义制度的建立，表明我们跨越了资本主义制度的卡夫丁峡谷，但与此同时也表明我们将面临如何摆脱文化滞后的历史难题。这种跨越导致新建立的社会必然承担着文化建设的双重任务，既要摆脱封建小农文化，又要避免陷入资本主义文化陷阱。从新中国成立以来的文化实践来看，我们在抵御资本主义文化侵蚀方面花了很大力气，但是在改造小农文化方面相对显得不足。以<a href="http://m.so.com/s?q=%E9%A9%AC%E5%85%8B%E6%80%9D%E4%B8%BB%E4%B9%89&amp;src=newstranscode" class="qkw">马克思主义</a>为指导的社会主义新文化的大众影响力还有待提升，缺少对小农文化的理性批判与积极扬弃，小农文化以其自身的传承性、民族心理的惯性仍然潜移默化地影响着当代中国人的思维方式和行为习惯。</p><p>人们都生活在一定的文化传统之中，党员干部也不例外。小农文化对于一些党员干部的影响，主要表现为以家长制作风行权，以皇权式思维来认知自己。全国政协常委、九三学社中央副主席<a href="http://m.so.com/s?q=%E8%B5%96%E6%98%8E&amp;src=newstranscode" class="qkw">赖明</a>对此深有感触--“经常听到有的地方领导干部在讲话、发言或作报告时说，‘我的人口’多少、‘我的GDP’多少、‘我的财政收入’多少，所言‘我的’意指他所在‘某市的’‘某县的’或‘某乡的’，似有一种‘老子天下第一’之霸气，让听者倍觉不爽”[5]。这种将国家、人民隶属于“我的”的小农意识危害是潜在的，也是深远的。这些人平时习惯于摆官架、说官话，“父母官”架势十足。给群众的感觉是“门难进、脸难看、话难说、事难办”。这种干群位置的颠倒，很容易导致党员干部做事虚于形式，下基层也是走马观花，热衷于“四个轮子转、隔着玻璃看”。</p><p>(三)由市场经济发育不完善导致的资源配置特权</p><p>市场经济本身并不是一种社会制度。作为一种经济体制或者资源配置机制，它往往依附于一定的社会制度，并因此表现出不同的色泽。市场经济的西方实践证明了其在资源配置方面虽有效，但并不完美。资本主义市场经济基于商品交换原则，崇尚差异，重视效率，因此，商品价值规律的分化作用必然导致贫富分化。有学者在文中提到，“市场并不必然能够带来公平的收入分配。市场经济可能会产生令人难以接受的收入水平和消费水平的巨大差异”[6]。</p><p>市场经济与社会主义能否结合，长期以来一直是国际学术界争论的焦点。丹麦学者克里斯滕森认为:“市场经济与社会主义的结合变成无法想象的事情。市场经济往往被视为社会主义的威胁。”[7]根据社会主义市场经济体制设计的初衷，社会主义保障公平，市场经济体现效率，二者的结合将实现公平与效率。一方面，社会主义对市场经济起着一定的规范与引导作用，确实在一定程度上具有公平的价值导引作用;另一方面，市场经济对社会主义也发挥着一定的浸染与牵制作用，它根据强大的市场逻辑去影响社会主义的表现形式。从实际运行看，社会主义市场经济确实发挥了巨大的制度潜能，对中国经济社会发展发挥了重要影响。但是，社会主义与市场经济之间并未度过“婚姻磨合期”，二者之间的适应仍然存在很大的问题，个性冲突表现得非常充分。例如，社会主义提倡集体主义，市场经济奉行个人主义;社会主义提倡奉献精神，市场经济奉行利益原则。在这种情况下，政府与市场在资源配置问题上的关系看似不难理解，实则关系微妙。一些党政干部手中掌握着政府的资源配置权力，在市场中寻租。结果出现了大量的官商勾结现象，大大加剧了贫富分化。“官僚与资本的共谋导致了不公平竞争，使财富与勤劳、智慧这些传统美德关系不大，而更多来自权力和剥削”[8]。以权谋私，贪污腐败，极端情况下导致群众性事件不断发生，使得党群底线被严重践踏。近些年来，“征地”、“拆迁”事件在网络上频繁曝光，引起社会极大关注，凸显了干群关系的紧张。这些情况的出现表明，在一些地方和一些领域，社会主义的公益性因素趋减，群众对社会主义的认同度降低，群众的主体地位趋于虚化。在市场监管不严的情况下，一些干部利用政策漏洞，低价变卖国家财产，从中谋取个人暴利抑或暗中扶植垄断企业，分享垄断利润，造成国有资产的大量流失。</p><p>(四)由用人体制的短板导致的考核机制的漏洞</p><p>干部的选用在政治建设中具有重要作用，如<a href="http://m.so.com/s?q=%E4%B9%A0%E8%BF%91%E5%B9%B3&amp;src=newstranscode" class="qkw">习近平</a>所言:“用一贤人则群贤毕至，见贤思齐就蔚然成风。”[9]因此，选人用人，必然有一套行之有效的考核评估机制，优则善，短则漏。</p><p>由于中国传统社会有着深厚的人情传统，显现“差序格局”[10]，加上社会生活中的等级序列、官本位文化影响，以及市场交易原则的无形渗透，干部考核的公平性面临着巨大的挑战。这主要表现在:从考核程序上看，虽然出台了条例性的刚性约束，但是“隐规则”严重地干扰着“显制度”，结果出现了诸如形式上走程序、暗地里走关系，先预定人选、再制定标准等现象。从考核规则上看，“上级说了算”的考核办法，使得选拔范围有限，论资排辈问题突出。从考核指标上看，重“显性”指标，轻“隐性”内涵，结果导致以“GDP”论英雄。在干部的监督制约上，由于实际上往往要靠由上而下的监督，这容易让一些领导干部搞一堂言、搞官僚作风，忽视基层意见和群众诉求，由此导致党群关系疏离。</p><p>(五)由长期执政的惰性导致的精神懈怠的危险</p><p>1945年，民主人士黄炎培到延安考察，在与毛泽东的“窑中对”中谈到“其兴也勃焉，其亡也忽焉”的历史周期律问题。从历史与现实来说，“窑中对”的忧虑与警示显得非常必要。中国封建王朝的兴衰、治乱更迭的历史，苏联解体、东欧剧变的教训，无不证明了“打江山难，坐江山更难”的深刻道理。</p><p>中国共产党成为执政党已经历经六十多个春秋，积累了丰富的执政经验，也取得了瞩目的执政成果。当今，面对和平环境带来的安全感，面对中国经济社会发展带来的成就感，一些党员干部滋生了执政惰性，凸显精神懈怠。在群众路线教育实践活动中，一些领导干部的精神懈怠突出表现为:思想空洞，对理论学习毫无兴趣，孤陋寡闻却怡然自得，对新事物熟视无睹，缺少创新;行动慵懒，办事奉行不作为，执行政策照本宣科，对人民诉求充耳不闻，缺少担当;甘于平庸，做事瞻前怕后、安于现状、明哲保身，缺少活力;生活奢靡，热衷于走秀过场，盲目攀比，“四风”问题突出，缺少责任;纪律松弛，讲究“上有政策，下有对策”，只要集中不讲民主，权大于法，缺少制约。近年来，中央一直将精神懈怠危险放置“四大危险”第一位，足以体现出消除精神懈怠的现实紧迫性。</p><p class="header">二、群众路线实践困境的破解之道</p><p>群众路线实践中面临的诸多问题，严重影响到群众路线的实施效果，成为践行群众路线的绊脚石。要走出群众路线的实践困境，必须从多方面发力。</p><p class="header">(一)确立群众本体，疏通民主渠道</p><p>马克思曾说:“‘思想’一旦离开‘利益’，就一定会使自己出丑。”[3]286加强社会整合，首先在于利益整合。消解英雄主义幻想，关键在于对利益进行合理布置。由此，建立有效的利益表达机制、合理的分配机制，成为利益整合的客观要求。恩格斯认为，历史的最终结果“总是从许多单个的意志的相互冲突中产生出来，而其中每一个意志，又是由于许多特殊的生活条件，才能成为它所成为的那样。这样就有无数互相交错的力量，有无数个力的平行四边形，由此产生出一个合力，即历史结果”[11]。就此而论，领导干部在推动地方经济社会发展过程中的确发挥着重要作用。然而，他们也只是“许多”中微不足道的极少部分，社会发展的主体力量在于人民大众。更有甚者，如果他们的决断与人民大众意志相左，那么对社会发展发挥的就不是推力，而是阻力了。</p><p>消解领导干部的个人英雄主义意识，必须确立群众本体。领导干部要清醒认识到历史由人民来创造，权力来自人民。领导干部不管职位高低，权力大小，都是人民公仆，都要有“俯首甘为孺子牛”的责任意识。要以人民群众这把尺子来衡量自己，增进群众感情，拉近群众距离，切实解决好“为了谁”“依靠谁”“我是谁”的问题。确立群众本体，必须积极发挥民主渠道，回应群众利益诉求。民主是社会主义的本质特征和内在要求。要健全民主制度，落实民主程序，积极实施民主选举、民主决策、民主管理、民主监督，确保社会活力和社会稳定。民主渠道的畅通，下能体现民意，上能警示干部，有利于形成双向监督机制，使党员干部摆脱官僚作风。</p><p class="header">(二)改造小农意识，培育核心价值观</p><p>改造小农意识，需要理性审视中国传统文化，分清传统文化的立与破。立，就是肯定传统文化之精华，诸如“讲仁爱、重民本、守诚信、崇正义、尚和合、求大同”[12]等优秀因子，亟待我们去推广普及、发扬光大;破，就是破除传统文化之糟粕，诸如小农文化思维、皇权等级崇拜、“三纲五常”之教化。历史地看，中国传统文化毕竟是在农耕文明时代和小农经济、宗法制度环境下逐渐形成和发展起来的，不可避免地带有不同时代和提出者阶级地位的烙印，存在着一定的历史局限性，在一些方面不能适应当前现代化建设、民主法治进程和民族复兴大业的现实要求。因此，必须站在时代的和历史的高度，对它加以细心清洗和现代转换，才能使之在中国梦的伟大实践中焕发出新的生机。实施这项宏大的工程，需要有科学的方法论指导。习近平指出:“要继承和弘扬我国人民在长期实践中培育和形成的传统美德，坚持马克思主义道德观、坚持社会主义道德观，在去粗取精、去伪存真的基础上，坚持古为今用、推陈出新，努力实现中华传统美德的创造性转化、创新性发展。”[13]如何使中华民族最基本的文化基因与当代文化相适应、与现代社会相协调，从而实现“创造性转化、创新性发展”，是一项重大的历史课题[14]。</p><p>“中国传统文化中有宝贵的民本思想，提倡统治者‘爱民’、‘惠民’，但这归根到底是站在统治者的立场上来考虑问题的。可以说，维护君主统治及相应的宗法制度，是它的主要价值目标。宗法制度必然衍生出等级制、家长制和人治传统”。“很显然，这与现代社会的平等观念、民主精神和法治要求格格不入。当代中国社会所追求的和谐，是以最广大人民的根本利益为出发点和落脚点的、是建立在民主法治和公平正义基础之上的”[15]。<a href="http://m.so.com/s?q=%E7%A4%BE%E4%BC%9A%E4%B8%BB%E4%B9%89%E6%A0%B8%E5%BF%83%E4%BB%B7%E5%80%BC%E8%A7%82&amp;src=newstranscode" class="qkw">社会主义核心价值观</a>的提出既是对社会主义全面认识的体现，也是社会主义先进文化的凝练与表达;既能给领导干部以思想指导，也能增强人民群众的主体意识和自我认知能力。这既是对小农文化的颠覆，也是社会主义新文化的核心。在核心价值观的培育中，既要立足于中国传统文化，固其根，守其脉，推陈出新;又要借鉴外来文化，辨其真，取其精，为我所用。在传播方面，要运用大众话语、教育引导、舆论宣传、文化熏陶、实践践行、制度保障等，使核心价值像空气一样无处不在。</p><p>(三)完善市场体制，消除资源配置特权</p><p>市场经济与群众路线的目的指向并不总是相互一致，要做好二者之间的协调，既发挥市场在资源配置中的决定作用，又能与群众路线的目的指向和社会主义本质相协调。</p><p>1.完善市场经济体制。当前，市场经济体制总体框架已经生成，基本上形成了以公有制为主体的多种所有制结构，基本建立起市场经济的市场体制、金融体制和财政体制，形成了现代企业制度。但是，市场经济本身的限制性因素与一些党员干部自利性干涉，使得进一步完善市场经济运行体制、限制和规范行政权力在资源配置中的作用，成为必然之选。2015年3月，中共中央办公厅、国务院办公厅印发《关于推行地方各级政府工作部门权力清单制度的指导意见》。这表明，建立权力清单、责任清单制度，探索政务公开透明运行机制，从源头上消除资源配置特权、预防腐败，已经成为社会共识和制度实践。</p><p>2.统筹目的与手段。目的需要手段实现，微观需要宏观指导;但手段有其自身特点，宏观也不能替代微观。如果任由市场经济手段自发作用，那么贫富分化自然会无可避免。因此，既要强调市场经济在资源配置中的决定作用，也要“更好发挥政府作用”。正如习近平在《关于〈中共中央关于全面深化改革若干重大问题的决定〉的说明》中指出:“市场在资源配置中起决定性作用，并不是起全部作用。”[16]可见，群众路线目的实现需要市场经济来支撑，宏观调控也要有微观活力。要使双方相互促进，也要设有一定的界限，归市场的应交由市场，归政府的应交给政府;各就其位、各安其职，方能以手段促目的、以微观促宏观，最终通达共同富裕。</p><p class="header">(四)加强制度建设，优化考核体制</p><p>制度建设，突出“刚性”指导。“制度不在多，而在于精，在于务实管用，突出针对性和指导性”[1]。如果空乏无力，难免流于形式，“牛栏关猫是不行的!”因此，“就必须进一步完善干部考评机制，增强干部考评工作的全面性、科学性和针对性，树立正确的用人导向”[17]。</p><p>考核体制关系到人心向背、事业成败。优化考核体制，要以“三严三实”为指导，落实政策，选准干部，实施监管，培养高素质干部人才。同时，要构建简明有效的考核规则。在思想上，重理论，重党性，重品行;在实践上，不惧事，肯干事，干成事。只有如此考核，才能使所选拔的干部在思想上能够“守得住”，在事业上“敢担当”，在行动上“有作为”。</p><p>优化考核体制，要发挥群众监督作用。得民心者得天下，失民心者失天下，要健全人民群众监督机制，警钟长鸣、居安思危、防患未然。群众的眼睛是雪亮的，要畅通建言献策渠道与批评监督渠道，向人民群众多请教，欢迎人民群众举报，并认真听取，合理采纳。“干部业绩在实践，干部名声在民间”。这表明，提高用人的规范化、科学化、透明化，关键在于保证群众参与度、提高参与有效性、保证意见落实性。</p><p class="header">(五)增强忧患意识，保持自身活力</p><p>忧患意识自古有之。孟子曰:“生于忧患，而死于安乐也。”(《孟子·告子下》)此后，忧患意识逐渐成为中国传统文化的优秀因子，也是历代圣贤的一种自觉情怀。“四风”的形成与执政惰性关系甚大，群众路线总要求无疑要干部洗涤尘污，清醒头脑，加强忧患意识，做到“为之于未有，治之于未乱”(《老子·六十四章》)。当前，面临国际国内复杂形势，增强忧患意识，提高思想认识，将有助于推动群众路线的深入发展。由此，习近平强调“空谈误国，实干兴邦”;提出“在前进道路上，我们一定要坚持从维护最广大人民根本利益的高度，多谋民生之利，多解民生之忧，在学有所教、劳有所得、病有所医、老有所养、住有所居上持续取得新进展”[18];力主全面从严治党，<a href="http://m.so.com/s?q=%E5%8A%A0%E5%BC%BA%E5%85%9A%E7%9A%84%E5%85%88%E8%BF%9B%E6%80%A7%E5%BB%BA%E8%AE%BE&amp;src=newstranscode" class="qkw">加强党的先进性建设</a>，大力防腐、拒腐防变，体现了他的忧国情怀、忧民意识、忧党意识。</p><p>党员干部有无群众观点，不仅是一个世界观、历史观问题，还是一个党性问题。党的作风就是党的形象，关系人心向背，关系党的生死存亡。当前，我们必须“深刻认识‘四大考验’的长期性和复杂性，深刻认识‘四种危险’的尖锐性和严峻性，深刻认识增强‘四自能力’的重要性和紧迫性”[19]。因此，必须加强作风建设，风清则气正，气正则心齐，心齐则事成。</p><p>中国共产党有着丰富的治惰经验，必须加以认真总结、有效利用。首先，要发挥批评与自我批评的优良传统，查摆问题、深挖问题、自我剖析、开诚布公。做到查摆问题不隐瞒，深挖问题重根源，自我剖析要深刻，开诚布公不留面，脱去“隐身衣”，捅破“窗户纸”。其次，要广泛开展民主生活会和组织生活会。敢于揭短亮丑、毫不作假、点准穴位，要使政治生活受到锻炼、思想受到洗礼、灵魂受到触动。再次，要广泛开展教育活动，做到“必须突出重点、聚焦问题;必须领导带头、以上率下;必须以知促行、以行促知;必须严字当头、从严从实;必须层层压紧、上下互动;必须相信群众、敞开大门”[20]。</p><p>[1]习近平.在党的群众路线教育实践活动总结大会上的讲话[N].<a href="http://m.so.com/s?q=%E4%BA%BA%E6%B0%91%E6%97%A5%E6%8A%A5&amp;src=newstranscode" class="qkw">人民日报</a>，2014~10~09.</p><p>[2]<a href="http://m.so.com/s?q=%E9%A9%AC%E5%85%8B%E6%80%9D%E6%81%A9%E6%A0%BC%E6%96%AF%E6%96%87%E9%9B%86&amp;src=newstranscode" class="qkw">马克思恩格斯文集</a>:第2卷[M].北京:<a href="http://m.so.com/s?q=%E4%BA%BA%E6%B0%91%E5%87%BA%E7%89%88%E7%A4%BE&amp;src=newstranscode" class="qkw">人民出版社</a>，2009.</p><p>[3]马克思恩格斯文集:第1卷[M].北京:人民出版社，2009.</p><p>[4]马克思恩格斯全集:第46卷，上[M].北京:人民出版社，1979:104.</p><p>[5]赖明.官员说话不宜称“某地的”为“我的”[N].<a href="http://m.so.com/s?q=%E5%85%89%E6%98%8E%E6%97%A5%E6%8A%A5&amp;src=newstranscode" class="qkw">光明日报</a>，2014~10~08.</p><p>[6][美]保罗·萨缪尔森，<a href="http://m.so.com/s?q=%E5%A8%81%E5%BB%89%C2%B7%E8%AF%BA%E5%BE%B7%E8%B1%AA%E6%96%AF&amp;src=newstranscode" class="qkw">威廉·诺德豪斯</a>.经济学:第19版[M].萧琛，译.北京:商务印书馆，2012:62.</p><p>[7][丹]尼斯·克里斯腾森.社会主义与市场经济的一体化[J].赵慧广，译.<a href="http://m.so.com/s?q=%E9%A9%AC%E5%85%8B%E6%80%9D%E4%B8%BB%E4%B9%89%E4%B8%8E%E7%8E%B0%E5%AE%9E&amp;src=newstranscode" class="qkw">马克思主义与现实</a>，2008，(6):74.</p><p>[8]赵汀阳.改革:怨恨挡不住诱惑[J].商务周刊，2008，(5):41.</p><p>[9]习近平.建设一支宏大高素质干部队伍[EB/OL].新华网，2013~06~29，http://news.xinhuanet.com/politics/2013~06/29/c_116339948.htm.</p><p>[10]费孝通.乡土中国[M].上海:上海世纪出版集团，2007:23.</p><p>[11]马克思恩格斯文集:第10卷[M].北京:人民出版社，2009:593.</p><p>[12]习近平.把培育和弘扬社会主义核心价值观作为凝魂聚气强基固本的基础工程[N].人民日报，2014~02~26.</p><p>[13]习近平.建设社会主义文化强国 着力提高国家文化软实力[N].人民日报，2014~01~01.</p><p>[14]孙来斌.中国梦的精神滋养和文化追求[EB/OL].光明网，2014~09~17，http://theory.gmw.cn/2014~09/17/content_13259553.htm.</p><p>[15]孙来斌.中国传统和谐思想与构建社会主义和谐社会[J].岭南学刊，2007，(6):71.</p><p>[16]习近平.关于《中共中央关于全面深化改革若干重大问题的决定》的说明[N].光明日报，2013~11~16.</p><p>[17]杨守鸿，徐鲲，梅哲.深入贯彻群众路线教育实践活动的机制创新研究[J].探索，2014，(1).</p><p>[18]习近平.全面贯彻落实党的十八大精神要突出抓好六个方面工作[J].求是，2013，(1):6.</p><p>[19]中共浙江省委党的群众路线教育实践活动领导小组.作风建设是群众路线的基础工程[N].人民日报，2014~08~06.</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://orig.cssn.cn/zzx/zggcd_zzx/201603/t20160310_2915315.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='5af1b60741f5b1330cf24f30db8857c6'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>深奥莫测</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '群众路线面临的实践困境及破解路径' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '群众路线面临的实践困境及破解路径'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";