s:14659:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>北京喜迎第四届"世界网球日"- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">北京喜迎第四届"世界网球日"</h1> <p id="source-and-time"><span id=source>中国广播网</span><time id=time>2016-03-08 20:29:00</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t0130d104f5d1047c6c.jpg?size=1000x667"></p><p><img src="http://p35.qhimg.com/t0156b7851c3af97ded.jpg?size=1000x667"></p><p>央广网北京3月8日消息(记者 王延辉)为响应国际网联的号召，由国际网联主办，<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E7%BD%91%E7%90%83%E5%8D%8F%E4%BC%9A&amp;src=newstranscode" class="qkw">中国网球协会</a>协办，北京比格文化传播有限公司全程运营推广的的大型网球公益活动第四届“<a href="http://m.so.com/s?q=%E4%B8%96%E7%95%8C%E7%BD%91%E7%90%83%E6%97%A5&amp;src=newstranscode" class="qkw">世界网球日</a>”今天(8日)在<a href="http://m.so.com/s?q=%E5%8C%97%E4%BA%AC%E6%95%99%E8%82%B2%E5%AD%A6%E9%99%A2%E9%99%84%E5%B1%9E%E4%B8%AD%E5%AD%A6&amp;src=newstranscode" class="qkw">北京教育学院附属中学</a>举办，参与学生人数达百余名， “世界网球日”活动会旨在响应全国青少年阳光体育，增强青少年儿童体质，全面发展青少年综合素质;增加网球运动的影响力，从而增加青少年学生的网球人口，为中国网球事业提供坚实后备力量，全面发展中国网球事业。</p><p>为了让学生更深入的了解网球、了解网球文化，丰富校园网球生活和活动内容。活动主办方组织举办了以“网球，健康生活方式”为主题的短文大赛和书画大赛。活动将评选出短文大赛冠军和书画大赛冠军各一名，并在世界网球日当天颁发冠军奖杯。本次活动主办方推出了“大白”、“小黄人”、“功夫熊猫”、“恐龙”等吉祥物跟学生互动，还特意组织了网球球感培养游戏 ，网<a href="http://m.so.com/s?q=%E7%90%83%E6%93%8D&amp;src=newstranscode" class="qkw">球操</a>表演环节更是把本次活动推向了最高潮。</p><p>全球范围内发展并推广网球运动，进一步的增加网球人口，让更多的人打网球，让更多的人都参与到网球的发展和建设中来，提高网球在中国的蓬勃发展，通过网球这项运动提高全民的综合素质。</p><p>世界网球日诞生于2013年，当年国际网联与星空公司宣布“世界网球日”正式在全球范围内启动，这一天不同国家通过不同方式，组织了大大小小的<a href="http://m.so.com/s?q=%E8%A1%A8%E6%BC%94%E8%B5%9B&amp;src=newstranscode" class="qkw">表演赛</a>或各类庆祝活动，众多的参与者中有顶尖的球员、也有来自世界各地的<a href="http://m.so.com/s?q=%E7%BD%91%E7%90%83%E7%88%B1%E5%A5%BD%E8%80%85&amp;src=newstranscode" class="qkw">网球爱好者</a>，每个人用自己的实际行动表达对网球的热爱、支持，第一年的参与国家和地区多达60个。2014年和2015年该活动连续两次在<a href="http://m.so.com/s?q=%E5%8C%97%E4%BA%AC%E5%B8%82%E9%93%81%E8%B7%AF%E7%AC%AC%E4%BA%8C%E4%B8%AD%E5%AD%A6&amp;src=newstranscode" class="qkw">北京市铁路第二中学</a>举行，受到了中国球迷的追捧和支持，参与活动的学生和社会人士都说将投入到网球运动中来。2015年全球总共有120余个国家和地区举行了世界网球日的庆祝活动。</p><p>编辑:付若愚</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://china.cnr.cn/gdgg/20160308/t20160308_521565595.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='febdd05bb6c05a88bbd185d2840c685e'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>北京市第四中学</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%8C%97%E4%BA%AC%E5%B8%82%E7%AC%AC%E5%9B%9B%E4%B8%AD%E5%AD%A6&amp;pn=1&amp;pos=6&amp;m=a415d9ccf6db445c3c777fe191866b3f4effc636&amp;u=http%3A%2F%2Fwww.ce.cn%2Fxwzx%2Fgnsz%2Fgdxw%2F201603%2F09%2Ft20160309_9377220.shtml" data-pos="1"> <b>北京</b>四中校长回应天价学区房:我不会干 </a>   <li> <a href="/transcode?q=%E5%8C%97%E4%BA%AC%E5%B8%82%E7%AC%AC%E5%9B%9B%E4%B8%AD%E5%AD%A6&amp;pn=1&amp;pos=7&amp;m=8dd7d71ca29b1d647cfa9a03bad8aae04c3cd9bc&amp;u=http%3A%2F%2Fnews.cnr.cn%2Fnative%2Fgd%2F20160309%2Ft20160309_521573040.shtml" data-pos="2"> <b>北京</b>名校校长谈择校热:我不会买天价学区房 </a>   <li> <a href="/transcode?q=%E5%8C%97%E4%BA%AC%E5%B8%82%E7%AC%AC%E5%9B%9B%E4%B8%AD%E5%AD%A6&amp;pn=1&amp;pos=8&amp;m=dfd8219208570ec8cb61919b764b2f80c87cdb3c&amp;u=http%3A%2F%2Fnews.youth.cn%2Fjsxw%2F201603%2Ft20160309_7722788.htm" data-pos="3"> <b>北京</b>四中校长:我不会买学区房 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '北京喜迎第四届"世界网球日"' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '北京喜迎第四届"世界网球日"'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";