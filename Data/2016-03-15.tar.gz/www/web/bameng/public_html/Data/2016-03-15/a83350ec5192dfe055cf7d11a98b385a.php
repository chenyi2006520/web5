s:18292:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>在福州，有一家来自爱琴海的地道土耳其餐厅。- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">在福州，有一家来自爱琴海的地道土耳其餐厅。</h1> <p id="source-and-time"><span id=source>搜狐</span><time id=time>2016-03-14 18:48:39</time></p> </header>  <div id="news-body"><p>在福州，有这样一家地道的<a href="http://m.so.com/s?q=%E5%9C%9F%E8%80%B3%E5%85%B6&amp;src=newstranscode" class="qkw">土耳其</a>餐厅，让人不必漂洋过海，在家门口就可品尝正宗的来自爱琴海岸的美味，这就是<a href="http://m.so.com/s?q=%E9%98%BF%E6%8B%89%E4%B8%81&amp;src=newstranscode" class="qkw">阿拉丁</a>土耳其餐厅!</p><p><img src="http://p32.qhimg.com/t011b0d21b3461063d5.jpg?size=600x459"></p><p class="img-title">环境</p><p class="header">Environment</p><p class="header">店面装饰为地中海风格，清新漂亮，</p><p>手绘壁画带来清新的<a href="http://m.so.com/s?q=%E7%88%B1%E7%90%B4%E6%B5%B7&amp;src=newstranscode" class="qkw">爱琴海</a>风情。</p><p><img src="http://p32.qhimg.com/t019f463559d518eb57.jpg?size=600x204"></p><p class="img-title">餐厅的装饰无处不体现土耳其的特色</p><p class="header">美丽的吊灯、郁金香纸巾、精致的餐盘</p><p class="header">还有代表幸运的蓝眼睛</p><p><img src="http://p32.qhimg.com/t01d5a1b174d751779c.jpg?size=600x300"></p><p><img src="http://p34.qhimg.com/t01c31c0aedc27ddb37.jpg?size=600x400"></p><p class="img-title">美食</p><p class="header">Food</p><p><img src="http://p34.qhimg.com/t01d6981350feea08cd.jpg?size=600x400"></p><p><a href="http://m.so.com/s?q=%E5%9C%9F%E8%80%B3%E5%85%B6%E7%83%A4%E8%82%89&amp;src=newstranscode" class="qkw">土耳其烤肉</a>:土耳其很多美食都很出名，尤其是闻名遐迩的土耳其烤肉，一进店就感受到其香飘四溢。</p><p><img src="http://p34.qhimg.com/t01ada8d4bd566752f7.jpg?size=600x400"></p><p>SALAD:与其他的西餐厅不同，阿拉丁的这款<a href="http://m.so.com/s?q=%E6%B2%99%E6%8B%89&amp;src=newstranscode" class="qkw">沙拉</a>选用的是土耳其橄榄和奶酪，味道上有着浓浓的爱琴海风情!</p><p><img src="http://p32.qhimg.com/t01947eb11dd02a4ead.jpg?size=600x400"></p><p>土耳其特色牛肉:这道菜据说是老板的最爱。手打的牛肉配上特色的土耳其米饭和薯球，不论分量或是口味都十分丰富。</p><p><img src="http://p31.qhimg.com/t01f7c28b82b5742013.jpg?size=600x400"></p><p>土耳其<a href="http://m.so.com/s?q=%E7%83%A4%E7%89%9B%E8%82%89%E5%8D%B7&amp;src=newstranscode" class="qkw">烤牛肉卷</a>:肉食控不可错过的菜品，<a href="http://m.so.com/s?q=%E8%96%84%E8%84%86&amp;src=newstranscode" class="qkw">薄脆</a>的卷饼配上正宗的土耳其烤肉，一口咬下去满口的异域风味，仿佛瞬间来到了安卡拉的街头!</p><p><img src="http://p34.qhimg.com/t01c6f77bee1c4778b0.jpg?size=480x720"></p><p>特色土耳其汤:十分美味，红豆汤香浓四溢，<a href="http://m.so.com/s?q=%E7%BE%8A%E8%82%9A%E6%B1%A4&amp;src=newstranscode" class="qkw">羊肚汤</a>酸爽可口，开胃又营养。</p><p><img src="http://p33.qhimg.com/t01198197665197f0b5.jpg?size=600x400"></p><p><a href="http://m.so.com/s?q=%E5%9C%9F%E8%80%B3%E5%85%B6%E9%B9%B0%E5%98%B4%E8%B1%86&amp;src=newstranscode" class="qkw">土耳其鹰嘴豆</a>泥:把鹰嘴豆磨成豆蓉，浇上芝士酱，淋上<a href="http://m.so.com/s?q=%E6%A9%84%E6%A6%84%E6%B2%B9&amp;src=newstranscode" class="qkw">橄榄油</a>，再配上特制的东方香料混合而成。<a href="http://m.so.com/s?q=%E8%B1%86%E6%B3%A5&amp;src=newstranscode" class="qkw">豆泥</a>的味道酸中带咸，醇和甘香，十分独特。</p><p><img src="http://p31.qhimg.com/t01cb76959a36054bb7.jpg?size=600x400"></p><p><img src="http://p33.qhimg.com/t018a6a2f1d562d6b69.jpg?size=600x400"></p><p>综合烤肉:这是新推出的菜品!里面有<a href="http://m.so.com/s?q=%E7%BE%8A%E6%8E%92&amp;src=newstranscode" class="qkw">羊排</a>、龙利鱼排、鸡排以及番茄青椒等，配料十足，绝对满足你的“肉欲”!</p><p><img src="http://p33.qhimg.com/t01b41c5bc3d1b6b81a.jpg?size=600x400"></p><p><a href="http://m.so.com/s?q=%E8%91%A1%E8%90%84%E5%8F%B6%E5%8D%B7&amp;src=newstranscode" class="qkw">葡萄叶卷</a>:十分独特，扎好的叶子蘸上<a href="http://m.so.com/s?q=%E9%85%B1%E6%B1%81&amp;src=newstranscode" class="qkw">酱汁</a>整个吃下，口味别具一格。</p><p><img src="http://p34.qhimg.com/t011547731870f6bb7d.jpg?size=600x400"></p><p>土耳其芝士<a href="http://m.so.com/s?q=%E8%96%84%E9%A5%BC&amp;src=newstranscode" class="qkw">薄饼</a>:松软可口</p><p><img src="http://p33.qhimg.com/t01e2f4580f6fdee577.jpg?size=480x720"></p><p>土耳其<a href="http://m.so.com/s?q=%E9%85%B8%E5%A5%B6&amp;src=newstranscode" class="qkw">酸奶</a>:与我们平时遇到的酸奶不同，土耳其酸奶分甜咸两味，口感稀而爽口，很像是饮料。</p><p><img src="http://p31.qhimg.com/t01886ef343f3a2d0ab.jpg?size=480x720"></p><p><img src="http://p32.qhimg.com/t01209029e7b20ce3ec.jpg?size=600x400"></p><p><a href="http://m.so.com/s?q=%E7%94%9C%E5%93%81&amp;src=newstranscode" class="qkw">甜品</a>:除了特色地道的土耳其菜品，阿拉丁的甜品也很棒。棉花糖酸奶清甜可口，米香<a href="http://m.so.com/s?q=%E7%89%9B%E5%A5%B6%E7%BE%B9&amp;src=newstranscode" class="qkw">牛奶羹</a>浓郁香醇，搭配土耳其米制作而成，口味更加别致。</p><p>橄榄油:阿拉丁如此地道的美味，除了大厨地道的烹制之外，更离不开这款来自土耳其当地的橄榄油。店内的沙拉及菜品都是使用进口的土耳其橄榄油，不仅保证了口味的纯正，也使得菜品更加健康营养!</p><p class="header">总结</p><p class="header">Summary</p><p>很惊喜地发现在福州居然可以吃到正宗的土耳其美食，不用远赴爱琴海，在家门口就可以感受浓浓的异域风情。阿拉丁土耳其餐厅，菜品口味纯正，食材新鲜健康，人均消费一百元左右。如果想要品味一下不一样的土耳其美食，可以去试试看!</p><p><img src="http://p35.qhimg.com/t01c29dadbf339e0c9f.jpg?size=480x720"></p><p class="img-title">地址:五四路信和广场一楼大堂内</p><p>停车:地下停车场方便停车，店内消费可提供停车票</p><p class="header">(图/文:李先森 排版:21°蓝)</p><p class="header">小编帮你来挑食</p><p>不知道去哪里吃饭好?可以直接将问题发送到“福州美食圈”微信公众平台，小编将会在工作时间内(周一至周五9:00-18:00)帮你挑出最适合的餐厅!</p><p>PS:问题请尽量体现所要用餐的人数、美食菜系种类以及能接受的人均价格!</p><p class="header">例如:</p><p>2个人，消费不超过300，吃牛排哪里好?</p><p class="header">公司聚餐，想吃海鲜，哪里性价比高?</p><p class="header">发现好的生活|做有态度的媒体</p><p><a href="http://m.so.com/s?q=%E5%BE%AE%E4%BF%A1&amp;src=newstranscode" class="qkw">微信</a>ID:fzbmms 广告:微信nss333333</p><p>长按二维码关注 福州美食圈</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://chihe.sohu.com/20160314/n440415418.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='019d383d11d5362b40d139110e71d34b'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>爱琴海</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%88%B1%E7%90%B4%E6%B5%B7&amp;pn=1&amp;pos=7&amp;m=db8f8e1c5518f2a2464b6469a7609da8f851c6f6&amp;u=http%3A%2F%2Fcul.china.com.cn%2Fcswh%2F2016-03%2F07%2Fcontent_8618311.htm" data-pos="1"> <b>爱琴海</b>难民船倾覆18人死 去年超3000难民在海域中丧生 </a>   <li> <a href="/transcode?q=%E7%88%B1%E7%90%B4%E6%B5%B7&amp;pn=1&amp;pos=8&amp;m=6c3d3b63c6c45c97adbbf781c78690d75357ac55&amp;u=http%3A%2F%2Fnews.gmw.cn%2F2016-03%2F10%2Fcontent_19235951.htm" data-pos="2"> 土希表示坚决阻止非法移民偷渡<b>爱琴海</b> </a>   <li> <a href="/transcode?q=%E7%88%B1%E7%90%B4%E6%B5%B7&amp;pn=1&amp;pos=9&amp;m=b778224ded78197d7a23f0ec19f133f118362ee9&amp;u=http%3A%2F%2Fintl.ce.cn%2Fqqss%2F201603%2F09%2Ft20160309_9381167.shtml" data-pos="3"> 土希两国总理表示坚决阻止非法移民偷渡<b>爱琴海</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '在福州，有一家来自爱琴海的地道土耳其餐厅。' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '在福州，有一家来自爱琴海的地道土耳其餐厅。'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";