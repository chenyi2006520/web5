s:16020:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>程京:染色体遗传病筛查该纳入医保- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">程京:染色体遗传病筛查该纳入医保</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-03-08 16:08:54</time></p> </header>  <div id="news-body"><p>“从1996年至2012年，在全国医疗资源最好的北京市新生儿出生缺陷率从千分之五攀升到了千分之二十，这还不算流动人口，其他地方的情况可想而知”，昨天下午，全国人大代表、<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E5%B7%A5%E7%A8%8B%E9%99%A2%E9%99%A2%E5%A3%AB&amp;src=newstranscode" class="qkw">中国工程院院士</a>、生物芯片北京国家工程研究中心主任<a href="http://m.so.com/s?q=%E7%A8%8B%E4%BA%AC&amp;src=newstranscode" class="qkw">程京</a>在参加北京团审议<a href="http://m.so.com/s?q=%E3%80%8A%E6%94%BF%E5%BA%9C%E5%B7%A5%E4%BD%9C%E6%8A%A5%E5%91%8A%E3%80%8B&amp;src=newstranscode" class="qkw">《政府工作报告》</a>时首先抛出了一组数字，“在单独二孩放开以前，我们的新生儿出生缺陷率只有攀升没有下降，而在出生缺陷防控没有到位之前，我们现在单独二孩又放开，可以预期将会有更多出生缺陷的孩子生下来，因为单独二孩放开以后有很多大龄妇女要生孩子，这是很容易出现的问题。”程京建议，针对出生缺陷防控，国家应对出生缺陷实施精准医疗计划干预，将单基因病、染色体遗传疾病筛查纳入医保。</p><p class="header">北京新生儿筛查</p><p>携带致聋<a href="http://m.so.com/s?q=%E5%9F%BA%E5%9B%A0%E7%AA%81%E5%8F%98&amp;src=newstranscode" class="qkw">基因突变</a></p><p>程京以率先利用<a href="http://m.so.com/s?q=%E7%94%9F%E7%89%A9%E8%8A%AF%E7%89%87%E6%8A%80%E6%9C%AF&amp;src=newstranscode" class="qkw">生物芯片技术</a>进行耳聋基因筛查的北京举例说，四年中北京已经完成83.6万新生儿筛查，“虽然是自愿参与筛查，但北京市民非常拥护，接受检测超过68%，查出来携带致聋基因突变的孩子有38400人，占4.4%，这个比例是非常高的”，程京介绍说，“另外参加筛查的孩子中有130个孩子怀的时候就是聋的，生下来就是听不见的，通过生物芯片技术孩子生下来三天我们就可以发现这种情况，这样就可以及时地帮他恢复听力，可以学说话，长大以后上<a href="http://m.so.com/s?q=%E8%81%8B%E5%93%91%E5%AD%A6%E6%A0%A1&amp;src=newstranscode" class="qkw">聋哑学校</a>，正常就业。四年中全国16个省市效仿北京，目前已经做了130万人次的检测，其中有5万多的孩子是携带这种致聋基因突变的，有3.2万多大人小孩通过生物芯片技术的检测避免了一针致聋成为残疾。”</p><p class="header">生物芯片技术</p><p class="header">可精准预防残疾发生</p><p>“我曾经算过一笔经济账，这些年我们的生物芯片技术累计收入2.4亿，但是通过预防残疾发生，为国家节省了220亿人民币，因为一个人只要残疾国家要支付将近70万。我们现在才做了130万例，如果要放大到全国每年2000万，那是多大的效益。现在全国8000万残疾人中听力残疾就有2000多万，占了20%多。我们算了一下，如果把他们全部治好，我们得花八万亿人民币”。程京介绍说，而且现在不光研制有<a href="http://m.so.com/s?q=%E8%80%B3%E8%81%8B&amp;src=newstranscode" class="qkw">耳聋</a>芯片，还有地中海贫血的芯片，<a href="http://m.so.com/s?q=%E5%9C%B0%E4%B8%AD%E6%B5%B7%E8%B4%AB%E8%A1%80&amp;src=newstranscode" class="qkw">地中海贫血</a>在沿海城市比较高发，有的地方高发率达到25%。但是这个<a href="http://m.so.com/s?q=%E5%9C%B0%E4%B8%AD%E6%B5%B7&amp;src=newstranscode" class="qkw">地中海</a>芯片也跟耳聋芯片一样，面临着批文、医保等很多推广难题。“我们还开发出了一次可以检测509种单基因异常的芯片，比国外最好的芯片多出100种，技术发展到今天中国在有些方面已经很强了，关键是我们的政策如果不到位的话，这些技术就只能是展品”，程京有些痛心地说。</p><p class="header">建议尽快立法</p><p class="header">恢复婚前检查</p><p>为此程京建议，针对出生缺陷防控，国家应对出生缺陷实施精准医疗计划干预，由政府托底，将单基因病、染色体遗传疾病在孕前、产前或者是出生筛查的时候纳入医保。“这个建议我已经呼吁了四年，同时建议尽快立法恢复婚前检查。每次人代会都替孩子们呼吁这个事情，快成‘<a href="http://m.so.com/s?q=%E7%A5%A5%E6%9E%97%E5%AB%82&amp;src=newstranscode" class="qkw">祥林嫂</a>’了”，程京语气中带有一丝无奈地说。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://finance.china.com.cn/industry/medicine/special/dbjyydbwyzth/20160308/3617998.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='ef4fac5fe5ec937a30b0b058c2f547fd'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>遗传病</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%81%97%E4%BC%A0%E7%97%85&amp;pn=1&amp;pos=4&amp;m=49fbce480cca17982f50787eb20b035c67999486&amp;u=http%3A%2F%2Fsports.sina.com.cn%2Ftennis%2Fwta%2F2016-03-09%2Fdoc-ifxqafrm7304917.shtml" data-pos="1"> 莎娃自辩服药为预防家族<b>遗传病</b> 或因此被禁赛4年 </a>   <li> <a href="/transcode?q=%E9%81%97%E4%BC%A0%E7%97%85&amp;pn=1&amp;pos=5&amp;m=6f59b7f8586fd590048490a65d7a63caa6555883&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Fpolitics%2F2016-03%2F07%2Fc_128780324.htm" data-pos="2"> 委员连续呼吁四年 染色体<b>遗传病</b>筛查纳入医保 </a>   <li> <a href="/transcode?q=%E9%81%97%E4%BC%A0%E7%97%85&amp;pn=1&amp;pos=6&amp;m=c2da6b71ade5228cd6f51d8c86f41a16f0dcc9d5&amp;u=http%3A%2F%2Fnews.youth.cn%2Fjsxw%2F201603%2Ft20160307_7714247.htm" data-pos="3"> 委员连续呼吁四年:染色体<b>遗传病</b>筛查纳入医保 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '程京:染色体遗传病筛查该纳入医保' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '程京:染色体遗传病筛查该纳入医保'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";