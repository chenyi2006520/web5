s:16312:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>美国卫星偷拍中国最新地下隧道工程:被眼前一幕彻底惊呆了- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">美国卫星偷拍中国最新地下隧道工程:被眼前一幕彻底惊呆了</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-14 18:59:16</time></p> </header>  <div id="news-body"><p><img src="http://p34.qhimg.com/t01f7fd0d2ffdadd991.jpg?size=640x435"></p><p>图片为本月14日<a href="http://m.so.com/s?q=%E3%80%8A%E8%A7%A3%E6%94%BE%E5%86%9B%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《解放军报》</a>报道中，为中国防核地下国防工程方面做出重大贡献的<a href="http://m.so.com/s?q=%E4%BB%BB%E8%BE%89%E5%90%AF&amp;src=newstranscode" class="qkw">任辉启</a>院士，据该报道称，任辉启院士主要负责中国在上世纪90年代进行的多次地下核试验和地下防核掩体工程，中国在上世纪80年代开始至2012年，曾分三期建设了庞大的“地下核长城”(Underground Great Wall)，即包括5000至5500千米的地下洞库，这其中主要是为东风-21和东风-31系列战略导弹建设的隧道式掩体阵地，而任辉启院士在这些工程中扮演了重要角色，他的研究方向是如何让地下洞库和隧道式掩体阵地能承受核打击。</p><p>【鹰眼图说军事 海外评中国栏目第306期】据悉，中国建造地下核武器洞库主要保护自身核武器的安全和可靠性，中国陆基机动核武器系统是一个通过掩蔽壕沟机动、分散掩体跑道机动、中心车库式机动、越野机动和公路机动相结合的掩体-机动方案。中国火箭军的东风-31A核导弹运输发射车，可连续地和不规律地在各个加固掩体之间的网状隧道中进行机动。</p><p><img src="http://p35.qhimg.com/t011781e744460541d5.jpg?size=640x402"></p><p>图片为<a href="http://m.so.com/s?q=%E4%B8%AD%E5%A4%AE%E7%94%B5%E8%A7%86%E5%8F%B0&amp;src=newstranscode" class="qkw">中央电视台</a>军事频道的新闻报道中，出现的战略导弹地下掩体画面，请注意其地下轨道，美国媒体认为，为了最大限度地发挥其迷惑效果，中国的东风31A导弹运输车往往把真导弹隐藏在掩体里，却带着假导弹进行机动，如果每枚导弹建造20个加固式掩体洞库 (每个掩体就是一个发射点)， 这样部署30枚东风-31A陆基机动导弹就有6000个瞄准点。敌方如果用两个弹头来攻击一个掩体，那就需要耗费12000个核弹头才能将这个核武器系统彻底摧毁，实际上，这已经超出了地球上任何国家具备的核战能力。</p><p>据美国媒体报道，美国在最近几年的卫星照片判读中发射，中国正在扩大自己的“<a href="http://m.so.com/s?q=%E5%9C%B0%E4%B8%8B%E9%95%BF%E5%9F%8E&amp;src=newstranscode" class="qkw">地下长城</a>”工程，该报记者比尔·格茨认为，这确实让人感到震惊，中国正在云南省昆明市市郊、甘肃省<a href="http://m.so.com/s?q=%E5%A4%A9%E6%B0%B4%E5%B8%82&amp;src=newstranscode" class="qkw">天水市</a>和陕西省汉中市附近的山区同时建造大型地下掩体工程，其工程规模是原有“地下长城”工程的数倍，从卫星图片上来看，每枚东风-31A导弹都建造了一个车库式掩体，在以车库掩体为中心 ，某一距离为半径的圆周上等间隔地设置20个左右的加固发射阵地式掩体 , 各掩体与中心洞库都用地下公路相沟通 。</p><p><img src="http://p35.qhimg.com/t0162feec6f3f63d4e2.jpg?size=640x395"></p><p>美国是如何通过卫星图片来分析中国<a href="http://m.so.com/s?q=%E5%9C%B0%E4%B8%8B%E9%9A%A7%E9%81%93&amp;src=newstranscode" class="qkw">地下隧道</a>工程的呢?上图为外媒根据卫星照片推测的中国<a href="http://m.so.com/s?q=%E9%9D%92%E6%B5%B7%E7%9C%81&amp;src=newstranscode" class="qkw">青海省</a>德林哈地区一处长达几百千米的大型导弹洞库群，据了解，所谓美军卫星拍摄中国导弹地下工程，主要是通过对比卫星图片上的山体外部设施，如排气通道、洞口大门、战备<a href="http://m.so.com/s?q=%E8%BF%9E%E6%8E%A5%E5%85%AC%E8%B7%AF&amp;src=newstranscode" class="qkw">连接公路</a>系统等设备，来判读中国导弹基地的内部结构，上图中这个导弹地下工程的外部共有20多处发射阵地，可以辨认出导弹阵地的建设规模和设施水平，小图为中国东风-4导弹在洞库内的轨道上进行发射前转移的画面。</p><p>美国媒体认为，东风-31A导弹平时藏在中心地下洞库内，一旦接到攻击的预警信号 , 就立即高速地开到任意一个发射阵地进行发射。采用这种方案，如果装备100枚导弹，就有14000个瞄准点，这已经超出了地球上任何国家可同时核攻击目标的上限。</p><p>鹰眼图说军事，用图说军事的<a href="http://m.so.com/s?q=%E5%BE%AE%E4%BF%A1&amp;src=newstranscode" class="qkw">微信</a>自媒体，认认真真做军事原创，我们让事实说话，请关注我们的微信公众号:tsjunshi81(长按可复制)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/article/4056383.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='e5fbbdd0dec255942e65fa325cc052b3'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>近日美国</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%BF%91%E6%97%A5%E7%BE%8E%E5%9B%BD&amp;pn=1&amp;pos=9&amp;m=028e3bd524db7c748d7fd4f57e4466e65b811df4&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4056780.html" data-pos="1"> <b>美国</b>曾最看不起中国一种武器:<b>如今</b>中国有希望赶上美20年前水平 </a>   <li> <a href="/transcode?q=%E8%BF%91%E6%97%A5%E7%BE%8E%E5%9B%BD&amp;pn=1&amp;pos=10&amp;m=d907800d0efc0f0285d534114a36edf45b7c0fe2&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4056169.html" data-pos="2"> 解放军当年白手起家:<b>如今</b>已能比肩<b>美国</b>! </a>   <li> <a href="/transcode?q=%E8%BF%91%E6%97%A5%E7%BE%8E%E5%9B%BD&amp;pn=2&amp;pos=1&amp;m=14ba9f31251bd2c464ad2f9d60dfc6b1e21c50f8&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4053936.html" data-pos="3"> 美军曾最看不起中国洲际导弹:<b>如今</b>中国总算成为<b>美国</b>叹服的核大国 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '美国卫星偷拍中国最新地下隧道工程:被眼前一幕彻底惊呆了' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '美国卫星偷拍中国最新地下隧道工程:被眼前一幕彻底惊呆了'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";