s:13977:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>代县聂营村康静中、乔林凤夫妻俩当“羊倌”发羊财- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">代县聂营村康静中、乔林凤夫妻俩当“羊倌”发羊财</h1> <p id="source-and-time"><span id=source>新华网山西频道</span><time id=time>2016-02-26 13:00:30</time></p> </header>  <div id="news-body"><p><img src="http://p34.qhimg.com/t01687c6f249bc60905.jpg?size=610x396"></p><p><a href="http://m.so.com/s?q=%E5%BA%B7%E9%9D%99&amp;src=newstranscode" class="qkw">康静</a>中、乔林凤夫妻俩给肉羊添加饲料</p><p><img src="http://p35.qhimg.com/t01ec942aa690be1b0d.jpg?size=610x405"></p><p>康静中、乔林凤夫妻俩与饲养人员在一起</p><p>农历正月十六，走进<a href="http://m.so.com/s?q=%E4%BB%A3%E5%8E%BF&amp;src=newstranscode" class="qkw">代县</a>聂营镇聂营村的泰福养殖专业合作社，只见圈舍齐整，肉羊满圈，喜气扑面，康静中、乔林凤夫妻俩正繁忙而快乐地给肉羊添加饲料，当“羊倌”为着发羊财。</p><p><img src="http://p35.qhimg.com/t013cd247778efa19d5.jpg?size=610x380"></p><p class="img-title">粉碎玉米秸秆喂肉羊</p><p><img src="http://p32.qhimg.com/t0126d38a1684008f90.jpg?size=602x400"></p><p class="img-title">储备的玉米饲料</p><p>康静中、乔林凤夫妻俩于2012年打定了发羊财的主意，联合全村60户农民共同入股创办了代县泰福养殖专业合作社，投资300万元建起3000平方米的圈舍，并从<a href="http://m.so.com/s?q=%E5%8F%B3%E7%8E%89%E5%8E%BF&amp;src=newstranscode" class="qkw">右玉县</a>引进60只优良杜泊种羊繁育滚动发展，雇用饲养人员10名，现已发展到800多只，去年出售肉羊创收12万元，让入股农民见到了红利。</p><p><img src="http://p34.qhimg.com/t011b7635a631e1b42d.jpg?size=610x405"></p><p class="img-title">开发的流动土地</p><p><img src="http://p35.qhimg.com/t01086a982c6f80bfeb.jpg?size=610x400"></p><p class="img-title">家人对肉羊的呵护</p><p><img src="http://p31.qhimg.com/t014bd66ac5c789a30e.jpg?size=602x400"></p><p class="img-title">夫妻俩与饲养人员合影</p><p>为了解决肉羊的喂养饲料问题，康静中、乔林凤夫妻俩投资26万元流转<a href="http://m.so.com/s?q=%E8%81%82%E8%90%A5%E6%9D%91&amp;src=newstranscode" class="qkw">聂营村</a>农民的150亩河滩地种植玉米，将玉米和秸秆作为肉羊饲料，并每年还要花钱收购本村农民的250亩玉米秸秆加工成饲料，改变了村民焚烧秸秆的恶习。康静中、乔林凤夫妻俩现已成为聂营村带领农民群众<a href="http://m.so.com/s?q=%E8%84%B1%E8%B4%AB%E8%87%B4%E5%AF%8C%E5%A5%94%E5%B0%8F%E5%BA%B7&amp;src=newstranscode" class="qkw">脱贫致富奔小康</a>的“羊老板”。(记者 石俊文 <a href="http://m.so.com/s?q=%E5%88%98%E7%9D%BF&amp;src=newstranscode" class="qkw">刘睿</a>)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.sx.xinhuanet.com/dfzx/2016-02/26/c_1118167847.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='b9f9ad3fd57b82a1170ab5a0acab452b'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>林凤</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9E%97%E5%87%A4&amp;pn=1&amp;pos=2&amp;m=243e7e50437a92ee73a4a30dc9bda1e7baefead3&amp;u=http%3A%2F%2Fwww.sx.xinhuanet.com%2Fdfzx%2F2016-02%2F26%2Fc_1118167847.htm" data-pos="1"> 代县聂营村康静中、乔<b>林凤</b>夫妻俩当"羊倌"发羊财 </a>   <li> <a href="/transcode?q=%E6%9E%97%E5%87%A4&amp;pn=1&amp;pos=3&amp;m=da4de9f3746c1ac7665172d85fd0aec2ca8f00c6&amp;u=http%3A%2F%2Fnews.163.com%2F15%2F0529%2F09%2FAQP9IVIV00014Q4P.html" data-pos="2"> <b>林凤</b>装饰强势入驻抚顺家装市场(图) </a>   <li> <a href="/transcode?q=%E6%9E%97%E5%87%A4&amp;pn=1&amp;pos=4&amp;m=394b4302dd78acbaa4217374c6fa121d16c4d65a&amp;u=http%3A%2F%2Fnews.sina.com.cn%2Fc%2F2014-09-19%2F123930883680.shtml" data-pos="3"> 赵广军为<b>林凤</b>娥小学义工队授旗 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '代县聂营村康静中、乔林凤夫妻俩当“羊倌”发羊财' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '代县聂营村康静中、乔林凤夫妻俩当“羊倌”发羊财'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";