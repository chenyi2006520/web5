s:14378:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>给4个熊孩子穿衣有多可怕?爸爸妈妈都要哭了- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">给4个熊孩子穿衣有多可怕?爸爸妈妈都要哭了</h1> <p id="source-and-time"><span id=source>网易</span><time id=time>2016-03-07 09:59:48</time></p> </header>  <div id="news-body"><p>前一阵，一个关于一位妈妈给她的三胞胎婴儿和两岁女儿穿睡衣的视频火了。这个视频吸引了五千六百万浏览量和超过百万的转发量。后来，这4个熊孩子的爸爸想PK一下，看自己是不是能以更快速度完成任务，竟然成功了!</p><p><img src="http://p33.qhimg.com/t015a43ffcf7fe428d3.jpg?size=550x550"></p><p>加拿大安大略省剑桥市的一个爸爸，叫Dan Gibson，他的太太名叫Corrie-Lynn Whyte，这是一对幸福的夫妻，他们生有4个小孩子:刚会走路的Emily和三胞胎婴儿Jackson、Olivia和Levi。这天，爸爸Dan有了一个有趣的想法，拍摄一段视频--记录妻子如何给4个熊孩子换睡衣。视频中，在喜感的背景音乐伴奏下，4个熊孩子动来动去，一点也不肯配合妈妈。</p><p><img src="http://p34.qhimg.com/t018edac1e9bdd3fbed.jpg?size=550x413"></p><p class="img-title">这就是视频中的那4个熊孩子。</p><p>这对夫妻把视频传到了<a href="http://m.so.com/s?q=Facebook&amp;src=newstranscode" class="qkw">Facebook</a>和YouTube频道上，然后便一发不可收拾地火了。</p><p>很多人称<a href="http://m.so.com/s?q=Corrie&amp;src=newstranscode" class="qkw">Corrie</a>是超级妈妈，也有一些人开玩笑说光是看她在孩子中忙活就够累了。</p><p>人们很吃惊:“谁能想象给三胞胎穿衣服竟然比给刚会走路的娃娃穿衣服要轻松?Corrie你真应该得到一枚奖章。希望你每天脸上都会挂着微笑!”</p><p>Dan在接受<a href="http://m.so.com/s?q=%E5%8A%A0%E6%8B%BF%E5%A4%A7&amp;src=newstranscode" class="qkw">加拿大</a>CBC新闻采访的时候说，平时都是他们夫妻俩协力给孩子换睡衣的，只是这次突然觉得如果让Corrie自己试试应该会很有趣。他还说，如果两人合作给四个孩子换睡衣的话，一般要六分钟左右。当时，Dan还透露给CBC新闻说这个视频的续集已经在制作中了。这次，他将挑战一个人给孩子们穿衣服。</p><p>谁能拒绝观看这样一场爸爸妈妈之间的可爱的竞赛呢?</p><p>于是了不得的事情发生了!爸爸居然赢得了这场比赛!</p><p>这回老爸给四个熊孩子穿衣服的视频瞬间收获了超过两百万浏览量和3万6千个赞。新视频依旧发在Facebook上。在欢快音乐的伴奏下，爸爸Dan真是用尽了浑身解数!</p><p><img src="http://p31.qhimg.com/t014b7fa5451824a3af.jpg?size=549x303"></p><p><img src="http://p34.qhimg.com/t010dbd33f945ac1bb3.jpg?size=550x305"></p><p><img src="http://p33.qhimg.com/t01b3958a45fc1e302b.jpg?size=550x307"></p><p>在这场宝宝换衣奥林匹克中，爸爸获胜了!不过这也要归功于有拉链的连体服……是的，四合扣，绳结，纽扣什么的每次都会减慢你的速度!</p><p><img src="http://p35.qhimg.com/t018af1f5d81d18d674.jpg?size=550x357"></p><p>本文来源:澎湃新闻网  责任编辑:王梦璇_NX6021</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.163.com/16/0307/09/BHI16TFT00014TUH.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='eecb7f4b61130fd1d7a50ee02caf4e78'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>穿衣大赛</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%A9%BF%E8%A1%A3%E5%A4%A7%E8%B5%9B&amp;pn=1&amp;pos=6&amp;m=01a5731fd301b8d30040e4fa979543e511c9eeef&amp;u=http%3A%2F%2Fsociety.yunnan.cn%2Fhtml%2F2015-06%2F07%2Fcontent_3771767.htm" data-pos="1"> 萌宝<b>穿衣大赛</b>在昆明展开 培养孩子自理能力 </a>   <li> <a href="/transcode?q=%E7%A9%BF%E8%A1%A3%E5%A4%A7%E8%B5%9B&amp;pn=1&amp;pos=7&amp;m=8885568fbbca8aaa4eda0e0d95c73776c98c3e00&amp;u=http%3A%2F%2Fwww.nxing.cn%2Fwap%2Farticle%2F4006064.html" data-pos="2"> 穆里尼奥入选GQ十大最佳<b>着装</b>男士 </a>   <li> <a href="/transcode?q=%E7%A9%BF%E8%A1%A3%E5%A4%A7%E8%B5%9B&amp;pn=1&amp;pos=8&amp;m=b882d8b1372f6c6578000f0e12c9f8aacb0ebea4&amp;u=http%3A%2F%2Fwww.techweb.com.cn%2Fshoujiyouxi%2F2016-03-07%2F2290793.shtml" data-pos="3"> 禁止LOL女主播<b>着装</b>暴露 屡教不改将会封杀 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '给4个熊孩子穿衣有多可怕?爸爸妈妈都要哭了' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '给4个熊孩子穿衣有多可怕?爸爸妈妈都要哭了'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";