s:15419:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>李冬娜:胜日本愿望实现了 离里约奥运只有一小步- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">李冬娜:胜日本愿望实现了 离里约奥运只有一小步</h1> <p id="source-and-time"><span id=source>网易</span><time id=time>2016-03-05 19:32:45</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E7%BD%91%E6%98%93%E4%BD%93%E8%82%B2&amp;src=newstranscode" class="qkw">网易体育</a>徐涛3月5日大阪报道:</p><p>奥预赛3轮战罢，<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E5%A5%B3%E8%B6%B3&amp;src=newstranscode" class="qkw">中国女足</a>暂时排在第2位，进军里约前景一片光明。队长<a href="http://m.so.com/s?q=%E6%9D%8E%E5%86%AC%E5%A8%9C&amp;src=newstranscode" class="qkw">李冬娜</a>回顾了过往的3场比赛，并称中国女足离<a href="http://m.so.com/s?q=%E5%A5%A5%E8%BF%90%E4%BC%9A&amp;src=newstranscode" class="qkw">奥运会</a>只有一小步。</p><p>李冬娜首先回顾了昨天战胜日本的比赛，“相对于第一场和第二场比赛，昨天我们的表现更好，队伍一场比一场打得好，尤其是进攻上，前场的球员都能把自己的特点发挥出来。”对于战胜日本的原因，李冬娜分析说，“这么多年跟日本比赛，无论是比分还是场面上，都不太占优势。昨晚无论是精神还是技战术，我们都赢了。在我踢球这么长时间里，我希望赢一场日本，昨天实现了。”</p><p>在战胜日本后，对手主帅<a href="http://m.so.com/s?q=%E4%BD%90%E4%BD%90%E6%9C%A8&amp;src=newstranscode" class="qkw">佐佐木</a>基本确定下课。李冬娜说，“从前也听说过对方教练想这次比赛打完离开，<a href="http://m.so.com/s?q=%E7%AB%9E%E6%8A%80%E4%BD%93%E8%82%B2&amp;src=newstranscode" class="qkw">竞技体育</a>就是这样。我们肯定是要全力争胜的，对方教练的问题我们不关心。”</p><p>作为国家队队长，李冬娜回顾了前3场比赛。“第一场打<a href="http://m.so.com/s?q=%E8%B6%8A%E5%8D%97&amp;src=newstranscode" class="qkw">越南</a>，赢了2个，我们发挥不是很好。第二场那么强的对手，给了我们很大的压力，从心理上调整，必须重视起来，大家团结在一起，从比赛当中打出自己的东西。第三场的对手跟前两场风格不一样，给了我们发挥自己特点的机会比较多。”</p><p>中国女足占据拿到奥运门票的主动权，李冬娜说，“我们确实离里约非常近了，但是这一小步是最困难的，无论是心里还是身体。有时候特别容易做到的事情，可能因为不够谨慎，或者小问题而出现意外。只有一小步，我们还会积极准备，希望真正拿下这个目标。”</p><p>对于下个对手韩国，李冬娜点评说，“韩国这几年的进步很大，尤其是进攻方面，前场有几个球员比较不错，针对她们前两场的进攻，我们肯定要做好防守，保证防守的基础上再去给对手进攻的压力。”</p><p>本文来源:网易体育 作者:滨腾 责任编辑:马赛_NS2135</p><p><img src="http://p31.qhimg.com/t013f73fb4c6d9a2a19.jpg?size=600x400"></p><p><a href="http://m.so.com/s?q=%E5%B8%83%E9%B2%81%E8%AF%BA&amp;src=newstranscode" class="qkw">布鲁诺</a>、张越斗舞</p><p><img src="http://p33.qhimg.com/t01a2d2fabf29b48d4b.jpg?size=600x400"></p><p><a href="http://m.so.com/s?q=%E8%B5%B5%E4%B8%BD%E5%A8%9C&amp;src=newstranscode" class="qkw">赵丽娜</a></p><p><img src="http://p34.qhimg.com/t014e4f7a2fba9566b8.jpg?size=600x400"></p><p><img src="http://p31.qhimg.com/t01083360219bd5be97.jpg?size=600x400"></p><p class="img-title">马晓旭</p><p><img src="http://p33.qhimg.com/t015f5677fdd15af267.jpg?size=600x400"></p><p><img src="http://p34.qhimg.com/t0199ac8512ad289e91.jpg?size=600x400"></p><p class="img-title">布鲁诺</p><p><img src="http://p33.qhimg.com/t0145827c28db3ced07.jpg?size=600x400"></p><p><a href="http://m.so.com/s?q=%E5%A5%B3%E8%B6%B3&amp;src=newstranscode" class="qkw">女足</a>恢复训练</p><p><img src="http://p33.qhimg.com/t01ae578c3b8be47398.jpg?size=600x400"></p><p class="img-title">女足进行恢复训练</p><p><img src="http://p31.qhimg.com/t01a8eafa09bb5a7e28.jpg?size=600x400"></p><p>恢复训练</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://sports.163.com/16/0305/19/BHDT6IVT00051C8M.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='f805bd3626fea4d156d94ebe7068c394'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>李冬娜</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9D%8E%E5%86%AC%E5%A8%9C&amp;pn=1&amp;pos=9&amp;m=612beb1935356176ee19b55870955aa3d007742b&amp;u=http%3A%2F%2Fsports.sohu.com%2F20160305%2Fn439493982.shtml" data-pos="1"> <b>李冬娜</b>:击败日本是最大梦想 距里约只有一小步 </a>   <li> <a href="/transcode?q=%E6%9D%8E%E5%86%AC%E5%A8%9C&amp;pn=1&amp;pos=10&amp;m=41e13e56494ea5d9f40d9ec10588420f321048b0&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fsport%2Ftyxw%2F4419737_1.html" data-pos="2"> 直击-王珊珊突破造点<b>李冬娜</b>罚丢 女足暂0-0越南 </a>   <li> <a href="/transcode?q=%E6%9D%8E%E5%86%AC%E5%A8%9C&amp;pn=2&amp;pos=1&amp;m=007c52837b443f6e5e242de9ea35923d8e891dd8&amp;u=http%3A%2F%2Fsports.cntv.cn%2F2016%2F02%2F29%2FVIDEVH1z00UsxSYERowt6Qm9160229.shtml" data-pos="3"> [女足]王珊珊造点 <b>李冬娜</b>主罚被扑错失破门机会 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '李冬娜:胜日本愿望实现了 离里约奥运只有一小步' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '李冬娜:胜日本愿望实现了 离里约奥运只有一小步'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";