s:14537:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>一年三季都有鲜桃上市 乐亭“南北桃”促农增收- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">一年三季都有鲜桃上市 乐亭“南北桃”促农增收</h1> <p id="source-and-time"><span id=source>新华网河北频道</span><time id=time>2015-05-19 15:38:52</time></p> </header>  <div id="news-body"><p>5月的<a href="http://m.so.com/s?q=%E4%B9%90%E4%BA%AD%E5%8E%BF&amp;src=newstranscode" class="qkw">乐亭县</a>北部农村，陆地桃树桃花满枝、万亩嫣红;而南部农村，却有大批的设施鲜桃已成熟采摘，俏销全国各地。每年从3月上旬到11月上旬，<a href="http://m.so.com/s?q=%E4%B8%80%E5%B9%B4%E4%B8%89%E5%AD%A3&amp;src=newstranscode" class="qkw">一年三季</a>乐亭都有鲜桃上市，这得益于10年来该县鲜桃产业的区域化发展。</p><p>目前，乐亭县鲜桃面积共有8.1万亩，其中设施桃面积近3万亩，形成了以南部<a href="http://m.so.com/s?q=%E6%96%B0%E5%AF%A8%E9%95%87&amp;src=newstranscode" class="qkw">新寨镇</a>为中心的设施桃产业带和以北部<a href="http://m.so.com/s?q=%E4%B8%AD%E5%A0%A1%E9%95%87&amp;src=newstranscode" class="qkw">中堡镇</a>为中心的陆地桃产业带。每年春夏之交，同在鲜桃之乡，产业模式却“南北有别”。</p><p>“<a href="http://m.so.com/s?q=%E4%B9%90%E4%BA%AD&amp;src=newstranscode" class="qkw">乐亭</a>鲜桃产业发展的分水岭形成于2005年。”该县<a href="http://m.so.com/s?q=%E6%9E%97%E4%B8%9A%E5%B1%80&amp;src=newstranscode" class="qkw">林业局</a>高级农艺师邸淑娇介绍，上世纪90年代，乐亭依托得天独厚的自然优势，大力扶持引导鲜桃产业。到2003年时，鲜桃总面积超过15万亩。但随着全国鲜桃产量的逐年增加，同质化竞争加剧，鲜桃价格逐年下滑。2005年，由于气候原因，加之树龄普遍较长、抵抗力下降，导致穿孔疮痂病在各个桃园集中爆发。</p><p>鲜桃产业路在何方?在深入调研中，他们发现了一个规律:以新寨镇为代表的南部区域，鲜桃产业发展较早，<a href="http://m.so.com/s?q=%E6%A1%83%E6%9E%97&amp;src=newstranscode" class="qkw">桃林</a>集中连片，穿孔病较为严重;而北部中堡镇一带，由于防护林网密集，抑制了穿孔病毒传播，再之树龄普遍较短，抵抗力强，穿孔病情较轻。另一方面，南部区域的农民在发展鲜桃产业的同时，也在致力发展设施蔬菜，而北部区域传统农业却占据绝对主导地位。</p><p>“因地制宜，走区域化差异发展之路。”在充分尊重桃农意愿的基础上，该县以新寨镇为中心，将桃树“移植”于温室，使设施桃产业迅速成为南部区域的支柱产业;而在以中堡镇为中心的北部区域，林业专家逐渐攻克了桃树穿孔病，陆地桃产业重新焕发出生机。</p><p>目前，该县设施桃产业发展迅猛，通过推广“高接换头”技术，将盛果期提前了2-3年;前促后控、避光休眠等生长干预技术的普及，使设施桃成熟时间由5月提前到3月上旬;而智能温控机、自动卷帘机等现代化设施的应用，大大提高了劳动效率。而陆地桃产业也逐步向精细化管理迈进，栽植密度加大，挂果周期大幅缩短。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.he.xinhuanet.com/zfwq/laoting/laoting/2015-05/19/c_1115336010.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='8e786ed7ff075992f92c4629d1ec39c6'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>一年三季</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%B8%80%E5%B9%B4%E4%B8%89%E5%AD%A3&amp;pn=1&amp;pos=3&amp;m=16133c29c473e792379c6b8098cfce0a9f553cf3&amp;u=http%3A%2F%2Fauto.eastday.com%2Fauto%2F08auto%2Fnews%2Fzh%2Fu1ai284759.html" data-pos="1"> "驾·享法兰西"东风雪铁龙科技创享体验营<b>第3季</b>即将成都开营 </a>   <li> <a href="/transcode?q=%E4%B8%80%E5%B9%B4%E4%B8%89%E5%AD%A3&amp;pn=1&amp;pos=4&amp;m=82c104ccd9895dfbcc3814d541b15cda4ed1072f&amp;u=http%3A%2F%2Fauto.eastday.com%2Fauto%2F08auto%2Fnews%2Fzh%2Fu1ai284760.html" data-pos="2"> 东风雪铁龙科技创享体验营<b>第3季</b>87城热力开营 </a>   <li> <a href="/transcode?q=%E4%B8%80%E5%B9%B4%E4%B8%89%E5%AD%A3&amp;pn=1&amp;pos=5&amp;m=2a8d8e4ecdc2d3cd6747526da0821326843d0329&amp;u=http%3A%2F%2Fauto.china.com%2Fdongtai%2Fqy%2F11031467%2F20160311%2F21850198.html" data-pos="3"> 东风雪铁龙科技创享体验营<b>第3季</b>即将成都开营 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '一年三季都有鲜桃上市 乐亭“南北桃”促农增收' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '一年三季都有鲜桃上市 乐亭“南北桃”促农增收'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";