s:15151:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>世界最大游轮耗资74亿元 比泰坦尼克号还长100米 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">世界最大游轮耗资74亿元 比泰坦尼克号还长100米 </h1> <p id="source-and-time"><span id=source>东方财富网</span><time id=time>2016-03-14 07:25:00</time></p> </header>  <div id="news-body"><p><img src="http://p31.qhimg.com/t010a3b4b3766fcb007.jpg?size=600x463"></p><p>世界最大的游轮“<a href="http://m.so.com/s?q=%E6%B5%B7%E6%B4%8B%E5%92%8C%E8%B0%90%E5%8F%B7&amp;src=newstranscode" class="qkw">海洋和谐号</a>”10日下午从法国圣纳泽尔港出发，首次下水试航(网页截图)</p><p>据英国<a href="http://m.so.com/s?q=%E3%80%8A%E6%AF%8F%E6%97%A5%E9%82%AE%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《每日邮报》</a>3月10日报道，世界最大的游轮“海洋和谐号”10日下午从法国圣纳泽尔港(Saint-Nazaire port)出发，进行首次海上试航。试航预计将于本周日(13日)结束。</p><p>报道称，“海洋和谐号”拥有18个甲板，长约362米，高约64米，载客容量达6000人，重达227000吨，共计花费8亿英镑打造。</p><p>“海洋和谐号”比历史上著名的“<a href="http://m.so.com/s?q=%E6%B3%B0%E5%9D%A6%E5%B0%BC%E5%85%8B%E5%8F%B7&amp;src=newstranscode" class="qkw">泰坦尼克号</a>”还要长100米，比此前世界上最大的两艘游轮--“<a href="http://m.so.com/s?q=%E6%B5%B7%E6%B4%8B%E9%AD%85%E5%8A%9B%E5%8F%B7&amp;src=newstranscode" class="qkw">海洋魅力号</a>”和 “海洋绿洲号”还要宽大概1米。</p><p>此次试航并未载有乘客，但是上面有500名工作人员。正式航行的时候，船上的工作人员将达2000人。10日下午，圣纳泽尔港聚集了很多前来观看“海洋和谐号”首次下水的民众。其实在下水之前数月，游客们就被允许登船，参观游轮豪华的内部装饰。</p><p>“海洋和谐号”的下次试航将于4月底前进行，原定于5月12日正式交付。本周试航目的是测试游轮的引擎和运行情况。如果所有试航都成功，“海洋和谐号”将于5月沿着<a href="http://m.so.com/s?q=%E5%9C%B0%E4%B8%AD%E6%B5%B7&amp;src=newstranscode" class="qkw">地中海</a>驶往英国南安普顿港口和西班牙的<a href="http://m.so.com/s?q=%E5%B7%B4%E5%A1%9E%E7%BD%97%E9%82%A3&amp;src=newstranscode" class="qkw">巴塞罗那</a>港口，进行首次正式航行。</p><p>据悉，“海洋和谐号”归皇家加勒比国际游轮公司所有，他们从2013年9月开始建造“海洋和谐号”。皇家加勒比国际游轮公司同时也是“海洋魅力号”和“<a href="http://m.so.com/s?q=%E6%B5%B7%E6%B4%8B%E7%BB%BF%E6%B4%B2%E5%8F%B7&amp;src=newstranscode" class="qkw">海洋绿洲号</a>”的拥有者。</p><p><img src="http://p34.qhimg.com/t011f839a64d5b5d0d6.jpg?size=600x385"></p><p>“海洋和谐号”长约362米，高约64米，载客容量达6000人，重达227000吨(网页截图)</p><p><img src="http://p33.qhimg.com/t01356a03c690d4409b.jpg?size=600x311"></p><p>此次试航并未载有乘客，不过载有约500名工作人员(网页截图)</p><p><img src="http://p31.qhimg.com/t01865cf041fdf9ba25.jpg?size=600x375"></p><p>圣纳泽尔港聚集了很多前来观看“海洋和谐号”首次下水的民众(网页截图)</p><p><img src="http://p33.qhimg.com/t014171ddf3b48b1d9b.jpg?size=600x442"></p><p>游轮上有多种游乐设施，包括室内冰场、人工冲浪场、攀岩墙等(网页截图)</p><p><img src="http://p31.qhimg.com/t015b821c1be5549c1f.jpg?size=600x383"></p><p>在“海洋和谐号”下水之前数月，游客们就被允许登船，参观游轮豪华的内部装饰(网页截图)</p><p><img src="http://p33.qhimg.com/t01eca488d40b2d141a.jpg?size=600x440"></p><p><img src="http://p31.qhimg.com/t01af85830f17c2a4d9.jpg?size=600x383"></p><p>“海洋和谐号”游轮上还有顶尖剧院(网页截图)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://money.eastmoney.com/news/1282,20160314603659584.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='75b639d2e82a4d274512531df793cdc4'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>泰坦尼克号</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%B3%B0%E5%9D%A6%E5%B0%BC%E5%85%8B%E5%8F%B7&amp;pn=1&amp;pos=2&amp;m=90e93b4d86fc5b3b0ca8de489a4a30ffc7330701&amp;u=http%3A%2F%2Fworld.people.com.cn%2FGB%2Fn1%2F2016%2F0311%2Fc1002-28192333.html" data-pos="1"> 世界最大游轮首次试航 长度超过"<b>泰坦尼克号</b>"(高清组图) </a>   <li> <a href="/transcode?q=%E6%B3%B0%E5%9D%A6%E5%B0%BC%E5%85%8B%E5%8F%B7&amp;pn=1&amp;pos=3&amp;m=02e7e4624eac1fda91561b53584b351af253bcc8&amp;u=http%3A%2F%2Fwww.china.com.cn%2Ftravel%2Ftxt%2F2016-03%2F11%2Fcontent_37998507.htm" data-pos="2"> 比<b>泰坦尼克号</b>豪华!世界最大游轮试航曝光 </a>   <li> <a href="/transcode?q=%E6%B3%B0%E5%9D%A6%E5%B0%BC%E5%85%8B%E5%8F%B7&amp;pn=1&amp;pos=4&amp;m=2efbc8ba7d3d027e3d7247fa9af40a9ca277031a&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2FHealth%2Fhealths%2F4686683_1.html" data-pos="3"> 世界最大游轮首次试航 比<b>泰坦尼克号</b>还长 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '世界最大游轮耗资74亿元 比泰坦尼克号还长100米 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '世界最大游轮耗资74亿元 比泰坦尼克号还长100米 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";