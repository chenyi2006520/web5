s:14031:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>“好心市民”捡弃婴交民警 却被发现是孩子亲妈- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">“好心市民”捡弃婴交民警 却被发现是孩子亲妈</h1> <p id="source-and-time"><span id=source>中国广播网</span><time id=time>2016-03-14 08:02:00</time></p> </header>  <div id="news-body"><p><img src="http://p35.qhimg.com/t018495d7c292658788.jpg?size=550x396"></p><p class="img-title">婴儿被送到医院新生儿病房</p><p><a href="http://m.so.com/s?q=%E9%BD%90%E9%B2%81%E7%BD%91&amp;src=newstranscode" class="qkw">齐鲁网</a>3月13日讯今天早上，有一位“市民”在<a href="http://m.so.com/s?q=%E8%8A%B1%E5%9B%AD%E8%B7%AF&amp;src=newstranscode" class="qkw">花园路</a>附近捡到一个婴儿，并把孩子送到了派出所民警手里。民警问着问着，发现情况不太对:这“弃婴”和“热心市民”，长得咋这么像呢?</p><p>据山东广播电视台<a href="http://m.so.com/s?q=%E9%BD%90%E9%B2%81&amp;src=newstranscode" class="qkw">齐鲁</a>频道《每日新闻》报道，上午10点，记者来到<a href="http://m.so.com/s?q=%E6%B5%8E%E5%8D%97%E5%B8%82%E4%B8%AD%E5%BF%83%E5%8C%BB%E9%99%A2&amp;src=newstranscode" class="qkw">济南市中心医院</a>的新生儿病房。医护人员说，孩子是个女婴，送来时一直发烧，现在正在进行身体检查。</p><p>医生说:“出生没几天，身上没有其他东西，还在检查结果没出来。”</p><p>据了解，女婴是<a href="http://m.so.com/s?q=%E5%B1%B1%E5%A4%A7%E8%B7%AF&amp;src=newstranscode" class="qkw">山大路</a>派出所的民警送到医院的。民警告诉我们，昨天下午4点多，一个女的抱着婴儿急匆匆赶到派出所。</p><p>民警:“说她在<a href="http://m.so.com/s?q=%E9%9D%92%E8%8B%B9%E6%9E%9C%E5%85%AC%E5%AF%93&amp;src=newstranscode" class="qkw">青苹果公寓</a>捡到一个孩子，昨天晚上还跟孩子一起待了一晚上，今天送来。”</p><p>民警说，抱孩子的女子看上去20多岁，操着外地口音。问着问着，民警发现她的神情越来越不对劲。“那女的嘴唇发黑，看她跟孩子长得差不多。”</p><p>一再追问下，直到晚上7点，“捡孩子”女子终于吐出了真话:她就是孩子的亲生母亲!</p><p>原来，女孩是个90后，家在<a href="http://m.so.com/s?q=%E7%83%9F%E5%8F%B0&amp;src=newstranscode" class="qkw">烟台</a>芝罘区，现住在济南一亲戚家，已有一个5岁的儿子。派出所民警说，女子之所以抱着自己的亲生骨肉，到派出所谎报捡到“弃婴”，竟是为了孩子的亲生父亲!</p><p>民警说，男子和该女子之前有一个承诺，可能没实现了，又找不着那个男的了，该女子身体也不大好。</p><p>现在，女孩因涉嫌遗弃罪移交东关派出所进一步调查。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.cnr.cn/native/gd/20160314/t20160314_521600088.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='4676f0f7657ff53edb91a3f74917889d'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>市民中心</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%B8%82%E6%B0%91%E4%B8%AD%E5%BF%83&amp;pn=1&amp;pos=7&amp;m=635e069c93acefda7dd18f18a9991086a599e9ee&amp;u=http%3A%2F%2Fnews.cnr.cn%2Fnative%2Fgd%2F20160314%2Ft20160314_521600088.shtml" data-pos="1"> "好心<b>市民</b>"捡弃婴交民警 却被发现是孩子亲妈 </a>   <li> <a href="/transcode?q=%E5%B8%82%E6%B0%91%E4%B8%AD%E5%BF%83&amp;pn=1&amp;pos=8&amp;m=60ab0e603542e34946c90b9799b5c950e9d69479&amp;u=http%3A%2F%2Fnews.sina.com.cn%2Fc%2F2016-03-14%2Fdoc-ifxqhfvp1000279.shtml" data-pos="2"> 武汉荷兰日开幕 <b>市民</b>可家门口体验荷兰文化与设计 </a>   <li> <a href="/transcode?q=%E5%B8%82%E6%B0%91%E4%B8%AD%E5%BF%83&amp;pn=1&amp;pos=9&amp;m=c4858c837e98ad996e3bb0d425db91f61578ec74&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Flocal%2F2016-03%2F13%2Fc_128796130.htm" data-pos="3"> 济南"好心<b>市民</b>"路边捡到弃婴 民警一问竟是孩子亲妈 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '“好心市民”捡弃婴交民警 却被发现是孩子亲妈' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '“好心市民”捡弃婴交民警 却被发现是孩子亲妈'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";