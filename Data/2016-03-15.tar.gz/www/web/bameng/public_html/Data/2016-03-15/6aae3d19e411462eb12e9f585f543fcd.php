s:21878:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>揭《小李飞刀》演员现状 范冰冰萧蔷吴京任泉焦恩俊 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">揭《小李飞刀》演员现状 范冰冰萧蔷吴京任泉焦恩俊 </h1> <p id="source-and-time"><span id=source>中国日报网</span><time id=time>2016-03-14 09:24:24</time></p> </header>  <div id="news-body"><p><img src="http://p32.qhimg.com/t01e9919e3e55f0ce38.jpg?size=550x327"></p><p>1999年，由<a href="http://m.so.com/s?q=%E7%84%A6%E6%81%A9%E4%BF%8A&amp;src=newstranscode" class="qkw">焦恩俊</a>、吴京、萧蔷、<a href="http://m.so.com/s?q=%E4%BF%9E%E9%A3%9E%E9%B8%BF&amp;src=newstranscode" class="qkw">俞飞鸿</a>等主演的《小李飞刀》红极一时，几位主演在该剧播出之后也都成了家喻户晓的人物。时隔十几载，俞飞鸿、<a href="http://m.so.com/s?q=%E8%90%A7%E8%94%B7&amp;src=newstranscode" class="qkw">萧蔷</a>容颜未老，焦恩俊两女初长成人，<a href="http://m.so.com/s?q=%E5%90%B4%E4%BA%AC&amp;src=newstranscode" class="qkw">吴京</a>甜蜜结婚。“飞刀帮”经历种种蜕变，如今又身在何方?</p><p><img src="http://p31.qhimg.com/t01d38985df2da0f076.jpg?size=600x418"></p><p><a href="http://m.so.com/s?q=%E3%80%8A%E5%B0%8F%E6%9D%8E%E9%A3%9E%E5%88%80%E3%80%8B&amp;src=newstranscode" class="qkw">《小李飞刀》</a></p><p>时隔十几年，小李探花<a href="http://m.so.com/s?q=%E6%9D%8E%E5%AF%BB%E6%AC%A2&amp;src=newstranscode" class="qkw">李寻欢</a>与义兄龙啸云、青梅竹马<a href="http://m.so.com/s?q=%E6%9E%97%E8%AF%97%E9%9F%B3&amp;src=newstranscode" class="qkw">林诗音</a>之间的感情纠葛，与<a href="http://m.so.com/s?q=%E6%83%8A%E9%B8%BF%E4%BB%99%E5%AD%90&amp;src=newstranscode" class="qkw">惊鸿仙子</a>杨艳的悲伤之恋，与义弟阿飞的兄弟之情，仍在许多观众心中萦绕。曾经的主演们，有的跃身成为女神，有的则没落不堪，今天小编带大家看看红透一时的“飞刀帮”的现状。</p><p><img src="http://p34.qhimg.com/t0191a021ec13682e2c.jpg?size=579x436"></p><p>俞飞鸿--<a href="http://m.so.com/s?q=%E6%9D%A8%E8%89%B3&amp;src=newstranscode" class="qkw">杨艳</a></p><p>俞飞鸿在《小李飞刀》中饰演杨艳，有“惊鸿仙子”之称。但在《小李飞刀》之前，俞飞鸿就凭借<a href="http://m.so.com/s?q=%E3%80%8A%E7%89%B5%E6%89%8B%E3%80%8B&amp;src=newstranscode" class="qkw">《牵手》</a>中的“小三”王纯走进观众视野。《牵手》导演杨阳经北影老师看到了一张俞飞鸿的黑白照，当即决定由她来饰演夏小雪，而俞飞鸿则认为自己的年龄、经历等更适合演<a href="http://m.so.com/s?q=%E7%8E%8B%E7%BA%AF&amp;src=newstranscode" class="qkw">王纯</a>，最后一切如她所愿，“王纯”这一角色让她一夜成名。</p><p><img src="http://p33.qhimg.com/t019dfb866ac78b50d9.jpg?size=574x289"></p><p>随着电视剧《大丈夫》的播出，俞飞鸿重回大众视野。43岁的她保养得当，魅力不减，让不少网友直呼她就是记忆中的女神，有网友曝对比照，俞飞鸿与王菲颇为相似。2011年，俞飞鸿被曝携富豪男友同回别墅。2012年，俞飞鸿再次被曝恋情，网传其搂抱“威猛”男友回家的照片，然而传说中的神秘富豪却从未被证实。</p><p><img src="http://p34.qhimg.com/t01467752d489dec2ef.jpg?size=576x313"></p><p class="img-title">俞飞鸿</p><p>俞飞鸿生于书香门第，父亲毕业于清华大学、妈妈毕业于浙江化工学院，从小的家庭条件优越，6岁被挑去学舞蹈，8岁第一次出演电影《竹》。1993年，俞飞鸿大学毕业留校任教，后因积累锻炼于1994年赴美读书，深造于美国加州大学分校，三年后归国。</p><p><img src="http://p31.qhimg.com/t01df9a541375f193cc.jpg?size=496x308"></p><p>2001年俞飞鸿买下《爱有来生》小说版权，自己写剧本，找投资。她不仅没有拿一分钱片酬，还投入了自己的积蓄，卖房、贴钱，差点搭上身家。2010年，俞飞鸿凭借此片夺得第17届北京大学生电影节最佳处女作奖。</p><p><img src="http://p31.qhimg.com/t0147a25c186d222308.jpg?size=400x579"></p><p class="img-title">萧蔷--林诗音</p><p>萧蔷在《小李飞刀》中饰演林诗音，时隔多年，提起萧蔷版的林诗音，观众还是意犹未尽。萧蔷出道较早，高中毕业时，模特儿经纪公司在毕业纪念册中看到她，便与其联络并签约。而萧蔷做模特儿仅3个月，就被<a href="http://m.so.com/s?q=%E9%A9%AC%E6%99%AF%E6%B6%9B&amp;src=newstranscode" class="qkw">马景涛</a>看中，向制片人推荐出演首部电视作品<a href="http://m.so.com/s?q=%E3%80%8A%E6%83%85%E6%B7%B1%E6%97%A0%E6%80%A8%E5%B0%A4%E3%80%8B&amp;src=newstranscode" class="qkw">《情深无怨尤》</a>。而萧蔷做模特儿仅3个月，就被马景涛看中，向制片人推荐出演首部电视作品《情深无怨尤》。</p><p><img src="http://p35.qhimg.com/t0126ab1b5f1f2d32aa.jpg?size=499x454"></p><p class="img-title">萧蔷现状</p><p>成名后的萧蔷负面新闻不断，而最具代表的莫过于整容风波。如今年过40的萧蔷频频被曝整容，而回过头来看看萧蔷的容貌，确实令我们心生质疑。即便保养得再好，萧蔷的神奇回春术也令观众咂舌，40多岁的她宛如18岁妙龄少女，网友称其“不老女神”。</p><p><img src="http://p35.qhimg.com/t010f0f47b62b82b107.jpg?size=580x435"></p><p>萧蔷，素有台湾“第一美女”封号，从绯闻男友黎耀文、歌坛天王齐秦，再到神秘亿万富翁，萧蔷身边的富豪男友不断。之前她被媒体直击上海闹区的千万豪宅，身价不菲。萧蔷在杭州某酒店被拍到与一位90后男子酒店密会照，该男子着装打扮时尚帅气，座驾是部数百万的豪车，可谓是一位十足的90后“高富帅”，照片中两人见面后亲热相拥，组图一出，立即引发网友一片热议。</p><p><img src="http://p33.qhimg.com/t0132d37816590d05f0.jpg?size=568x427"></p><p>范冰冰--<a href="http://m.so.com/s?q=%E6%9D%8F%E5%84%BF&amp;src=newstranscode" class="qkw">杏儿</a></p><p>范冰冰在《小李飞刀》中饰演杨艳的贴身婢女杏儿，该剧也是<a href="http://m.so.com/s?q=%E8%8C%83%E5%86%B0%E5%86%B0&amp;src=newstranscode" class="qkw">范冰冰</a>继《还珠格格》之后的又一经典“丫鬟”之作。范冰冰出名后，也没能逃脱疑似整容的传闻。而范爷做事一向洒脱，竟然为辟谣整容跑到医院鉴定，成为明星鉴定整容的第一人。</p><p><img src="http://p32.qhimg.com/t01a285450d17df04b2.jpg?size=496x252"></p><p>医院的鉴定书结果:根据骨骼情况，肯定没有做过手术或者放假体，下巴，鼻子，额头，眼睛，腮一切正常。自此，也打破了范冰冰整容的异议</p><p><img src="http://p34.qhimg.com/t013c298ac69ace1b49.jpg?size=575x349"></p><p class="img-title">杏儿</p><p>2007年，范冰冰成立工作室，成为老板。第一部自家制作的电视剧是《胭脂雪》。范冰冰自家成立了艺校，成为校长，范冰冰的父母负责平时的行政管理事务。</p><p><img src="http://p35.qhimg.com/t012f316df298c12146.jpg?size=500x395"></p><p class="img-title">焦恩俊--李寻欢</p><p>焦恩俊在《小李飞刀》中饰演李寻欢，正因为这个角色，焦恩俊被誉为“古装第一人”。焦恩俊早年曾学跆拳道、武术和双截棍，高中刚毕业后由嘉义只身北上到台北都会区，参加中影演员训练班。他在课余时间到餐厅洗盘子，扣掉付房租的钱，每天只剩十五元的伙食费。为了生活，焦恩俊跑去当临时演员，在无戏可演的日子里又做起了家庭手工发箍。1994年，焦恩俊与前妻<a href="http://m.so.com/s?q=Fendi&amp;src=newstranscode" class="qkw">Fendi</a>结婚，并育有两个女儿，但因Fendi红杏出墙，二人于2005年低调离婚，结束了十一年的婚姻生活。为换得女儿的抚养权，焦恩俊甚至放弃上亿身家，净身出户。</p><p><img src="http://p32.qhimg.com/t016b0127f2d96d27d2.jpg?size=414x415"></p><p>而在2007年，焦恩俊遭前妻控告索要女儿监护权，此后一段时间内两个女儿便在焦恩俊的视线中消失，使得他一度在镜头前痛哭流涕。失去两女后，焦恩俊开始酗酒，曾让公司的工作人员担心他会有抑郁症。时隔四年，焦恩俊终于重见女儿。</p><p><img src="http://p31.qhimg.com/t017003f2e3bcbfc961.jpg?size=446x379"></p><p>2012年，焦恩俊被曝带神秘女子入住上海某酒店，十余保安保驾大牌十足，对此，焦恩俊本人及经纪公司站出来澄清给予否认，称该女子实为工作人员，并怒斥无良狗仔偷拍、捏造事实。</p><p><img src="http://p35.qhimg.com/t015f1e4888c5666c57.jpg?size=597x266"></p><p><a href="http://m.so.com/s?q=%E8%B4%BE%E9%9D%99%E9%9B%AF&amp;src=newstranscode" class="qkw">贾静雯</a>--孙小红</p><p>贾静雯在《小李飞刀》中饰演<a href="http://m.so.com/s?q=%E5%AD%99%E5%B0%8F%E7%BA%A2&amp;src=newstranscode" class="qkw">孙小红</a>。贾静雯的出道多少有些离奇，某天在逛街时被星探发现，请她拍了生平第一支广告“妞妞甜八宝”2005年，贾静雯与美籍华人孙志浩在拉斯维加斯闪电结婚，她的丈夫在上海开设德威、虎威两家货运公司。婚后不久，贾静雯便生下女儿孙翎茜(小名:梧桐妹)。贾静雯生女后，因为绯闻情史太丰富，一度传出夫家打听过“来历”后，要求验明正身，确认是孙家的种，才愿意正式接纳完婚，为这桩婚姻埋下一颗未爆弹，没过门与婆家鸿沟就已难跨越。</p><p><img src="http://p35.qhimg.com/t017a4d0ea50930f264.jpg?size=592x455"></p><p><a href="http://m.so.com/s?q=%E9%83%91%E4%BD%B3%E6%AC%A3&amp;src=newstranscode" class="qkw">郑佳欣</a>--林仙儿</p><p>郑佳欣在《小李飞刀》中饰演<a href="http://m.so.com/s?q=%E6%9E%97%E4%BB%99%E5%84%BF&amp;src=newstranscode" class="qkw">林仙儿</a>，当年关于郑佳欣的争议声还是很大的，有观众觉得她是剧中最漂亮的，而此言一出，立马有网友大投反对票。在《小李飞刀》之前，郑佳欣参演《还珠格格》，饰演抛绣球相亲的杜家大小姐--杜若兰。</p><p><img src="http://p31.qhimg.com/t01dcc0d1217b5a724d.jpg?size=339x220"></p><p>虽然观众对郑佳欣的名字略感陌生，但是她的同班同学赵薇、陈坤、黄晓明等皆是当今一线明星。或许郑佳欣运气稍弱，至今仍没有一部耳熟能详的作品面世。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://cnews.chinadaily.com.cn/2016-03/14/content_23851246.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='987fe11840a46a800f50a650a3ed0ed7'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>小李飞刀</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%B0%8F%E6%9D%8E%E9%A3%9E%E5%88%80&amp;pn=1&amp;pos=2&amp;m=3fed11f15a0f72f2bfc400b1ee161f55005e36a1&amp;u=http%3A%2F%2Fcnews.chinadaily.com.cn%2F2016-03%2F12%2Fcontent_23835496.htm" data-pos="1"> 《<b>小李飞刀</b>》演员现状 有人成女神有人没落不堪 </a>   <li> <a href="/transcode?q=%E5%B0%8F%E6%9D%8E%E9%A3%9E%E5%88%80&amp;pn=1&amp;pos=3&amp;m=9ccb2c7ad51b19c0d95a640fce37a3c7e8dbfef6&amp;u=http%3A%2F%2Fwww.zj.xinhuanet.com%2F2016-03%2F10%2Fc_1118290345.htm" data-pos="2"> 《<b>小李飞刀</b>》演员现状 有人跃身成女神有人没落不堪 </a>   <li> <a href="/transcode?q=%E5%B0%8F%E6%9D%8E%E9%A3%9E%E5%88%80&amp;pn=1&amp;pos=4&amp;m=9b7805b208bd45fe5010c5e0a317d689c3761b36&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4008977.html" data-pos="3"> <b>小李飞刀</b>!拉锯战李敬宇成奇兵夺命三分力挽狂澜 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '揭《小李飞刀》演员现状 范冰冰萧蔷吴京任泉焦恩俊 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '揭《小李飞刀》演员现状 范冰冰萧蔷吴京任泉焦恩俊 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";