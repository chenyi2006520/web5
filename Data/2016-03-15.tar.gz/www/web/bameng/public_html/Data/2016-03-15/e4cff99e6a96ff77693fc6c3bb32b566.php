s:26813:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>从零到一，美芽的技术实战- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">从零到一，美芽的技术实战</h1> <p id="source-and-time"><span id=source>CSDN</span><time id=time>2015-05-13 16:44:22</time></p> </header>  <div id="news-body"><p>【编者按】美芽作为一个美妆视频社区，在 2 月份上线之后，极受女性用户的欢迎。此次美芽 CTO 姚东旭在 UPYUN Open Talk 厦门场分享了美芽<a href="http://m.so.com/s?q=%E4%BB%8E%E9%9B%B6%E5%88%B0%E4%B8%80&amp;src=newstranscode" class="qkw">从零到一</a>的整个产品生命周期，带给创业公司很多值得借鉴的地方。</p><p class="header">以下为正文</p><p>美芽在萌芽过程中，同很多初创产品一样，有常见的三个特点:较小的用户规模、快速的需求变化以及尚未完善的团队。</p><p>1. 较小的用户规模。虽然偶有例外，譬如“足迹”的爆发式增长，传言 DAU 有 300 万，而一般的产品不会有这种运气;</p><p>2. 快速的需求变化。初创产品蕴含很多的不确定性。无法同时兼顾产品细节，也无法在较短时间内将功能极尽完善，因而通常情况下会尽快推向市场，以验证想法的正确性;</p><p>3. 尚未完善的团队。互联网创业公司对于技术人员的强烈需求，与市场的供不应求，有着难以消解的矛盾。加上创业公司无法高价请人，通常情况下的应对之策只能是一人多用。</p><p>面对这样的境况，相比较代码的执行效率或线上接口的响应效率，更为注重开发效率是美芽的应对之策。而影响开发效率主要包括三方面:一是沟通成本，以客户端和后端同学的沟通为主;二是重复轮子，已经有成熟的开源实现了，却用自己的代码重复实现了;三是过度设计。</p><p class="header">沟通成本:协议 / 流程</p><p class="header">1. 协议</p><p>在协议方面，很多项目在设计前后端交互协议时非常随意，比如 /<a href="http://m.so.com/s?q=Post&amp;src=newstranscode" class="qkw">Post</a>/Show/xx ，实现起来也没有统一标准。</p><p><img src="http://p32.qhimg.com/t01914a3b2c4b4076b5.jpg?size=600x417"></p><p>从请求无法明确看出该以哪种方式获取数据，客户端同学必须询问服务端，或者在文档里清晰的描述出来。特别是对于新加入的开发者，需要一个熟悉的过程。比如删除一个帖子，使用 <a href="http://m.so.com/s?q=DELETE&amp;src=newstranscode" class="qkw">DELETE</a> 或 GET 方法，也并没有统一的标准，针对这个问题，美芽是选用 <a href="http://m.so.com/s?q=REST&amp;src=newstranscode" class="qkw">REST</a>风格。</p><p>REST可以翻译为表现层状态转化，这里应该还有个主语，那就是 Resource(资源)，特指网络上的具体信息，比如帖子和评论。美芽在设计客户端请求接口的时候都是针对一个资源做操作。REST定义了一个对资源操作的标准，使用 HTTP 的四个动词表示对资源的操作，GET，<a href="http://m.so.com/s?q=POST&amp;src=newstranscode" class="qkw">POST</a>，DELETE，PUT。以用户帖子为例:</p><p><img src="http://p33.qhimg.com/t0198906976c22ca68e.jpg?size=600x362"></p><p>GET /<a href="http://m.so.com/s?q=posts&amp;src=newstranscode" class="qkw">posts</a> 获取帖子列表，</p><p>GET /posts/id 获取编号为 id 帖子的内容，</p><p class="header">POST /posts 发布帖子，</p><p>DELETE /posts/id 删除编号为 id 的帖子，</p><p>PUT /posts/id 修改编号为 id 的帖子。</p><p>无论新加任何功能模块，包括评论或点赞等都执行这一标准。在开发客户端的过程中，就避免了添加新功能时对接口做其他的约定。</p><p><img src="http://p34.qhimg.com/t0177fcdea56e0f140c.jpg?size=600x414"></p><p>以模型 Post 举例，接口可以变成在获取帖子时，将 id 传过去，返回来就是需要的对象。帖子在后端或数据库中的字段，在客户端对应的就是 Post 模型的属性。</p><p>不再需要有文档去介绍它，只需要自动生成一份数据库字典就把所有东西解决了，少了很多中间成本。在客户端要创建帖子就变得极其简单，客户端用定义好的方法请求到后端，服务端收到请求后就往数据库里新建一个资源。美芽在客户端接口设计的时候都是针对资源操作。</p><p>总结来说，接口设计面向资源、而非功能。在客户端有各种功能和操作，在接口上面肯定不能所有的东西都按客户端的要求设计，这样会增加很大成本。我们在接口设计上只关注数据，至于怎么操作是客户端的事情，将数据和表现分离。</p><p class="header">2. 流程</p><p>开发流程，刚出道的时候由于流程不完善，会出现各种问题，比如刚上线的代码或刚修正了一个 Bug随意发布，发布上去后又发现有问题。</p><p><img src="http://p33.qhimg.com/t01861345c4ccff02ab.jpg?size=471x434"></p><p>针对这点，美芽制定了本地环境 - 开发环境 - 预发环境 - 生产环境四个环节。每个人在本地环境完成后将代码提交，会自动发布到集成开发环境;预发环境的存在，是想在上线之前，在同样的生产环境下，做最终的确认，之后再更新到用户环境中。</p><p><img src="http://p32.qhimg.com/t01e3da12bafe71ba13.jpg?size=600x331"></p><p>代码管理的流程，从仓库来说，首先有 <a href="http://m.so.com/s?q=master&amp;src=newstranscode" class="qkw">master</a> 和 dev 两个长期分支，master 是主干分支，dev 是开发的集成环境 。当要修改 bug或者开发新特性时会新建一个新分支，问题修复后需要将这个分支 merge 到 dev 分支，需要上线时就合并到 master，这是一个特定的生命周期。</p><p>代码在推向预发环境前要经过其他成员的审核，审核之后才会合并。合并后使用 git hooks 工具，自动将代码更新到预发环境，在App客户端 内部会做一些开关控制它用哪个环境。</p><p><img src="http://p32.qhimg.com/t01cb8c78a5aff4016b.jpg?size=602x537"></p><p>在整个过程中，对所有同学都是透明的，我们使用了 <a href="http://m.so.com/s?q=Slack&amp;src=newstranscode" class="qkw">Slack</a> 作为消息枢纽，Slack 订阅了 Github 通知事件。团队里面的每一位成员，只要关注项目都会看到所有的动态，包括特性上线、Bug修复等。还有一个工具 <a href="http://m.so.com/s?q=fabric&amp;src=newstranscode" class="qkw">fabric</a>， 这是一个 异常上报 组件，客户端集成 fabric sdk后就可以将异常上报到 fabric，fabric再通知到 Slack, 团队成员就能在 slack 中看到客户端运行动态了。</p><p>重复轮子:框架 / 类库 / <a href="http://m.so.com/s?q=%E5%BC%80%E6%BA%90%E8%BD%AF%E4%BB%B6&amp;src=newstranscode" class="qkw">开源软件</a></p><p class="header">框架</p><p>其一，为了保证开发效率，希望框架使用起来能够足够简单，新的团队成员也能够很好地适应。关于颇受争议的 ORM 需要观察它的适用情况，在用户规模尚小、数据量较小时，ORM 能够快速实现业务需求，而当量级渐长就该果断舍弃;其二，框架必须保证功能强大，以尽可能减少开发量。基于以上的综合考虑，美芽选择选择使用了以下PHP框架和工具:</p><p><img src="http://p32.qhimg.com/t0184eb3aebe510ec30.jpg?size=600x450"></p><p>2. DB <a href="http://m.so.com/s?q=migration&amp;src=newstranscode" class="qkw">migration</a>，这个是修改数据表结构的一个工具。刚刚提及的需求会较不稳定，经常会遇到字段的增减，而此类操作如果只是手动修改，并需要同步到其它环境，将极其不利于管理。DB migration 这个机制是用要代码表示数据库字段的增删。</p><p><img src="http://p33.qhimg.com/t01a50f52eb7c9c3bbd.jpg?size=600x406"></p><p>譬如在增设字段时，新增一个类表示对数据表的操作，其中，up 方法就是执行修改，down 是回滚修改。等到上线时，就只需更新 PHP代码，这就统一了表结构的统一操作，所有的东西都用代码呈现，呈现又是文本，可以进行版本管理。人员对数据库的所有操作都有纪录。</p><p>3. Command。比如，开发一个<a href="http://m.so.com/s?q=%E5%91%BD%E4%BB%A4%E8%A1%8C&amp;src=newstranscode" class="qkw">命令行</a>工具，让用户输入一个名字，根据名字调用信息，需要包含输入参数，和选项参数以及输出。Command 会将这些东西做包装，不需要开发除了产品业务逻辑之外的东西。</p><p><img src="http://p33.qhimg.com/t01625bcbbc822c415c.jpg?size=600x425"></p><p>4. Queue，进行很多操作时不能同步等待，比如推送一条消息，发布一条评论让对方收到消息通知，肯定不能在请求里同步处理，而是要放到队列里异步执行，再推送到苹果的服务器最后推送到用户。这个例子是项目中用的，我们添加队列的时候只需在服务器上执行一条命令打开这个队列。</p><p><img src="http://p31.qhimg.com/t016e4cb76a7065b588.jpg?size=600x438"></p><p>5. Tinker，这也是命令行的工具，可以做到在执行这条命令的时候，把整个项目环境加载进去。而且是一个交互式的操作，比如要取一个对象就可以直接查询，把信息打出来。相比较调试代码时用url或者添加各种参数，这种处理方式会非常方便。</p><p><img src="http://p35.qhimg.com/t01ac7c626e890f2122.jpg?size=600x371"></p><p>6. 还有一个是对 Log 的处理，使用时只需要配置一下，在当前环境下需要打的 Log 级别，在代码中直接使用即可，或者在生产中将这类信息都保留。</p><p><img src="http://p35.qhimg.com/t01acee10756b8d9c6a.jpg?size=600x440"></p><p>上面使用的每一项都不是太复杂，或者难度特别大，自己做也都可以。但在资源有限的情况下，初创团队更重要的是投入更大的时间和精力在业务上。这个框架是集成了开发中一些通用的内容，减少了很多额外的开发工作。</p><p><img src="http://p31.qhimg.com/t01fc923450c41cf6e7.jpg?size=600x376"></p><p>虽然看上去 Laravel 框架非常美好，但美好都是有代价的，Laravel 框架非常的慢。因为它提供了各种封装、加载了很多东西，导致一个空的接口响应时间也需要几十毫秒。所以更适合量不大的初创产品。但与此同时，美芽也正在积极解决效率问题。</p><p>再来看 iOS 类库，REST 只是定义了标准，而没有提供完整的工具来实现，通常服务端返回的是 <a href="http://m.so.com/s?q=JSON&amp;src=newstranscode" class="qkw">JSON</a> 格式数据，客户端将收到的 JSON 格式转换成 <a href="http://m.so.com/s?q=NSDictionary&amp;src=newstranscode" class="qkw">NSDictionary</a>，再由 NSDictionary 转换成 NSObject, 这可能对应到客户端的一个 Model 或者一个具体对象;客户端发请求到服务端时，就需要将 NSObject 转化成 NSDictionary， 再转换成 JSON 格式，然后发送到服务端。这个过程非常烦锁，而且需要对每个类都实现一套 encode decode 的逻辑，而实质上我们关心的只是 Value 而已。我们引进了 Mantle 库，这个库会帮你实现这一系列封包解包的过程。</p><p><img src="http://p33.qhimg.com/t01474350826ca9035c.jpg?size=600x399"></p><p>再加上 TMCache AFNetworking 这两个库(前者用来实现快速的对象缓存，而后者基本上每个 iOS 程序员都熟悉的一个网络框架)，就能实现整个产品的 Model 层。</p><p><img src="http://p33.qhimg.com/t01c0d4e410693b21b2.jpg?size=600x317"></p><p>最后介绍一套开源软件 ELK(Elastic<a href="http://m.so.com/s?q=search&amp;src=newstranscode" class="qkw">search</a> Logstash <a href="http://m.so.com/s?q=Kibana&amp;src=newstranscode" class="qkw">Kibana</a>)，这一套软件主要用来处理日志，进而分析问题，其中Elasticsearch 负责存储+搜索、<a href="http://m.so.com/s?q=Logstash&amp;src=newstranscode" class="qkw">Logstash</a> 负责搜集、Kibana 负责展示，通过 ELK我们可以随时观察事件的发生，并作出及时妥当的处理。</p><p><img src="http://p34.qhimg.com/t01516b59579417cbdd.jpg?size=600x346"></p><p>比如客户端访问服务器时返回系统繁忙这些错误，或者是帖子加载过慢这些问题都可以通过这一套软件展示出来。虽然看似复杂，但实际操作却极其简单，现在我们主要分析程序内部日志，<a href="http://m.so.com/s?q=Nginx&amp;src=newstranscode" class="qkw">Nginx</a> access log 和 Nginx error log。</p><p><img src="http://p33.qhimg.com/t0159d0bfdbe6090434.jpg?size=600x260"></p><p>这些日志会先通过 <a href="http://m.so.com/s?q=logstash&amp;src=newstranscode" class="qkw">logstash</a> 采集，存储到 ES 上，再通过 Kibana 展示出来。</p><p>同时，这一套工具还有对运营数据分析的支持。接入这套工具，美芽实现了各种业务的简单统计，包括注册统计、地区分析、时间分析、用户活跃时间等等。接入 ELK 也是非常简单的，只需将原始数据导入，调用一些查询语句就可以展现，只需要调用一下接口、填入统计数据即可，业务上不需要做什么操作和修改，更无需修改数据库和代码主逻辑。</p><p><img src="http://p33.qhimg.com/t013d89c319ad7cbfb8.jpg?size=600x430"></p><p>美芽整体宏观架构如下图所示:美芽用户通过 APP 或者PC 版跟 Nginx 交互再访问 API，这里所产生的日志都会写文件，在文件写入之后就会有 Logstash Agent 会翻译成固定的格式存到 Elsearch， 同时 API 内部也会将日志会先输出到消息队列中，由消息队列再异步输出到 Logstash Agent，Dashboard 会调用 kibana 的接口，以运营能接受的形式展现出来，如下图:</p><p><img src="http://p31.qhimg.com/t0161daa18a77e9a804.jpg?size=600x353"></p><p>会管理线上服务器的客户端开发，才是一名好运维</p><p>特别介绍下美芽的运维，尽一人多用之能事，运维也兼做开发。在代码的上线流程中并不需要运维的参与，但软件安装、配置更新就需要运维处理。美芽的运维，主要是通过 Saltstack，用 <a href="http://m.so.com/s?q=YAML&amp;src=newstranscode" class="qkw">YAML</a> 来描述服务器的状态。YAML 作为一种比较简洁的数据格式，是纯文本的，也就是说服务器的所有状态都可以进行版本管理，服务器的状态可根据每个版本里面的配置文件体现出来服务器当前是什么样的状态。</p><p>看下面一个简单的示例，下图是一个 logstash 的 saltstack 配置:</p><p><img src="http://p31.qhimg.com/t0131db2d7de3bbdd2e.jpg?size=600x322"></p><p>首先是有一个 master 节点，这是一个中心节点，然后有很多的 minion 节点需要被更新。</p><p><img src="http://p34.qhimg.com/t019b9b239193e151ae.jpg?size=600x473"></p><p>执行以下一条命令就可以将所有的 minion 更新了，命令有两个参数，一个是 prod，是一个分组的概念，比如五台服务器，把五台服务器都放到分组里面;后面一个参数 production, 代表生产环境。操作时，前半部分是针对五台服务器做的工作。</p><p>作者简介:姚东旭，美芽 CTO，原腾讯工程师，曾在 QQ 会员以及微云产品中心做研发工作，由于个人兴趣以及工作原因，做过各种平台的开发，目前主要关注 DevOps、团队开发效率以及代码质量保证等领域。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.csdn.net/article/2015-05-12/2824668">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='4ad855c76a5f6c2a13d8b14554f69da4'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>从零到一</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%BB%8E%E9%9B%B6%E5%88%B0%E4%B8%80&amp;pn=1&amp;pos=6&amp;m=d77362b18daf2f4228f74952514d00a2a000b9fc&amp;u=http%3A%2F%2Fauto.sohu.com%2F20150624%2Fn415567170.shtml" data-pos="1"> 孙晓东重构营销体系 观致实现<b>从零到壹</b> </a>   <li> <a href="/transcode?q=%E4%BB%8E%E9%9B%B6%E5%88%B0%E4%B8%80&amp;pn=1&amp;pos=7&amp;m=9464941104894de5320c4840cbd03d60d70cf473&amp;u=http%3A%2F%2Fwww.csdn.net%2Farticle%2F2015-05-12%2F2824668" data-pos="2"> <b>从零到一</b>,美芽的技术实战 </a>   <li> <a href="/transcode?q=%E4%BB%8E%E9%9B%B6%E5%88%B0%E4%B8%80&amp;pn=1&amp;pos=8&amp;m=0fe31e654a63aa84ce0b287d611bbe98cd481f55&amp;u=http%3A%2F%2Fit.southcn.com%2F9%2F2015-06%2F03%2Fcontent_125548381.htm" data-pos="3"> 任剑琼:风投就是见证"<b>从零到一</b>" </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '从零到一，美芽的技术实战' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '从零到一，美芽的技术实战'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";