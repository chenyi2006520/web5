s:22973:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>沈阳师范大学2015年在职教育硕士招生简章- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">沈阳师范大学2015年在职教育硕士招生简章</h1> <p id="source-and-time"><span id=source>搜狐</span><time id=time>2015-06-24 11:37:51</time></p> </header>  <div id="news-body"><p>广大考生请注意:今年是在职教育硕士招生的最后一年，勤思在职考研辅导老师提醒大家要抓住机会，争取考上理想的院校!各招生单位2015年在职攻读教育硕士专业学位招生简章、招生专业目录、参考书目正在陆续发布，我们会在第一时间发布相关信息。以下是<a href="http://m.so.com/s?q=%E6%B2%88%E9%98%B3%E5%B8%88%E8%8C%83%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">沈阳师范大学</a>2015在职攻读教育硕士专业学位招生简章，敬请大家关注!</p><p>沈阳师范大学隶属于<a href="http://m.so.com/s?q=%E8%BE%BD%E5%AE%81%E7%9C%81%E4%BA%BA%E6%B0%91%E6%94%BF%E5%BA%9C&amp;src=newstranscode" class="qkw">辽宁省人民政府</a>，是一所涵盖哲学、经济学、法学、教育学、文学、理学、工学、管理学、艺术学等九大门类的多科性大学。学校占地面积1888.69亩，共有全日制本、专科生22000余人，硕士研究生3300余人。学校拥有专任教师1597人，其中二级教授26人，教授278人、副教授641人。现有本科专业73个，硕士学位一级学科授权点18个,硕士学位二级学科授权点128个，专业学位授权点11个，是<a href="http://m.so.com/s?q=%E6%99%AE%E9%80%9A%E9%AB%98%E7%AD%89%E5%AD%A6%E6%A0%A1&amp;src=newstranscode" class="qkw">普通高等学校</a>推荐优秀应届本科毕业生免试攻读硕士学位研究生单位，是中国政府和<a href="http://m.so.com/s?q=%E5%AD%94%E5%AD%90%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">孔子学院</a>奖学金留学生接受单位,是商务部援外培训承办单位, 是教育部首批开展专业学位研究生教育综合改革试点单位。</p><p>自1998年获得教育硕士专业学位授予权以来，我校始终坚持“面向基础教育，培养高层次、应用型专门人才”的办学定位，为<a href="http://m.so.com/s?q=%E8%BE%BD%E5%AE%81%E7%9C%81&amp;src=newstranscode" class="qkw">辽宁省</a>基础教育和教育管理部门培养了2400余名教育硕士。为了适应国家专业学位教育改革工作新形势的需要，学校于2010年组建教育硕士研究生院，统筹全校教育硕士培养工作。目前，教育硕士研究生院设有教育管理、现代教育技术、学前与初等教育、语文、英语和综合6个专业教学部，在15个领域分别招收全日制教育硕士和在职教育硕士。</p><p class="header">一、报考条件:</p><p>2012年7月31日前国民教育序列大学本科(含全日制、自考、电大、函授，要求学信网可查到本人信息)或本科以上毕业并取得毕业证书(一般应有学士学位)的在职普通中学、小学、幼儿园和其他中等学校的文化基础课专任教师或管理人员，以及省、市、区、县教育研究部门或政府机关教育系统中有相当于中学、小学、幼儿园教师职务的教研员或管理人员。</p><p class="header">二、学制、学习方式及学费</p><p>在职教育硕士专业学位教育实行寒暑假集中面授+课外研修和学分制管理，实行2-5年弹性学制。学费为18000元(以物价部门最后审核为准)。</p><p class="header">三、招生人数及领域</p><p>沈阳师范大学2015年拟招收在职教育硕士研究生100人。</p><p>设教育管理、学科教学(数学、物理、化学、生物、思政、语文、英语、音乐、体育、美术)、小学教育、现代教育技术、心理健康教育和<a href="http://m.so.com/s?q=%E5%AD%A6%E5%89%8D%E6%95%99%E8%82%B2&amp;src=newstranscode" class="qkw">学前教育</a>等15个招生领域。其中，现代教育技术领域招收中小学信息技术课程专任教师和从事相关工作的教育教学管理人员。</p><p class="header">四、考试科目、时间及地点</p><p>1.考试科目:外国语(英语、日语、俄语选一，英语专业为英二)、教育学和心理学综合、政治理论、专业课考试(含面试)，共计4门。外国语、教育学和心理学综合为全国联考;政治理论和专业课考试由我校自行命题，考试时间安排在复试阶段。</p><p>2.全国联考的时间为:2015年10月25日，具体科目的考试时间以准考证为准;复试考试及录取时间约为2016年1-2月份，具体时间请关注我校教育硕士网(http://jyss.synu.edu.cn/)。</p><p>3. 全国联考考试地点详见“准考证”。</p><p class="header">五、录取方式</p><p>学校将根据考生入学考试成绩(含复试)划定录取分数线，择优录取。</p><p class="header">六、报名工作程序及要求</p><p class="header">(一)网上报名</p><p>考生于6月23日-7月11日访问全国统一报名网站“中国学位与研究生教育信息网”(以下简称学位网，网址)，登陆“在职人员攻读硕士专业学位管理信息平台”(以下简称信息平台，考生登录入口:http://www.chinadegrees.cn/zzlk)，按信息平台说明和要求注册、上传本人近期电子照片、填写提交报名信息和网上缴纳报名考试费，完成网上报名，生成并打印<a href="http://m.so.com/s?q=%E3%80%8A2015%E5%B9%B4%E5%9C%A8%E8%81%8C%E4%BA%BA%E5%91%98%E6%94%BB%E8%AF%BB%E7%A1%95%E5%A3%AB%E4%B8%93%E4%B8%9A%E5%AD%A6%E4%BD%8D%E6%8A%A5%E5%90%8D%E7%99%BB%E8%AE%B0%E8%A1%A8%E3%80%8B&amp;src=newstranscode" class="qkw">《2015年在职人员攻读硕士专业学位报名登记表》</a>。具体要求如下:</p><p>1.资格自审。所有报考者须满足教育硕士应具备的条件。在网上填写报名信息前，必须认真阅读教育硕士应具备的条件，确定自己是否符合报考资格。如因不符合考试报名条件或提供虚假信息而未能被招生单位录取，责任由考生自负，所缴报名考试费不予退还。</p><p class="header">2.按要求填写并提交报名信息。</p><p>3.上传本人近期电子照片(采用中国护照证件照片标准，具体要求见附件1，该电子照片将在<a href="http://m.so.com/s?q=%E3%80%8A%E6%8A%A5%E5%90%8D%E7%99%BB%E8%AE%B0%E8%A1%A8%E3%80%8B&amp;src=newstranscode" class="qkw">《报名登记表》</a>、《资格审查表》、准考证、成绩单上使用)。我校将对考生上传的电子照片进行审核，若审核未通过，信息平台将自动向该考生发送手机短信和电子邮件，该考生需重新上传标准照片。照片未经审核或审核不通过的考生不能进行现场确认。</p><p>4.现场确认前，可以随时浏览、修改相关信息。</p><p>5.网报成功后，生成<a href="http://m.so.com/s?q=%E3%80%8A%E6%8A%A5%E5%90%8D%E7%99%BB%E8%AE%B0%E8%A1%A8%28%E6%A0%B7%E8%A1%A8%29%E3%80%8B&amp;src=newstranscode" class="qkw">《报名登记表(样表)》</a>，核准相关信息并打印。</p><p class="header">(二)现场确认</p><p>所有网上缴费成功且照片审核通过的考生须于7月12日-15日每天早9:00至16:00持第二代居民身份证、学历和学位证书原件以及<a href="http://m.so.com/s?q=%E3%80%8A2015%E5%B9%B4%E5%9C%A8%E8%81%8C%E4%BA%BA%E5%91%98%E6%94%BB%E8%AF%BB%E7%A1%95%E5%A3%AB%E5%AD%A6%E4%BD%8D%E6%8A%A5%E5%90%8D%E7%99%BB%E8%AE%B0%E8%A1%A8%E3%80%8B&amp;src=newstranscode" class="qkw">《2015年在职人员攻读硕士学位报名登记表》</a>，到沈阳师范大学知行楼219室进行现场核验并确认报名信息。报名信息经考生签字确认后，一律不得更改。</p><p>考生应在规定的期限内完成网上报名和现场确认工作，逾期不予办理。只完成网上报名但未在规定时间内办理现场确认手续的，本次报名无效，所缴报名考试费不予退还。</p><p class="header">(三)报名证件要求与预报名</p><p>居住在<a href="http://m.so.com/s?q=%E4%B8%AD%E5%8D%8E%E4%BA%BA%E6%B0%91%E5%85%B1%E5%92%8C%E5%9B%BD&amp;src=newstranscode" class="qkw">中华人民共和国</a>境内的公民(含现役军人和人民武装警察)须持第二代居民身份证报名，其他人员须持港澳台身份证件、华侨身份证或外籍护照报名。</p><p>由于证件遗失或尚未办理等原因，无法在现场确认时出具上述规定的有效身份证件的考生，网上报名时证件类型应选择“暂无”。在现场确认时须签署<a href="http://m.so.com/s?q=%E3%80%8A%E9%A2%84%E6%8A%A5%E5%90%8D%E6%89%BF%E8%AF%BA%E4%B9%A6%E3%80%8B&amp;src=newstranscode" class="qkw">《预报名承诺书》</a>，并于10月9日持规定的有效身份证件到沈阳师范大学知行楼203室修改信息。届时未兑现承诺的将无法下载准考证，本次报名无效，所缴报名考试费不予退还。</p><p class="header">七、准考证下载</p><p>报名成功的考生须于10月15日后，登录信息平台下载本人准考证，并持此准考证参加考试。</p><p class="header">八、资格审查</p><p>考试成绩发布后，通过我校公布的复试分数线的考生登录学位网，下载本人<a href="http://m.so.com/s?q=%E3%80%8A2015%E5%B9%B4%E5%9C%A8%E8%81%8C%E4%BA%BA%E5%91%98%E6%94%BB%E8%AF%BB%E7%A1%95%E5%A3%AB%E4%B8%93%E4%B8%9A%E5%AD%A6%E4%BD%8D%E8%B5%84%E6%A0%BC%E5%AE%A1%E6%9F%A5%E8%A1%A8%E3%80%8B&amp;src=newstranscode" class="qkw">《2015年在职人员攻读硕士专业学位资格审查表》</a>，一式两份，由所在单位人事部门(或档案管理部门，下同)填写推荐意见，并在落款及电子照片处加盖公章;将该表与学历、学位证书在复试考试阶段一并提交我校教育硕士研究生院进行资格审查。如考生持境外学历、学位报考，资格审查时须提交教育部留学服务中心出具的认证报告。因不符合考试报名条件、提供虚假信息或不能提供相关材料而未被录取，责任由考生自负。</p><p>九、教育硕士全国联考科目考试大纲和参考书目</p><p><img src="http://p33.qhimg.com/t01345d5751a224dbe4.jpg?size=600x321"></p><p class="img-title">十、学位授予</p><p>课程考试合格、修满规定学分并通过教育硕士学位论文答辩者将授予教育硕士(Ed.M)专业学位证书。</p><p><a href="http://m.so.com/s?q=%E5%8D%81%E4%B8%80&amp;src=newstranscode" class="qkw">十一</a>、招生改革</p><p>从2016年起，国务院学位办将不再组织在职人员攻读教育硕士专业学位全国联考，在职人员攻读教育硕士专业学位招生工作将以非全日制研究生教育形式纳入国家招生计划和全国硕士研究生统一入学考试。</p><p class="header">十二、联系方式</p><p class="header">1.联系方式:</p><p class="header">沈阳师范大学教育硕士研究生院</p><p class="header">田老师024-86592009</p><p class="header">李老师024-86578475</p><p>2.网    址:沈阳师范大学教育硕士网()。</p><p>3.通信地址:沈阳市<a href="http://m.so.com/s?q=%E7%9A%87%E5%A7%91%E5%8C%BA&amp;src=newstranscode" class="qkw">皇姑区</a>黄河北大街253号，邮编:110034</p><p>4.乘车方式:<a href="http://m.so.com/s?q=%E6%B2%88%E9%98%B3%E7%AB%99&amp;src=newstranscode" class="qkw">沈阳站</a>乘255路公共汽车，<a href="http://m.so.com/s?q=%E6%B2%88%E9%98%B3%E5%8C%97%E7%AB%99&amp;src=newstranscode" class="qkw">沈阳北站</a>乘236路公共汽车到沈阳师范大学站下车;乘坐地铁<a href="http://m.so.com/s?q=2%E5%8F%B7%E7%BA%BF&amp;src=newstranscode" class="qkw">2号线</a>师范大学站下车D出口。</p><p class="header">沈阳师范大学 教育硕士研究生院</p><p>2015年6月19日</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://learning.sohu.com/w/news/20150624/415544495.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='457a308c74a0a24ef213858faa71bcc3'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>沈阳师范学院</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%B2%88%E9%98%B3%E5%B8%88%E8%8C%83%E5%AD%A6%E9%99%A2&amp;pn=1&amp;pos=6&amp;m=f248e7a886ccbbe9ce6928732960ac8ba513e711&amp;u=http%3A%2F%2Fwww.gx211.com%2Fnews%2F201634%2Fn6898342454.html" data-pos="1"> <b>沈阳师范大学</b>2016年高水平运动员招生简章 </a>   <li> <a href="/transcode?q=%E6%B2%88%E9%98%B3%E5%B8%88%E8%8C%83%E5%AD%A6%E9%99%A2&amp;pn=1&amp;pos=7&amp;m=b02ee70f26922ea48042b2148d64732dabc74437&amp;u=http%3A%2F%2Fwww.chinadaily.com.cn%2Fdfpd%2Fdl%2F2015-01%2F08%2Fcontent_19270614.htm" data-pos="2"> <b>沈阳师范大学</b>:六成毕业生选择沈阳大连就业 </a>   <li> <a href="/transcode?q=%E6%B2%88%E9%98%B3%E5%B8%88%E8%8C%83%E5%AD%A6%E9%99%A2&amp;pn=1&amp;pos=8&amp;m=b1c0a31fa2324c5f4f07b8513788db7fa08c3be0&amp;u=http%3A%2F%2Flearning.sohu.com%2Fw%2Fnews%2F20150624%2F415544495.shtml" data-pos="3"> <b>沈阳师范大学</b>2015年在职教育硕士招生简章 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '沈阳师范大学2015年在职教育硕士招生简章' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '沈阳师范大学2015年在职教育硕士招生简章'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";