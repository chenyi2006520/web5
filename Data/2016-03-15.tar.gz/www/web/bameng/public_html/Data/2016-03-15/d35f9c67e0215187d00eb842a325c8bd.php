s:20282:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>百度手机卫士:315 保障移动互联网安全- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">百度手机卫士:315 保障移动互联网安全</h1> <p id="source-and-time"><span id=source>中华网</span><time id=time>2016-03-14 17:35:01</time></p> </header>  <div id="news-body"><p>【IT168 资讯】明天就是3.15消费者权益保护日，今年央视3.15晚会主题为“共筑消费新生态”，随着<a href="http://m.so.com/s?q=%E7%A7%BB%E5%8A%A8%E4%BA%92%E8%81%94%E7%BD%91&amp;src=newstranscode" class="qkw">移动互联网</a>时代到来，社会消费结构和人们消费观念、方式都发生了日新月异的变化。据悉，今年的晚会将会更加聚焦新型消费领域的信息安全。然而，早在去年的3.15晚会上，免费<a href="http://m.so.com/s?q=WiFi&amp;src=newstranscode" class="qkw">WiFi</a>安全隐患、诈骗短信等被重点曝光，移动互联网安全问题就已经被推上了风口浪尖。据百度安全近期发布的<a href="http://m.so.com/s?q=%E3%80%8A2015%E4%B8%AD%E5%9B%BD%E4%BA%92%E8%81%94%E7%BD%91%E5%AE%89%E5%85%A8%E7%99%BD%E7%9A%AE%E4%B9%A6%E3%80%8B&amp;src=newstranscode" class="qkw">《2015中国互联网安全白皮书》</a>(以下简称《白皮书》)中数据显示，风险WiFi、电信诈骗等安全问题在2015年仍处在上升阶段，除此之外伪基站短信和钓鱼短信也日趋增多，成为时下新兴的诈骗手段，2015年国内移动互联网的安全问题依旧十分严峻。</p><p class="header">免费WiFi不“免费”</p><p>在信息膨胀化的今天，流量费用成了手机用户头疼的问题，出门在外连接几乎零成本的免费WiFi无疑是“最好”的选择，然而这却给不法分子提供了犯罪机会。</p><p>伪装公共WiFi诱骗用户连接是不法分子惯用的伎俩。譬如在<a href="http://m.so.com/s?q=%E9%BA%A6%E5%BD%93%E5%8A%B3&amp;src=newstranscode" class="qkw">麦当劳</a>附近，不法分子建立一个名为McDonald_Free的免费<a href="http://m.so.com/s?q=%E6%97%A0%E7%BA%BF%E7%BD%91%E7%BB%9C&amp;src=newstranscode" class="qkw">无线网络</a>，与公共WiFi极其相似的名称设置，会极大提升 “钓鱼”的成功率。用户一旦连接上风险WiFi，手机中的隐私信息就会被不法分子截取保留下来，社交软件、支付软件等重要的账号和密码、<a href="http://m.so.com/s?q=%E6%89%8B%E6%9C%BA%E9%80%9A%E8%AE%AF%E5%BD%95&amp;src=newstranscode" class="qkw">手机通讯录</a>等便彻底暴露在不法分子面前，个人财产安全从而面临严重威胁。</p><p>对于免费公共WiFi的安全隐患问题，<a href="http://m.so.com/s?q=%E7%99%BE%E5%BA%A6%E6%89%8B%E6%9C%BA%E5%8D%AB%E5%A3%AB&amp;src=newstranscode" class="qkw">百度手机卫士</a>的WiFi安全检测将为用户从根源上解决WiFi安全问题，为用户的手机上网安全给予高度保障。同时，对用户而言，日常生活中应谨慎使用免费公共WiFi，关闭手机中自动连接WiFi的功能，同时如果使用免费WiFi，尽量不要进行网络购物和网银支付的操作，可最大程度的避免个人重要信息遭到泄露。</p><p><img src="http://p32.qhimg.com/t01d783b7350d7115c8.jpg?size=500x426"></p><p class="img-title">骚扰电话、伪基站短信上升最明显</p><p>“喂，您好，我是“<a href="http://m.so.com/s?q=%E5%BB%BA%E8%AE%BE%E9%93%B6%E8%A1%8C&amp;src=newstranscode" class="qkw">建设银行</a>”的客服人员，正值建设银行<a href="http://m.so.com/s?q=%E5%BB%BA%E8%A1%8C&amp;src=newstranscode" class="qkw">建行</a>30周年，我行目前正在举办回馈用户的活动，需要您留下身份证号和银行卡号，为您办理自动升级金卡业务。”生活中我们经常接到这样的电话，当你留下身份证号和银行卡号以后，这才发现遭遇了诈骗。据<a href="http://m.so.com/s?q=%E3%80%8A%E7%99%BD%E7%9A%AE%E4%B9%A6%E3%80%8B&amp;src=newstranscode" class="qkw">《白皮书》</a>数据显示，2015年全国的诈骗电话总量为88.3亿，犯罪分子通常会冒充银行、运营商的客服人员，利用人们贪财逐利的心理进行诈骗。这样的诈骗电话不仅扰民，更会给用户带来直接经济损失。</p><p>除诈骗电话外，2015年更令人防不胜防的是伪基站短信。根据数据显示，2015年全国伪基站短信量达23.2亿条，较2014年同比上涨95%。尤其以冒充各大银行的“955”系列号码伪基站短信最多，占到了22%的比例，成为最具风险的诈骗形式。伪基站主要是通过新型的无线电发射装置，利用局部功率大的优势，干扰屏蔽运营商通信信号，然后伪装成运营商的网络，骗取用户手机连接到它自己建立的手机网上，最终强行向用户手机发送真假难辨的诈骗类短信。当用户收到任何可疑短信时切勿盲目相信，在经过多方面核实后才可对短信真伪进行判断，以免受骗。</p><p>百度安全专家表示，凭借独创的“云拦截”核心技术，百度手机卫士可自动拦截伪基站垃圾短信，准确率达到96%;同时依托百度大数据的优势，对于陌生主叫号码，百度手机卫士也能够准确识别对方是否为诈骗电话。对于无法安装安全软件的IOS用户，百度安全也已与<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E8%81%94%E9%80%9A&amp;src=newstranscode" class="qkw">中国联通</a>、移动进行合作，只需开通运营商提供的“防骚扰提醒”服务，便可轻松获得提醒从而规避风险。</p><p><img src="http://p31.qhimg.com/t016ea6dea12e0f2361.jpg?size=301x530"></p><p>钓鱼短信肆虐，<a href="http://m.so.com/s?q=%E7%A7%BB%E5%8A%A8%E6%94%AF%E4%BB%98&amp;src=newstranscode" class="qkw">移动支付</a>要当心</p><p><img src="http://p33.qhimg.com/t014b2131dbd94e9713.jpg?size=405x229"></p><p>央视3.15晚会已经连续三年关注信息安全问题。2013年央视315聚焦安全网购;2014年央视315晚会曝光网银支付被指存漏洞;2015年央视315晚会曝光公共场所无密码<a href="http://m.so.com/s?q=wifi&amp;src=newstranscode" class="qkw">wifi</a>陷阱。但是依然不断有用户网购被骗、<a href="http://m.so.com/s?q=%E7%AC%AC%E4%B8%89%E6%96%B9%E6%94%AF%E4%BB%98&amp;src=newstranscode" class="qkw">第三方支付</a>软件被盗号等恶意行为发生。这主要是由于，伴随大量涌现的恶意山寨应用对用户隐私窃取的情况不断发生，用户最常用的淘宝、<a href="http://m.so.com/s?q=%E6%94%AF%E4%BB%98%E5%AE%9D&amp;src=newstranscode" class="qkw">支付宝</a>、京东商城、美团、<a href="http://m.so.com/s?q=%E5%A4%A9%E7%8C%AB&amp;src=newstranscode" class="qkw">天猫</a>等应用成为山寨应用的主要模仿目标。由于这类应用往往都需要用户输入账号密码等隐私信息，一旦用户使用山寨应用，其账号密码等隐私就会轻易的被窃取。</p><p>同时，根据百度安全统计，2015年还出现了不少新的支付诈骗伎俩，主要包括:钓鱼网站积分兑换、冒充熟人请你接收照片、航空公司航班改签、汽车公司汽车退税、国家生育或丧葬费用补贴、冒充公检法的涉案汇款以及房租到期房东请求汇款。这七种诈骗手段都和移动支付挂钩，且通常会以短信形式出现，并在短信结尾附带一条网站链接。一旦用户警惕性不高点击链接，便会进行下载携带<a href="http://m.so.com/s?q=%E6%9C%A8%E9%A9%AC&amp;src=newstranscode" class="qkw">木马</a>病毒的山寨app或进行手机支付、密码填写等危险操作，用户很容易在不知不觉中泄露隐私，让不法分子得手。</p><p><img src="http://p32.qhimg.com/t0190000fd7d52a22ac.jpg?size=350x599"></p><p>面对不法分子层出不穷的诈骗手段，用户一方面需要提高警惕，不要轻信短信内容，被奖品冲昏头脑;一方面对于自身无法识别的钓鱼网站等威胁，需要安装诸如百度手机卫士等专业的安全软件进行防护。据悉，百度手机卫士已经具有全面的扫描和分析能力，能够准确识别恶意代码和虚假网址，在系统层面进行了全面防护。当用户打开某一个支付类APP或者打开某一网址时，百度手机卫士会对当前支付环境进行扫描，提醒用户是否安全。</p><p>移动互联网改变着人们的生活方式，同时也将人们置于相对更高的风险之下。2016年随着<a href="http://m.so.com/s?q=%E6%99%BA%E8%83%BD%E6%89%8B%E6%9C%BA&amp;src=newstranscode" class="qkw">智能手机</a>和移动互联网的进一步发展，用户面临着安全风险也将越来越多。百度安全专家提示，<a href="http://m.so.com/s?q=%E5%A4%A9%E4%B8%8B%E6%B2%A1%E6%9C%89%E5%85%8D%E8%B4%B9%E7%9A%84%E5%8D%88%E9%A4%90&amp;src=newstranscode" class="qkw">天下没有免费的午餐</a>，广大用户一定要从提高自身安全防范意识，同时下载安装如百度手机卫士的手机安防软件，保障手机安全。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://tech.china.com/news/it/11146618/20160314/21931474_all.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='a17d939c68a1a493b8bf77a872b96064'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>移动互联网技术</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%A7%BB%E5%8A%A8%E4%BA%92%E8%81%94%E7%BD%91%E6%8A%80%E6%9C%AF&amp;pn=1&amp;pos=4&amp;m=81c9663f4f501c203ad554df829ab72adce98f21&amp;u=http%3A%2F%2Fwww.cctime.com%2Fhtml%2F2016-3-14%2F1147960.htm" data-pos="1"> 百度手机卫士:315维权日,领先保障<b>移动互联网</b>安全 </a>   <li> <a href="/transcode?q=%E7%A7%BB%E5%8A%A8%E4%BA%92%E8%81%94%E7%BD%91%E6%8A%80%E6%9C%AF&amp;pn=1&amp;pos=5&amp;m=f65940af99b71363c89531aff21a1595702aa82c&amp;u=http%3A%2F%2Finsurance.hexun.com%2F2016-03-14%2F182744737.html" data-pos="2"> 按天买的车险,易秒通科技<b>移动互联网</b>车险产品天天保正式发布 </a>   <li> <a href="/transcode?q=%E7%A7%BB%E5%8A%A8%E4%BA%92%E8%81%94%E7%BD%91%E6%8A%80%E6%9C%AF&amp;pn=1&amp;pos=6&amp;m=ed6c259a41056fb25c1b1f76601eda78fe59b0fd&amp;u=http%3A%2F%2Ffinance.sina.com.cn%2Froll%2F2016-03-13%2Fdoc-ifxqhmve9131188.shtml" data-pos="3"> 【重点推荐二】解码<b>移动互联网</b>新骗局 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '百度手机卫士:315 保障移动互联网安全' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '百度手机卫士:315 保障移动互联网安全'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";