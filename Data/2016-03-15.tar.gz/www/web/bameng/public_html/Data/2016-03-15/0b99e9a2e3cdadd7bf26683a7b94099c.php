s:19468:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>鸡鸣寺樱花开啦!一路逛吃逛吃根本停不下来!- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">鸡鸣寺樱花开啦!一路逛吃逛吃根本停不下来!</h1> <p id="source-and-time"><span id=source>搜狐</span><time id=time>2016-03-11 20:13:43</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t01d64595aa053ac4d4.gif?size=1346x488"></p><p class="img-title">每年3月是观赏樱花的大好时节</p><p><a href="http://m.so.com/s?q=%E9%B8%A1%E9%B8%A3%E5%AF%BA&amp;src=newstranscode" class="qkw">鸡鸣寺</a>的樱花开啦!</p><p><img src="http://p32.qhimg.com/t016df79307170041fe.png?size=600x433"></p><p class="img-title">活生生看饿了!赏完樱花去吃点啥?</p><p><a href="http://m.so.com/s?q=%E5%88%98%E9%95%BF%E5%85%B4&amp;src=newstranscode" class="qkw">刘长兴</a>(北京东路店)</p><p><img src="http://p31.qhimg.com/t01198f717a86a59265.jpg?size=497x677"></p><p>推荐理由:红色招牌，黄色字体，桌位很多，有汤包，<a href="http://m.so.com/s?q=%E8%8C%B6%E5%8F%B6%E8%9B%8B&amp;src=newstranscode" class="qkw">茶叶蛋</a>，鸭血粉丝汤，<a href="http://m.so.com/s?q=%E7%85%8E%E9%A5%BA&amp;src=newstranscode" class="qkw">煎饺</a>等等，南京老字号价格实惠味道正宗!</p><p class="header">人均:21元</p><p>地址: <a href="http://m.so.com/s?q=%E7%8E%84%E6%AD%A6%E5%8C%BA&amp;src=newstranscode" class="qkw">玄武区</a>北京东路57-2号(<a href="http://m.so.com/s?q=%E5%8D%97%E4%BA%AC%E5%A4%96%E5%9B%BD%E8%AF%AD%E5%AD%A6%E6%A0%A1&amp;src=newstranscode" class="qkw">南京外国语学校</a>对面南京人才大厦旁边)</p><p class="header">年代札记</p><p><img src="http://p31.qhimg.com/t014f66ae3ab7ed52ff.jpg?size=497x677"></p><p>推荐理由:听说这家店开了有些年头了，老板和老板娘是地道的台湾人，<a href="http://m.so.com/s?q=%E7%BD%97%E5%AE%8B%E6%B1%A4&amp;src=newstranscode" class="qkw">罗宋汤</a>里牛肉放得挺多挺实在~</p><p class="header">人均:59元</p><p>地址: 玄武区<a href="http://m.so.com/s?q=%E6%88%90%E8%B4%A4%E8%A1%97&amp;src=newstranscode" class="qkw">成贤街</a>文昌桥1号(近景月涧<a href="http://m.so.com/s?q=%E9%9F%A9%E5%9B%BD%E6%96%99%E7%90%86&amp;src=newstranscode" class="qkw">韩国料理</a>)</p><p>龙涎花甲(<a href="http://m.so.com/s?q=%E5%8C%97%E4%BA%AC%E4%B8%9C%E8%B7%AF&amp;src=newstranscode" class="qkw">北京东路</a>店)</p><p><img src="http://p33.qhimg.com/t01ecfb491c7020ec17.jpg?size=497x677"></p><p>推荐理由:特色的龙涎花甲，锡纸包着带汤烤的做法很特别，分量给的足，香菜自助加，汤汁略甜，微辣，是一种火锅和烧烤混合的味道，好吃~</p><p class="header">人均:16元</p><p>地址: 玄武区北京东路57号刘长兴茶餐厅对面</p><p class="header">蓝湾咖啡(北京东路店)</p><p><img src="http://p33.qhimg.com/t01daae08c45a821d1b.jpg?size=497x677"></p><p>推荐理由:连锁的咖啡店，菜品很好，口味比以前要进步很多，现在换了菜单，多了好多吃的，价格便宜，服务态度挺好~</p><p class="header">人均:55元</p><p>地址: 玄武区北京东路57号(鸡鸣寺地铁口4号出口,南京外国语学校对面)</p><p class="header">i厨-我家厨房</p><p><img src="http://p31.qhimg.com/t019b9beeba026174ec.jpg?size=497x677"></p><p>推荐理由:酸菜鱼，盆底配的是<a href="http://m.so.com/s?q=%E7%B2%89%E7%9A%AE&amp;src=newstranscode" class="qkw">粉皮</a>，应该是山芋粉皮，很劲道!豆花鱼特别好吃，豆花嫩滑爽口，而且没有豆腥味，分量足够。</p><p class="header">人均:32元</p><p>地址: 玄武区北京路外国语学校对面(七天连锁酒店隔壁)</p><p class="header">雅苑酒家</p><p><img src="http://p35.qhimg.com/t014a92f923f6adb4e3.jpg?size=497x677"></p><p>推荐理由:推荐他们家的<a href="http://m.so.com/s?q=%E7%83%A4%E9%B2%88%E9%B1%BC&amp;src=newstranscode" class="qkw">烤鲈鱼</a>，每次去必点的一道菜，锡纸裹着，蒜香味浓，老板娘也很热情，味道总体不错，但是就餐环境有些吵杂。</p><p class="header">人均:40元</p><p>地址: 玄武区文昌桥1号(<a href="http://m.so.com/s?q=%E4%B8%9C%E5%8D%97%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">东南大学</a>东大门)</p><p class="header">麦萌(北京东路店)</p><p><img src="http://p31.qhimg.com/t014c56ea5b92527a7b.jpg?size=497x677"></p><p>推荐理由:热热的饮品，既暖和又抵饿，口味也很浓郁，营业员很耐心告诉里面的成份和配料，服务很贴心到位。</p><p class="header">人均:12元</p><p>地址: 玄武区北京东路57号(南京外国语学校对面)</p><p class="header">串味鲜(太平北路店)</p><p><img src="http://p32.qhimg.com/t01018d6ae431d172ad.jpg?size=497x677"></p><p>推荐理由:相比于其他麻辣烫，他家全是袋装的食品，卫生程度满意，而且有调料，像<a href="http://m.so.com/s?q=%E7%81%AB%E9%94%85%E8%98%B8%E6%96%99&amp;src=newstranscode" class="qkw">火锅蘸料</a>一样可以使用，原味汤底味道很鲜美~</p><p class="header">人均:19元</p><p>地址: 玄武区梅园新村街道太平北路126-11号(小锅小灶隔壁)</p><p class="header">景月涧韩国料理</p><p><img src="http://p31.qhimg.com/t01597a55c24a6d3be0.jpg?size=497x677"></p><p>推荐理由:环境很干净很宽敞，茶水上来很快，还送了萝卜小菜，<a href="http://m.so.com/s?q=%E7%9F%B3%E9%94%85%E6%8B%8C%E9%A5%AD&amp;src=newstranscode" class="qkw">石锅拌饭</a>泡菜味正宗，饭的量很足，老板和服务员也挺客气的~</p><p class="header">人均:22元</p><p>地址: 玄武区文昌桥1号(近东南大学)</p><p class="header">德义餐厅</p><p><img src="http://p31.qhimg.com/t01b81d035ca9d5988f.jpg?size=497x677"></p><p>推荐理由:一家性价比特别高的餐馆!爆满!分量特别足，又快又好吃!推荐<a href="http://m.so.com/s?q=%E5%B1%B1%E8%8D%AF%E8%82%89%E7%89%87&amp;src=newstranscode" class="qkw">山药肉片</a>，山药又黏又滑裹着肉片好吃的一米!</p><p class="header">人均:17元</p><p>地址: 玄武区文昌桥1号(近东南大学东门)</p><p class="header">西安面馆(文昌桥店)</p><p><img src="http://p34.qhimg.com/t012c5325a92f8cc70f.jpg?size=497x677"></p><p>推荐理由:油泼面口感很像刀削面，杂酱的味道挺足的，有点油腻，裤带面口感很好，劲道足，肉也挺多的，凉面蒜味恰到好处，好吃~</p><p class="header">人均:9元</p><p>地址: 玄武区文昌桥2号(近成贤街)</p><p>高岗里小马<a href="http://m.so.com/s?q=%E7%89%9B%E8%82%89%E9%9D%A2&amp;src=newstranscode" class="qkw">牛肉面</a>(太平北路店)</p><p><img src="http://p32.qhimg.com/t01dc873e2176fb4acf.jpg?size=497x677"></p><p>推荐理由:这家牛肉面的口味真的不错，牛肉<a href="http://m.so.com/s?q=%E7%89%9B%E6%9D%82&amp;src=newstranscode" class="qkw">牛杂</a>卤得入味，分量足味道好，这里的拉面还不错，面条也很劲道。</p><p class="header">人均:11元</p><p class="header">地址: 玄武区太平北路(近文昌桥)</p><p class="header">CooffeeNetwork</p><p><img src="http://p33.qhimg.com/t01aa5275c0b1f95411.jpg?size=497x677"></p><p>推荐理由:一家很文艺的小店，墙上是飞天小女警的涂鸦画，还有辛普森插画，门口还有<a href="http://m.so.com/s?q=%E5%8D%97%E4%BA%AC%E5%91%B3%E9%81%93&amp;src=newstranscode" class="qkw">南京味道</a>的明信片，气泡系列的饮品很好喝，性价比很不错哒~</p><p>地址: 玄武区成贤街104号(<a href="http://m.so.com/s?q=%E6%9D%A8%E5%BB%B7%E5%AE%9D%E6%95%85%E5%B1%85&amp;src=newstranscode" class="qkw">杨廷宝故居</a>)对面,近东南大学东门</p><p class="header">风行茶饮</p><p><img src="http://p34.qhimg.com/t013050a688b082334d.jpg?size=497x677"></p><p>推荐理由:门面比较小，奶茶口味偏甜，珍珠奶茶还是不错的，珍珠有嚼劲，布丁奶茶中的布丁口感爽滑~</p><p class="header">人均:15元</p><p>地址: 玄武区大纱冒巷40号永和大王路口</p><p class="header">鸡鸣寺 樱花</p><p class="header">心醉于浪漫当中</p><p class="header">伴着花香暖意来</p><p class="header">也不要忘记犒劳“饿”意满满肚子哟</p><p>南京热门美食(ID:njfood025)原创，未经授权，禁止转载</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://chihe.sohu.com/20160311/n440168642.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='d15119e14bfdb30e31122385266c403b'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>樱花布丁</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%A8%B1%E8%8A%B1%E5%B8%83%E4%B8%81&amp;pn=1&amp;pos=8&amp;m=79310e1625dc10a91fc1e98f6d0899c3a8ede0cd&amp;u=http%3A%2F%2Fqingdao.iqilu.com%2Fmeishi%2Fmszx%2F2016%2F0225%2F2700593.shtml" data-pos="1"> 日本女生最爱!盘点那些貌美如花稀奇古怪的<b>布丁</b> </a>   <li> <a href="/transcode?q=%E6%A8%B1%E8%8A%B1%E5%B8%83%E4%B8%81&amp;pn=1&amp;pos=9&amp;m=4eb8c8797603ae95227fe674341ff470b8e5db0b&amp;u=http%3A%2F%2Ftravel.163.com%2F15%2F0310%2F01%2FAKAEK56300063JSA.html" data-pos="2"> 又到<b>樱花</b>季 这些粉嫩的pink美食吃起来! </a>   <li> <a href="/transcode?q=%E6%A8%B1%E8%8A%B1%E5%B8%83%E4%B8%81&amp;pn=1&amp;pos=10&amp;m=ad8160215ca6f7e69c101c71ab351069f9f03cb2&amp;u=http%3A%2F%2Fchihe.sohu.com%2F20160311%2Fn440168642.shtml" data-pos="3"> 鸡鸣寺<b>樱花</b>开啦!一路逛吃逛吃根本停不下来! </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '鸡鸣寺樱花开啦!一路逛吃逛吃根本停不下来!' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '鸡鸣寺樱花开啦!一路逛吃逛吃根本停不下来!'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";