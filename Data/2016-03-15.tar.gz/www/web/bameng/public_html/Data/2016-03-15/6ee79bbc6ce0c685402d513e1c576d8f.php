s:15780:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>跑过最美的风景遇见最好的你- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">跑过最美的风景遇见最好的你</h1> <p id="source-and-time"><span id=source>新浪</span><time id=time>2016-03-05 01:00:23</time></p> </header>  <div id="news-body"><p>“我行过许多地方的桥，看过许多次的云，喝过许多种类的酒，却只爱过一个正当最好年龄的人。”</p><p>十多年前，我读到这句话懵懵懂懂，领略不到它的妙处。只觉得一个人只要走过很多地方，就能遇到那个最好的人。两年前，我爱上了跑步。这两年我跑过很多的地方，烟花三月下扬州，人在画中跑<a href="http://m.so.com/s?q=%E6%97%A0%E9%94%A1&amp;src=newstranscode" class="qkw">无锡</a>，烟雨朦胧游杭州，却错过了最美的风景和那些人。</p><p>不到两年的时间，我跑过二十多场<a href="http://m.so.com/s?q=%E9%A9%AC%E6%8B%89%E6%9D%BE&amp;src=newstranscode" class="qkw">马拉松</a>。每一场都有新奇的故事，每一步都有美丽的风景，却鲜有意外之喜。然而，如果你不去跑步，很难遇到新奇的故事;如果你不去跑步，很难看到美丽的风景;如果你不去跑步，永远无法遇到惊喜。所以，跑步是世间最丰盛美好的礼物。</p><p>犹记得，第一场马拉松，好友二十多个电话让我有力量完赛;犹记得，第二场马拉松，一个人在上海成功PB;犹记得，那场马拉松，冲过终点瘫坐在地上，陌生跑友帮我拉伸按摩;犹记得，那些场马拉松，他们陪我一起跑过的比赛，她帮我，他助我，他们都是天使……</p><p>只可惜，我是一个惫懒的人，做事不太用心。聪明的人也是最用心的人，每到一处他们能会用文字记录下每个感动的瞬间和细节。之前我很少能安静下来思考，跑过那么多地方，究竟为什么而跑?我只是习惯性地跑完每个地方，拍完屁股就走，然后寻找下一个跑马的地方。</p><p><a href="http://m.so.com/s?q=%E6%9D%91%E4%B8%8A%E6%98%A5%E6%A0%91&amp;src=newstranscode" class="qkw">村上春树</a>比我聪明很多。“终点线只是一个记号而已，其实并没有什么意义，关键是这一路你是如何跑的。人生也是如此。”人生很短，走得太急的话，会错过很多风景。有些风景需要你慢下来，才会遇见。其实，如果你不用心去思考，一样会错过很多风景，错过那些人。</p><p>吸取之前的教训，我现在不再漫无目的的跑步了。某个清晨，我跑步去上班，遇到那个经常在公司附近晨跑的<a href="http://m.so.com/s?q=%E5%A4%96%E5%9B%BD%E5%A7%91%E5%A8%98&amp;src=newstranscode" class="qkw">外国姑娘</a>，我会停下来向她打声招呼。人间美景千万种，唯有<a href="http://m.so.com/s?q=%E5%A4%9C%E8%89%B2%E9%86%89&amp;src=newstranscode" class="qkw">夜色醉</a>人心。某个夜晚，下班之后，我会换上跑鞋，沿着<a href="http://m.so.com/s?q=%E9%95%BF%E5%AE%89%E8%A1%97&amp;src=newstranscode" class="qkw">长安街</a>来一次长距离夜跑，只为一次纯粹的放空。</p><p>如果你想看最美的风景，想听沿途为你加油的助威声，想有资格说出那个名句，用心去跑步吧。那一刻，你或许只是一个人。当你迈开双腿的时候，你将注定遇到一些人，错过一些人，直到遇见最好的那个人。跑过最美的风景遇见最好的那个人，这或许也是你坚持跑马的理由。</p><p>跑过最美的风景遇见最好的你，这是多美的一幅画啊!其实，人生就是一幅画卷，只要你认真对待，就能画得辉煌灿烂。然而，真正<a href="http://m.so.com/s?q=%E7%BE%8E%E5%A6%99%E7%9A%84%E4%BA%BA%E7%94%9F&amp;src=newstranscode" class="qkw">美妙的人生</a>，不是一直成功，而是充满很多压力，承受很多刺激。即便错过最美的风景和那些人，跑过最美的风景<a href="http://m.so.com/s?q=%E9%81%87%E8%A7%81%E6%9C%80%E5%A5%BD%E7%9A%84%E8%87%AA%E5%B7%B1&amp;src=newstranscode" class="qkw">遇见最好的自己</a>也不错呀。</p><p>至于那句名言，如果稍加改动，我会更加喜欢。“我行过许多地方的桥，看过许多次的云，喝过许多种类的酒，也爱过一打儿正当最好年龄的人。”当然，我更喜欢跑过最美的风景遇见最好的自己。迈开自己的步伐，遇到最好的自己。奔跑中，唯跑步和爱不可辜负。</p><p>文/<a href="http://m.so.com/s?q=%E9%99%88%E6%BD%AD&amp;src=newstranscode" class="qkw">陈潭</a></p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.sina.com.cn/o/2016-03-05/doc-ifxpzzhk2219621.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='24f6c5fa0df3aede5a0e0b0c9c71be18'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>遇见的那个人</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%81%87%E8%A7%81%E7%9A%84%E9%82%A3%E4%B8%AA%E4%BA%BA&amp;pn=1&amp;pos=8&amp;m=979f84488f7a10050ecba076a2d3f662c4cd8cbb&amp;u=http%3A%2F%2Fdy.qq.com%2Farticle.htm%3Fid%3D20140820A0013700" data-pos="1"> 早安心语:做最真实的自己,才会<b>遇到</b>最该<b>遇见的那个人</b> </a>   <li> <a href="/transcode?q=%E9%81%87%E8%A7%81%E7%9A%84%E9%82%A3%E4%B8%AA%E4%BA%BA&amp;pn=1&amp;pos=9&amp;m=cdc78d6955f72927dcd5a0bb828601977e08e2e3&amp;u=http%3A%2F%2Fnews.gmw.cn%2Fnewspaper%2F2016-03%2F05%2Fcontent_111288059.htm" data-pos="2"> 每个好姑娘都值得<b>遇见</b>更好的人 </a>   <li> <a href="/transcode?q=%E9%81%87%E8%A7%81%E7%9A%84%E9%82%A3%E4%B8%AA%E4%BA%BA&amp;pn=1&amp;pos=10&amp;m=967224a0142e04d96a002e4cf7281d818b427435&amp;u=http%3A%2F%2Ffj.ce.cn%2Fn02%2Fn456%2F201407%2F23%2Ft20140723_1672030.shtml" data-pos="3"> 没关系是爱情啊1集直播 男主意外<b>撞到</b>女主爱情来了 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '跑过最美的风景遇见最好的你' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '跑过最美的风景遇见最好的你'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";