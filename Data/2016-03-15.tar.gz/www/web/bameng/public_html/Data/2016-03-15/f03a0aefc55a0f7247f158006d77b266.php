s:20709:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>花千骨首播精彩抢先看 剧情介绍虐心恋经典台词回顾 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">花千骨首播精彩抢先看 剧情介绍虐心恋经典台词回顾 </h1> <p id="source-and-time"><span id=source>中国日报网</span><time id=time>2015-06-10 10:32:00</time></p> </header>  <div id="news-body"><p>花千骨今晚首播精彩抢先看 剧情介绍<a href="http://m.so.com/s?q=%E8%99%90%E5%BF%83%E6%81%8B&amp;src=newstranscode" class="qkw">虐心恋</a>经典台词回顾</p><p>由<a href="http://m.so.com/s?q=%E6%85%88%E6%96%87%E4%BC%A0%E5%AA%92%E9%9B%86%E5%9B%A2&amp;src=newstranscode" class="qkw">慈文传媒集团</a>出品，唐丽君担任制片人，导演<a href="http://m.so.com/s?q=%E6%9E%97%E7%8E%89%E8%8A%AC&amp;src=newstranscode" class="qkw">林玉芬</a>、高林豹执导，<a href="http://m.so.com/s?q=%E9%9C%8D%E5%BB%BA%E5%8D%8E&amp;src=newstranscode" class="qkw">霍建华</a>、赵丽颖等超强阵容连袂出演的传奇仙侠大剧<a href="http://m.so.com/s?q=%E3%80%8A%E8%8A%B1%E5%8D%83%E9%AA%A8%E3%80%8B&amp;src=newstranscode" class="qkw">《花千骨》</a>即将在6月9日晚22点登陆<a href="http://m.so.com/s?q=%E6%B9%96%E5%8D%97%E5%8D%AB%E8%A7%86&amp;src=newstranscode" class="qkw">湖南卫视</a>钻石独播剧场，热力上映。小说中大气磅礴的长留仙境与令人肝肠寸断的虐恋给读者留下了深刻的印象，电视剧《花千骨》伴随书迷、观众的万千期待而生，近日该剧的催泪台词曝光，具象而灵动地展现了这段锥心虐恋。不少观众们表示:“看片花流过的泪，完全可以养两条金鱼了”、“当时躲在被窝里哭着看的场景被还原了，华哥丽颖演技棒棒哒，期待播出”。</p><p><img src="http://p34.qhimg.com/t01d52db3786d2f6fcf.jpg?size=500x281"></p><p>《花千骨》集合仙剑、古剑原班人马重磅打造，仙三中以“徐长卿”一角成功跻身“天涯四美”的霍建华自我颠覆再塑经典，一改淡定儒雅的“白豆腐”形象，化身高冷师尊颜倾六界，搭档首次出演仙侠类型剧的<a href="http://m.so.com/s?q=%E8%B5%B5%E4%B8%BD%E9%A2%96&amp;src=newstranscode" class="qkw">赵丽颖</a>上演虐心又催泪的倾世虐恋，而剧中的台词也引发网友争相盘点。“我有朋友，我有爱人，我有师父，我曾经以为我有全世界。爱我的人为我而死，我爱的人一心想要我死”一句催泪无数，无论是决裂时的“我身上这一百零三剑，十七个窟窿，满身疤痕，没有一处不是你赐我的。断念已残，宫铃已毁，从今往后，我与你师徒恩断义绝 ”，还是为爱而死时“我<a href="http://m.so.com/s?q=%E4%BB%A5%E7%A5%9E%E7%9A%84%E5%90%8D%E4%B9%89&amp;src=newstranscode" class="qkw">以神的名义</a>诅咒你，今生今世，永生永世，不老不死，不伤不灭”，皆令网友们动容不已。赵丽颖在接受采访时也坦言有被剧中虐情触动，霍建华也表示与小骨的爱情中最虐的就是这份“不可说”的晦涩。</p><p><img src="http://p35.qhimg.com/t01792b9bd5e7e2b425.jpg?size=500x332"></p><p>这部备受期待和关注的传奇仙侠大剧《花千骨》，已定档6月9日湖南卫视钻石独播剧场播出，<a href="http://m.so.com/s?q=%E7%99%BD%E5%AD%90&amp;src=newstranscode" class="qkw">白子</a>画和花千骨这段锥心互虐到令六界色变的隐忍之爱即将揭晓。</p><p><img src="http://p34.qhimg.com/t011f21ad4c0b6e1e5f.jpg?size=500x280"></p><p class="img-title">花千骨</p><p>花千骨她是世间<a href="http://m.so.com/s?q=%E6%9C%80%E5%90%8E%E4%B8%80%E4%B8%AA%E7%A5%9E&amp;src=newstranscode" class="qkw">最后一个神</a>，也是百年难得一见的天煞孤星，她善良而坚强执着，对待朋友真心实意。由于身上有着易招引鬼怪的特殊气味，所以自小便被妖魔缠身。出生时，满城鲜花尽数凋零，故取名花千骨。性格天真，敢爱敢恨。原本心无杂念的她，自从在群仙宴上初遇白子画时，便注定了她此生为他沉沦…十七根消魂钉、一百零三剑、十六年的囚禁和两条命…她被他伤的体无完肤，却依然深爱的不肯放弃。然而，当白子画削去那块绝情池水所留下的伤疤时，当白子画被花千骨制造的幻境所迷，选天下还是选花千骨时候，白子画选了天下将轩辕剑(悯生剑)刺入她的身体时，她临死前，对他下了一道<a href="http://m.so.com/s?q=%E7%A5%9E%E7%9A%84%E8%AF%85%E5%92%92&amp;src=newstranscode" class="qkw">神的诅咒</a>:“白子画，我以神的名义诅咒你，今生今世，永生永世，不老不死，不伤不灭!”说是下诅咒，其实她也是不忍心自己深爱的白子画陪她灰飞烟灭，她只想得到白子画的信任和承认对她的爱而已。远古时代她身为神时拯救了苍生，这一次花千骨又用神身拯救了世界。</p><p class="header">白子画</p><p>白子画长留上仙白子画，横霜锋芒护天下。着一袭白袍，银光笼罩周身，惊为天人的眉宇面貌间掩不住的清高傲岸，略有些单薄的唇比常人少了些血色，眉间是殷红色的掌门印记。淡然带着冰冷的目光，流泄如水如月华。</p><p>超凡而孤高，冰凉而淡漠，温润如玉又云淡风清。仙姿秀逸，孤冷出尘，长发如瀑，眼落星辰，风采翩翩绝世。这世上，怕是再无一画，可以装得下他的<a href="http://m.so.com/s?q=%E4%BB%99%E8%B5%84&amp;src=newstranscode" class="qkw">仙资</a>，他的容貌，他的风采，他的气质。</p><p>修为极其高深，论对手，绝对是最可怕的一个。</p><p>其师传位于他之时曾说:“子画在，可保长留千年基业，可守仙界百年平安。”</p><p>从此他便是长留上仙，长留掌门，六界道行最高之人，他心怀苍生，悲悯世人，大爱众生，一肩挑起守护长留，守护众生的沉重责任。</p><p>原无所牵挂的他自从在群仙宴上初遇天煞孤星花千骨，他明知是自己的婆娑劫。仍不顾众人劝阻，收花千骨为徒“我此生只收一个徒儿”从此为花千骨操碎了心。他不信命，冒险替花千骨逆天改命，呕心沥血教导花千骨。为救花千骨身中剧毒，<a href="http://m.so.com/s?q=%E5%91%BD%E6%82%AC%E4%B8%80%E7%BA%BF&amp;src=newstranscode" class="qkw">命悬一线</a>。在花千骨放出妖神闯下大祸后，毅然为她承担起大部罪责，自罚64根销魂钉，一病不起。花千骨囚禁海底，亦相伴左右16年。不知不觉中花千骨已成为他生命中最大牵绊。当花千骨最终成为妖神危及苍生时，白子画孤身前往劝阻，双方终明了对方的情意。花千骨制造出毁灭天下的幻象逼迫白子画在天下人和自己之间选择。白子画终不能放弃对天下人的大爱，而忍痛将剑刺向花千骨，并自杀相随。却不料花千骨怨怒下诅咒白子画不老不死，永远活在失去自己的痛苦中。白子画一生不负长留，不负六界，不负众生，不负任何人，唯独负了自己一世韶光。</p><p><img src="http://p34.qhimg.com/t01dd424bbb62fb5d2a.jpg?size=500x437"></p><p>花千骨1、白子画，黄泉路上，<a href="http://m.so.com/s?q=%E5%BF%98%E5%B7%9D%E6%B2%B3&amp;src=newstranscode" class="qkw">忘川河</a>中，三生石旁，<a href="http://m.so.com/s?q=%E5%A5%88%E4%BD%95%E6%A1%A5%E5%A4%B4&amp;src=newstranscode" class="qkw">奈何桥头</a>，我可否有见过你?</p><p>2、长留<a href="http://m.so.com/s?q=%E5%88%97%E4%BB%99&amp;src=newstranscode" class="qkw">列仙</a>在上，弟子花千 骨，命格异数，厄运缠身，生是不祥之人，承蒙尊上不弃，悉心教导，收我为徒。弟子定会堂堂正正，无 愧天地，无愧长留，无愧尊上。今后生为尊生，死为尊死。绝不违抗半句师命。天地为证!</p><p>3、这世上我最怕两样东西，鬼和师父……</p><p>4、白子画，我身上这一百零三剑，十七个窟窿，满身疤痕，没有一处不是你赐我的。十六年的囚禁，再加上 这两条命，欠你的，我早还清了。断念已残，宫铃已毁，从今往后，我与你师徒恩断义绝。</p><p><img src="http://p35.qhimg.com/t019f2d197a8c2c79a4.jpg?size=500x280"></p><p>9、我不相信正，不相信邪，不<a href="http://m.so.com/s?q=%E7%9B%B8%E4%BF%A1%E5%B9%B8%E7%A6%8F&amp;src=newstranscode" class="qkw">相信幸福</a>，可是我相信你!</p><p>10、白子画，你其实从不信我，你只信自己的眼睛。</p><p>11、白子画，你还是不肯爱我么......既然如此，你有什么资格和我一起死?</p><p>12、白子画站在所有人前面，单薄的身子，却在她和众人间筑起一道牢不可破的城墙。多傻，既想保护身后的人，又想保护身前的人，最后被摧毁的只能是他。</p><p>8、当初师父传位给他之时曾说:“子画在，可保长留千年基业，可守仙界百年平安。”</p><p>9、爱别离，<a href="http://m.so.com/s?q=%E6%80%A8%E6%86%8E%E4%BC%9A&amp;src=newstranscode" class="qkw">怨憎会</a>，撒手西归，全无是类。不过是满眼空花，一片虚幻。</p><p>10、她是他用整个生命来守护的徒儿，胜过一切，他宁可自己死，也再不要伤她一分一毫。</p><p>11、只要你一直在我身边，不伤不死就不是诅咒，而是<a href="http://m.so.com/s?q=%E7%A5%9E%E6%81%A9%E6%B5%A9%E8%8D%A1&amp;src=newstranscode" class="qkw">神恩浩荡</a>。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.chinadaily.com.cn/hqcj/xfly/2015-06-10/content_13825216.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='0acdfb81dc7fe28295fd98d19269a5f8'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>虐心恋</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%99%90%E5%BF%83%E6%81%8B&amp;pn=1&amp;pos=9&amp;m=266ee7686f26c00cffd3194e0f1f720b9c7d564a&amp;u=http%3A%2F%2Fyule.sohu.com%2F20140814%2Fn403446083.shtml" data-pos="1"> 《深宅雪》开机 男主角姚奕辰上演<b>虐心恋</b> </a>   <li> <a href="/transcode?q=%E8%99%90%E5%BF%83%E6%81%8B&amp;pn=1&amp;pos=10&amp;m=5cd71eb99a726e78f322e9007d0f73b6b43cc2ee&amp;u=http%3A%2F%2Fent.qq.com%2Fa%2F20140715%2F030969.htm" data-pos="2"> 《爱情最美丽》吊足胃口 麻辣情<b>虐心恋</b>值得守候 </a>   <li> <a href="/transcode?q=%E8%99%90%E5%BF%83%E6%81%8B&amp;pn=2&amp;pos=1&amp;m=76b38a2f34ebb275dac511406133a6dc57cc98f8&amp;u=http%3A%2F%2Fyule.sohu.com%2F20140715%2Fn402276184.shtml" data-pos="3"> 《爱情最美丽》发片花吊胃口 麻辣情<b>虐心恋</b>值得守候 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '花千骨首播精彩抢先看 剧情介绍虐心恋经典台词回顾 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '花千骨首播精彩抢先看 剧情介绍虐心恋经典台词回顾 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";