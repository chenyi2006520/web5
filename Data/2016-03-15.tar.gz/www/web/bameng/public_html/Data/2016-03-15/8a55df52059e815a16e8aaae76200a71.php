s:15633:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>香草冰淇淋配美酒 抵挡不住的诱惑!- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">香草冰淇淋配美酒 抵挡不住的诱惑!</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-03-03 14:13:18</time></p> </header>  <div id="news-body"><p>摘要: 如果你今晚要招待客人，却已经为佳肴忙得焦头烂额而没有办法去顾及甜品的事情。那么今天小编将要传授给大家一个做法简单又非常美味的小秘方!</p><p>ABSTRACT: If you ever <a href="http://m.so.com/s?q=entertain&amp;src=newstranscode" class="qkw">entertain</a>, or even might entertain, here’s a tip for dessert: keep some <a href="http://m.so.com/s?q=sweet+wine&amp;src=newstranscode" class="qkw">sweet wine</a> around so you don’t have to actually exert yourself。</p><p>今天，小编要教给大家的是一个做法非常简单、看起来非常高大上、吃起来也非常美味的甜品小秘方，那就是甜型利口酒浇<a href="http://m.so.com/s?q=%E9%A6%99%E8%8D%89%E5%86%B0%E6%B7%87%E6%B7%8B&amp;src=newstranscode" class="qkw">香草冰淇淋</a>啦!是不是光听名字都已经垂涎三尺了呢?而且，小编要强调的是，这个甜品的做法真的非常，非常，非常的简单，重要的事情说三遍!</p><p><img src="http://p31.qhimg.com/t0134896b90066969da.jpg?size=550x275"></p><p class="img-title">下面请看详细做法:</p><p>1.跑到超市或者便利店买一桶香草冰淇淋和一瓶甜型利口酒</p><p>2.如果是招待客人，就用鸡尾酒杯来装一球香草冰淇淋(瞬间变得高大上)</p><p>3.根据个人喜好将利口酒浇在<a href="http://m.so.com/s?q=%E5%86%B0%E6%B7%87%E6%B7%8B&amp;src=newstranscode" class="qkw">冰淇淋</a>上面(如果想口感更佳可以加入<a href="http://m.so.com/s?q=%E9%A6%99%E8%95%89%E6%B3%A5&amp;src=newstranscode" class="qkw">香蕉泥</a>)</p><p>没有复杂的过程，<a href="http://m.so.com/s?q=%E6%89%8B%E5%88%B0%E6%8B%BF%E6%9D%A5&amp;src=newstranscode" class="qkw">手到拿来</a>的美味甜品你是不是也想立刻试试呢!不过别着急，小编还很贴心地整理了几款适合搭配香草冰淇淋的利口酒给大家，大家可以按照自己的口味来选择。</p><p class="header">一、百利甜酒(Baileys)</p><p><img src="http://p35.qhimg.com/t0199081f940845fc15.jpg?size=324x220"></p><p>百利甜酒相信对于中国消费者来说并不陌生，在各大超商都能见到它的身影。百利甜酒既保持了<a href="http://m.so.com/s?q=%E5%A5%B6%E6%B2%B9&amp;src=newstranscode" class="qkw">奶油</a>的天然新鲜和丝绸般的顺滑口感，又达成了奶油和威士忌的美妙融合。小编还特别推荐用咖啡口味的百利甜酒搭配香草冰淇淋，可谓绝配!</p><p>二、佩德罗-<a href="http://m.so.com/s?q=%E5%B8%8C%E6%A2%85%E5%86%85%E6%96%AF&amp;src=newstranscode" class="qkw">希梅内斯</a>(Pedro <a href="http://m.so.com/s?q=Ximenez&amp;src=newstranscode" class="qkw">Ximenez</a>)</p><p><img src="http://p32.qhimg.com/t0116e52dfdb32263d5.jpg?size=550x310"></p><p>佩德罗-希梅内斯是<a href="http://m.so.com/s?q=%E8%A5%BF%E7%8F%AD%E7%89%99&amp;src=newstranscode" class="qkw">西班牙</a>赫雷斯(Jerez)地区酿造甜型雪利酒的著名白葡萄。虽然这种<a href="http://m.so.com/s?q=%E8%91%A1%E8%90%84%E9%85%92&amp;src=newstranscode" class="qkw">葡萄酒</a>通常并不会在酒标上标识出雪利(Sherry)字样，但人们还是习惯称之为PX雪利(<a href="http://m.so.com/s?q=Pedro&amp;src=newstranscode" class="qkw">Pedro</a> Ximenez简写)。佩德罗-希梅内斯或者PX雪利通常带有丰富的<a href="http://m.so.com/s?q=%E6%97%A0%E8%8A%B1%E6%9E%9C%E5%B9%B2&amp;src=newstranscode" class="qkw">无花果干</a>、巧克力、焦糖、<a href="http://m.so.com/s?q=%E5%A4%AA%E5%A6%83%E7%B3%96&amp;src=newstranscode" class="qkw">太妃糖</a>、浓缩咖啡、甜香料的味道，这些味道和香草冰淇淋搭配也是一绝!</p><p>三、意大利青核桃利口酒(Nocino)</p><p><img src="http://p32.qhimg.com/t0119be178b8e75f5ea.jpg?size=550x304"></p><p>这款意大利青核桃利口酒，相比于前两种利口酒来说，中国消费者就接触得比较少了。意大利青核桃利口酒香甜又略有<a href="http://m.so.com/s?q=%E6%A0%B8%E6%A1%83&amp;src=newstranscode" class="qkw">核桃</a>苦味，最早是意大利修道院里自制的药酒，可以治疗胃部痉挛，但现在已经成为搭配冰淇淋等甜点的神秘食材，如果有幸遇到这种酒，不妨搭配香草冰淇淋来尝尝鲜哦!</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/2016/kuaixun_0303/4513363.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='53f32650746b00615262e62e5697b8bb'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>香草</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%A6%99%E8%8D%89&amp;pn=1&amp;pos=8&amp;m=fb95b7541df482d812be414133c0063492cc03be&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4018296.html" data-pos="1"> 绽放八月北京海淀紫云台<b>香草</b>园盛装亮相 </a>   <li> <a href="/transcode?q=%E9%A6%99%E8%8D%89&amp;pn=1&amp;pos=9&amp;m=4a2f06acd319e925edc77d5fdf1b6fc5a6ef3ba1&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fkuaixun_0303%2F4513363.html" data-pos="2"> <b>香草</b>冰淇淋配美酒 抵挡不住的诱惑! </a>   <li> <a href="/transcode?q=%E9%A6%99%E8%8D%89&amp;pn=1&amp;pos=10&amp;m=b628a1d38f755c8d1985fa9d6299d690e9f7e2f0&amp;u=http%3A%2F%2Ffj.china.com.cn%2F2016-03%2F11%2Fcontent_16919637.htm" data-pos="3"> 厦门"赏<b>香草</b>观樱花"摄影大赛11日启动 活动时间将持续至 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '香草冰淇淋配美酒 抵挡不住的诱惑!' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '香草冰淇淋配美酒 抵挡不住的诱惑!'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";