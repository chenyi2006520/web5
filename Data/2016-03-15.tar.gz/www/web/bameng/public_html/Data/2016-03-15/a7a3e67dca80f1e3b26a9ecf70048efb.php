s:15330:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>万象PARK杯弹子石雀神大赛即将开战!- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">万象PARK杯弹子石雀神大赛即将开战!</h1> <p id="source-and-time"><span id=source>搜狐焦点</span><time id=time>2016-03-09 14:52:00</time></p> </header>  <div id="news-body"><p>你是所向无敌的<a href="http://m.so.com/s?q=%E9%BA%BB%E5%B0%86%E9%AB%98%E6%89%8B&amp;src=newstranscode" class="qkw">麻将高手</a>吗?你是否一直苦于找不到对手?3月12日(本周六)，<a href="http://m.so.com/s?q=%E5%BC%B9%E5%AD%90%E7%9F%B3&amp;src=newstranscode" class="qkw">弹子石</a>暖春最值得期待的赛事--“万象PARK杯”弹子石<a href="http://m.so.com/s?q=%E9%9B%80%E7%A5%9E&amp;src=newstranscode" class="qkw">雀神</a>争霸赛，即将在华润•凯旋天地火热开战!谁能摘取“雀神”桂冠?谁能赢得万元豪礼?且看各路英豪过关斩将<a href="http://m.so.com/s?q=%E8%83%9C%E8%80%85%E4%B8%BA%E7%8E%8B&amp;src=newstranscode" class="qkw">胜者为王</a>!</p><p class="header">玩雀神争霸赢万元豪礼</p><p>这是一次雀友间的风云际会,也是一场各路豪强的巅峰对决,更将是一个斗牌技、赢大奖的绝妙机会。</p><p>作为此次雀神争霸赛的主办方--华润•凯旋天地为此次比赛准备了上万元大奖，在比赛中脱颖而出的选手们，按照名次将获得:一等奖1名，价值5000元的神秘奖品+雀神称号证书+雀神奖杯;二等奖1名，机麻一台+雀圣称号证书+雀圣奖杯;三等奖1名，机麻一台+<a href="http://m.so.com/s?q=%E9%9B%80%E7%8E%8B&amp;src=newstranscode" class="qkw">雀王</a>称号证书+雀王奖杯;四等奖1名:机麻一台+雀友称号证书+雀友奖杯。此外，活动期间，人人有奖，参与即能获得20-50元奖品!</p><p><img src="http://p33.qhimg.com/t010b8ef1ee4b13ae37.jpg?size=536x262"></p><p class="img-title">轮番对决，争霸雀神之位</p><p>根据赛程安排，本次雀神大赛将通过<a href="http://m.so.com/s?q=%E5%88%9D%E8%B5%9B&amp;src=newstranscode" class="qkw">初赛</a>、复赛、半决赛及决赛四个环节:3月12日-3月13日为第一轮初赛，3月19日-3月20日为第二轮初赛，3月26日举行复赛，3月27日上午举行半决赛。最终将于3月27日下午决出雀神，决出雀神大赛的一、二、三名。整个比赛采用的是<a href="http://m.so.com/s?q=%E5%9B%9B%E5%B7%9D%E9%BA%BB%E5%B0%86&amp;src=newstranscode" class="qkw">四川麻将</a>赛制，对所有报名人员每四人一组，比赛的座位都是随机安排。</p><p>轮番的角逐，不仅最大程度地确保比赛过程的公平公正，更将为紧张激烈的雀神争霸增添许多惊喜和乐趣!</p><p><img src="http://p32.qhimg.com/t015f2e6b8e4b6e7b05.jpg?size=313x434"></p><p class="img-title">华润•凯旋天地 奢享商圈繁华</p><p>华润·凯旋天地位于重庆市南岸区弹子石，而弹子石CBD与<a href="http://m.so.com/s?q=%E8%A7%A3%E6%94%BE%E7%A2%91&amp;src=newstranscode" class="qkw">解放碑</a>CBD、江北嘴CBD组成重庆市市政府规划的<a href="http://m.so.com/s?q=%E4%B8%AD%E5%A4%AE%E5%95%86%E5%8A%A1%E5%8C%BA&amp;src=newstranscode" class="qkw">中央商务区</a>。交通条件得天独厚，“五桥四路三隧道双轻轨”便捷路网，双轻轨规划以及数条公交线路穿梭，能够快速便捷通达全城。</p><p>华润·凯旋天地建成后将成为弹子石CBD首个城市商业综合体，6万方家庭欢乐体验中心MALL将聚集IMAX影院、大型超市、儿童游乐、知名零售及餐饮等业态，填补弹子石区域内无<a href="http://m.so.com/s?q=%E5%95%86%E4%B8%9A%E4%B8%AD%E5%BF%83&amp;src=newstranscode" class="qkw">商业中心</a>的空白，为区域居民带来全新的高品质消费!与此同时韩国CGV影院已经签约即将入驻，带你领略最前沿的时尚潮流生活!</p><p>项目动态:华润•凯旋天地25㎡小户公寓1元起低首付，投资自住两相宜，低投资高回报!与此同时47-68㎡的6米挑空跃层小户也在火热抢购中!</p><p>项目地址:南岸区弹子石腾龙大道<a href="http://m.so.com/s?q=%E6%B4%8B%E4%BA%BA%E8%A1%97&amp;src=newstranscode" class="qkw">洋人街</a>转盘</p><p>热线电话;023-68688999</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.focus.cn/cq/2016-03-09/10743144.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='adf32d82782f85c62b43d0ba54d7897b'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>弹子石</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%BC%B9%E5%AD%90%E7%9F%B3&amp;pn=1&amp;pos=10&amp;m=3b2cff0b2fbd31a2871a8849e4efdec483126057&amp;u=http%3A%2F%2Fwww.cqna.com.cn%2Fna_topic14%2F2016-03%2F06%2Fcontent_4072000.htm" data-pos="1"> 居民"微心愿" 社工帮实现:来自<b>弹子石</b>街道的"微心愿"故事 </a>   <li> <a href="/transcode?q=%E5%BC%B9%E5%AD%90%E7%9F%B3&amp;pn=2&amp;pos=1&amp;m=86f98727357dceac5cd4848eba0d970ab5508822&amp;u=http%3A%2F%2Fcq.loupan.com%2Fhtml%2Fnews%2F201602%2F2193292.html" data-pos="2"> 2016<b>弹子石</b>CBD潜力楼盘推荐--锦江小时代公寓 </a>   <li> <a href="/transcode?q=%E5%BC%B9%E5%AD%90%E7%9F%B3&amp;pn=2&amp;pos=2&amp;m=1ee82117cf2972dcededf5318c964c72390cab50&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0620%2F06%2F9V5OJJPU00014AED.html" data-pos="3"> <b>弹子石</b>小户大阳台来了(图) </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '万象PARK杯弹子石雀神大赛即将开战!' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '万象PARK杯弹子石雀神大赛即将开战!'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";