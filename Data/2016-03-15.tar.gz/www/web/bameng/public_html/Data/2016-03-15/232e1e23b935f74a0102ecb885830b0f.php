s:16470:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>电商咨询:行业腾飞的华丽“舞台”- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">电商咨询:行业腾飞的华丽“舞台”</h1> <p id="source-and-time"><span id=source>金融界</span><time id=time>2015-05-22 09:51:00</time></p> </header>  <div id="news-body"><p>北京2015-05-22(中国商业电讯)-- 今年<a href="http://m.so.com/s?q=%E4%B8%A4%E4%BC%9A&amp;src=newstranscode" class="qkw">两会</a>，国家总理李 克强在<a href="http://m.so.com/s?q=%E6%94%BF%E5%BA%9C%E5%B7%A5%E4%BD%9C%E6%8A%A5%E5%91%8A&amp;src=newstranscode" class="qkw">政府工作报告</a>中首次提出，“制定‘互联网+’行动计划，推动<a href="http://m.so.com/s?q=%E7%A7%BB%E5%8A%A8%E4%BA%92%E8%81%94%E7%BD%91&amp;src=newstranscode" class="qkw">移动互联网</a>、云计算、大数据、物联网等与现代制造业结合，促进电子商务、工业互联网和<a href="http://m.so.com/s?q=%E4%BA%92%E8%81%94%E7%BD%91%E9%87%91%E8%9E%8D&amp;src=newstranscode" class="qkw">互联网金融</a>健康发展”。</p><p>截止到14年，<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E7%94%B5%E5%AD%90%E5%95%86%E5%8A%A1&amp;src=newstranscode" class="qkw">中国电子商务</a>市场交易规模达10.2万亿，同比增长29.9%。其中，B2B电子商务市场交易额达8.2万亿元，同比增长31.2%。网络零售市场交易规模达18851亿元，同比增长42.8%。国家发展改革委表示，13个部门将出台系列政策措施，从可信交易、<a href="http://m.so.com/s?q=%E7%A7%BB%E5%8A%A8%E6%94%AF%E4%BB%98&amp;src=newstranscode" class="qkw">移动支付</a>、网络电子发票、商贸流通和物流配送共5个方面支持电子商务发展。产业洞察网发布的<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E5%9B%BD%E7%94%B5%E5%AD%90%E5%95%86%E5%8A%A1%E8%A1%8C%E4%B8%9A%E8%B0%83%E7%A0%94%E3%80%8B&amp;src=newstranscode" class="qkw">《中国电子商务行业调研》</a>报告显示，中国内地电商持续快速增长，交易额突破8万亿元，同比增长 31.7%。</p><p>从以上分析得出，电商行业有良好的发展前景，得到了政府的支持，最近一段时间，许多现象表明，互联网已经不是那个通过网络获取流量的时代了。人们正在经历一个获取信息的变革时代，即从网络搜索到直接通过App获取服务，从信息比对到直接通过App达成交易，直接跨越了所有中间环节。把App留在移动端的前提下，在于能不能明确满足用户的一个垂直需求，提供相对性的服务。以前衡量市场规模，然后再切入的创业模式，平台的形态多样，满足用户任何的需求。</p><p><img src="http://p33.qhimg.com/t0162e107ef57fbb1f6.jpg?size=500x365"></p><p>举个例子来说明会更容易理解，比如电商咨询垂直<a href="http://m.so.com/s?q=%E6%90%9C%E7%B4%A2%E5%BC%95%E6%93%8E&amp;src=newstranscode" class="qkw">搜索引擎</a>，整体流程大致如下:抓取网页后，对网页商品信息进行抽取，抽取出商品名称、价格、简介……甚至可以进一步将笔记本简介细分成“品牌、型号、CPU、内存、硬盘、显示屏、……”然后对信息进行清洗、去重、分类、分析比较、数据挖掘，最后通过分词索引提供用户搜索、通过分析挖掘提供市场行情报告。</p><p>互联网的营销理念是“把握潮流、掌握先机、不断创新”，如今我国互联网市场规模就已出现超高速增长的态势，互联网为各行业带来了许多的变化，最显著的是信息传播方式上的变化，互联网和移动互联网虽然是虚拟的，但是这就是它们的优势，不受时间和地域限制，不管客户什么时候想了解、想购买都能够通过电脑、手机等诸多媒介实现，打破传统销售的各种限制因素，提高加盟商家积极性，由于厂家和加盟商增多，导致互联网市场较为散乱，没有一个集中有秩序的互联网平台以供加盟商有序发展，而电商咨询垂直搜索则有利的调补了这一空白。电商咨询垂直搜索创始人通过自身对电商行业的认识，并对互联网营销方式的认可，联合<a href="http://m.so.com/s?q=%E5%A4%A9%E4%B8%8B%E4%BA%92%E8%81%94&amp;src=newstranscode" class="qkw">天下互联</a>信息科技有限公司打造出这一款多功能门户平台，比较精准、细化的搜索服务，针对电商咨询行业进行了精准的关键词定向，并结合移动App可以提供LBS服务的特色加强了地域性管理和筛选功能，因此使用电商咨询移动垂直搜索引擎能取得更精准的搜索结果。</p><p>电子商务的蓬勃发展，是市场供求关系的体现，随着网络的发展和技术的日趋成熟，从而带动了网络购物人数和商品交易量的蓬勃增长。电商咨询垂直搜索对众多企业来说，特别是产品销售为主要收入来源的企业网络就意味着一座金矿。</p><p>创新是电子商业行业门户发展的根本。商业模式创新、<a href="http://m.so.com/s?q=%E4%BA%A7%E5%93%81%E6%8A%80%E6%9C%AF%E5%88%9B%E6%96%B0&amp;src=newstranscode" class="qkw">产品技术创新</a>、资本融合创新促使电子商业行业门户高速发展。在“创新中国”的理念引领下，电商咨询垂直搜索不断创造出新的奇迹，实现全球电商产业领军地位。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://finance.jrj.com.cn/biz/2015/05/22095119256696.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='46e9288c0665d620dc14076b452f3e8d'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>华丽舞台</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%8D%8E%E4%B8%BD%E8%88%9E%E5%8F%B0&amp;pn=1&amp;pos=7&amp;m=a7295e9e742c1a76a3df109ed117c752b0ad1dc1&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4024241.html" data-pos="1"> 第二届智能产品大赛完美收官,加意新品用最<b>华丽舞台</b>向创新致敬 </a>   <li> <a href="/transcode?q=%E5%8D%8E%E4%B8%BD%E8%88%9E%E5%8F%B0&amp;pn=1&amp;pos=8&amp;m=1c85bc898b5d0efff6731240b3f4254ad19fbd3a&amp;u=http%3A%2F%2Fnews.163.com%2F15%2F0618%2F03%2FASC3KIP300014Q4P.html" data-pos="2"> <b>华丽舞台</b>温情珠宝 </a>   <li> <a href="/transcode?q=%E5%8D%8E%E4%B8%BD%E8%88%9E%E5%8F%B0&amp;pn=1&amp;pos=9&amp;m=461360943c32364f1b2ddf1976b9ce32aa7bd5dd&amp;u=http%3A%2F%2Fauto.gmw.cn%2Fnewspaper%2F2015-06%2F18%2Fcontent_107382670.htm" data-pos="3"> 张信哲演唱会<b>华丽舞台</b>已开始搭建 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '电商咨询:行业腾飞的华丽“舞台”' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '电商咨询:行业腾飞的华丽“舞台”'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";