s:15436:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>伟星平湖秋月:真正的市中心洋房正在清盘|图- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">伟星平湖秋月:真正的市中心洋房正在清盘|图</h1> <p id="source-and-time"><span id=source>和讯网</span><time id=time>2015-06-18 11:01:00</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=365%E6%B7%98%E6%88%BF&amp;src=newstranscode" class="qkw">365淘房</a> 芜湖(楼盘)讯 备受市场关注的<a href="http://m.so.com/s?q=%E5%B9%B3%E6%B9%96%E7%A7%8B%E6%9C%88&amp;src=newstranscode" class="qkw">平湖秋月</a>收官产品-洋房组团，目前离清盘已经是分秒倒数，经历过热情的客户数轮疯抢后，可以确定的是，越来越少的人，能够真正拥有平湖秋月了。毕竟，真正的市中心洋房，为数不多，而且，只在平湖秋月。我要抢购咨询电话:400-8181-365转9834</p><p><a href="http://m.so.com/s?q=%E8%8A%9C%E6%B9%96&amp;src=newstranscode" class="qkw">芜湖</a>楼市首届明星置业顾问<a href="http://m.so.com/s?q=%E5%BE%AE%E4%BF%A1&amp;src=newstranscode" class="qkw">微信</a>评选大赛盛启</p><p>环顾市中心，如此亲湖乐活，托付一生，足矣</p><p>环顾芜湖整个市中心板块，真正湖岸的洋房，也就只有平湖秋月了。这么近距离的西洋湖生活，使空气中湿度，温度，含氧量都比其他普通住宅要好得多，是一座“躲”在城市中心的天然绿肺氧吧，这样的自然属性，加上市中心的绝对地段，可谓是双重意义上的绝版资源!</p><p>走进园区，你可以看到内部保留了的6亩原生坡地景观，环境清静幽雅，已经入住的业主们，在这里悠闲诗意的生活;而只要走出园区，家门口一站式名校教育，以及和各大<a href="http://m.so.com/s?q=%E5%95%86%E4%B8%9A%E8%A1%97&amp;src=newstranscode" class="qkw">商业街</a>恰好的步行距离，从小孩教育问题到老人休闲养生的需求一一满足，一座真正的全能生活、健康、娱乐的综合<a href="http://m.so.com/s?q=%E5%A4%A7%E5%9F%8E&amp;src=newstranscode" class="qkw">大城</a>。</p><p><img src="http://p33.qhimg.com/t018af170597a75e08a.jpg?size=500x326"></p><p class="img-title">伟星平湖秋月实景图</p><p class="header">无论老人、孩子，更习惯多层洋房</p><p>平湖秋月的洋房产品，不仅不同于高层、小高层，更区别于市场上比较普遍的电梯洋房，无论是<a href="http://m.so.com/s?q=%E5%BE%97%E6%88%BF%E7%8E%87&amp;src=newstranscode" class="qkw">得房率</a>，还是后期的维护费用，甚至是居住的安全性，都极具优势，不过，真正的洋房，好处远远不止于此。</p><p>事实上，洋房，可以用不同的层面来满足不同家庭成员的各种需求:想象下，家中长辈，可以不用去习惯高层建筑带来的不便，轻松享受温馨的家族天伦;孩子更接地气，不用每天被关在高楼里，放任整座园林，做他的游乐场;而奢阔的客餐厅，大尺度宽景阳台，足以赏尽<a href="http://m.so.com/s?q=%E6%BB%A1%E5%9B%AD%E6%98%A5%E8%89%B2&amp;src=newstranscode" class="qkw">满园春色</a>，将生活中的美好全部汇聚于此。</p><p><img src="http://p34.qhimg.com/t01dd6a53f117c80725.jpg?size=500x324"></p><p class="img-title">利好不断，优质学区或将再升级</p><p>无论何时，<a href="http://m.so.com/s?q=%E5%AD%A6%E5%8C%BA%E6%88%BF&amp;src=newstranscode" class="qkw">学区房</a>永远是楼市中的金字招牌，对于平湖秋月业主来说，已经享受了安师大附幼、<a href="http://m.so.com/s?q=%E5%8C%97%E5%A1%98%E5%B0%8F%E5%AD%A6&amp;src=newstranscode" class="qkw">北塘小学</a>等名校带来的一站式教育体系，而在未来，<a href="http://m.so.com/s?q=%E5%B9%B3%E6%B9%96&amp;src=newstranscode" class="qkw">平湖</a>或将迎来更多的教育资源利好!坊间不断有消息传来:芜湖最好的初中之一-27中分校，也将划入平湖秋月的学区范畴了!优质学区，或将再度升级。</p><p>而面对最后几套洋房房源，伟星也给出了史无前例的多重钜惠，可以说，这座十年经营而成的大盘，已经到了最佳的收藏时机，不用等待，即刻入住;不怕负担，轻松拥有，你不容错过。</p><p>平湖秋月珍稀地下车位，接受咨询中。收官中心洋房，再见平湖秋月!平湖秋月，市中心仅此低层、低密花园洋房，原生坡地，<a href="http://m.so.com/s?q=%E5%87%86%E7%8E%B0%E6%88%BF&amp;src=newstranscode" class="qkw">准现房</a>，公园美宅，清盘在即!</p><p>珍藏专线:400-8181-365转9834</p><p>销售展示中心:黄山东路西洋湖公园西侧(<a href="http://m.so.com/s?q=%E5%B8%82%E8%A1%8C%E6%94%BF%E6%9C%8D%E5%8A%A1%E4%B8%AD%E5%BF%83&amp;src=newstranscode" class="qkw">市行政服务中心</a>对面)</p><p>&gt;&gt;&gt; 关注<a href="http://m.so.com/s?q=%E6%96%B0%E6%B5%AA%E5%BE%AE%E5%8D%9A&amp;src=newstranscode" class="qkw">新浪微博</a>“芜湖365地产家居网”或搜索微信“whhouse365”获得更多资讯。返回芜湖365房产网&gt;&gt;</p><p>详情户型地图社区二手房电话:400-8181-365 转 9834</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://house.hexun.com/2015-06-18/176843215.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='26bdceb85e8f6612587f195bbb8e98f5'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>平湖秋月</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '伟星平湖秋月:真正的市中心洋房正在清盘|图' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '伟星平湖秋月:真正的市中心洋房正在清盘|图'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";