s:16415:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>中国古代“三大球”:马球、蹴鞠、捶丸- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">中国古代“三大球”:马球、蹴鞠、捶丸</h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2016-03-02 14:05:00</time></p> </header>  <div id="news-body"><p><img src="http://p35.qhimg.com/t0166043c6434135924.jpg?size=179x270"></p><p>清象牙雕醉酒对弈<a href="http://m.so.com/s?q=%E5%9B%B4%E6%A3%8B&amp;src=newstranscode" class="qkw">围棋</a>图笔筒</p><p><img src="http://p35.qhimg.com/t010a695c4f50c64ec5.jpg?size=406x270"></p><p class="img-title">宋代邛窑玩具小儿相抱</p><p><a href="http://m.so.com/s?q=%E9%A9%AC%E7%90%83&amp;src=newstranscode" class="qkw">马球</a>、蹴鞠、捶丸:中国古代“<a href="http://m.so.com/s?q=%E4%B8%89%E5%A4%A7%E7%90%83&amp;src=newstranscode" class="qkw">三大球</a>”</p><p>提到现代的“三大球”运动，大家都很熟悉，在中国古代，也有风靡一时的三大球类运动:<a href="http://m.so.com/s?q=%E8%B9%B4%E9%9E%A0&amp;src=newstranscode" class="qkw">蹴鞠</a>、马球和捶丸。三者<a href="http://m.so.com/s?q=%E6%B5%81%E8%A1%8C%E7%9A%84%E6%97%B6%E9%97%B4&amp;src=newstranscode" class="qkw">流行的时间</a>有早有晚，但都形成了严密的组织和比赛规则。蹴鞠起源于春秋战国时期，兴盛于宋、元、明等朝代，在南宋，全国范围内还有不少民间蹴鞠社团，其中最有名的当属“齐云社”，不少城市都有，社团要组织、宣传比赛，还定有社规，入社人员都要遵守。</p><p><a href="http://m.so.com/s?q=%E6%88%90%E9%83%BD%E4%BD%93%E8%82%B2%E5%AD%A6%E9%99%A2%E5%8D%9A%E7%89%A9%E9%A6%86&amp;src=newstranscode" class="qkw">成都体育学院博物馆</a>馆长郝勤介绍说，档案记载，马球则主要流行在唐代，上马打球也并非男子专利，女子也能骑在马上一较高低，而<a href="http://m.so.com/s?q=%E6%8D%B6%E4%B8%B8&amp;src=newstranscode" class="qkw">捶丸</a>也从马球演变而来。在漫长的历史中，蹴鞠、马球杆和捶丸杆并不易于保存，但今人能从捶丸用的绞胎球、<a href="http://m.so.com/s?q=%E6%89%93%E9%A9%AC%E7%90%83&amp;src=newstranscode" class="qkw">打马球</a>的陶俑、蹴鞠图等文物中，侧面了解当时人对这几种球的玩法。</p><p class="header">钓鱼、射箭是古代重要的生产手段</p><p><a href="http://m.so.com/s?q=%E9%83%9D%E5%8B%A4&amp;src=newstranscode" class="qkw">郝勤</a>介绍说，古时，钓鱼、射箭是重要的生产手段，射箭同时也是一种军事手段，在周时，射箭已经不仅仅是战场上比拼的手段，也是有着完整礼仪和制度的比赛项目，包括到清朝，贵族也有<a href="http://m.so.com/s?q=%E5%B0%84%E7%AE%AD%E6%AF%94%E8%B5%9B&amp;src=newstranscode" class="qkw">射箭比赛</a>。成都体育学院博物馆还收藏有一件清朝时期的箭靶，白色的<a href="http://m.so.com/s?q=%E7%BE%8A%E7%9A%AE&amp;src=newstranscode" class="qkw">羊皮</a>上，落满点点箭痕。</p><p>不过虽然现在也有射箭比赛，但和中国古代的射箭比赛已大相径庭，拉弓的手势都是不一样的，而从古代弓、箭镞、剑等武器的展品上，我们也能看出当时的生产工艺。</p><p class="header">百戏:今天技巧体育的雏形</p><p>在<a href="http://m.so.com/s?q=%E8%B0%A2%E4%B8%B9&amp;src=newstranscode" class="qkw">谢丹</a>主任和郝勤馆长的介绍中，最有意思的展品要数百戏陶俑:一个个泥塑的小人或把腿向后上方弯，直把脚搁在肩上，或者两人在下作为“底座”，第三人在两人的肩上倒立，很像今天的杂技。但这跟体育有什么关系呢，郝勤解释说，这些“百戏”就是今天的技巧体育的雏形。</p><p><a href="http://m.so.com/s?q=%E6%A3%8B%E7%B1%BB&amp;src=newstranscode" class="qkw">棋类</a>、养生、休闲古代女子也喜欢玩</p><p>这次，四川地区还选了不少跟围棋、<a href="http://m.so.com/s?q=%E5%85%AD%E5%8D%9A&amp;src=newstranscode" class="qkw">六博</a>和象棋有关的文物，如东汉时的仙人六博画像砖、宋朝的铜质象棋子、清朝的玻璃围棋罐。六博的玩法早已失传，只能从画像、陶俑的造型上寻找一些端倪。</p><p>郝勤介绍，展出中的导引术、导引图则展示了古人的养生体育活动，四川博物院提供的一对拿在手里转动的水晶<a href="http://m.so.com/s?q=%E4%BF%9D%E9%BE%84%E7%90%83&amp;src=newstranscode" class="qkw">保龄球</a>，是从红牌楼的一座明代万历墓里出土的，晶莹剔透。</p><p>成都有感档案还记载，对于古时的小孩子来说，除开蹴鞠，还有各色弹珠、<a href="http://m.so.com/s?q=%E9%99%80%E8%9E%BA&amp;src=newstranscode" class="qkw">陀螺</a>可以玩，对于女子来说，秋千和风筝则是最主要的体育休闲活动，墙外蹴鞠声，<a href="http://m.so.com/s?q=%E5%A2%99%E5%86%85%E7%A7%8B%E5%8D%83&amp;src=newstranscode" class="qkw">墙内秋千</a>笑。看来，古人玩体育竞技，谁说女子不如男啊?</p><p class="header">华西都市报记者 王茜</p><p>摄影 陈羽啸右列图片由<a href="http://m.so.com/s?q=%E5%9B%9B%E5%B7%9D%E7%9C%81%E5%8D%9A%E7%89%A9%E9%99%A2&amp;src=newstranscode" class="qkw">四川省博物院</a>提供</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://yn.people.com.cn/n2/2016/0302/c372458-27848584.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='8468ddc4bb467305ec98a737fd2c4507'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>马球</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%A9%AC%E7%90%83&amp;pn=1&amp;pos=6&amp;m=9afb68d29ab081a306aa75dc9000335a8e5eabe5&amp;u=http%3A%2F%2Fsports.qq.com%2Fa%2F20160304%2F036613.htm" data-pos="1"> 西媒:J<b>马球</b>荒达779分钟 表现与身价相差10倍 </a>   <li> <a href="/transcode?q=%E9%A9%AC%E7%90%83&amp;pn=1&amp;pos=7&amp;m=694578759524a45c3755940c093c5f24388b72f9&amp;u=http%3A%2F%2Fsports.ifeng.com%2Fa%2F20160224%2F47571274_0.shtml" data-pos="2"> 韩球迷讽J<b>马球</b>场蒸发 韩媒:足球不能靠金钱堆砌 </a>   <li> <a href="/transcode?q=%E9%A9%AC%E7%90%83&amp;pn=1&amp;pos=8&amp;m=cb15d8bdbd2a134d870e23150253c181450c196f&amp;u=http%3A%2F%2Fah.people.com.cn%2Fn2%2F2016%2F0302%2Fc358327-27843894.html" data-pos="3"> <b>马球</b>传承千年至清而止 因清代严禁百姓养马 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '中国古代“三大球”:马球、蹴鞠、捶丸' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '中国古代“三大球”:马球、蹴鞠、捶丸'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";