s:26384:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>《商业周刊》:美联航改革初显成效- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">《商业周刊》:美联航改革初显成效</h1> <p id="source-and-time"><span id=source>东方财富网</span><time id=time>2016-01-28 13:20:00</time></p> </header>  <div id="news-body"><p>去年夏天，<a href="http://m.so.com/s?q=%E7%BE%8E%E8%81%94%E8%88%AA&amp;src=newstranscode" class="qkw">美联航</a>(United Airlines)调查乘客对什么问题最不满。一天时间美联航就收到了8000份乘客调查问卷，涉及的问题林林总总:行李是否另外收费?座位放脚空间够不够?咖啡味道如何……</p><p>当然每一家航空公司都发生过可怕的情况--乘客有的是机会失去对航空公司的希望，但事实证明美联航是这方面的“领头羊”:在航班延误、取消、行李粗暴对待、乘客不满等所有主要指标方面，美联航自2012年以来稳拿第一名或与第一名不相上下。美国交通局数据显示，2012年乘客投诉43%针对美国的航空公司。在J.D. Power & Associates的2015年客户满意度调查中，美联航在北美非廉价航空公司中垫底。最近美联航又为多次停机坪延误和粗暴对待残疾乘客支付280万美元罚款。<a href="http://m.so.com/s?q=%E9%BA%A6%E8%82%AF%E9%94%A1&amp;src=newstranscode" class="qkw">麦肯锡</a>已退休的高级合伙人门多萨(Lenny Mendonca)说:“我从未见过美联航这么差的航空公司。”尽管他这辈子搭乘美联航飞行了300多万英里(约合500多万公里)，但他说“但凡有别的选择，我会乘坐其他航空公司的飞机”。</p><p>五年前美联航与大陆航空公司合并，成为当时全球最大的航空公司，但这次合并进行得并不顺利。当2012年和2014年初<a href="http://m.so.com/s?q=%E5%85%A8%E7%BE%8E%E8%88%AA%E7%A9%BA&amp;src=newstranscode" class="qkw">全美航空</a>集团、达美航空公司、西南航空公司报告创造大量、有时甚至创记录的利润时，合并后的美联航却告亏损。财报电话会议成了时任CEO<a href="http://m.so.com/s?q=%E6%96%AF%E7%B1%B3%E5%A1%9E%E5%85%8B&amp;src=newstranscode" class="qkw">斯米塞克</a>(Jeffery Smisek)的道歉会。“我知道我们对部分乘客造成了伤害，因为我们的变革进行的太快，我对此表示道歉，”斯米塞克2012年7月在财报会议上如是说。“我们知道我们能够做得更好，我们正在采取行动做得更好，”他在2014年4月如此承诺。</p><p>然而对这位CEO来说，形势却每况愈下。去年9月，斯米塞克和两位顶级高管黯然离职，当时美国司法部正在调查美联航是否对<a href="http://m.so.com/s?q=%E7%BA%BD%E7%BA%A6&amp;src=newstranscode" class="qkw">纽约</a>与新泽西港务局(Port Authority of New York & New Jersey)--该地区主要机场运营机构--施加不当影响。一个月后，<a href="http://m.so.com/s?q=%E7%A9%86%E8%AF%BA%E6%96%AF&amp;src=newstranscode" class="qkw">穆诺斯</a>(Oscar Munoz)继任CEO，但他又因心脏病发作而请病假。1月6日他接受心脏移植手术。虽然美联航表示他将在今年一季度末或者二季度初返岗，但谁也不能否认，一家早该改革的公司进行了顺利、彻底的改革，通过复杂、有力的工作以新面目面世。</p><p>“我们大胆承认，要是五年前能整合就好了，”美联航总顾问、临时CEO<a href="http://m.so.com/s?q=%E5%93%88%E7%89%B9&amp;src=newstranscode" class="qkw">哈特</a>(Brett Hart)说。不过他坚持认为美联航的面貌正在改善:这几个月来飞机的准时性、航班取消和行李处理问题是合并以来最好的。“大家看到飞机准时起降，”哈特说，“员工与乘客的交流大不一样，乘客反映服务水平提高。大家说，你知道吗?这种感觉就像新的一天开始。”2015年第二季度美联航利润创历史最高纪录，不计特别项目盈利13亿美元，第三季度攀升至17亿美元。</p><p>在美联航与<a href="http://m.so.com/s?q=%E5%A4%A7%E9%99%86%E8%88%AA%E7%A9%BA&amp;src=newstranscode" class="qkw">大陆航空</a>合并漫长的五年中，人们有着不切实际的幻想。尽管季度利润创记录，美联航仍在为业绩增长而拼搏--去年第二、第三季度营收同比下跌4%。公司所取得的进步在很多方面只不过是回到了最初的样子。公司“客户体验”部门梳理去年夏天问卷调查中乘客的所有不满，发现了一个直截了当的问题:2013年实行的登机程序复杂，对此美联航表示已确定该问题，计划很快更新程序。<a href="http://m.so.com/s?q=Gimme&amp;src=newstranscode" class="qkw">Gimme</a> Credit交通行业分析师<a href="http://m.so.com/s?q=%E5%B8%83%E8%8E%B1%E6%81%A9&amp;src=newstranscode" class="qkw">布莱恩</a>(Vicki Bryan)对美联航尤其严词批评，“它早就应该改进，但我发现它仍然拖拖拉拉。”</p><p>导致斯米塞克离职的事件发生在他担任合并后的美联航CEO一年之后。2011年9月，他和公司的两位政府事务高管与纽约与<a href="http://m.so.com/s?q=%E6%96%B0%E6%B3%BD%E8%A5%BF&amp;src=newstranscode" class="qkw">新泽西</a>港务局主席萨姆森(David Samson)一起在曼哈顿Novita饭店用餐。斯米塞克让塞姆森对<a href="http://m.so.com/s?q=%E6%B8%AF%E5%8A%A1%E5%B1%80&amp;src=newstranscode" class="qkw">港务局</a>运营的美联航纽瓦克机场进行数亿美元的设施改造，萨姆森则要求投桃报李:希望新的美联航恢复从<a href="http://m.so.com/s?q=%E7%BA%BD%E7%93%A6%E5%85%8B&amp;src=newstranscode" class="qkw">纽瓦克</a>到南卡哥伦比亚的航线，而萨姆森在距离哥伦比亚一小时车程的小城艾肯拥有一座价值百万美元的周末度假别墅。</p><p>在接下来的几个月，萨姆森多次重申他的要求，说他将阻止纽瓦克机场设施改进。美联航恢复了这趟不赚钱的航班。这趟萨姆森称之为“主席航班”的航班安排正好与他的周末度假旅程吻合，要不是报复政敌的“堵桥门”事发牵出此事，这将成为一场神不知鬼不觉的政治交易。2014年3月，萨姆森因“堵桥门”辞职四天后“主席航班”取消。</p><p>新泽西方面没有指控美联航的任何人，但美联航的声明明确表示，斯米塞克和两位高管因公司内部调查而离职，而斯米塞克得到2860万美元分手费。</p><p>在20世纪90年代，律师出身的斯米塞克是扭转大陆航空困难局面团队的一员。2010年1月，上任大陆航空CEO三个月的斯米塞克打断全美航空和美联航的合并谈判，说大陆航空这个伙伴更好。斯米塞克谈及时任美联航CEO谭凯翔(Glenn Tilton):“我不想他娶个丑姑娘。”</p><p>与斯米塞克密切共事的人说他很风趣、聪明绝顶，但同时也说他对人冷淡，有时听不进意见。大陆航空一位前员工回忆，有一次斯米塞克结束与飞行员工会代表的会谈之后，马上带上皮手套自己开车。Gimme <a href="http://m.so.com/s?q=Credit&amp;src=newstranscode" class="qkw">Credit</a>分析师布莱恩说，斯米塞克的高冷范使管理团队瘫痪，对正在发展的问题反应迟缓。</p><p>合并后的美联航很多一线员工抱怨管理层向投资者承诺大幅节省开支，把削减成本放在首位。公司进行大量裁员、休假，把行李托运和<a href="http://m.so.com/s?q=%E7%99%BB%E6%9C%BA%E9%97%A8&amp;src=newstranscode" class="qkw">登机门</a>地勤工作外包。大陆航空前员工透露，公司劝他们不要向对飞行经历不满的乘客发放代金券安抚。甚至新制服也偷工减料。“对制服质量出现很多抱怨，”Garcia回忆道。</p><p>员工不满情绪严重解释了合并后航空公司的表现为何那么差。Bloomberg Intelligence航空业分析师弗格森(George Ferguson)说:“内心不满的机械师往往不愿意多付出一点努力让飞机准备就绪。”常坐飞机的乘客注意到了飞机多次延误、取消和行李丢失，以及地勤人员和空姐的不耐烦。“作为个人来说请他们人都不错，”在美联航一年飞行15万英里的IT人士斯普尔说，“但他们所处的形势很糟糕，经常要设法对付不高兴的乘客，感到十分无力。”</p><p>使合并后的美联航不堪其扰的一些问题是一脉相承的。在结束于2006年的三年野蛮破产保护期，美联航大降工资、爽约养老金方案、停止设施升级和飞机更换，从而造成员工怨声载道和服役机龄业内偏老。从行李处理到飞机可靠性等各方面深受其害。甚至时至今日一些劳工问题也在公司控制之外。大陆航空、美联航前空姐是目前唯一未签订初步共同合约的员工群体，她们对采纳哪家公司的工作规则分歧严重。美联航对此无能为力，只能让她们自己决定。</p><p>斯米塞克及其执行团队显然忽视了飞机的准时起降，为不可避免的恶劣天气和机械故障留出余地。相比之下，<a href="http://m.so.com/s?q=%E8%BE%BE%E7%BE%8E%E8%88%AA%E7%A9%BA&amp;src=newstranscode" class="qkw">达美航空</a>在2008年与西北航空合并之后便废除了与恶劣天气无关的航班取消制度并取得成果。大陆航空、美联航合并也不可避免地造成了广泛的技术问题。合并后的美联航不是逐步结合两家公司的订票系统、网站和<a href="http://m.so.com/s?q=%E5%B8%B8%E6%97%85%E5%AE%A2%E8%AE%A1%E5%88%92&amp;src=newstranscode" class="qkw">常旅客计划</a>，而是一天就把三套系统合并，造成极大的破坏和混乱。采纳比自己规模小的大陆航空的乘客服务系统后，美联航又得培训大量人员使用不同软件。最终证明培训进行得不够。合并后的美联航使用大陆航空的排班计划，但其中部分飞行员数据不知所终，导致航班取消、航班被安排给退休或已故飞行员。</p><p>2014年7月14日发生的一件事凸显了美联航员工与管理层的不信任。一架即将从<a href="http://m.so.com/s?q=%E6%97%A7%E9%87%91%E5%B1%B1&amp;src=newstranscode" class="qkw">旧金山</a>飞往香港的航班被人恶意涂鸦，机身用颜料涂上bye bye字样和两张粗糙的脸庞。空姐拒绝起飞，除非飞机再进行全面安全检查--马航370正好4个月前失踪。美联航执飞、安全、维护团队及飞行员都说飞机已经全面检查过。僵局最终以航班取消告终，空姐因不服从命令而被解雇。</p><p>去年8月9日下午3点半，美联航通知分析师一个小时后召开电话会议。分析师们拨进电话后听到了公司非执行董事长亨利-梅耶尔III(Henry Meyer III)的声音，他宣布斯米塞克立刻辞职，由美联航董事穆诺斯接任。穆诺斯之前在大陆航空任职，但他是航空业的门外汉。他来自CSX公司，在那里担任首席运营官和总裁。他曾被视为这家铁路巨头的可能掌门人--职业生涯初期参加了可乐大战双方阵营，先是在百事可乐、然后跳槽到可口可乐。电话会议上一位分析师问穆诺斯，鉴于美联航最高层的突然变故，会不会有重大决定要推迟到将来。他回答说我的字典里根本没有推迟这两个字。当另一位分析师问美联航何时选任一名新的首席财务官时，穆诺斯回答说“这是我的前半小时”。</p><p>穆诺斯马上投身于让美联航以新面目示人的工作。他给大陆航空深受爱戴的前CEO贝休恩去电，邀请他到芝加哥商量如何恢复美联航的声誉。美联航在全美国媒体大方承认“我们辜负了大家的期望，没有实现承诺和发挥2010年合并的潜力”。在致员工的公开信中，穆诺斯答应“给员工合适工具提供服务和可靠性”。 他说在与一位供职美联航多年的空姐谈话中，这位空姐差点掉下泪来，告诉他“由于不得不多次跟乘客道歉，我觉得好累”。 在感恩节、圣诞节前夕的旺季，美联航管理人员在机场向乘客发放免费矿泉水--一种贝休恩的升级版手段。</p><p>无论穆诺斯飞到哪里，他都要和员工谈心，常常出人意料地出现在他们的休息室。“他特别善于倾听，他明白员工工作用心的价值，”贝休恩说。上任后第二天，穆诺斯就来到威尼斯大厦的网络运营中心。在一个迅速流传的故事中，据说他破坏了员工在芝加哥市中心酒吧的工余活动。对此美联航空姐、空姐协会(Association of Flight Attendants-CWA)国际总裁莎拉-尼尔森(Sara Nelson)说:“这就像美联航病得不轻，而穆诺斯就是一剂青霉素。它会好起来，但真正起作用需要时间。”</p><p>去年9月，麦肯锡前合伙人门多萨在Medium网站发出公开信表达对美联航的失望。穆诺斯给他发了电子邮件，两人定于10月15日谈一谈。到了那一天，门多萨收到穆诺斯助手发来的电子邮件，说CEO身体不太舒服。次日美联航证实，穆诺斯脏病发作住院。接下来的星期一，美联航宣布哈特担任临时CEO.</p><p>在哈特的领导下，美联航保持陆陆续续或大或小的变革。10月23日，美联航宣布与机械师工会领导达成协议，一个月后与飞行员续签合同。这两项工作最终都需要工会会员投票决定。美联航宣布暂停机场客户服务外包和登机口工作到2017年，让公司制服供应商代表倾听员工意见。也许更重要的是，美联航又恢复了经济舱的免费餐点。</p><p>还有咖啡问题，虽然这谈不上公司业务的中心问题，但它体现了美联航解决问题的软弱无能。去年11月19日，美联航宣布候机厅和机上供应的咖啡将从Fresh Brew牌换成意大利高档品牌Illy。对喜欢现场抱怨的乘客和机组人员来说，这是值得欢迎的消息，同时也默认了两家航空公司合并后的咖啡品牌选择尘埃落定。这个决定历时近一年，耗费了数千工时，牵涉从斯米塞克到总厨、空姐的每一个人。</p><p>更为基本的是，美联航重新审视了它的登机方式。负责去年夏天客户满意度调查的执行董事<a href="http://m.so.com/s?q=%E6%A0%BC%E9%9B%B7&amp;src=newstranscode" class="qkw">格雷</a>瓦尔(Mandeep Grewal)表示:“大家对登机过程很不耐烦。你一再发现满意度越来越低。”美联航的登机程序--五条警戒线对应各自登机群体--于2013年实行，以便人群在门口集结。但格雷瓦尔他们发现，这些警戒线有自我强化的作用。只要有人开始排队，其他人也觉得要排队。于是虽然登机时间还早，但候机厅已用警戒线围出了大片地方。不管登机实际用了多久，那些排队的人觉得等待时间更长了。</p><p>通过与美联航机长运营部门排班人员的合作，格雷瓦尔在凤凰城和纽瓦克的出港航班进行试验，实行只有两条大通道的登记制度:一条为目前正在登机人群使用，另一条为下一个航班人群使用。为了保留后到贵客的特权，又增加一条“旁道”。去年10月末，登机程序工作组接管芝加哥奥黑尔国际机场登机口一个月，显著改善了登机流程。</p><p>飞机飞行路线也不断改进。之前美联航严重依赖所谓的“线性路线”(linear routing)，比如一架飞机从纽约起飞会降落在芝加哥，然后再飞往丹佛、旧金山，最终停在西雅图。这种方式使得每架飞机在赚钱路线上的飞行时间最长，但一座机场的恶劣天气就可造成多条路线的延误、取消。去年11月，美联航开始增加当天返回基地的转场(out-and-back)路线飞行。</p><p>“我们从资产角度而非运营角度努力寻求最大效率的航班安排平衡，”美联航国际路线网规划部门执行董事布坎南(Andy Buchanan)说，“我发现我们找到了更好的平衡点。”</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://stock.eastmoney.com/news/1441,20160128590412391.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='38a5930818d963130844f6797596edf0'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>商业周刊</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '《商业周刊》:美联航改革初显成效' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '《商业周刊》:美联航改革初显成效'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";