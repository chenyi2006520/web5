s:18940:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>一周体坛论语:C罗为不当言论道歉 苏宁外援获赞- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">一周体坛论语:C罗为不当言论道歉 苏宁外援获赞</h1> <p id="source-and-time"><span id=source>中国青年网</span><time id=time>2016-03-07 09:29:54</time></p> </header>  <div id="news-body"><p><img src="http://p31.qhimg.com/t01021a815851c44d37.jpg?size=550x366"></p><p>中新网3月7日电 刚刚过去的一周中，世界体坛风起云涌。库里的“超远绝杀”持续被热议，NBA官方也更新了精确距离;<a href="http://m.so.com/s?q=%E6%9D%8E%E4%B8%96%E7%9F%B3&amp;src=newstranscode" class="qkw">李世石</a>与“阿尔法”的<a href="http://m.so.com/s?q=%E4%BA%BA%E6%9C%BA%E5%A4%A7%E6%88%98&amp;src=newstranscode" class="qkw">人机大战</a>备受关注，不过众多泰斗还是看好韩国人获胜;<a href="http://m.so.com/s?q=%E6%9B%BC%E8%81%94&amp;src=newstranscode" class="qkw">曼联</a>新妖王拉什福德横空出世，<a href="http://m.so.com/s?q=%E8%8C%83%E5%8A%A0%E5%B0%94&amp;src=newstranscode" class="qkw">范加尔</a>殿点评他有“特别的天赋”;<a href="http://m.so.com/s?q=%E4%B8%AD%E8%B6%85&amp;src=newstranscode" class="qkw">中超</a>开战，苏宁超级外援令各方称赞。</p><p>2月29日 范加尔:拉什福德有特别的天赋</p><p><a href="http://m.so.com/s?q=%E5%8C%97%E4%BA%AC%E6%97%B6%E9%97%B4&amp;src=newstranscode" class="qkw">北京时间</a>29日凌晨，英超第27轮，曼联在主场凭借拉什福德的<a href="http://m.so.com/s?q=%E6%A2%85%E5%BC%80%E4%BA%8C%E5%BA%A6&amp;src=newstranscode" class="qkw">梅开二度</a>3-2战胜了老对手阿森纳，这位18岁的小将迅速成为曼联球迷的新宠。赛后，主教练范加尔大肆称赞了小将拉什福德的表现。</p><p>范加尔说:&quot;他踢得很好，也许比对中日德兰时更好。因为对手更出色，他表现得也更出色。我为他感到高兴。我认为他应当拥有特别的天赋。&quot;</p><p>拉什福德本人则十分谦虚的表示，“这是我的<a href="http://m.so.com/s?q=%E8%8B%B1%E8%B6%85&amp;src=newstranscode" class="qkw">英超</a>首秀，所以这当然是令人十分吃惊的，而打进两球就是一份额外的奖励，所以我希望我可以继续保持下去。”</p><p class="header">3月1日 C罗为不当言论向队友道歉</p><p>在<a href="http://m.so.com/s?q=%E7%9A%87%E9%A9%AC&amp;src=newstranscode" class="qkw">皇马</a>0比1不敌马竞的比赛后，C罗发表了一些批评队友的言论，引发外界声讨，最终葡萄牙人不得不向队友道歉。</p><p>这场马德里德比的结果让C罗很失望，赛后在接受采访时他语出惊人:“如果队友跟我一个水平，或许我们现在就是领头羊了”。</p><p>事后，C罗解释说:“我没有不尊重其他人的意思，但是如果最好的球员不在球场上，我们很难赢球。”</p><p>据外媒1日报道，在皇马负于<a href="http://m.so.com/s?q=%E9%A9%AC%E7%AB%9E&amp;src=newstranscode" class="qkw">马竞</a>后的首堂训练课上，C罗在风波后首次面对全体队友，并在训练课开始前向全队解释自己的言论，表明自己没有恶意。他向队友们做出了道歉，而皇马其他队员也接受了C罗的道歉，没有将矛盾继续扩大。</p><p>3月2日 NBA官方:库里绝杀11.28米</p><p>上周，NBA联盟中的话题人物依旧是库里，更准确的说，是他在与雷霆比赛中完成的那记超远距离的三分绝杀。</p><p>NBA官方也在北京时间2日更新数据，把那一球的正确测量距离改为11.28米。以NBA<a href="http://m.so.com/s?q=%E4%B8%89%E5%88%86%E7%BA%BF&amp;src=newstranscode" class="qkw">三分线</a>最长7.25米来计算，他是在三分线后约4米投进这一球，由于是在跑动中投进，NBA当初判定时有一个脚步的差距，经过反复测量后做出了更正。</p><p>同样在上周，<a href="http://m.so.com/s?q=%E5%8A%B3%E4%BC%A6%E6%96%AF%E4%B8%96%E7%95%8C%E4%BD%93%E8%82%B2%E5%A5%96&amp;src=newstranscode" class="qkw">劳伦斯世界体育奖</a>正式公布了2016年度各奖项的候选人名单。斯蒂芬-库里和他的金州勇士分别入围了最佳男运动员和最佳团队两大奖项。</p><p>3月3日 <a href="http://m.so.com/s?q=%E7%8E%8B%E6%B1%9D%E5%8D%97&amp;src=newstranscode" class="qkw">王汝南</a>:人机大战李世石赢</p><p>距离“<a href="http://m.so.com/s?q=%E9%98%BF%E5%B0%94%E6%B3%95&amp;src=newstranscode" class="qkw">阿尔法</a>”和李世石的“人机大战”不足一周了。早些时候“阿尔法”击败欧洲冠军樊麾的消息引发了围棋界的震动，虽然樊麾的战斗力相较一流高手有不小差距，但这毕竟是电脑程序第一次在平等情况下击败职业棋手。</p><p>据媒体报道，作为中国围棋协会主席，在王汝南看来，这场“人机大战”无疑是有利于<a href="http://m.so.com/s?q=%E5%9B%B4%E6%A3%8B&amp;src=newstranscode" class="qkw">围棋</a>项目的宣传推广，他说:“这个关注度非常高，欧美很多不知道、不懂围棋的人一下就关注围棋了。从这个角度看，我们也希望李世石能赢，而且希望人类能多坚持几年，毕竟，二者抗衡时间越长，可能越有助于围棋项目的发展。”</p><p>展望李世石和“阿尔法”的“人机大战”，王汝南表示，就目前看到的棋(指和樊麾的对局)来看，就算几个月来一直在进步，应该还是李世石赢的可能性更大。</p><p>3月4日 <a href="http://m.so.com/s?q=%E5%91%A8%E7%90%A6&amp;src=newstranscode" class="qkw">周琦</a>:暂不考虑选秀</p><p>将卫冕冠军北京男篮挡在了季后赛次轮之外，新疆队本有机会更进一步。但在与四川男篮的较量中，新疆男篮落入下风，“大魔王”周琦在与哈达迪的对话中并没有优势可言。</p><p>在接受媒体采访时，周琦表示对自己这个赛季的表现总体还比较满意。对于这个夏天的安排，周琦回应:“夏天打完国家队就开始准备联赛，从思想到心理到身体都处于一个高强度的连轴转，一直都没怎么休息，整个人感到比较疲惫，也有一些疲劳性的伤病，休赛期主要是先休养吧，然后会出国接受一些训练，提升身体对抗能力。”</p><p>至于会不会在下赛季登录NBA，周琦表示，现在还没有去考虑选秀的事情。</p><p>3月5日 中超开战 外援惊艳获各方称赞</p><p>恐怕赛前没多少人想到，<a href="http://m.so.com/s?q=%E8%8B%8F%E5%AE%81&amp;src=newstranscode" class="qkw">苏宁</a>与鲁能的这场中超首轮最受关注的较量，会打出3:0这样的大比分。拉米雷斯首开纪录，<a href="http://m.so.com/s?q=%E7%89%B9%E8%B0%A2%E6%8B%89&amp;src=newstranscode" class="qkw">特谢拉</a>梅开二度，苏宁的这场胜利真正体现了巨星效应。</p><p>据媒体报道，赛后苏宁主帅<a href="http://m.so.com/s?q=%E4%BD%A9%E7%89%B9%E9%9B%B7%E6%96%AF%E5%BA%93&amp;src=newstranscode" class="qkw">佩特雷斯库</a>特意谈到了球队大牌外援的表现:“外援的身体和磨合还没有达到最佳状态，但是他们的身价和水平摆在那里，特别是特谢拉的进球，证明了他的身价。”</p><p>就连鲁能主帅曼诺也大赞苏宁外援，“引进高水平的外援，对一个球队来说可以快速提升水平，这场比赛对手比我们更能抓住反击的机会。苏宁战胜全北现代，再加上本场比赛，水平一直在提升。”</p><p>值得一提的是，赢下这场比赛，有媒体表示苏宁今年投资巨大，是夺冠大热门，对此佩帅说:“对于我们来说，俱乐部有一个长远的规划，我们还是先打好基础，不是赢下一场球就想拿冠军，如果这么想的话压力就会很大，对于我们来说下一场对阵延边的比赛才是最重要的。”</p><p>3月6日 乒球男女队奥运名单仍有变数</p><p>第53届<a href="http://m.so.com/s?q=%E4%B8%96%E4%B9%92%E8%B5%9B&amp;src=newstranscode" class="qkw">世乒赛</a>团体赛昨天在马来西亚落幕，中国男、女队双双卫冕。中国男队实现世乒赛男团八连冠捧起斯韦思林杯，中国女队则继2012年以来连续第三届捧起象征女团冠军的考比伦杯。值得一提的是，无论男队还是女队，这均是国乒历史上第20次在这项锦标上捧杯。</p><p>据媒体报道，国乒总教练刘国梁和中国女队主教练孔令辉在赛后谈到奥运阵容时均没有正面回应具体名单，他们只是暗示大致将是从男、女队各4名奥运重点队员中产生。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.youth.cn/zc/201603/t20160307_7712265.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='ecdbbaa146f594fe4fa91d18ab8ecdbc'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>论语</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '一周体坛论语:C罗为不当言论道歉 苏宁外援获赞' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '一周体坛论语:C罗为不当言论道歉 苏宁外援获赞'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";