s:17198:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>别让家长成为孩子生病的感染源- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">别让家长成为孩子生病的感染源</h1> <p id="source-and-time"><span id=source>搜狐</span><time id=time>2015-10-30 14:54:01</time></p> </header>  <div id="news-body"><p>有的孩子出生后反复呼吸道感染，经常感冒、发热、<a href="http://m.so.com/s?q=%E5%92%B3%E5%97%BD&amp;src=newstranscode" class="qkw">咳嗽</a>，难道是孩子天生体质弱吗?</p><p>根据我多年的研究，孩子反复呼吸道感染的罪魁祸首可能就是最爱孩子的家人，包括父母、爷爷奶奶等经常接触孩子的亲人。家人身上的疾病，是孩子反复生病的固定<a href="http://m.so.com/s?q=%E6%84%9F%E6%9F%93%E6%BA%90&amp;src=newstranscode" class="qkw">感染源</a>。有的家长患有<a href="http://m.so.com/s?q=%E6%85%A2%E6%80%A7%E9%BC%BB%E7%AA%A6%E7%82%8E&amp;src=newstranscode" class="qkw">慢性鼻窦炎</a>、过敏性鼻炎、<a href="http://m.so.com/s?q=%E6%85%A2%E6%80%A7%E5%92%BD%E7%82%8E&amp;src=newstranscode" class="qkw">慢性咽炎</a>等，由于时间太长，症状也不是很明显，自己也就习以为常，没有去治。他们不知道的是，这种情况最容易使孩子也发生感染。</p><p><img src="http://p34.qhimg.com/t01f80455ddc0c9a81e.jpg?size=349x227"></p><p>一些反复呼吸道感染的孩子来就诊时，我多次提醒这些患儿的家长注意:家里是否有人鼻子或者嗓子有疾病?我得到的答案大多数都是否定的。很多家长不愿意承认自己有问题，或者意识不到自己有慢性病，特别是爷爷奶奶，他们接受不了孩子是被自己感染的这个事实，他们觉得自己那么爱孩子，怎么会给孩子带来疾病呢?</p><p>有些家长总爱强调是环境的变化导致孩子生病的，比如说上幼儿园或者天气的变化等。但这些都只是诱因，如果没有种子，再浇水施肥也不会开出花结出果。只有病原的种子先存在于孩子的身体内，再加上环境因素诱导，孩子才会生病。</p><p><img src="http://p35.qhimg.com/t01e7e5546c3ee48baf.jpg?size=300x228"></p><p>很多老人有慢性<a href="http://m.so.com/s?q=%E6%B0%94%E7%AE%A1%E7%82%8E&amp;src=newstranscode" class="qkw">气管炎</a>，而且反复发作。这时候，老人的气管就是耐药细菌的培养基地。老人咳嗽得很厉害、吐黄痰或浓痰的时候，就说明老人的体内已经复制和培养了大批细菌。如果老人和孩子一起生活，细菌随同痰液扩散出来，就会感染孩子。有些老人虽然不跟孩子生活在一起，但孩子去看望老人的时候也会被感染。如果家里有这样的老人，要及时带他们去医院治疗，同时让孩子多喝水，经常给孩子冲洗鼻腔，避免孩子被感染。</p><p>有些父母的鼻子有问题，最常见的症状就是鼻子经常堵，睡觉打呼噜。这些父母很容易忽略自己的疾病，因为他们已经习以为常，根本意识不到自己得了慢性疾病。如果早上起来反复清嗓子，说明患了慢性咽炎。慢性咽炎是<a href="http://m.so.com/s?q=%E9%BC%BB%E7%82%8E&amp;src=newstranscode" class="qkw">鼻炎</a>、鼻窦炎导致鼻涕流进嗓子造成的，治好鼻炎、<a href="http://m.so.com/s?q=%E9%BC%BB%E7%AA%A6%E7%82%8E&amp;src=newstranscode" class="qkw">鼻窦炎</a>，慢性咽炎就会好转。另外，如果父母感觉口腔经常发干发黏，早上起床后嘴里有异味，这也是鼻炎、<a href="http://m.so.com/s?q=%E5%92%BD%E7%82%8E&amp;src=newstranscode" class="qkw">咽炎</a>的表现。鼻炎、咽炎不能轻视，要及时治疗，否则就很容易感染孩子。</p><p><img src="http://p31.qhimg.com/t019dc4884c84922ee9.jpg?size=313x213"></p><p><a href="http://m.so.com/s?q=%E6%85%A2%E6%80%A7%E9%BC%BB%E7%82%8E&amp;src=newstranscode" class="qkw">慢性鼻炎</a>还有以下典型症状:一是容易出现<a href="http://m.so.com/s?q=%E7%9D%A1%E7%9C%A0%E9%9A%9C%E7%A2%8D&amp;src=newstranscode" class="qkw">睡眠障碍</a>，要么失眠，要么多梦;二是脾气不好，经常发火、抱怨，对人对事比较苛刻;三是肠胃不好，要么<a href="http://m.so.com/s?q=%E4%BE%BF%E7%A7%98&amp;src=newstranscode" class="qkw">便秘</a>，要么腹泻，要么经常肚子疼。</p><p>有慢性呼吸道疾病的家长有以下特征:吐黄痰、流黄鼻涕、鼻子堵、反复清嗓子、口臭。为了孩子的健康，家人要先控制自己的慢性炎症，这些炎症常年不愈，鼻子里的细菌就成了久经考验的杀手，有了<a href="http://m.so.com/s?q=%E8%80%90%E8%8D%AF%E6%80%A7&amp;src=newstranscode" class="qkw">耐药性</a>，也很容易传染给孩子。</p><p>孩子生病还有很多其他因素，清除了家里的感染源，虽然不能保证孩子从此以后就不生病，但会明显减少孩子生病的次数。愿每一个孩子都健康成长，远离疾病，远离医院!</p><p><img src="http://p32.qhimg.com/t017f015f48e58febfd.jpg?size=290x213"></p><p class="img-title">温馨提示</p><p>有些孩子经常发热、咳嗽、反复感冒，有可能不是孩子体质弱，而是家人身上有慢性疾病，导致孩子反复感染。</p><p>如果家长有以下症状:鼻子经常堵、睡觉打呼噜、早晨清嗓子、口腔干燥发黏有异味、失眠多梦、易怒、便秘、<a href="http://m.so.com/s?q=%E8%85%B9%E6%B3%BB&amp;src=newstranscode" class="qkw">腹泻</a>，很可能患有慢性鼻窦炎、<a href="http://m.so.com/s?q=%E8%BF%87%E6%95%8F%E6%80%A7%E9%BC%BB%E7%82%8E&amp;src=newstranscode" class="qkw">过敏性鼻炎</a>或慢性咽炎。有这种情况的家长一定要及时治疗，以免感染孩子。同时要让孩子多喝水，经常给孩子冲洗鼻腔，避免孩子被感染。</p><p>更多、更全面的的<a href="http://m.so.com/s?q=%E8%82%B2%E5%84%BF%E5%BF%83%E7%BB%8F&amp;src=newstranscode" class="qkw">育儿心经</a>、亲子知识、父母课堂等资讯!关注“爱宝宝育儿亲子教育”，让您在宝宝的成长过程中，少走一点弯路!，公众号搜索“aibaobao1982”(长按复制)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://baobao.sohu.com/20151030/n424723646.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='1204d48020c3cdf986abb78e3d094daf'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>感染源</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%84%9F%E6%9F%93%E6%BA%90&amp;pn=1&amp;pos=6&amp;m=87acacbb1025a40f54fb27fcf47ea86c25e7a0f9&amp;u=http%3A%2F%2Fdiscovery.163.com%2F14%2F0908%2F18%2FA5L1RFRI000125LI.html" data-pos="1"> 日本发现新登革热<b>感染源</b> </a>   <li> <a href="/transcode?q=%E6%84%9F%E6%9F%93%E6%BA%90&amp;pn=1&amp;pos=7&amp;m=08bc229e747ac60cfa98e71fec7b755a23b10e5f&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0906%2F01%2FA5E0VORG00014JB5.html" data-pos="2"> 日本发现新的登革热<b>感染源</b> </a>   <li> <a href="/transcode?q=%E6%84%9F%E6%9F%93%E6%BA%90&amp;pn=1&amp;pos=8&amp;m=009cec7f603c4ecdd74ce7136661ad81fd07ae6a&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0902%2F17%2FA55GT4HB00014AEE.html" data-pos="3"> 日本登革热<b>感染</b>者达34人 公园毒蚊疑为<b>感染源</b>(图) </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '别让家长成为孩子生病的感染源' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '别让家长成为孩子生病的感染源'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";