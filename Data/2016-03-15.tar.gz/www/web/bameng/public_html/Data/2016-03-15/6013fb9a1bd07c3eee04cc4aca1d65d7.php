s:21562:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>历史上杀过三个皇帝的两位皇帝 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">历史上杀过三个皇帝的两位皇帝 </h1> <p id="source-and-time"><span id=source>张家口新闻网</span><time id=time>2015-06-04 09:11:00</time></p> </header>  <div id="news-body"><p>在中国历史上，皇帝是一国的元首，拥有至高无上的权力，有谁胆敢取皇帝老子的性命啊?难道就不怕小命整没了，抄家灭族?你还别说，历史上敢杀皇帝的人还真不少，下至贫民百姓、草根领袖;上至国家官员、宗室贵胄，成功的也有，失败的也有。然而比起来先后<a href="http://m.so.com/s?q=%E6%9D%80%E8%BF%87&amp;src=newstranscode" class="qkw">杀过</a>三个皇帝的皇帝来说，那简直就是小巫见大巫，不值一提。说到这里，那么历史上先后杀过三个<a href="http://m.so.com/s?q=%E7%9A%87%E5%B8%9D%E7%9A%84%E7%9A%87%E5%B8%9D&amp;src=newstranscode" class="qkw">皇帝的皇帝</a>到底有几位呢?笔者据史料总结出来两位:他们分别是<a href="http://m.so.com/s?q=%E5%8D%81%E5%85%AD%E5%9B%BD&amp;src=newstranscode" class="qkw">十六国</a>时期的前赵第三位皇帝昭武帝<a href="http://m.so.com/s?q=%E5%88%98%E8%81%AA&amp;src=newstranscode" class="qkw">刘聪</a>和南北朝时期的南朝宋<a href="http://m.so.com/s?q=%E5%BC%80%E5%9B%BD%E7%9A%87%E5%B8%9D&amp;src=newstranscode" class="qkw">开国皇帝</a>刘裕。</p><p class="header">一、前赵昭武帝刘聪</p><p>刘聪(?—公元318年)，匈奴人，也称刘载，字玄明，新兴(今山西忻州)人，汉赵(前赵)光文帝<a href="http://m.so.com/s?q=%E5%88%98%E6%B8%8A&amp;src=newstranscode" class="qkw">刘渊</a>第四子，十六国时期汉赵第三位皇帝，公元310年—公元318年在位。刘聪在位的8年间，先后杀掉了三位皇帝，他们分别是汉赵第二位皇帝<a href="http://m.so.com/s?q=%E5%88%98%E5%92%8C&amp;src=newstranscode" class="qkw">刘和</a>(刘聪的兄长)、西晋怀帝司马炽、西晋最后一位皇帝愍帝<a href="http://m.so.com/s?q=%E5%8F%B8%E9%A9%AC%E9%82%BA&amp;src=newstranscode" class="qkw">司马邺</a>。</p><p class="header">1、刘和</p><p><img src="http://p32.qhimg.com/t01616ae8c523be8451.jpg?size=400x366"></p><p>刘和(?—公元310年)，匈奴人，字玄泰，前赵光文帝刘渊的长子，十六国时期前赵第二位皇帝。</p><p>刘和在位期间，曾命卫尉、西昌王刘锐，舅父呼延攸与马景、刘钦结盟攻打四王，意欲收回兵权，结果就在攻打楚王刘聪的时候，吃了败仗，刘聪攻进西明门，刘锐等人逃进南宫，前锋跟着追。后来，刘聪在光极西室将兄长刘和斩杀。据《资治通鉴》记载:“永嘉四年(公元310年)甲申，聪攻西明门，克之;锐等走入南宫，前锋随之。乙酉，杀和于光极西室。”</p><p class="header">2、晋怀帝司马炽</p><p><img src="http://p35.qhimg.com/t01db48f8b640f4a6c1.jpg?size=420x326"></p><p>晋怀帝司马炽(公元284年—公元313年)，字丰度，<a href="http://m.so.com/s?q=%E6%99%8B%E6%AD%A6%E5%B8%9D%E5%8F%B8%E9%A9%AC%E7%82%8E&amp;src=newstranscode" class="qkw">晋武帝司马炎</a>第二十五子，晋惠帝司马衷异母弟，西晋第三位皇帝，公元307年—公元311年在位。</p><p><a href="http://m.so.com/s?q=%E6%B0%B8%E5%98%89&amp;src=newstranscode" class="qkw">永嘉</a>五年(公元311年)六月，匈奴刘聪的军队攻入洛阳，<a href="http://m.so.com/s?q=%E6%99%8B%E6%80%80%E5%B8%9D&amp;src=newstranscode" class="qkw">晋怀帝</a>在逃往长安途中被俘。</p><p>永嘉七年二月初一日(公元313年3月14日)，晋怀帝在正月的朝会上被命令为斟酒的仆人，有晋朝旧臣号哭，令刘聪反感。不久，刘聪用毒酒毒杀晋怀帝，享年三十岁。《晋书·卷五·帝纪第五》记载:“七年春正月，刘聪大会，使帝著青衣行酒。侍中庾珉号哭，聪恶之。丁未，帝遇弑，崩于<a href="http://m.so.com/s?q=%E5%B9%B3%E9%98%B3&amp;src=newstranscode" class="qkw">平阳</a>，时年三十。”</p><p class="header">3、晋愍帝司马邺</p><p><img src="http://p31.qhimg.com/t01f624d60d19dcec37.jpg?size=400x374"></p><p>晋愍帝司马邺(公元300年—公元318年)，也称司马业，晋武帝司马炎之的孙子，吴敬王司马晏的儿子，晋惠帝司马衷和晋怀帝司马炽的侄子，西晋最后一位皇帝，公元313年—公元317年在位。</p><p>永嘉七年(公元313年)，晋怀帝在平阳被刘聪杀害之后，司马邺于长安即帝位，改元建兴。司马邺即位时，西晋江山已经岌岌可危了，名存实亡。而且也没有资本与前赵作战。</p><p>建兴四年(公元316年)八月，前赵刘曜率军围攻长安，长安城内外断绝联系。<a href="http://m.so.com/s?q=%E6%99%8B%E6%84%8D%E5%B8%9D&amp;src=newstranscode" class="qkw">晋愍帝</a>在食粮断绝的情况之下于十一月十一日(12月11日)投降前赵。</p><p>晋愍帝投降前赵后，刘聪对他百般羞辱。建兴五年(公元317年)十月，刘聪外出打猎，令晋愍帝执行车骑将军的职务，穿着戎服，手执戟矛，在前面开路，百姓聚在路旁观看，有些晋朝遗民故老，看了以后抽泣流涕，刘聪听到后十分厌恶。后来，刘聪又趁宴会时让晋愍帝行酒，洗酒杯，上厕所时又使晋愍帝拿马桶盖，旁边的晋臣多失声哭泣，尚书郎辛宾抱住晋愍帝痛哭，被刘聪杀害。十二月二十日(公元318年2月7日)，刘聪在平阳将晋愍帝杀害，终年十八岁。据《晋书·卷五·帝纪第五》记载:“冬十月丙子，日有蚀之。刘聪出猎，令帝行车骑将军，戎服执戟为导，百姓聚而观之，故老或歔欷流涕，聪闻而恶之。聪后因大会，使帝行酒洗爵，反而更衣，又使帝执盖，晋臣在坐者多失声而泣，尚书郎辛宾抱帝恸哭，为聪所害。十二月戊戌，帝遇弑，崩于平阳，时年十八。”</p><p>二、南朝<a href="http://m.so.com/s?q=%E5%AE%8B%E6%AD%A6%E5%B8%9D%E5%88%98%E8%A3%95&amp;src=newstranscode" class="qkw">宋武帝刘裕</a></p><p>宋武帝刘裕(公元363年—公元422年)，字德舆，小名寄奴，祖籍彭城县绥舆里，为南朝宋开国皇帝。公元420年—公元422年在位。<a href="http://m.so.com/s?q=%E5%88%98%E8%A3%95&amp;src=newstranscode" class="qkw">刘裕</a>一生先后杀死了三个皇帝，未做皇帝之前杀了两位皇帝，他们分别是十六国时期<a href="http://m.so.com/s?q=%E5%8D%97%E7%87%95&amp;src=newstranscode" class="qkw">南燕</a>最后一位皇帝慕容超和东晋安帝司马德宗;做了皇帝后又杀了东晋恭帝司马德文。</p><p>1、<a href="http://m.so.com/s?q=%E6%85%95%E5%AE%B9%E8%B6%85&amp;src=newstranscode" class="qkw">慕容超</a></p><p><img src="http://p32.qhimg.com/t019375b176eb0e9d2e.jpg?size=400x400"></p><p>慕容超(公元384年―公元410年)，鲜卑族人，字祖明，南燕献武帝慕容德的侄子，北海王慕容纳之子，十六国时期南燕最后一位皇帝。公元405年—410年在位，统治南燕五年。</p><p>慕容超在位前期清明，后期荒废朝政，奢侈糜费，出游围猎，百姓深受其害，另外还肆意凌虐宗室大臣。最终，慕容超失去了人心、众叛亲离。</p><p>南燕太上六年(公元410年)正月，东晋太尉刘裕率领军队讨伐慕容超，慕容超向后秦求援无果，而此时适逢大夏皇帝赫连勃勃大败后秦，因此，前燕的支援梦想彻底破灭了。结果前燕军队在没有外援军队的支持下，节节败退。慕容超见形势不利，便和身边的数十人出城逃跑，被刘裕的军队抓住。刘裕数说慕容超不投降的罪状，慕容超神色自若，一言不发，只把母亲托付给<a href="http://m.so.com/s?q=%E5%88%98%E6%95%AC%E5%AE%A3&amp;src=newstranscode" class="qkw">刘敬宣</a>而已。刘裕命人将慕容超押送到建康(今江苏南京)，并在街市将其斩首，时年二十六岁，南燕灭亡。据《晋书》记载:超与左右数十骑出亡，为裕军所执。裕数之以不降之状，超神色自若，一无所言，惟以母托刘敬宣而已。送建康市斩之，时年二十六。</p><p class="header">2、晋安帝司马德宗</p><p><img src="http://p32.qhimg.com/t011a54d523155ada44.jpg?size=400x493"></p><p>晋安帝司马德宗(公元382年―公元419年)，字安德，晋孝武帝司马曜长子，晋恭帝司马德文同母兄，为东晋的第十位皇帝，公元397年—公元419年在位，共在位11年。</p><p>关于<a href="http://m.so.com/s?q=%E6%99%8B%E5%AE%89%E5%B8%9D&amp;src=newstranscode" class="qkw">晋安帝</a>的死因，虽史书上的说法略有不同，但都是刘裕命王韶之所杀。</p><p>①、《晋书》记载，当初流传<a href="http://m.so.com/s?q=%E8%B0%B6%E8%AF%AD&amp;src=newstranscode" class="qkw">谶语</a>说:“昌明之后有二帝”，刘裕为了能篡夺东晋政权，于是命王韶之勒死晋安帝而立司马德文为帝，来应予谶语。</p><p>②、《南史》中称刘裕命王韶之与晋安帝左右将他毒死。</p><p>③、《资治通鉴》称，刘裕因为谶语说“昌明之后尚有二帝”，所以指使中书侍郎王韶之与晋安帝左右密谋毒死晋安帝，而立晋安帝的弟弟琅邪王司马德文。司马德文一直陪在安帝左右，饮食寝处，从不离开;后来司马德文生病，搬到宫外居住。义熙十四年十二月戊寅日(公元419年1月28日)，王韶之在东堂用散衣勒死晋安帝。</p><p class="header">3、晋恭帝司马德文</p><p><img src="http://p32.qhimg.com/t01f324a15c7f4ed6a9.jpg?size=400x447"></p><p>晋恭帝司马德文(公元386年—公元421年)，晋孝武帝司马曜次子，晋安帝司马德宗之弟，东晋最后一位皇帝。</p><p>义熙十四年十二月戊寅日(公元419年1月28日)，刘裕杀害晋安帝司马德宗，立其弟司马德文为帝，年号元熙。公元419年—公元420年在位。</p><p>元熙二年(公元420年)，刘裕废晋恭帝司马德文，自立为帝，国号宋，定都建康(今江苏南京)，南朝由此开始，东晋自此灭亡。刘裕贬司马德文为零陵王，居于秣陵。永初二年九月丁丑日(公元421年11月10日)，刘裕便派人以棉被闷死司马德文，享年三十六岁。司马德文死后，谥号恭皇帝，葬于冲平陵。(陈令申)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.zjknews.com/news/wenhualishi/wenhualishi/201506/04/108860.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='4b918c6c03efeec888efc2a2ad8e69da'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>杀过</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9D%80%E8%BF%87&amp;pn=1&amp;pos=6&amp;m=f663ec60f77f9e841c27152663be66dabea3c74e&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0907%2F02%2FA5GP8LRB00014AEF.html" data-pos="1"> 我在山东<b>杀过</b>十二三岁的孩子(日本战犯口述) </a>   <li> <a href="/transcode?q=%E6%9D%80%E8%BF%87&amp;pn=1&amp;pos=7&amp;m=6827771c34f3a7cac55b2590588a0ec7415d3fae&amp;u=http%3A%2F%2Fsports.sina.com.cn%2Fzl%2Ffootball%2Fblog%2F2014-06-17%2F0737%2F1147278087%2F446213070101rijc.shtml" data-pos="2"> 孙梦维:战车碾<b>杀过</b>的狼藉 </a>   <li> <a href="/transcode?q=%E6%9D%80%E8%BF%87&amp;pn=1&amp;pos=8&amp;m=44116e0001613b9ce85897a793bc7256b0c25d63&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0807%2F07%2FA31F6UTS00014AED.html" data-pos="3"> 谭伯牛专栏:道光<b>杀过</b>三个人 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '历史上杀过三个皇帝的两位皇帝 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '历史上杀过三个皇帝的两位皇帝 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";