s:14887:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>2015卡萨帝思享荟:携手《十二道锋味》 打造锋味专属定制- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">2015卡萨帝思享荟:携手《十二道锋味》 打造锋味专属定制</h1> <p id="source-and-time"><span id=source>光明网</span><time id=time>2015-06-03 14:09:00</time></p> </header>  <div id="news-body"><p>光明科技讯 6月2日，国际高端家电品牌卡萨帝在北京举行的<a href="http://m.so.com/s?q=2015MLA&amp;src=newstranscode" class="qkw">2015MLA</a>思享荟上，正式携手<a href="http://m.so.com/s?q=%E3%80%8A%E5%8D%81%E4%BA%8C%E9%81%93%E9%94%8B%E5%91%B3%E3%80%8B&amp;src=newstranscode" class="qkw">《十二道锋味》</a>第二季，开启了全新的味爱之旅。活动当天，<a href="http://m.so.com/s?q=%E9%9C%8D%E6%B1%B6%E5%B8%8C&amp;src=newstranscode" class="qkw">霍汶希</a>、王小帅夫妇、<a href="http://m.so.com/s?q=%E9%83%91%E6%B0%B8%E9%AA%8F&amp;src=newstranscode" class="qkw">郑永骏</a>等众多演艺名人汇聚一堂，共同见证了卡萨帝的这段味爱“思享”盛宴。</p><p><img src="http://p31.qhimg.com/t01a917b503e48f5cdc.jpg?size=547x361"></p><p>对此，业内人士表示:此次卡萨帝携手《十二道锋味》第二季，一方面可以借助《十二道锋味》栏目的影响力普及高端生活方式，另一方也可充分诠释卡萨帝以及“<a href="http://m.so.com/s?q=%E6%80%9D%E4%BA%AB%E8%8D%9F&amp;src=newstranscode" class="qkw">思享荟</a>”的品牌内涵，二者合作可谓相得益彰。</p><p>据了解，为了引领高端生活方式演进，自今年年初卡萨帝就正式启动了家电行业首个高端家庭会员平台“思享荟”，旨在汇聚爱家庭、懂生活、赏艺术的社会精英人士，共赏生活艺术、<a href="http://m.so.com/s?q=%E8%81%86%E5%90%AC%E6%99%BA%E6%85%A7&amp;src=newstranscode" class="qkw">聆听智慧</a>、分享新知，推动<a href="http://m.so.com/s?q=%E9%AB%98%E7%AB%AF%E6%99%BA%E6%85%A7&amp;src=newstranscode" class="qkw">高端智慧</a>生活方式的普及。</p><p><img src="http://p32.qhimg.com/t018895743312e6ce6c.jpg?size=538x353"></p><p>在2015MLA思享荟活动现场，除了郑永骏畅谈美食味道，分享“锋味”背后的人生感悟之外;知名导演<a href="http://m.so.com/s?q=%E7%8E%8B%E5%B0%8F%E5%B8%85&amp;src=newstranscode" class="qkw">王小帅</a>更是在现场，亲自为妻子下厨烹饪美食，大秀恩爱。谈电影，聊生活，说理想，三位明星嘉宾的实时互动，不时迎来阵阵掌声。</p><p>作为此次活动的主角，《十二道锋味》栏目组也力邀卡萨帝会员代表，能够与第二季“锋味”一起，参与到节目中来，共同讲述<a href="http://m.so.com/s?q=%E7%88%B1%E4%B8%8E%E5%AE%B6%E5%BA%AD&amp;src=newstranscode" class="qkw">爱与家庭</a>的故事，享受“爱与美食”的美好时光。</p><p><img src="http://p31.qhimg.com/t012e2a359791b54903.jpg?size=540x367"></p><p>“对于卡萨帝而言，每一件产品都传递着与生俱来的自信和尊贵，传递着对高品质生活的追求，传递着对美和艺术的理解。我们希望这种高品质的生活方式，借助《十二道锋味》第二季的影响力，能够被更多的消费者所认同。”卡萨帝的负责人表示。</p><p>据悉，作为一档由<a href="http://m.so.com/s?q=%E8%B0%A2%E9%9C%86%E9%94%8B&amp;src=newstranscode" class="qkw">谢霆锋</a>领衔的《十二道锋味》，不仅为观众展现了一段段追寻美食的旅程，也让一次次烹制美食变成一种享受。早在“锋味”第一季，栏目就创下了收视高潮。此次第二季即将开播，卡萨帝的参与，必定会为观众再次奉上一次“锋味”大餐。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://tech.gmw.cn/2015-06/03/content_15868838.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='e85051ffe1f148db557021dcef3c2d57'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>郑永骏</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%83%91%E6%B0%B8%E9%AA%8F&amp;pn=1&amp;pos=6&amp;m=f277e23a0b268d525dbad0c5754a8351faa9933d&amp;u=http%3A%2F%2Ftech.gmw.cn%2F2015-06%2F03%2Fcontent_15868838.htm" data-pos="1"> 2015卡萨帝思享荟:携手《十二道锋味》 打造锋味专属定制 </a>   <li> <a href="/transcode?q=%E9%83%91%E6%B0%B8%E9%AA%8F&amp;pn=1&amp;pos=7&amp;m=9e39b56da48b41fee97f4b6de14999930b0a88f6&amp;u=http%3A%2F%2Fwww.chinadaily.com.cn%2Fhqcj%2Fxfly%2F2015-06-16%2Fcontent_13854117.html" data-pos="2"> 卡萨帝?思享荟 携手胡可沙溢招募精英"思享家" </a>   <li> <a href="/transcode?q=%E9%83%91%E6%B0%B8%E9%AA%8F&amp;pn=1&amp;pos=8&amp;m=49c59075944562751bc89c350a9a5baf167da9e6&amp;u=http%3A%2F%2Ftech.gmw.cn%2Fjd%2F2015-06%2F03%2Fcontent_15868788.htm" data-pos="3"> 卡萨帝携手《十二道锋味》 开启锋味美食之旅 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '2015卡萨帝思享荟:携手《十二道锋味》 打造锋味专属定制' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '2015卡萨帝思享荟:携手《十二道锋味》 打造锋味专属定制'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";