s:17872:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>阮玲玉当年的一个萝卜蹲，就注定了她是一个没素质的女人- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">阮玲玉当年的一个萝卜蹲，就注定了她是一个没素质的女人</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-02-29 14:23:00</time></p> </header>  <div id="news-body"><p>话说，关于女孩蹲着等地铁没素质这件事情，好像已经过不去了，因为到现在为止都还在撕过来撕过去。</p><p><img src="http://p35.qhimg.com/t01d97ea98248d6f05b.jpg?size=640x469"></p><p>可能这个优越癌晚期的居委会红领巾@我叫三颗牙，也没有想到，自己的几个连续咄咄逼人的问句，居然把爆发了2016开年第一撕。</p><p>为何现在那么多女孩子不懂得教养?等个地铁就可以随随便便蹲着，难看不难看?谁教他们的?这是什么生活习惯?</p><p>有的人觉得在蹲着等地铁特没素质影响市容。</p><p><img src="http://p34.qhimg.com/t019ab82ee264f63daf.jpg?size=440x202"></p><p>有的人则觉得又没碍着什么事儿，爱咋咋地。</p><p>所以，一直争论不休，直到今儿一早，也没有人去过问四年一遇了，都在纷纷检具或者审视一些没有素质的人。</p><p class="header">1.这是一只没有教养的猫。</p><p><img src="http://p35.qhimg.com/t010470dfcb30014fad.jpg?size=350x350"></p><p class="img-title">哦不，是两只。</p><p><img src="http://p31.qhimg.com/t01b804fa4a8dac54ee.jpg?size=350x363"></p><p>2.在得知<a href="http://m.so.com/s?q=Peter&amp;src=newstranscode" class="qkw">Peter</a>其实就是蜘蛛侠后，女友立刻提出分手。</p><p>“为什么?” Peter很是不解，“你不是最喜欢蜘蛛侠的吗?”</p><p>“可能我老了，很多事情比较保守，你怎么可以在公共场所随随便便就蹲着，难道不知道这样做很不雅很没教养吗? ”</p><p><img src="http://p31.qhimg.com/t01896885df2b7060ed.jpg?size=350x249"></p><p>3.菜园蹲完沙滩蹲，沙滩蹲完草坪蹲，原来你是这种胖。</p><p><img src="http://p32.qhimg.com/t01b26fa38829feb99f.jpg?size=350x230"></p><p><img src="http://p32.qhimg.com/t01e2fbb3d6dc4eecfd.jpg?size=350x231"></p><p><img src="http://p34.qhimg.com/t01f40f0c0c9235814e.jpg?size=350x230"></p><p><img src="http://p33.qhimg.com/t011505edf539aca5ce.jpg?size=350x233"></p><p><img src="http://p31.qhimg.com/t010bcdfb09b932936a.jpg?size=350x246"></p><p>4.前几天请来一位保洁，五十开外，四川人，家里实在太乱，预约了四个小时。临近中午，她说出去吃点饭，很快回来。大概过了五分钟，我开门扔垃圾，看见她蹲在楼道里吃<a href="http://m.so.com/s?q=%E7%85%8E%E9%A5%BC&amp;src=newstranscode" class="qkw">煎饼</a>。我说你进来坐着吃吧。她赶紧吃完起身说:不要紧的，吃东西有气味，我穿的是干活的衣服。当时，我哭了。</p><p class="header">他妈的，居然如此没有教养。</p><p><img src="http://p34.qhimg.com/t0124e9af0899c2aab0.jpg?size=440x660"></p><p>5.在厕所蹲坑，突然一道手机闪光灯闪过，接着有个人说:“你们农村人真没素质，竟然蹲着拉屎!”</p><p>6.难过了，就<a href="http://m.so.com/s?q=%E8%B9%B2%E4%B8%8B%E6%9D%A5%E6%8A%B1%E6%8A%B1%E8%87%AA%E5%B7%B1&amp;src=newstranscode" class="qkw">蹲下来抱抱自己</a>，对自己说一句:我真特么没教养。</p><p><img src="http://p33.qhimg.com/t010c8dbb6b4ead3598.jpg?size=440x494"></p><p>7.鞋带散了我都不敢系，怕别人说我没素质。还好身体柔韧，一个<a href="http://m.so.com/s?q=%E4%B8%80%E5%AD%97%E9%A9%AC&amp;src=newstranscode" class="qkw">一字马</a>下去，挽回了颜面。</p><p><img src="http://p31.qhimg.com/t0160f556fef4dc5f18.jpg?size=350x234"></p><p>8.钱包掉地上了，所以我到底是要还是不要，在线等。</p><p><img src="http://p32.qhimg.com/t01a3b2a8b07ff70d29.jpg?size=350x262"></p><p class="img-title">赶紧救命，我要报警了。</p><p><img src="http://p34.qhimg.com/t01ed546841993d7d6b.jpg?size=350x262"></p><p class="img-title">算了，只能用这个了。</p><p><img src="http://p34.qhimg.com/t01138ad96d659481a2.jpg?size=350x220"></p><p>9.深夜斗殴现场，记者闪光灯咔咔咔响，警察拿着警棍命令两帮小混混:“手抱头，蹲下，都蹲下!” 众小混混乖乖听命，唯独一位仍然站得笔直，警察喊他:“你为什么不蹲下?” 那位小混混手一指:“他们都拍照了，我会被说没教养的。”</p><p>10.就算别人踢我命根子，我也会倔强地站着，如果我蹲下，别人会说我没教养的。</p><p>11.蹲着会被认为没有素质，挺直了又会被人说拽什么拽，所以总是驼背的，其实是深谙中庸之道。</p><p>12.上课时笔掉了，蹲下身去捡，窗外一道刺眼的白光，“这个学生怎么回事，十几年书白读了，居然蹲着上课，素质被狗吃了吗”</p><p><img src="http://p33.qhimg.com/t017e9d7b22ce5ef02f.jpg?size=424x398"></p><p>13.有说蹲下像上厕所的，你们简直性别歧视，男的站着全都像在上厕所。</p><p class="header">14.这下有教养了</p><p><img src="http://p34.qhimg.com/t01e429284a5eec86d4.jpg?size=350x224"></p><p>15.【<a href="http://m.so.com/s?q=%E4%BC%8F%E5%9C%B0%E9%AD%94&amp;src=newstranscode" class="qkw">伏地魔</a>被评为J.K笔下最没素质角色】据中国挑刺协会评估，虽然J.K.<a href="http://m.so.com/s?q=%E7%BD%97%E7%90%B3&amp;src=newstranscode" class="qkw">罗琳</a>创作的《哈利波特》系列作品脍炙人口，但其中一个角色的名字实在是“太没教养”，会长彪碧莲表示“我不知道是不是我老了，但我知道无论是人是魔公开场合趴地上是很没教养的，也不知道他爹妈有没有好好教他。”</p><p>16.对不让你蹲着的人，你为什么不把他打趴下。</p><p><img src="http://p32.qhimg.com/t013717bf85d2441ce2.jpg?size=350x270"></p><p><img src="http://p31.qhimg.com/t01ab2d43872f9f8b9a.jpg?size=350x276"></p><p><img src="http://p35.qhimg.com/t01ae6ad65f051fcf92.jpg?size=350x393"></p><p><img src="http://p33.qhimg.com/t01f6f87c9409eb0b98.jpg?size=350x342"></p><p><img src="http://p33.qhimg.com/t018c355a76005176d8.jpg?size=350x233"></p><p><img src="http://p31.qhimg.com/t019c69381a7dbb3546.jpg?size=350x233"></p><p>17.<a href="http://m.so.com/s?q=%E9%98%AE%E7%8E%B2%E7%8E%89&amp;src=newstranscode" class="qkw">阮玲玉</a>，上海，没教养。</p><p><img src="http://p35.qhimg.com/t01a4ffc8ad6dbb5f7b.jpg?size=400x2025"></p><p>虽然有人说，对于这种狭隘心理没有必要揪着不放，但是讲道理，这节奏真的不能随便带。小明的爷爷之所以能活到90岁，是因为他从来不多管闲事。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://toutiao.com/i6256594919176012289/">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='adf9d0b33d4613bccf43bae783e0a19d'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>阮玲玉</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%98%AE%E7%8E%B2%E7%8E%89&amp;pn=1&amp;pos=6&amp;m=999f4247e9b8e1f0806a82dd07d409fee5fcc530&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fkuaixun_0216%2F4072287.html" data-pos="1"> <b>阮玲玉</b>胡蝶周璇 这些女神在上海留下传说 </a>   <li> <a href="/transcode?q=%E9%98%AE%E7%8E%B2%E7%8E%89&amp;pn=1&amp;pos=7&amp;m=899f326e09a06c03abaf8e6c91f3fd7035ff07aa&amp;u=http%3A%2F%2Ftoutiao.com%2Fi6256594919176012289%2F" data-pos="2"> <b>阮玲玉</b>当年的一个萝卜蹲,就注定了她是一个没素质的女人 </a>   <li> <a href="/transcode?q=%E9%98%AE%E7%8E%B2%E7%8E%89&amp;pn=1&amp;pos=8&amp;m=739142d3b0a632a2a984e4a4313793a1a5599280&amp;u=http%3A%2F%2Ftv.sohu.com%2F20160308%2Fn439731706.shtml" data-pos="3"> 1935年3月8日 <b>阮玲玉</b>自杀身亡 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '阮玲玉当年的一个萝卜蹲，就注定了她是一个没素质的女人' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '阮玲玉当年的一个萝卜蹲，就注定了她是一个没素质的女人'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";