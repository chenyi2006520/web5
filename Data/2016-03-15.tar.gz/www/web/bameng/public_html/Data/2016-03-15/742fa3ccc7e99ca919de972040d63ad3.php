s:15204:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>《神雕侠侣》全新光武曝光 无双兵刃即将到来- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">《神雕侠侣》全新光武曝光 无双兵刃即将到来</h1> <p id="source-and-time"><span id=source>安趣网</span><time id=time>2016-03-09 11:31:36</time></p> </header>  <div id="news-body"><p>全新资料片“风陵夜话”上线后，随着等级上限提高，<a href="http://m.so.com/s?q=%E3%80%8A%E7%A5%9E%E9%9B%95%E4%BE%A0%E4%BE%A3%E3%80%8B&amp;src=newstranscode" class="qkw">《神雕侠侣》</a>手游从九十年代步入百级时代，雕友们也从90后摇身一变，成为00后~在全新的副本，恩仇录，一条龙中，不少雕友表示力不从心，通关?臣妾做不到啊~《神雕侠侣》超级光武3.0震撼开启，经历无数次战斗的磨练，神兵再度觉醒，无双兵刃初开锋，助你称霸武林，一统群雄!</p><p><img src="http://p32.qhimg.com/t014f6bf40353b9ef89.jpg?size=500x281"></p><p class="img-title">百级光武 无双兵刃</p><p>漫长的等待过后，《神雕侠侣》手游终于迎来了百级时代的第一次装备更新，超级光武3.0--无双兵刃即将到来，特效再升级，造型更拉风，更能大幅加强无双技能，破军千里外，斩敌谈笑间!</p><p>随着中原战火愈演愈烈，蛮兵大军将<a href="http://m.so.com/s?q=%E8%A5%84%E9%98%B3%E5%9F%8E&amp;src=newstranscode" class="qkw">襄阳城</a>层层包围，情势不容乐观。守城的<a href="http://m.so.com/s?q=%E9%83%AD%E9%9D%96&amp;src=newstranscode" class="qkw">郭靖</a>、黄蓉夫妇二人欲找到一位有胆有识的侠义之士，希望将<a href="http://m.so.com/s?q=%E4%B8%AD%E5%8E%9F&amp;src=newstranscode" class="qkw">中原</a>武学封存在其兵器内。当各位雕友到达100级且拥有二阶光武后，就能够接取第三阶段光武的“无双兵刃”相关任务。</p><p><img src="http://p32.qhimg.com/t014ba7047e82af800c.jpg?size=500x500"></p><p class="img-title">英雄大会 再战玄金</p><p><a href="http://m.so.com/s?q=%E5%82%B2%E8%A7%86%E6%AD%A6%E6%9E%97&amp;src=newstranscode" class="qkw">傲视武林</a>群雄，天下谁与争锋，神雕江湖迎来了百级之后的第一次英雄大会，作为《神雕侠侣》手游中最为经典的2V2竞技模式，在90年代，经过雕友们多年的战斗积累，已经开发出数十种门派搭配和战术体系，而迎来100级之后，随着全新的宠物、养成系统以及无双兵刃等要素的加入，战斗局势更加多样化，唯一不变的，就是在这武林群雄争霸赛中，要杀出镔铁，斩尽泰银，直指玄金，究竟本届英雄大会将出现哪些奇葩的门派组合，战术思路让我们拭目以待!</p><p><img src="http://p35.qhimg.com/t01e66c4a217cd1474a.jpg?size=500x375"></p><p><img src="http://p31.qhimg.com/t01be4dec996d21b39f.jpg?size=500x280"></p><p><a href="http://m.so.com/s?q=%E4%BA%8C%E9%9B%B6%E4%B8%80%E5%85%AD&amp;src=newstranscode" class="qkw">二零一六</a> 江湖依旧</p><p>3月10日，<a href="http://m.so.com/s?q=%E9%87%91%E5%BA%B8&amp;src=newstranscode" class="qkw">金庸</a>先生的92岁寿辰即将到来，<a href="http://m.so.com/s?q=%E5%9B%9E%E5%BF%86%E5%AD%A6%E7%94%9F%E6%97%B6%E4%BB%A3&amp;src=newstranscode" class="qkw">回忆学生时代</a>，这位武林前辈的故事陪我们度过了无数夜晚，白驹过隙，不变的仍是心中的那份<a href="http://m.so.com/s?q=%E5%A4%A7%E4%BE%A0%E6%A2%A6&amp;src=newstranscode" class="qkw">大侠梦</a>。在此，让我们共同预祝<a href="http://m.so.com/s?q=%E6%AD%A6%E6%9E%97%E8%87%B3%E5%B0%8A&amp;src=newstranscode" class="qkw">武林至尊</a>生日快乐!</p><p>在神雕江湖中，我们曾或悲，或喜，有聚，有离，但无论过去多久，你依旧不会忘记那些与你一起追逐梦想的小伙伴们，2016，<a href="http://m.so.com/s?q=%E6%B1%9F%E6%B9%96%E4%BE%9D%E6%97%A7&amp;src=newstranscode" class="qkw">江湖依旧</a>，《神雕侠侣》手游，与你一起<a href="http://m.so.com/s?q=%E5%89%8D%E7%BC%98%E5%86%8D%E7%BB%AD&amp;src=newstranscode" class="qkw">前缘再续</a>!</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.anqu.com/sdxl/news/177484.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='881a62aadee832faff33349ce6cafd7a'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>神雕</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%A5%9E%E9%9B%95&amp;pn=1&amp;pos=7&amp;m=e222f57757bd29ac96af4995dc7370560de0ad70&amp;u=http%3A%2F%2Fgames.sina.com.cn%2Fo%2Fn%2F2016-03-11%2Ffxqhmvc2338378.shtml" data-pos="1"> 让爱升温 <b>神雕</b>侠侣邀你共度白色情人节 </a>   <li> <a href="/transcode?q=%E7%A5%9E%E9%9B%95&amp;pn=1&amp;pos=8&amp;m=c16be2e714fc14620c6e8e41fdc8a554764e88c4&amp;u=http%3A%2F%2Fmt.sohu.com%2F20160313%2Fn440272154.shtml" data-pos="2"> 看<b>神雕</b>侠侣,女友:"你看人家杨过,愿意为一个被QJ过的老女人等16年~"我:"你看反... </a>   <li> <a href="/transcode?q=%E7%A5%9E%E9%9B%95&amp;pn=1&amp;pos=9&amp;m=8f1d1e069316380a19390c48186985ade4b870cd&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4046561.html" data-pos="3"> 回合手游大作《<b>神雕</b>侠侣》WP版今日上架 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '《神雕侠侣》全新光武曝光 无双兵刃即将到来' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '《神雕侠侣》全新光武曝光 无双兵刃即将到来'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";