s:16762:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>《龙与精灵》宣传视频流出进入掌中魔幻世界- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">《龙与精灵》宣传视频流出进入掌中魔幻世界</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-13 21:29:27</time></p> </header>  <div id="news-body"><p>全球首款2.5D魔幻格斗手游<a href="http://m.so.com/s?q=%E3%80%8A%E9%BE%99%E4%B8%8E%E7%B2%BE%E7%81%B5%E3%80%8B&amp;src=newstranscode" class="qkw">《龙与精灵》</a>，终极封测正在火爆进行中!在玩家的热切期盼和呼唤下，《龙与精灵》终于决定将于4月中旬首先开启iOS正式版，下旬在安卓全渠道上线，<a href="http://m.so.com/s?q=%E9%AD%94%E5%B9%BB%E4%B8%96%E7%95%8C&amp;src=newstranscode" class="qkw">魔幻世界</a>中的格斗盛宴即将来袭，与此同时也发放出精美官方宣传视频，一起来先睹为快吧!</p><p><img src="http://p33.qhimg.com/t012692c7e74936fa72.jpg?size=500x278"></p><p class="img-title">宏大世界观 打造掌中魔幻世界</p><p>在视频中可以看到《龙与精灵》庞大的世界观背景:女神艾露茜娅借<a href="http://m.so.com/s?q=%E4%B8%8A%E5%B8%9D%E4%B9%8B%E6%89%8B&amp;src=newstranscode" class="qkw">上帝之手</a>，为六大种族创造了美丽祥和的世界，然而邪恶残暴的<a href="http://m.so.com/s?q=%E9%AD%94%E9%BE%99&amp;src=newstranscode" class="qkw">魔龙</a>奥菲特却打破了平静，对女神的子民发起战争，想成为世界王者。女神不忍战争下生灵涂炭，发动禁忌咒语封印了魔龙，但自己也因禁咒反噬而<a href="http://m.so.com/s?q=%E5%8D%8E%E4%B8%BA&amp;src=newstranscode" class="qkw">华为</a>石像，她与毁灭之神坠落在曙光与黄昏<a href="http://m.so.com/s?q=%E4%B8%A4%E4%B8%AA%E5%A4%A7%E9%99%86&amp;src=newstranscode" class="qkw">两个大陆</a>上，隔海而立，和平重新回归<a href="http://m.so.com/s?q=%E6%9B%99%E5%85%89%E5%A4%A7%E9%99%86&amp;src=newstranscode" class="qkw">曙光大陆</a>，邪恶之力也在另一边的<a href="http://m.so.com/s?q=%E9%BB%84%E6%98%8F%E4%B9%8B%E5%9C%B0&amp;src=newstranscode" class="qkw">黄昏之地</a>平静下来。3000年过去了，女神<a href="http://m.so.com/s?q=%E5%B0%81%E5%8D%B0%E7%9A%84%E5%8A%9B%E9%87%8F&amp;src=newstranscode" class="qkw">封印的力量</a>逐渐衰弱，黑暗中，奥菲特再次睁开了眼睛......</p><p>于是，《龙与精灵》魔幻世界的征途拉开了序幕，六大种族<a href="http://m.so.com/s?q=%E6%88%98%E9%AD%82%E8%A7%89%E9%86%92&amp;src=newstranscode" class="qkw">战魂觉醒</a>，化身英雄，守护和平弑杀魔龙，誓为女神荣耀而战!</p><p><img src="http://p33.qhimg.com/t0115a0d69bbf8b0073.jpg?size=500x254"></p><p class="img-title">六大职业 为女神荣耀而战</p><p>《龙与精灵》六大种族中，在之前的测试版本中已推出四个种族和对应职业，分别是龙族寒冰术士、人族战士、精灵族弓箭手和狼族<a href="http://m.so.com/s?q=%E5%BE%B7%E9%B2%81%E4%BC%8A&amp;src=newstranscode" class="qkw">德鲁伊</a>。</p><p>龙族是天生的法师，拥有操控冰雪的魔力，变身后化为寒冰<a href="http://m.so.com/s?q=%E5%B7%A8%E9%BE%99&amp;src=newstranscode" class="qkw">巨龙</a>，冰冻力量强力爆发，尘封千里无人能挡!</p><p>人族战士擅长冲锋，变身后通体红光，狂性大发，在降低敌人防御的同时，冲刺斩杀，一往无前!</p><p>精灵族弓箭手拥有强大的控制能力，变身后的精灵形象清新冷艳，散发出灵魂深处的高贵优雅，其<a href="http://m.so.com/s?q=%E8%97%90%E8%A7%86%E7%BE%A4%E9%9B%84&amp;src=newstranscode" class="qkw">藐视群雄</a>的姿态已使敌人望而生畏。</p><p>狼族德鲁伊变身为<a href="http://m.so.com/s?q=%E5%97%9C%E8%A1%80%E7%8B%BC%E4%BA%BA&amp;src=newstranscode" class="qkw">嗜血狼人</a>，极速攻击更无懈可击，出其不意间置对方于死地。</p><p>曙光大陆现在处处弥漫着腐烂的血腥气息，危机四伏，四大种族将拿起手中的武器，踏上屠<a href="http://m.so.com/s?q=%E9%AD%94%E4%B9%8B%E8%B7%AF&amp;src=newstranscode" class="qkw">魔之路</a>，还有血族和亡灵族是否会在公测时开放，玩家们期待一下吧!</p><p><img src="http://p35.qhimg.com/t01def6020aea076463.jpg?size=500x281"></p><p class="img-title">十大独创特色 打破传统格斗定义</p><p>作为最受玩家期待的格斗手游，《龙与精灵》在画面和玩法上拥有着独一无二的特色和魅力。突破传统格斗形式，创新变身战斗玩法;摒弃无趣的数据PK模式，首创在线实时PVP;改变单一成长线，角色中期自由转职;超越端游团战体验，百人同屏战BOSS.....刺激酣爽超乎你的想象!还有翅膀功能、萌宠小精灵、离线挂机和<a href="http://m.so.com/s?q=%E5%BE%AE%E4%BF%A1&amp;src=newstranscode" class="qkw">微信</a>式语音实时交流等特色玩法也令人沉醉其中，欲罢不能。</p><p><img src="http://p35.qhimg.com/t01604f79efce2847cf.jpg?size=500x278"></p><p>经过数月的测试和优化，《龙与精灵》终于要与玩家正式见面了!请坚信，《龙与精灵》一定不会辜负大家<a href="http://m.so.com/s?q=%E9%95%BF%E4%B9%85%E7%9A%84%E7%AD%89%E5%BE%85&amp;src=newstranscode" class="qkw">长久的等待</a>。用品质证明，《龙与精灵》值得你期待!掌中<a href="http://m.so.com/s?q=%E9%AD%94%E5%B9%BB%E4%B9%8B%E6%97%85&amp;src=newstranscode" class="qkw">魔幻之旅</a>值得你来征战!最新资讯和更多精彩活动，请密切关注《龙与精灵》官网和论坛。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/article/4024058.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='0ab07a1c806ed057ad04fcc4570aef0f'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>魔幻世界</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%AD%94%E5%B9%BB%E4%B8%96%E7%95%8C&amp;pn=1&amp;pos=5&amp;m=f092392af7a588421a33769a2948ba714028f4d9&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fjsnews%2Faround%2F4731521_1.html" data-pos="1"> 扬州马可波罗花<b>世界</b>4月16日开园 5D剧透开启<b>魔幻</b>东游奇旅 </a>   <li> <a href="/transcode?q=%E9%AD%94%E5%B9%BB%E4%B8%96%E7%95%8C&amp;pn=1&amp;pos=6&amp;m=874f82c0a47f5de895d470ac37f0fb52950dc5d6&amp;u=http%3A%2F%2Fwww.77l.com%2FNews%2Fwynews%2F92415.html" data-pos="2"> <b>魔幻世界</b>《神域大乱斗》IOS版蓄势待发 </a>   <li> <a href="/transcode?q=%E9%AD%94%E5%B9%BB%E4%B8%96%E7%95%8C&amp;pn=1&amp;pos=7&amp;m=cf0a6fc4a2f3dbdcedc36ee1cc84a0308643fb3d&amp;u=http%3A%2F%2Fyule.sanxia193.com%2Fkoushu%2F39950.html" data-pos="3"> 独家曝光《幻城》概念设计图 打造全新<b>魔幻世界</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '《龙与精灵》宣传视频流出进入掌中魔幻世界' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '《龙与精灵》宣传视频流出进入掌中魔幻世界'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";