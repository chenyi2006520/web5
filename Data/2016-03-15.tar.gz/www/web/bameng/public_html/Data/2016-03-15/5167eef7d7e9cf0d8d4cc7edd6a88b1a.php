s:20317:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>并非中国:谁才是世界军事工业“山寨”能力最强的国家- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">并非中国:谁才是世界军事工业“山寨”能力最强的国家</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-14 18:27:54</time></p> </header>  <div id="news-body"><p><img src="http://p32.qhimg.com/t017c25136734843997.jpg?size=590x496"></p><p><img src="http://p31.qhimg.com/t01920c6c941e0236f4.jpg?size=640x345"></p><p><img src="http://p35.qhimg.com/t01db9f612dd24b0f47.jpg?size=550x366"></p><p><img src="http://p33.qhimg.com/t019382b82302d15103.jpg?size=565x334"></p><p><img src="http://p31.qhimg.com/t017eaf6f59a4f9008e.jpg?size=640x330"></p><p><img src="http://p31.qhimg.com/t0115303ae856a305bb.jpg?size=640x427"></p><p><img src="http://p34.qhimg.com/t0138de0bda2b54539d.jpg?size=590x428"></p><p>在2015年9月3日举行的纪念抗战胜利70周年<a href="http://m.so.com/s?q=%E7%9B%9B%E5%A4%A7&amp;src=newstranscode" class="qkw">盛大</a>阅兵式上，中国展示了以99A<a href="http://m.so.com/s?q=%E4%B8%BB%E6%88%98%E5%9D%A6%E5%85%8B&amp;src=newstranscode" class="qkw">主战坦克</a>、05A自行榴弹炮、攻击-1无人机、东风-26弹道导弹等一大批先进武器，代表了中国国防工业的技术水平。对此西方媒体又开始酸溜溜的<a href="http://m.so.com/s?q=%E8%AF%84%E8%AE%BA%E4%B8%AD%E5%9B%BD&amp;src=newstranscode" class="qkw">评论中国</a>武器都是模仿抄袭外国产品，甚至把每一种阅兵装备都找一个“外国爹”。</p><p>中国的军事工业，在几十年前确实存在大量模仿或山寨，例如我们仿制和改进了大量苏式武器。这种早期的模仿对于中国国防工业能力的进步是必不可少的。从另一个角度看，能有“山寨”别国武器，也是工业能力的一种体现。这个世界上并非所有国家都有“山寨”能力。只有拥有基础雄厚、种类齐全的工业能力，才能够随心所欲的“山寨”，否则都只能照猫画虎。能够大规模“山寨”，是一个国家工业和制造业水平的提现。</p><p>事实上一提到“山寨”，世界人民总会想起中国。其实，在军事工业“山寨”能力领域，世界最强国家并非中国，而是头号超级大国--美国。</p><p>国防军事工业，是指一个国家拥有的，与<a href="http://m.so.com/s?q=%E7%8E%B0%E4%BB%A3%E6%88%98%E4%BA%89&amp;src=newstranscode" class="qkw">现代战争</a>和现代化军队密切相关的国防军事重工业体系、武器研发与制造体系以及军工附属产业制造体系的总称。是支持一个国家进行国防建设和战争行动的基础。</p><p>“山寨”，又称“<a href="http://m.so.com/s?q=%E9%80%86%E5%90%91%E5%B7%A5%E7%A8%8B&amp;src=newstranscode" class="qkw">逆向工程</a>”，是指一个国家以另一个国家已成型军事产品或技术为基础，进行反向逻辑推导、理论技术剖析与科研重构，进而还原其产品成型过程，并实施量产原产品，或进一步提升原产品性能。这就是我们老百姓俗称的“山寨”</p><p>国防军事工业“逆向工程”能力，是一个国家军事工业综合实力的重要组成部分。世界上只有极少数国家具有完全“山寨”其他国家先进武器。</p><p>关于武器的山寨，早先有一句特别的忠告:“修改原始设计要慎之又慎”。如果能力不足就贸然更改山寨产品的设计，会引发不可预料的后果。</p><p>我国早期在改进苏联设计的图-4战略轰炸机为预警机，仿制安-12运输机和图-16<a href="http://m.so.com/s?q=%E8%BD%B0%E7%82%B8%E6%9C%BA&amp;src=newstranscode" class="qkw">轰炸机</a>的时候，均遇到过不可克服的技术难关。仿制苏联米格-19为歼-6战斗机时，因未遵照原准设计，加之技术基础薄弱，导致初期产品发生大面积质量事故。</p><p>1969年至1971年，<a href="http://m.so.com/s?q=%E6%B2%88%E9%A3%9E&amp;src=newstranscode" class="qkw">沈飞</a>共生产了400多架歼-6Ⅲ型战斗机，交付部队后发生严重质量问题，全部停飞返厂。经中共中央和毛泽东主席批准，存在严重质量问题的922架歼6Ⅲ、直-5等飞机返厂修理。七十年代，中国军事援助<a href="http://m.so.com/s?q=%E5%B7%B4%E5%9F%BA%E6%96%AF%E5%9D%A6&amp;src=newstranscode" class="qkw">巴基斯坦</a>等国的战斗机，也曾连续发生等级事故，经统计，发生质量问题的援外歼-6等型号飞机数量占到援外飞机总数量的17%，也就是说每100架交付中国盟国的战机就有17架有质量问题。</p><p>基础基础薄弱时期，“山寨”别国武器经常发生对个别技术细节理解的差异，导致照猫画虎。以至于有过这样的笑话:早些年，俄罗斯专家访问沈阳飞机制造厂，那时候沈飞正在仿制著名的苏-27歼击机，也就是我们空军现役的歼-11A歼击机，这种歼击机与后来经过广泛改进的歼-11B型不同，歼-11A完全仿制苏-27，没有大多数零件都与进口型号一模一样。求知若渴的沈飞技师围追堵截俄罗斯专家，不耻下问:“为啥你们原装苏27战机座舱里X设备上有2只油浸的<a href="http://m.so.com/s?q=%E4%B8%9D%E7%BB%B5&amp;src=newstranscode" class="qkw">丝绵</a>，我们设计时百思不解，山寨歼11A的时候，只好照样学了”。俄罗斯专家答曰:“那2只丝绵，可能是苏霍伊<a href="http://m.so.com/s?q=%E5%85%B1%E9%9D%92%E5%9F%8E&amp;src=newstranscode" class="qkw">共青城</a>飞机制造厂的技师，组装苏-27的时候遗留在座舱里的”。</p><p>只有到了武器装备自由设计阶段，拥有门类齐全、基础雄厚、规模庞大、技艺高超的国防军事产业的国家，才能够按照需要自由修改原设计，这就是所谓的自由“山寨”。</p><p>这几年，中国的武器研发获得了巨大发展，武器设计也摆脱笨拙，进入自由阶段，似乎可以随心所欲定制武器。</p><p>下述评分根据<a href="http://m.so.com/s?q=%E3%80%8A%E7%AE%80%E6%B0%8F%E9%98%B2%E5%8A%A1%E5%91%A8%E5%88%8A%E3%80%8B&amp;src=newstranscode" class="qkw">《简氏防务周刊》</a>2013年的相关统计数据整理而成。本文只是赞成这个打分，并不确认此数据的真实性。</p><p>括号内，为一个国家国防军事工业“逆向工程”能力的系数，数值越大，能力越高。</p><p class="header">超强能力:美国(93分)</p><p class="header">极强能力:中国(79分)</p><p>强能力:<a href="http://m.so.com/s?q=%E4%BB%A5%E8%89%B2%E5%88%97&amp;src=newstranscode" class="qkw">以色列</a>(67分)、俄罗斯(65分)</p><p>较强能力:法国(58分)、英国(57分)、日本(55分)、<a href="http://m.so.com/s?q=%E4%B9%8C%E5%85%8B%E5%85%B0&amp;src=newstranscode" class="qkw">乌克兰</a>(52分)</p><p class="header">1、简氏的评分还算比较客观。</p><p>2、俄罗斯:从1990年苏联解体以来，俄罗斯的军工复合体产业主要以吃老本为主，是“逆向工程”能力下降最快的国家。</p><p>3、美国:世界上在军工复合体领域，美国是唯一可进行“严丝合缝的逆向重构”的国家。</p><p>4、中国:世界上“山寨”他国武器(主要是苏式武器)数量最多国家，并且能够山寨所有武器，最后还能超越原准国性能的国家。全世界改进苏联武器的最好型号都在中国，就连继承前苏联衣钵的俄罗斯都自愧不如。例如国产歼-7E/G型战机就是改进的最好的米格-21，国产的03式300毫米远程<a href="http://m.so.com/s?q=%E7%81%AB%E7%AE%AD%E7%82%AE&amp;src=newstranscode" class="qkw">火箭炮</a>也是改进的最好的<a href="http://m.so.com/s?q=%E9%BE%99%E5%8D%B7%E9%A3%8E&amp;src=newstranscode" class="qkw">龙卷风</a>火箭炮。</p><p>5、 由于美国的超强研发能力，所以尽管有山寨一切他国武器的能力，但美国很少山寨，美国只“山寨”自己一时拿不出来的别人最好的产品，例如以英国鹞式垂直起降战斗机发展的AV-8战斗机，以英国UFH式155毫米超轻型榴弹炮发展的M777型155毫米超轻型自行榴弹炮。所以，这地球上的逆向工程超级大国，就只剩下中国了。</p><p>6、这个统计唯一不科学的地方是忘了<a href="http://m.so.com/s?q=%E5%8D%B0%E5%BA%A6&amp;src=newstranscode" class="qkw">印度</a>，这是大放光芒的国家。假如没有中国，印度就是个相当成功的国家，政治民主，百姓听话，经济稳定爬升，能仿制各种武器，能够自行研制和制造第三代战斗机、航空母舰、<a href="http://m.so.com/s?q=%E6%A0%B8%E6%BD%9C%E8%89%87&amp;src=newstranscode" class="qkw">核潜艇</a>，先进主战坦克，超音速反舰导弹。能把卫星送上<a href="http://m.so.com/s?q=%E7%81%AB%E6%98%9F&amp;src=newstranscode" class="qkw">火星</a>。拥有一支庞大的军队，先进的软件技术，庞大的精英和<a href="http://m.so.com/s?q=%E4%B8%AD%E4%BA%A7%E9%98%B6%E5%B1%82&amp;src=newstranscode" class="qkw">中产阶层</a>，一切都那么完美，假如没有中国!</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/article/4055767.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='596f9f2b0533dd232964a5c09f68116a'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>世界军事</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%B8%96%E7%95%8C%E5%86%9B%E4%BA%8B&amp;pn=1&amp;pos=5&amp;m=b14f79c933e4cb27efa3734928e3c0da55d8623f&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4055841.html" data-pos="1"> 海湾战争的坦克大战:<b>世界</b>第三<b>军事</b>强国的覆灭 </a>   <li> <a href="/transcode?q=%E4%B8%96%E7%95%8C%E5%86%9B%E4%BA%8B&amp;pn=1&amp;pos=6&amp;m=2ff634459918ad980a8a3141d15e6bf5fbe175f8&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4054941.html" data-pos="2"> 中国总体<b>军事</b>实力排名<b>世界</b>第三:中国海军673艘战舰数量超美国 </a>   <li> <a href="/transcode?q=%E4%B8%96%E7%95%8C%E5%86%9B%E4%BA%8B&amp;pn=1&amp;pos=7&amp;m=7fd124dafac0716ef8cf7d529c1fc701c72943e0&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4051737.html" data-pos="3"> 2015年<b>世界军事</b>形势年会在京召开 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '并非中国:谁才是世界军事工业“山寨”能力最强的国家' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '并非中国:谁才是世界军事工业“山寨”能力最强的国家'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";