s:15874:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>省侨联主席王朝霞赴葫芦岛调研- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">省侨联主席王朝霞赴葫芦岛调研</h1> <p id="source-and-time"><span id=source>新浪</span><time id=time>2015-06-04 08:59:12</time></p> </header>  <div id="news-body"><p><img src="http://p34.qhimg.com/t013e2e047a64ec27a9.jpg?size=300x185"></p><p>省侨联主席<a href="http://m.so.com/s?q=%E7%8E%8B%E6%9C%9D%E9%9C%9E&amp;src=newstranscode" class="qkw">王朝霞</a>(右三)一行在<a href="http://m.so.com/s?q=%E8%91%AB%E8%8A%A6%E5%B2%9B%E5%B8%82&amp;src=newstranscode" class="qkw">葫芦岛市</a>侨联调研期间与葫芦岛市委书记<a href="http://m.so.com/s?q=%E9%83%BD%E6%9C%AC%E4%BC%9F&amp;src=newstranscode" class="qkw">都本伟</a>(中)等领导合影■华商晨报 掌中沈阳客户端记者 蔡敏强 摄</p><p>本报讯(华商晨报 掌中沈阳客户端主任记者 闻英奇)日前，<a href="http://m.so.com/s?q=%E8%BE%BD%E5%AE%81%E7%9C%81&amp;src=newstranscode" class="qkw">辽宁省</a>侨联党组书记、主席王朝霞，副主席<a href="http://m.so.com/s?q=%E8%83%A1%E5%B9%B3&amp;src=newstranscode" class="qkw">胡平</a>前往葫芦岛市侨联，就中共辽宁省委办公厅印发<a href="http://m.so.com/s?q=%E3%80%8A%E5%85%B3%E4%BA%8E%E5%8A%A0%E5%BC%BA%E5%92%8C%E6%94%B9%E8%BF%9B%E6%96%B0%E5%BD%A2%E5%8A%BF%E4%B8%8B%E4%BE%A8%E8%81%94%E5%B7%A5%E4%BD%9C%E7%9A%84%E5%AE%9E%E6%96%BD%E6%84%8F%E8%A7%81%E3%80%8B&amp;src=newstranscode" class="qkw">《关于加强和改进新形势下侨联工作的实施意见》</a>的通知文件的贯彻落实情况调研，并征集对拟召开的省第九次归侨侨眷代表大会的代表建议。</p><p><a href="http://m.so.com/s?q=%E8%91%AB%E8%8A%A6%E5%B2%9B&amp;src=newstranscode" class="qkw">葫芦岛</a>侨商感谢侨联工作</p><p>6月2日省侨联党组书记、主席王朝霞一行来到葫芦岛国际酒店，葫芦岛市委书记都本伟、市委副书记<a href="http://m.so.com/s?q=%E7%99%BD%E9%9B%AA%E5%B3%B0&amp;src=newstranscode" class="qkw">白雪峰</a>参与会见。都本伟对葫芦岛市侨联近几年的工作给予了充分肯定，并要求市侨联在省侨联的指导下能够发挥应有的作用，为侨胞侨眷提供满意的服务，为葫芦岛的城市发展建设贡献力量。</p><p>王朝霞对葫芦岛市委、市政府对市侨联工作的支持与认可表示感谢。在接下来的归侨侨眷座谈会上，王朝霞对葫芦岛市侨联近一段时间的工作表示认可，并对与会的葫芦岛市归侨、侨眷、基层干部及工作人员的努力付出表示感谢。</p><p>在随后的座谈会上，<a href="http://m.so.com/s?q=%E5%8A%A0%E6%8B%BF%E5%A4%A7&amp;src=newstranscode" class="qkw">加拿大</a>侨商高晓镝表示，葫芦岛市侨联在企业面临困难时，及时提供的帮助让企业能够迅速完成一直无法完成的工作，其对市侨联的帮助表示感谢。</p><p><a href="http://m.so.com/s?q=%E5%A2%A8%E8%A5%BF%E5%93%A5&amp;src=newstranscode" class="qkw">墨西哥</a>侨商高大平表示，通过市侨联的帮助，企业能够在葫芦岛顺利发展，期盼着未来侨联能够继续开创良好的局面。</p><p>王朝霞指出，近年间，葫芦岛市侨联在市委、市政府的领导下，团结归侨侨眷和海外侨胞致力于促进当地经济发展、参政议政、维护侨益等各项工作，坚持求实的工作作风，取得了较好的成果。</p><p class="header">“世界知名侨商辽宁行”将在沈举行</p><p>王朝霞表示，葫芦岛侨商心系祖国、心系家乡为家乡经济发展服务，也是对侨联系统的强有力支撑，在座谈会上提出了很好的建议和意见，都将作为省侨联未来工作的参考。</p><p>王朝霞指出，近期侨联系统将进行换届选举工作，为侨联更新血液激发活力增强侨联凝聚力起到重要作用。</p><p>座谈会期间王朝霞为归侨、侨眷介绍了即将在沈阳举办的由中国侨联、<a href="http://m.so.com/s?q=%E8%BE%BD%E5%AE%81%E7%9C%81%E4%BA%BA%E6%B0%91%E6%94%BF%E5%BA%9C&amp;src=newstranscode" class="qkw">辽宁省人民政府</a>主办，由省侨联、省发改委、省经信委、省外贸厅、省侨办承办的世界知名侨商辽宁行活动。</p><p>王朝霞表示，世界知名侨商辽宁行活动本着围绕中心服务大局，为经济发展服务，得到了省委、省政府的大力支持，力争打造成与绿公司年会比肩的品牌活动，举办该活动也是省委、省政府活跃辽宁经济发展的重要举措。</p><p>通过活动让世界了解辽宁，让辽宁走向世界，打造辽宁影响力，提高知名度，为<a href="http://m.so.com/s?q=%E6%8B%9B%E5%95%86%E5%BC%95%E8%B5%84&amp;src=newstranscode" class="qkw">招商引资</a>提供平台。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.sina.com.cn/o/2015-06-04/085931912715.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='64a3c7c9a64901f8ae5a2d107d641897'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>王朝霞</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%8E%8B%E6%9C%9D%E9%9C%9E&amp;pn=1&amp;pos=5&amp;m=13504a1fde8f2a6a86d0ac63b5bf90851bc6262a&amp;u=http%3A%2F%2Fnews.sina.com.cn%2Fo%2F2015-02-27%2F093931548083.shtml" data-pos="1"> 省侨联主席<b>王朝霞</b>赴鞍山走访调研 </a>   <li> <a href="/transcode?q=%E7%8E%8B%E6%9C%9D%E9%9C%9E&amp;pn=1&amp;pos=6&amp;m=22dbc607291dba32c178fdaa764e0d286dde90c6&amp;u=http%3A%2F%2Fnews.anshan.fang.com%2F2015-02-27%2F14949961.htm" data-pos="2"> 鞍山市领导会见省侨联主席<b>王朝霞</b>一行 </a>   <li> <a href="/transcode?q=%E7%8E%8B%E6%9C%9D%E9%9C%9E&amp;pn=1&amp;pos=7&amp;m=20f6da54960b332945fa75404cb117929d141c6f&amp;u=http%3A%2F%2Fgov.hebnews.cn%2F2015-01%2F12%2Fcontent_4461005.htm" data-pos="3"> <b>王朝霞</b>任辽宁省侨联党组书记 王之峰不再担任(简历) </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '省侨联主席王朝霞赴葫芦岛调研' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '省侨联主席王朝霞赴葫芦岛调研'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";