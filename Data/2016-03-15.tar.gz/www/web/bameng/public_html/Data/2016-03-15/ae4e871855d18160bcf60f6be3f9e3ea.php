s:15709:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>奥奇传说小说《光明传奇》第七章- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">奥奇传说小说《光明传奇》第七章</h1> <p id="source-and-time"><span id=source>7k7k</span><time id=time>2015-03-17 11:28:00</time></p> </header>  <div id="news-body"><p class="header">作者:天释   编辑:7k7k蒙蒙</p><p><img src="http://p33.qhimg.com/t01d7d6bace43978380.jpg?size=450x303"></p><p class="img-title">暗影崖之巅。</p><p>一股强大的<a href="http://m.so.com/s?q=%E6%81%B6%E9%AD%94%E4%B9%8B%E5%8A%9B&amp;src=newstranscode" class="qkw">恶魔之力</a>向着封印阵阵中间灌输而进，封印阵的四根石柱上仿佛有了感应，符文闪烁着晶莹的蓝光，好似在抵御这股恶魔之力。蓝光能量与恶魔之力抵触间造成了一次比一次强大的<a href="http://m.so.com/s?q=%E4%BD%99%E6%B3%A2&amp;src=newstranscode" class="qkw">余波</a>，顺着那股恶魔之力的主人散发而去。</p><p>恶魔系精灵被这突如其来的能量余波震退了数步，骇得吐出了一口紫红的鲜血，手上停止了传输。</p><p>就在这时，恶魔之力的效果显现了出来:暗影大帝的本源之晶与封印阵中央逐渐有了契合的迹象，而四根石柱发出强大的能量，射在本源之晶上，与本源之晶的能量对峙着，阻止它们之间的融合。</p><p>本源之晶慢慢融入到了阵中央，如今只剩下了二分之一不到的本源能量还没有契合，看来石柱的干扰也不是毫无作用的。</p><p>小诺飞奔似地来到了暗影崖，当它看到暗影崖上传来的的一阵阵黑暗能量时，心里越想越奇怪，随即疾冲向了山顶。</p><p>小诺身上散发出璀璨的光明能量，驱走了它附近的黑暗，在它的奔跑下，山顶上<a href="http://m.so.com/s?q=%E4%BF%AE%E5%B0%94&amp;src=newstranscode" class="qkw">修尔</a>的影子也是越来越逼近，越来越清晰，它望着距自己仅有几十余米的修尔，怀疑般地揉了揉眼睛，以确定自己不是在做梦。</p><p>确实，小诺曾无数次梦到过阿修，它梦见它和阿修回到了从前的山崖上，一起决斗，一起玩耍，一起……可<a href="http://m.so.com/s?q=%E6%A2%A6%E7%BB%88%E7%A9%B6%E6%98%AF%E6%A2%A6&amp;src=newstranscode" class="qkw">梦终究是梦</a>，一觉醒来却总是带起一阵失落，面前的阿修令它无法分辨自己是不是又到了一个梦中。直到小诺确认自己不是在做梦后，它惊喜地叫了出声:“阿修，没想到真的是你，我是小诺啊!”</p><p>修尔朝小诺步步逼近，它神色无悲无喜，冷冷地道:“我不是什么阿修，我的名字是修尔，是主人的精灵，你再不走，可别怪我将你杀了!”</p><p>此时，神秘男子也注意到了小诺，它阴森地说:“这难道就是三年前的那只被打得昏迷不醒的金色精灵吗?没想到你大难不死，还长进了不少，但你千不该，万不该，不该来到这个地方，也罢，也罢，既然你来了，就让你尝尝被伙伴攻击的滋味，修尔，动手!给我杀了它!”</p><p>小诺望向神秘男子，情不自禁地脱口而出:“你原来就是修罗，三年前的那个也是你吧。你对修尔到底做了什么?”修罗，他原本是奥奇一班的一员，可却因为叛离出逃的原因，而从此<a href="http://m.so.com/s?q=%E6%81%B6%E5%90%8D%E6%98%AD%E5%BD%B0&amp;src=newstranscode" class="qkw">恶名昭彰</a>，奥奇一班一直在寻找他，小诺也没想到神秘男子就是修罗。</p><p>“知道了又能如何，修尔，还不动手!”修罗望着面前仿佛在做着艰难抉择的修尔，心里咆哮着:“不好!为什么修尔情绪起伏的波动如此之大，难不成修尔认出了小诺?到底是什么让修尔这般，对，是小诺的光明能量，得快除掉它才行，不然肯定后患无穷!”</p><p>修尔的脑袋隐隐作痛，它意识中好像认识这只金色精灵，却总是什么也想不起来，它终于下定决心，朝着小诺斩杀过去，瞬间已至小诺面前，但，它的爪子却停留在小诺的胸口前，痛苦地抱着脑袋，凄厉地叫出声来眼睛布满血丝，一片通红。</p><p>修尔头上的印记一丝一缕地消散着，它的眼神也慢慢从呆滞转变回有神，它终于是恢复了所有的记忆，当然也包括被修罗控制的事，它看着小诺，兴奋地与小诺拥抱在一起。</p><p>就在这时，一声巨响响彻云霄，暗影大帝即将突破封印，修罗森冷地笑道:“怎么，久别重逢的感觉还好吗?但你们不觉得这还早了点不是?”</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.7k7k.com/content/20150317/707027.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='8035bf61d0d5471f8ffd916d04cc5534'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>梦终究是梦</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%A2%A6%E7%BB%88%E7%A9%B6%E6%98%AF%E6%A2%A6&amp;pn=1&amp;pos=8&amp;m=afdc4c446f056f8f6f7d72e3e569dc876d7db37c&amp;u=http%3A%2F%2Fsports.163.com%2F15%2F0123%2F11%2FAGL26VK500051C8U.html" data-pos="1"> 梦醒时分 人在旅途 </a>   <li> <a href="/transcode?q=%E6%A2%A6%E7%BB%88%E7%A9%B6%E6%98%AF%E6%A2%A6&amp;pn=1&amp;pos=9&amp;m=09c9b65da9b750814291a24e2b600f9c58bdeb61&amp;u=http%3A%2F%2Fgame.people.com.cn%2Fn%2F2014%2F1016%2Fc174244-25848596.html" data-pos="2"> 37《深渊》翅膀系统 华丽变身 闪耀星空 </a>   <li> <a href="/transcode?q=%E6%A2%A6%E7%BB%88%E7%A9%B6%E6%98%AF%E6%A2%A6&amp;pn=1&amp;pos=10&amp;m=4263e885783a46b9fdeeea9ded83095a3679890d&amp;u=http%3A%2F%2F2014.qq.com%2Fa%2F20140709%2F030867.htm" data-pos="3"> 震撼一战!德国让巴西崩溃 克洛泽超大罗封神 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '奥奇传说小说《光明传奇》第七章' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '奥奇传说小说《光明传奇》第七章'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";