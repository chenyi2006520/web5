s:21992:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>上海10家蒸汽海鲜火锅推荐 吃完海鲜再喝粥 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">上海10家蒸汽海鲜火锅推荐 吃完海鲜再喝粥 </h1> <p id="source-and-time"><span id=source>新华网上海频道</span><time id=time>2016-03-14 14:04:54</time></p> </header>  <div id="news-body"><p>蒸汽<a href="http://m.so.com/s?q=%E6%B5%B7%E9%B2%9C%E7%81%AB%E9%94%85&amp;src=newstranscode" class="qkw">海鲜火锅</a>，你吃过没有?据说在广州、厦门都超级火的哟!<a href="http://m.so.com/s?q=%E8%92%B8%E6%B1%BD%E7%81%AB%E9%94%85&amp;src=newstranscode" class="qkw">蒸汽火锅</a>用最简单的烹饪呈现<a href="http://m.so.com/s?q=%E6%B5%B7%E9%B2%9C&amp;src=newstranscode" class="qkw">海鲜</a>最美味的鲜甜。一锅两吃，上层蒸应季海鲜，下层同时熬煮香米粥。吃完蒸火锅，再喝鲜美现熬的养生粥，一口鲜美、一口热乎，别提多舒服了!(文章来源:上海去哪吃)</p><p class="header">1、元蒸坊</p><p>地址:卢湾区泰康路61号汇丰银行3楼</p><p class="header">人均:130元</p><p><img src="http://p34.qhimg.com/t01537ea35de4087887.jpg?size=450x600"></p><p class="img-title">元蒸坊</p><p>1000多平米面积，多达六七十种极品海鲜，堪比小型水族馆，可以说是魔都最大的蒸汽火锅餐厅了!海瓜子、鲍鱼、<a href="http://m.so.com/s?q=%E9%A6%99%E8%9E%BA&amp;src=newstranscode" class="qkw">香螺</a>、蛤蜊、竹蛏……都是可以挑选的。</p><p><img src="http://p33.qhimg.com/t019fbe9203b8a2a23c.jpg?size=550x413"></p><p>海鲜可直接在菜单上点，也可以在养殖区边看边点，先选好锅底(推荐养生杂粮米锅)，就盖上蒸垫直接蒸海鲜咯。蘸酱是自助的，全部都是餐厅自己熬的，强烈推荐豉油皇+花生油+<a href="http://m.so.com/s?q=%E8%BE%A3%E6%A4%92%E5%9C%88&amp;src=newstranscode" class="qkw">辣椒圈</a>+葱花的组合!</p><p>吃完海鲜，是时候揭开这一锅神秘<a href="http://m.so.com/s?q=%E6%9D%82%E7%B2%AE%E7%B2%A5&amp;src=newstranscode" class="qkw">杂粮粥</a>了!加入大麦、玉米碎、糙米、黄香米的杂粮粥，味道与普通的粥大大不同了哟!前面蒸着的海鲜味道都顺着蒸锅流入粥里，鲜得眉毛也要掉下来。</p><p>2、<a href="http://m.so.com/s?q=%E6%B5%B7%E8%BE%BE&amp;src=newstranscode" class="qkw">海达</a>人蒸汽海鲜主题餐厅</p><p>地址:浦东新区南泉北路588号新大陆广场南楼1楼</p><p class="header">人均:150元</p><p><img src="http://p31.qhimg.com/t0120b6023fdb04814f.jpg?size=550x413"></p><p class="img-title">海达人蒸汽海鲜</p><p>听说老板是潮汕人，新颖的蒸汽海鲜火锅吸引了不少吃货们慕名而去，毕竟吃腻了麻辣火锅、牛肉火锅、涮羊肉火锅后，也想换点新口味。</p><p>长脚蟹蒸好后壳不是特别硬，<a href="http://m.so.com/s?q=%E8%82%89%E8%B4%A8&amp;src=newstranscode" class="qkw">肉质</a>也比较紧，配海鲜豉油超赞!潮州手打牛肉丸，一口咬下去的瞬间还有汁水“爆裂”的感觉，特备弹牙。</p><p><img src="http://p35.qhimg.com/t019342a005db03e84b.jpg?size=550x413"></p><p>海达人蒸汽<a href="http://m.so.com/s?q=%E6%B5%B7%E9%B2%9C%E7%B2%A5&amp;src=newstranscode" class="qkw">海鲜粥</a></p><p>海鲜吃完后，鲜美清甜营养的粥也熬好了，来一碗整个人非常舒服，吃完一点也不会口干，衣服上也不会有味道。推荐集精华于一锅的<a href="http://m.so.com/s?q=%E5%B9%B2%E8%B4%9D%E6%8E%92%E9%AA%A8%E7%B2%A5&amp;src=newstranscode" class="qkw">干贝排骨粥</a>!干贝和排骨都很多，粥非常的浓稠，超级好口味!</p><p class="header">3、天下第一蒸</p><p class="header">地址:杨浦区长阳路2467号</p><p class="header">人均:126元</p><p><img src="http://p32.qhimg.com/t01f8443417e46af076.jpg?size=450x530"></p><p class="img-title">天下第一蒸蒸鱼</p><p>天下第一蒸，名气还蛮响的，既然敢夸口自己是“天下第一”，想必东西自然不会差。海鲜都是现点称重的，全程无添油，原汁原味，调料海鲜酱油+蒜泥+辣椒圈，就是最完美的搭配。</p><p>喜欢吃鱼的，记得试试这种时尚的蒸鱼方法，选好你想吃的鱼，就可以让服务员拿下去帮忙处理，吃的时候稍微蘸点酱油就已经很鲜美啦!个人觉得雪花<a href="http://m.so.com/s?q=%E8%82%A5%E7%89%9B&amp;src=newstranscode" class="qkw">肥牛</a>也很特别，平时都是涮火锅吃，还是第一次尝试这种蒸的吃法，跟火锅里涮的完全不同，蒸出来的肥牛更能锁住汁水，吃起来更加香嫩。</p><p class="header">4、螃门虾道美式手抓海鲜</p><p class="header">地址:静安区奉贤路286号</p><p class="header">徐汇区天钥桥路498号03</p><p class="header">人均:140元</p><p><img src="http://p34.qhimg.com/t01838a645c1aff22c8.jpg?size=550x366"></p><p class="img-title">螃门虾道</p><p>Duang!一大锅生猛海鲜上桌。锅里的鲜虾还在做最后的挣扎，一不留神就会跃出锅外。</p><p>上层是鲜虾花蛤八爪鱼，下层则是加了不少“猛料”的海鲜粥，一起焖个5分钟左右，就可以开动啦，原味蒸海鲜&amp;海鲜酱油简直绝配!再盛一碗热乎乎的海鲜粥喝下去，浓浓精华都在里面哟。</p><p class="header">5、潮庭原蒸</p><p>地址:长宁区天山路762号巴黎春天天山店西区3楼</p><p><img src="http://p32.qhimg.com/t01bb99a66ee5037a41.jpg?size=550x275"></p><p class="img-title">潮庭原蒸</p><p>海鲜隔水蒸是最家常的做法，原始但营养，好不好吃主要还是看食材是否新鲜。这家店的海鲜蒸出来不沾料也好吃，原汁原味的鲜美。</p><p><img src="http://p33.qhimg.com/t01c8ddf0d5120c0d12.jpg?size=450x550"></p><p class="img-title">潮庭原蒸 2</p><p>蒸的时候，也完全不用担心到底几分钟比较合适，这里的蒸锅都是特别定制的，桌子上还有这一个电控按钮，每份海鲜蒸多久，服务员都心里有数，定个时就能轻松搞定。时间一到，揭开锅，贝壳类海鲜个个都已经张开了壳，露出诱人的蛤肉，赶紧迫不及待开吃!</p><p class="header">6、原烹蒸道</p><p>地址:闵行区<a href="http://m.so.com/s?q=%E7%94%B3%E9%95%BF%E8%B7%AF&amp;src=newstranscode" class="qkw">申长路</a>888号虹桥天地广场1号楼2F近<a href="http://m.so.com/s?q=%E8%8B%8F%E8%99%B9%E8%B7%AF&amp;src=newstranscode" class="qkw">苏虹路</a>等</p><p class="header">人均:700元</p><p><img src="http://p34.qhimg.com/t01d70bc2b3c3f11464.jpg?size=550x413"></p><p class="img-title">原烹蒸道</p><p><img src="http://p35.qhimg.com/t018eddea423a8dc1b8.jpg?size=550x494"></p><p>是不是乍一看人均700元，还以为小编是不是手抖多打了一个0?同样是吃蒸海鲜，这家店贵就贵在，主打阿拉斯加<a href="http://m.so.com/s?q=%E5%B8%9D%E7%8E%8B%E8%9F%B9&amp;src=newstranscode" class="qkw">帝王蟹</a>!一只深海帝王蟹3分半钟就可以烹饪好了，食材都新鲜的不得了，蟹肉完全不蘸酱，都自带一股鲜甜。</p><p>据说光这套全电脑控制的蒸锅就申请了几十个专利，研发费用耗资200W+呢!听上去很高大上有木有，虽然人均消费不低，但食材、环境、服务都一流，是适合宴请的好地方。</p><p>7、<a href="http://m.so.com/s?q=%E8%B1%A1%E5%B1%B1&amp;src=newstranscode" class="qkw">象山</a>蒸汽海鲜</p><p class="header">地址:长宁区仙霞路762号</p><p class="header">人均:120元</p><p><img src="http://p31.qhimg.com/t01596c887ca522e37f.jpg?size=550x413"></p><p class="img-title">象山蒸汽海鲜</p><p>网上人气颇高的蒸汽海鲜馆，虽然地理位置不是很方便，离威宁路地铁站还有点距离，但依然阻挡不了吃货们的热情。一楼点海鲜，二楼是用餐区域。</p><p>主要食材都蛮新鲜的，蒸汽火锅下面是小米粥，上面可以随意蒸虾、<a href="http://m.so.com/s?q=%E6%89%87%E8%B4%9D&amp;src=newstranscode" class="qkw">扇贝</a>、鱼、黄蚬之类，时间都蛮快的，两分钟即可蒸熟，味道不错。整体比一般的火锅要干净，吃完身上也没什么味道。</p><p class="header">8、炎蒸 原味蒸汽海鲜</p><p>地址:嘉定区<a href="http://m.so.com/s?q=%E8%99%9E%E5%A7%AC%E5%A2%A9%E8%B7%AF&amp;src=newstranscode" class="qkw">虞姬墩路</a>566号(华江公路)</p><p><img src="http://p32.qhimg.com/t01e9e51069a5d09a60.jpg?size=450x505"></p><p class="img-title">炎蒸 原味蒸汽海鲜</p><p>店分上下两层，面积不是很大，生意倒不错，由于海鲜挑选区的占用，一楼用餐地稍显拥挤，用的是蒸汽锅，也是分上下两层，服务员先在锅底放上米，排骨，香菇，咸肉，然后盖上圆孔蒸格，让后面蒸海鲜的水汽慢慢下去，最后熬成的粥原汁原味的自然是鲜到眉毛掉下来了!</p><p>再说蒸海鲜，海鲜品种还蛮丰富的，有的论斤称重，有的论个卖，装在一个个塑料容器里，价钱和批发市场的价格差不多。吃下来，营养又健康，全程无油。</p><p class="header">9、蒸汽制造</p><p>地址:宝山区一二八纪念路1000弄宝山万达金街3楼343号(共和新路)</p><p class="header">人均:127元</p><p><img src="http://p33.qhimg.com/t01af18338a1dde7299.jpg?size=550x366"></p><p class="img-title">蒸汽制造</p><p>新开的蒸汽海鲜餐厅，店面不大，仅放的下9张桌子，不过从装修设计上看的出花了很多心思，干干净净的小店，而且从老板、老板娘到店员颜值都算蛮高的，算是赏心悦目的一家店。</p><p>食材非常新鲜，濑尿虾和基围虾都是活蹦乱跳的，入锅时当心它们“越狱”哦，加拿大翡翠螺比海螺吃上去肉质更鲜甜一些。雪花牛肉超级好吃，肉很嫩很嫩。<a href="http://m.so.com/s?q=%E8%92%9C%E8%93%89%E4%BA%94%E8%8A%B1%E8%82%89&amp;src=newstranscode" class="qkw">蒜蓉五花肉</a>吃上去肉很紧实，肥瘦搭配的刚刚好。娃娃菜和珍珠斑也是好吃到哭。</p><p class="header">10、汇蒸轩</p><p>地址:黄浦区浙江中路266号(汉口路口)</p><p class="header">人均:145元</p><p><img src="http://p31.qhimg.com/t015e72de99d017139f.jpg?size=550x367"></p><p class="img-title">汇蒸轩</p><p><img src="http://p31.qhimg.com/t01f1c94b92d50c6e35.jpg?size=550x354"></p><p>主打养生的一家店，店内所有东西都用蒸着一种方式来呈现食材最天然的味道。</p><p>印象最深的是香螺，肉质饱满弹性，无沙，蘸点海鲜酱油就已经很完美了。梭子蟹的个头虽然小了点，但胜在肉质饱满，强烈推荐扇贝!蒸完的扇贝汁水鲜甜，平时吃的豆豉、蒜蓉都盖过了扇贝原有的鲜味，而这原汁原味的鲜美才是食材最本真的健康美味。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://sh.xinhuanet.com/2016-03/14/c_135186308.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='78d042a5722ff91f22cb627cd8c5f23b'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>海鲜火锅</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%B5%B7%E9%B2%9C%E7%81%AB%E9%94%85&amp;pn=1&amp;pos=2&amp;m=959b041c85cec16a4b30dfce1e794cd299fc2bb9&amp;u=http%3A%2F%2Fmt.sohu.com%2F20160312%2Fn440183256.shtml" data-pos="1"> <b>海鲜火锅</b>:上东今旅酒店浓咖啡餐厅 </a>   <li> <a href="/transcode?q=%E6%B5%B7%E9%B2%9C%E7%81%AB%E9%94%85&amp;pn=1&amp;pos=3&amp;m=44941c1aa69bbda8e66a428e924438a8655f706f&amp;u=http%3A%2F%2Fgd.sina.com.cn%2Fyj%2F2016-03-07%2Fcity-yj-ifxqafha0432767.shtml" data-pos="2"> 东江港<b>海鲜</b>城 阳江首家<b>海鲜</b>蒸汽<b>火锅</b> </a>   <li> <a href="/transcode?q=%E6%B5%B7%E9%B2%9C%E7%81%AB%E9%94%85&amp;pn=1&amp;pos=4&amp;m=baa370531113d5dcbef39e6668bf68fc1dffe03c&amp;u=http%3A%2F%2Fsh.qq.com%2Fa%2F20160229%2F013282.htm" data-pos="3"> 上海蒸汽<b>海鲜火锅</b>推荐 吃完海鲜再喝粥 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '上海10家蒸汽海鲜火锅推荐 吃完海鲜再喝粥 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '上海10家蒸汽海鲜火锅推荐 吃完海鲜再喝粥 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";