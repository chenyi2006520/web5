s:18787:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>二胎生男孩秘诀 如何才能怀上聪明的男宝宝- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">二胎生男孩秘诀 如何才能怀上聪明的男宝宝</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-02-22 10:03:00</time></p> </header>  <div id="news-body"><p>固然往常重男轻女的思想曾经渐渐淡化，但是假定第一<a href="http://m.so.com/s?q=%E8%83%8E%E7%94%9F&amp;src=newstranscode" class="qkw">胎生</a>的是女宝宝，第二胎还是会想要个男宝宝，往常，有许多二胎生男孩的秘诀普遍被传播，下面和小编一同来看看，想生二胎的女性们，在二胎中如何生个男孩吧!</p><p><img src="http://p32.qhimg.com/t0159e6fd6adbfb2eb4.jpg?size=449x300"></p><p class="img-title">二胎中如何生个男宝宝?</p><p class="header">1、找准做爱机遇</p><p>受精卵分别前一个月的环境温度，也就是男生与女生在性行为发作前的一个月所处环境的温度，是影响宝宝性别的重要要素。 高温环境容易生出男宝宝，低温环境容易生出女宝宝。高温会影响精子的X染色体，让女宝宝不容易出生;低温会影响精子的Y染色体，让男宝宝不容易出生。因而，想生男孩，最好在夏天受孕，想生女孩，则尽量在冬天受孕。</p><p class="header">2、改动酸碱</p><p>分别带有X、Y染色体的精子在酸碱值不同的环境里，游动的速度不相同:带有Y染色体的精子在碱性环境中生机较强，而带有X染色体的精子在酸性环境里较为生动。所以，假定夫妻俩希望生女孩，可用少量而洁净的温开水稀释醋酸之后，冲洗妇女阴道，让阴道呈酸性。反之则生男孩。</p><p class="header">3、同房姿态和频率</p><p>想生男孩，能够采取站姿或后入式姿态，同房后安静地平躺一会儿，假定想生女孩，无妨试试传教士体位或女上式同房姿态。另外，同房频繁听说能够进步生女孩的几率。</p><p class="header">4、饮食调理</p><p>女性的阴道普通呈酸性，若在高潮时分泌碱性物质，则较适合Y精子生存，想生男孩者必需留意;想生女孩子则应维持体内的酸性环境。</p><p>饮食控制是将食物分为酸性、碱性和中性，男性多吃酸性食物，女性吃碱性食物，能够辅佐生男孩;而男性多吃碱性食物，女性多吃酸性食物，则对生女孩较有利。</p><p><img src="http://p33.qhimg.com/t01f654df56ad65ee93.jpg?size=415x287"></p><p class="img-title">饮食方面应该留意什么?</p><p class="header">1.饮食要回归自然</p><p>准备怀孕时及怀孕后，都应留意选用新颖、无污染的蔬菜、瓜果及野菜，防止食用含<a href="http://m.so.com/s?q=%E9%A3%9F%E5%93%81%E6%B7%BB%E5%8A%A0%E5%89%82&amp;src=newstranscode" class="qkw">食品添加剂</a>、色素、防腐剂的食物。</p><p class="header">2.饮食上要多样化</p><p>不同的食物所含的营养素不同，所具有的营养含量也不等。因而，食物要吃得杂一些，不要偏食或忌口，最好什么都吃，特别是五谷杂粮。</p><p><img src="http://p34.qhimg.com/t014aa5d5f7122bfe2a.jpg?size=640x405"></p><p class="img-title">3.留意在体内贮存钙和铁</p><p>怀孕中后期，容易发作<a href="http://m.so.com/s?q=%E7%BC%BA%E9%93%81%E6%80%A7%E8%B4%AB%E8%A1%80&amp;src=newstranscode" class="qkw">缺铁性贫血</a>和缺钙，受孕后再去补充为时已晚，特别是本来营养较差的女性。因而，在孕前应多食用鱼类、牛奶、<a href="http://m.so.com/s?q=%E5%A5%B6%E9%85%AA&amp;src=newstranscode" class="qkw">奶酪</a>、海藻、牛肉、<a href="http://m.so.com/s?q=%E7%8C%AA%E8%82%89&amp;src=newstranscode" class="qkw">猪肉</a>、鸡蛋、豆类及绿黄色蔬菜等食物，在体内贮存丰厚的铁和钙，以免怀孕后发作铁和钙的缺乏。</p><p class="header">4.增加精子和卵子的生机</p><p>夫妻双方因精子或卵子生机不强而致<a href="http://m.so.com/s?q=%E6%80%80%E5%AD%95&amp;src=newstranscode" class="qkw">怀孕</a>失败的例子较为多见，多吃瘦肉、蛋类、鱼虾、肝脏、豆类及豆制品、海产品、新颖蔬菜和时令水果等，能够改善精子和卵子的某些缺陷，进一步步增加受孕几率。</p><p class="header">5.生活中一定要留意补水</p><p>身体有了充足的水分，能够辅佐肃清体内的各种代谢毒物如重金属，加强免疫功用和抗病力，特别是在夏季，这样便可为怀孕后胎儿宝贝提供一个良好的生长发育环境。但要留意多喝烧开后自然冷却的白开水，少喝含<a href="http://m.so.com/s?q=%E5%92%96%E5%95%A1%E5%9B%A0&amp;src=newstranscode" class="qkw">咖啡因</a>、色素、香精等人工制造的饮料或<a href="http://m.so.com/s?q=%E6%9E%9C%E6%B1%81&amp;src=newstranscode" class="qkw">果汁</a>。与此同时，备孕期还要防止食用以下食物哦。</p><p><img src="http://p33.qhimg.com/t01bfb933d4d5476c28.jpg?size=640x655"></p><p class="img-title">孕前饮食忌讳</p><p>防止辛辣食物:<a href="http://m.so.com/s?q=%E8%BE%A3%E6%A4%92&amp;src=newstranscode" class="qkw">辣椒</a>、胡椒、花椒等调味品刺激性较大的等，多食可对<a href="http://m.so.com/s?q=%E4%BE%BF%E7%A7%98&amp;src=newstranscode" class="qkw">便秘</a>都有很大的好处。若准备怀孕的准妈妈食用大量这类食品后，同样会呈现消化功用的障碍。因而，倡议您尽可能防止摄入此类食品。</p><p>防止饮酒:酒精是招致胎儿畸形和<a href="http://m.so.com/s?q=%E6%99%BA%E5%8A%9B%E4%BD%8E%E4%B8%8B&amp;src=newstranscode" class="qkw">智力低下</a>的重要要素之一。</p><p>防止吃过多的糖:若经常食用高糖食物，常常会惹起糖代谢紊乱，但是招致成为潜在的糖尿病患者。</p><p>防止吃<a href="http://m.so.com/s?q=%E5%91%B3%E7%B2%BE&amp;src=newstranscode" class="qkw">味精</a>:味精的成分是<a href="http://m.so.com/s?q=%E8%B0%B7%E6%B0%A8%E9%85%B8%E9%92%A0&amp;src=newstranscode" class="qkw">谷氨酸钠</a>，进食过多可影响锌的吸收，不利于胎儿神经系统的发育。</p><p>防止吃人参、<a href="http://m.so.com/s?q=%E6%A1%82%E5%9C%86&amp;src=newstranscode" class="qkw">桂圆</a>:中医以为孕妇多数阴血偏虚，食用人参会惹起气盛阴耗，加重早孕反响、<a href="http://m.so.com/s?q=%E6%B0%B4%E8%82%BF&amp;src=newstranscode" class="qkw">水肿</a>和高血压等;桂圆辛温助阳，孕妇食用后易动<a href="http://m.so.com/s?q=%E8%A1%80%E5%8A%A8&amp;src=newstranscode" class="qkw">血动</a>胎。因而，倡议您食用前慎重思索。</p><p>防止吃腌制食品:这类食品固然美味，但内含亚硝酸盐、苯丙芘等，对身体很不利。</p><p>过敏性体质的人慎食致敏食品:食用可能致敏食物对胎儿的影响尚未惹起人们的注重，但事实上，致敏食品很可能会惹起流产、<a href="http://m.so.com/s?q=%E6%97%A9%E4%BA%A7&amp;src=newstranscode" class="qkw">早产</a>，招致胎儿畸形等多种恶性结果。</p><p>防止吃各种“污染”食品:食物从其原料消费直至食用前的全过程中，会阅历很多必需的环节，可能会不同水平地遭到污染，给人的身体带来危害。因而，应尽量选用新颖自然食品，防止食用含添加剂、色素、防腐剂的食品;蔬菜应充沛清洗洁净，水果最好去皮后再食用，以防止农药污染。</p><p>防止吃罐头食品:罐头食品中含有的添加剂和防腐剂，是招致惹起畸胎和流产的风险要素。孕前饮食是关于整个孕期和未来胎儿发育都是很重要的，千万要认真对待哦。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://toutiao.com/i6253930335034147329/">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='c0395fcc151dd4b98ef2f5d4bc56f3ed'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>胎生</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%83%8E%E7%94%9F&amp;pn=1&amp;pos=7&amp;m=af8e4a0faa332403aa42ecfa3d5be324c467df32&amp;u=http%3A%2F%2Fgb.cri.cn%2F42071%2F2015%2F05%2F04%2F7931s4950949.htm" data-pos="1"> 凯特二<b>胎生</b>公主 圆婆婆戴妃生女遗愿(组图) </a>   <li> <a href="/transcode?q=%E8%83%8E%E7%94%9F&amp;pn=1&amp;pos=8&amp;m=fe85a581fd229971882fc76834e2eab5a042dd11&amp;u=http%3A%2F%2Fwww.zj.xinhuanet.com%2F2016-02%2F18%2Fc_1118082845.htm" data-pos="2"> 36岁关心妍报喜 与老公希望首<b>胎生</b>女儿 </a>   <li> <a href="/transcode?q=%E8%83%8E%E7%94%9F&amp;pn=1&amp;pos=9&amp;m=8cada3b495f1f9c98d9914fd5070be487381da17&amp;u=http%3A%2F%2Fnews.sina.com.cn%2Fc%2F2014-08-08%2F070530651057.shtml" data-pos="3"> 老婆两<b>胎生</b>了三娃老公不是孩子他爸 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '二胎生男孩秘诀 如何才能怀上聪明的男宝宝' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '二胎生男孩秘诀 如何才能怀上聪明的男宝宝'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";