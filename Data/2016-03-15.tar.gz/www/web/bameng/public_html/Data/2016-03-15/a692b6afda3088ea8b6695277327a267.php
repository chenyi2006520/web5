s:14835:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>陈沛:AlphaGo如果完胜人类 或许直接退役- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">陈沛:AlphaGo如果完胜人类 或许直接退役</h1> <p id="source-and-time"><span id=source>网易</span><time id=time>2016-03-13 13:58:06</time></p> </header>  <div id="news-body"><p><img src="http://p35.qhimg.com/t01935f04ae893524a9.jpg?size=550x413"></p><p>网易科技讯 3月13日消息，<a href="http://m.so.com/s?q=%E8%B0%B7%E6%AD%8C&amp;src=newstranscode" class="qkw">谷歌</a>AlphaGo和<a href="http://m.so.com/s?q=%E6%9D%8E%E4%B8%96%E7%9F%B3&amp;src=newstranscode" class="qkw">李世石</a>的人机大战进入第四场，根据规则约定，在三连败的情况下，需要继续完成最后两场的比赛，李世石发起最后一搏，<a href="http://m.so.com/s?q=%E4%B8%BA%E5%B0%8A%E4%B8%A5%E8%80%8C%E6%88%98&amp;src=newstranscode" class="qkw">为尊严而战</a>。</p><p>网易人机大战直播嘉宾<a href="http://m.so.com/s?q=%E9%99%88%E6%B2%9B&amp;src=newstranscode" class="qkw">陈沛</a>认为，经过一个多小时的比拼，从场面来看，现在说胜负还为时尚早，到目前为止，李世石发挥稳定，并没有出现上一局出现的明显失误，如果继续保持水准，并不是没有扳回一局的可能性。</p><p>目前，从<a href="http://m.so.com/s?q=%E7%BD%91%E6%98%93%E6%96%B0%E9%97%BB&amp;src=newstranscode" class="qkw">网易新闻</a>客户端的投票结果来看，认为李世石一局都不会赢的占到了74%，只有26%的网友认为，李世石会不辱使命，为人类赢得尊严的一战。</p><p>陈沛在直播中讲到，这次比赛特别体现了<a href="http://m.so.com/s?q=%E4%BA%BA%E5%B7%A5%E6%99%BA%E8%83%BD&amp;src=newstranscode" class="qkw">人工智能</a>飞跃的进步，也体现了人工智能的神经网络、深度智能的技术在<a href="http://m.so.com/s?q=%E5%9B%B4%E6%A3%8B&amp;src=newstranscode" class="qkw">围棋</a>领域的突破性发展，某种意义上它也出乎我们很多人的意料，其实围棋的电脑程序很早就存在，不过它和人类顶级的水平相差4个子左右，原来我们认为它可能要用10年到20年的时间来赶超人类，但是现在它提前了，所以这个结果对我们很多人来说都是一个极大的震撼。提到人工智能威胁论时，他持否定立场，认为并不存在威胁一说，人工智能是人创造的，会为我所用，在更广泛的领域帮助到人类，他举例说道，比如酒店<a href="http://m.so.com/s?q=%E6%9C%BA%E5%99%A8%E4%BA%BA&amp;src=newstranscode" class="qkw">机器人</a>服务员，它比人类服务得更好，内部使用了大量的人工智能技术，会提高客人的幸福感。</p><p>对于这场<a href="http://m.so.com/s?q=%E4%BA%BA%E6%9C%BA%E5%A4%A7%E6%88%98&amp;src=newstranscode" class="qkw">人机大战</a>，中国观众表现出了极大的热情，期待<a href="http://m.so.com/s?q=AlphaGo&amp;src=newstranscode" class="qkw">AlphaGo</a>与中国围棋高手对决，中国棋手<a href="http://m.so.com/s?q=%E6%9F%AF%E6%B4%81&amp;src=newstranscode" class="qkw">柯洁</a>也站出来表示，希望阻挡一下“阿尔法围棋”，对此，陈沛坦言，在1997年IBM的人工智能深蓝战胜<a href="http://m.so.com/s?q=%E5%9B%BD%E9%99%85%E8%B1%A1%E6%A3%8B&amp;src=newstranscode" class="qkw">国际象棋</a>顶级大师后，随即宣布退役，所以并没有机会让更多的人挑战它，它挑战完人类以后，目的已经达到了，再挑战没有意义，它会继续深入学习把人类甩得越来越远。(广胜)</p><p>本文来源:<a href="http://m.so.com/s?q=%E7%BD%91%E6%98%93%E7%A7%91%E6%8A%80&amp;src=newstranscode" class="qkw">网易科技</a>报道  责任编辑:王凤枝_NT2541</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://tech.163.com/16/0313/13/BI1T7IB0000915BD.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='6ce3ca24ce58fc434a039d615c06eb7b'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>陈沛</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%99%88%E6%B2%9B&amp;pn=1&amp;pos=2&amp;m=9fcfb9f18a271632376434bf99a37c03f1a47f4a&amp;u=http%3A%2F%2Ftech.163.com%2F16%2F0313%2F13%2FBI1T7IB0000915BD.html" data-pos="1"> <b>陈沛</b>:AlphaGo如果完胜人类 或许直接退役 </a>   <li> <a href="/transcode?q=%E9%99%88%E6%B2%9B&amp;pn=1&amp;pos=3&amp;m=8e639082bea8202dfbd15a19d511db2096591a95&amp;u=http%3A%2F%2Fsc.sina.com.cn%2Ffinance%2Fjrfw%2F2016-03-08%2Fdetail_f-ifxqaffy3764454.shtml" data-pos="2"> 恒丰精英|<b>陈沛</b>:切实解决客户问题才是根本 </a>   <li> <a href="/transcode?q=%E9%99%88%E6%B2%9B&amp;pn=1&amp;pos=4&amp;m=ab1734e459f2052791b7731f7d404640c626db4a&amp;u=http%3A%2F%2Fmt.sohu.com%2F20160312%2Fn440223003.shtml" data-pos="3"> 我是搜索引擎技术专家<b>陈沛</b>,关于AlphaGo和围棋的问题,问我吧! </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '陈沛:AlphaGo如果完胜人类 或许直接退役' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '陈沛:AlphaGo如果完胜人类 或许直接退役'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";