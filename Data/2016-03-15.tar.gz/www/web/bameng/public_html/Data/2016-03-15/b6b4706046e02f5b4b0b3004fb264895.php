s:15987:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>匠心独运筑造精品 三棵树天彩石一瞬一世的美学艺术- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">匠心独运筑造精品 三棵树天彩石一瞬一世的美学艺术</h1> <p id="source-and-time"><span id=source>慧聪网</span><time id=time>2016-03-15 09:10:00</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E6%85%A7%E8%81%AA&amp;src=newstranscode" class="qkw">慧聪</a>涂料网讯:距第一家<a href="http://m.so.com/s?q=%E5%BC%80%E6%9E%97&amp;src=newstranscode" class="qkw">开林</a>颜料油漆厂创办已经有100年历史，外墙与人类行为可以说是一件弥足珍贵的艺术品，深具内涵、且质感醇厚。天然<a href="http://m.so.com/s?q=%E5%A4%A7%E7%90%86%E7%9F%B3&amp;src=newstranscode" class="qkw">大理石</a>是大自然馈赠给人类最珍贵的礼物，这是经久不衰的经典。然而，过度的大理石开采使用，让人类付出了巨大的代价。<a href="http://m.so.com/s?q=%E9%9B%BE%E9%9C%BE&amp;src=newstranscode" class="qkw">雾霾</a>、水士流失、山体滑坡，环境破坏………</p><p><img src="http://p34.qhimg.com/t014fb201f3d13c4edc.jpg?size=550x259"></p><p>匠心独运筑造精品三棵<a href="http://m.so.com/s?q=%E6%A0%91%E5%A4%A9&amp;src=newstranscode" class="qkw">树天</a>彩石一瞬一世的美学艺术</p><p>由于其自重大，粘结强度不够，大理石石材在建筑外墙装饰中使用，不但加大了建筑物的负重，同时增加了高空坠落的危险，给我们的人身带来巨大的威胁。</p><p><img src="http://p32.qhimg.com/t01bd6fed700444d061.jpg?size=550x234"></p><p class="img-title">坚守节能环保，践行绿色涂装</p><p>三棵树着力于大理石装饰美学的研究，在技术工艺不断创新下，开发出三棵树天彩石漆满足绿色建筑建材、环保节能的全新要求。它让更多的人享受天然大理石逼真装饰效果的同时减少了对天然大理石的需求，有效保护了自然环境、节约自然资源。一座<a href="http://m.so.com/s?q=%E5%9F%8E%E5%B8%82%E7%9A%84%E5%B4%9B%E8%B5%B7&amp;src=newstranscode" class="qkw">城市的崛起</a>，是文化的崛起，天彩石所代表的格调品味、生活情趣、居住方式，也代表了城市中间力量的审美取向。三棵树工程根据项目的类型及设计风格为<a href="http://m.so.com/s?q=%E6%9D%AD%E5%B7%9E%E8%A5%BF%E6%BA%AA&amp;src=newstranscode" class="qkw">杭州西溪</a>海度身打造了一系列外墙标准化体系，以还原建筑美学之初衷，让建筑彰显不凡的品味。</p><p><img src="http://p35.qhimg.com/t01cbf6a37daaa70775.jpg?size=550x265"></p><p class="img-title">天彩石VS天然石材</p><p>可持续发展的城市绿色建筑全面解决方案</p><p>一座城市的崛起，是文化的崛起，天彩石所代表的格调品味、生活情趣、居住方式，也代表了城市中间力量的审美取向。三棵树工程根据项目的类型及设计风格为杭州西溪<a href="http://m.so.com/s?q=%E6%B5%B7%E5%BA%A6&amp;src=newstranscode" class="qkw">海度</a>身打造了一系列外墙标准化体系，以还原建筑美学之初衷，让建筑彰显不凡的品味。</p><p><img src="http://p33.qhimg.com/t0174bf710eedce050e.jpg?size=550x409"></p><p>三棵树天彩石产品工艺成熟，是优质的“绿色外立面”装饰材料。作为新型涂料产品，完全摒弃了天然大理石作存在的色差大、瑕疵多、易渗水渗污、价格高昂且难运输、供货周期长等缺陷。</p><p><img src="http://p32.qhimg.com/t019077bd250fb342c4.jpg?size=550x312"></p><p>三棵树天彩石让杭州西溪海犹如石头中精雕细琢而出的顶级居所，匹配城市精英的<a href="http://m.so.com/s?q=%E9%BC%8E%E7%BA%A7%E4%BA%BA%E7%94%9F&amp;src=newstranscode" class="qkw">鼎级人生</a>。从任何角度欣赏，都能惊奇的发现它独具风格且耐人寻味。</p><p><img src="http://p32.qhimg.com/t01ca776500891e20f7.jpg?size=550x502"></p><p>为呈现更具质感的建筑格调，杭州西溪海在共计12万平方米的外墙涂刷中，采用了如下外墙涂装配套体系:</p><p><img src="http://p31.qhimg.com/t018e028a5775a3f38d.jpg?size=550x364"></p><p class="img-title">精益求精&精雕细凿</p><p><img src="http://p34.qhimg.com/t01adcd14bdeccea3ed.jpg?size=550x307"></p><p>天彩石墙面分割线效果完美，立体逼真，无限接近真实石材效果，配合专业的施工团队，让三棵树天彩石展现出超出预期的视觉效果。</p><p><img src="http://p34.qhimg.com/t01a83b07130ea70423.jpg?size=550x364"></p><p>经过风雨和时间的考验，现在杭州西溪海外墙面在阳光的照射下依然保持着极佳的效果。三棵树天彩石凭借其优秀的抗污性和耐水耐候性，收获了一座城市的瞩目和赞誉。</p><p>责任编辑:张淑芬</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://info.coatings.hc360.com/2016/03/150910660285.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='011a48f3bd7a628a6ea486af7af958b3'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>视觉美学</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%A7%86%E8%A7%89%E7%BE%8E%E5%AD%A6&amp;pn=1&amp;pos=9&amp;m=d3f7a2ca9bb16a8f948646cbba95c1d0e41da720&amp;u=http%3A%2F%2Fmedia.china.com.cn%2Fcmyj%2F2015-05-09%2F424024.html" data-pos="1"> 论新媒体舞蹈"重构<b>美学</b>"的<b>视觉</b>思维 </a>   <li> <a href="/transcode?q=%E8%A7%86%E8%A7%89%E7%BE%8E%E5%AD%A6&amp;pn=1&amp;pos=10&amp;m=a914d47cb6ec86105f5b5eaa24fa2257f2cabe7b&amp;u=http%3A%2F%2Fmt.sohu.com%2F20160309%2Fn439898898.shtml" data-pos="2"> 酷开新品演绎大家伙的极致<b>美学</b> </a>   <li> <a href="/transcode?q=%E8%A7%86%E8%A7%89%E7%BE%8E%E5%AD%A6&amp;pn=2&amp;pos=1&amp;m=26a077fa0f1b9def5a8c11d943b582d565a6862a&amp;u=http%3A%2F%2Fnews.xgo.com.cn%2F138%2F1381863.html" data-pos="3"> 演绎性能<b>美学</b> 全新一代XF引领运动商务座驾新风范 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '匠心独运筑造精品 三棵树天彩石一瞬一世的美学艺术' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '匠心独运筑造精品 三棵树天彩石一瞬一世的美学艺术'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";