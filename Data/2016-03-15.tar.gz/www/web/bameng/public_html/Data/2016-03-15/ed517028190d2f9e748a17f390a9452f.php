s:23240:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>刘青云汤唯《三城记》演绎旷世绝恋 现打鸟枪定情画面(图)- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">刘青云汤唯《三城记》演绎旷世绝恋 现打鸟枪定情画面(图)</h1> <p id="source-and-time"><span id=source>凤凰网</span><time id=time>2015-05-28 07:44:00</time></p> </header>  <div id="news-body"><p><img src="http://p31.qhimg.com/t014cf35587a17fa361.jpg?size=500x333"></p><p><img src="http://p35.qhimg.com/t01543d7e50a405f131.jpg?size=500x333"></p><p><a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%89%E5%9F%8E%E8%AE%B0%E3%80%8B&amp;src=newstranscode" class="qkw">《三城记》</a>主创合影</p><p>主演<a href="http://m.so.com/s?q=%E5%88%98%E9%9D%92%E4%BA%91&amp;src=newstranscode" class="qkw">刘青云</a>和汤唯</p><p>凤凰娱乐讯 影片《三城记》昨(27日)在京举办首场发布会，这是影片杀青后首次对外揭开神秘面纱。华谊总裁<a href="http://m.so.com/s?q=%E7%8E%8B%E4%B8%AD%E7%A3%8A&amp;src=newstranscode" class="qkw">王中磊</a>、导演张婉婷和监制<a href="http://m.so.com/s?q=%E7%BD%97%E5%90%AF%E9%94%90&amp;src=newstranscode" class="qkw">罗启锐</a>，携刘青云、汤唯、<a href="http://m.so.com/s?q=%E7%A7%A6%E6%B5%B7%E7%92%90&amp;src=newstranscode" class="qkw">秦海璐</a>、井柏然和黄觉五位主演全阵容亮相。</p><p>继<a href="http://m.so.com/s?q=%E3%80%8A%E5%B2%81%E6%9C%88%E7%A5%9E%E5%81%B7%E3%80%8B&amp;src=newstranscode" class="qkw">《岁月神偷》</a>之后，金牌搭档<a href="http://m.so.com/s?q=%E5%BC%A0%E5%A9%89%E5%A9%B7&amp;src=newstranscode" class="qkw">张婉婷</a>导演和监制罗启锐瞄准爱情题材，十年前便创作剧本，历经三年时间筹备，用十倍于《岁月神偷》的宏大投资和精良的制作，将《三城记》打造为旷世恋传奇。影帝刘青云和影后<a href="http://m.so.com/s?q=%E6%B1%A4%E5%94%AF&amp;src=newstranscode" class="qkw">汤唯</a>首度搭档，演绎一场跨越三城间用生命追逐真爱的<a href="http://m.so.com/s?q=%E6%97%B7%E4%B8%96%E7%BB%9D%E6%81%8B&amp;src=newstranscode" class="qkw">旷世绝恋</a>，汤唯直言羡慕角色的爱情。而金马影后秦海璐和人气男星<a href="http://m.so.com/s?q=%E4%BA%95%E6%9F%8F%E7%84%B6&amp;src=newstranscode" class="qkw">井柏然</a>则挑战反差极大的姐弟恋，秦海璐表示被对方的才华打动，而井柏然则赞仇大姐满足男人所有欲望。自嘲沦为备胎的<a href="http://m.so.com/s?q=%E9%BB%84%E8%A7%89&amp;src=newstranscode" class="qkw">黄觉</a>现场圆梦，兴奋为汤唯量身。在展现定情信物环节，刘青云和汤唯现场演绎打鸟枪，秦海璐和井柏然欢乐再现<a href="http://m.so.com/s?q=%E6%8C%91%E9%B8%A1%E8%9B%8B&amp;src=newstranscode" class="qkw">挑鸡蛋</a>。片方不仅曝光首款预告片，并宣布《三城记》将于今年秋季上映，令观众在秋季身沐爱情的春光。</p><p>刘青云汤唯现场打鸟枪 汤唯为刘青云送惊喜</p><p>在介绍影片角色时，汤唯称月荣是有传奇色彩的一个女子，刘青云则表示道龙是一个身份复杂的警察。影帝影后首次搭档，汤唯用圆梦来形容。“一拿到剧本就非常喜欢，开机之后没想到竟然是青云，非常开心。”刘青云力赞汤唯演戏真实，“汤唯是演戏很真实，把自己投入进去的演员，目标很精准，把自己全部放在电影里”，刘青云如此形容汤唯。</p><p>第一次看到预告片的汤唯现场落泪，她表示月荣和道龙的爱情是现代人无法体会的浪漫，两人为此上山下海，跨越时间和空间，两人的忠诚和信任让她非常羡慕。影片当中，月荣和道龙的定情信物是一支枪，汤唯称由枪感受到道龙的帅和男性魅力。现场两人再现打鸟枪画面。发布会上，汤唯为刘青云送上惊喜，特别带来戏中的道具酒壶，杀青时剧组将酒壶和烟斗赠送给两人留作纪念，原本选到酒壶的刘青云，因汤唯看中而割爱。</p><p>黄觉扮演的裁缝周师傅则是上演单恋，为月荣痴痴守候。当初接到角色邀约时，导演向他介绍是刘青云情敌，黄觉称十分高兴，而听说女主角是汤唯时，他更迅速答应出演。现场他吐槽自己被骗，“分明就是一备胎。”现场黄觉坦言想为汤唯量身，还不忘为自己辩白，“青云哥之前还吃醋，旗袍怎么量的那么合身，我真没量过，我是用<a href="http://m.so.com/s?q=%E7%88%B1%E9%87%8F&amp;src=newstranscode" class="qkw">爱量</a>的。”在即将量身的一刹那，刘青云突然登台，“我就是来看看”，下台前还不忘放狠话，“有什么问题我会上来的。”谈到量身的感觉，黄觉称很兴奋很高兴，“我在戏里都没碰到她，圆了一个梦想。”</p><p>秦海璐井柏然演绎旷世虐恋 现场欢乐互动金句频出</p><p>另一对恋人仇肖玲和收买华由秦海璐和井柏然出演，此次演绎反差极大的姐弟恋，井柏然直言在当时的年代很前卫。自称收买破旧的井柏然，表示在这个过程中，收买到了半辈子当中最珍贵的仇大姐。被问及为何看上收买华，秦海璐称被他的才华所打动，“虽然外表是收破烂，但实际是地下党，经常说有哲理的话，让我看到了春光。”井柏然补充说，“虽然我是收破烂的，但很有魅力。”谈到片中如何演绎深刻的爱情，井柏然开玩笑道，“其实是秦海璐比较有经验”， 秦海璐还戏言片中上演的是“平民爱情”。</p><p>片中，两人感情因鸡蛋升华，秦海璐再度力赞收买华，“仇大姐对他特别爱慕，因为他连挑鸡蛋都要告诉你，什么样的鸡蛋比较好，很博学。”井柏然则表示，“仇大姐可以满足所有男人的欲望”，他还肯定秦海璐不仅演出来了，自己还很满足。另外，井柏然颠覆造型在预告片中<a href="http://m.so.com/s?q=%E6%83%8A%E9%B8%BF%E4%B8%80%E7%8E%B0&amp;src=newstranscode" class="qkw">惊鸿一现</a>，令人大跌眼镜之余，对他在片中的全新形象和演绎更加期待。</p><p>优良制作宏大投资 《三城记》谱写旷世恋传奇</p><p>电影《三城记》取材自真实的故事，因<a href="http://m.so.com/s?q=%E3%80%8A%E7%8E%BB%E7%92%83%E4%B9%8B%E5%9F%8E%E3%80%8B&amp;src=newstranscode" class="qkw">《玻璃之城》</a>、《岁月神偷》等备受好评、获奖无数的香港金牌搭档再度合作，张婉婷导演，罗启锐监制，两位共同创作剧本，影帝刘青云和影后汤唯首度携手，金马影后秦海璐、作品井喷的井柏然和魅力型男黄觉等倾情加盟，讲述在战火纷飞的背景之下，几位主人公辗转于安徽、上海和香港三个城市之间，用生命追逐爱情，上演一段浪漫的乱世爱情故事，成为一段传奇。监制兼编剧罗启锐称自己亦投入到故事当中，他直言主人公在乱世当中迎难而上的奋斗和等待，是非常难得。</p><p>据导演张婉婷介绍，《三城记》剧本早在十年前就已完成，但因投资问题暂时搁置。因《岁月神偷》大获成功之后，不少投资方都来找两位拍摄续集，但导演张婉婷坚持拍摄《三城记》，还获得<a href="http://m.so.com/s?q=%E5%8D%8E%E8%B0%8A%E5%85%84%E5%BC%9F&amp;src=newstranscode" class="qkw">华谊兄弟</a>十倍于《岁月神偷》的投资，“其实这个故事把年代推到四五十年代，也是父母辈的集体回忆，钱比《岁月神偷》多十倍，当时就没人投资。”监制及编剧罗启锐对故事也相当投入，为这段<a href="http://m.so.com/s?q=%E7%AD%89%E5%BE%85%E7%9A%84%E7%88%B1%E6%83%85&amp;src=newstranscode" class="qkw">等待的爱情</a>所感动。影片坐拥两大影后和三大男神，说到演员阵容的选择，导演张婉婷表示当时没考虑颜值，“其实我觉得他们蛮配的，他们都是演技派，演出来非常真实，我自己看到现场都觉得火花，被感动到他们哭我在旁边一起哭。我觉得自己太幸福了。”</p><p>影片筹备历时三年，由美术大师<a href="http://m.so.com/s?q=%E5%8F%B6%E9%94%A6%E6%B7%BB&amp;src=newstranscode" class="qkw">叶锦添</a>设计场景及造型，精心雕琢三十多个场景，令这段旷世恋情在战火中更显浪漫。《三城记》能够顺利完成拍摄，<a href="http://m.so.com/s?q=%E6%96%BD%E5%8D%97%E7%94%9F&amp;src=newstranscode" class="qkw">施南生</a>亦功不可没，王中磊介绍剧本是由施南生推荐。虽然投资宏大，但因导演的金字招牌和对爱情片的喜爱，再加上对施南生的信任，影片最终华谊总裁王中磊力挺，他还亲自致电秦海璐邀请出演。</p><p>首款预告曝定档秋季 王中磊:希望深秋感受到春光和美好</p><p>影片首款预告片于会上曝光，画面中可见两人月下共舞的浪漫一面，但更可见生离死别。刘青云饰演的道龙和汤唯饰演的月荣因战乱失散，在滚滚人流当中，刘青云一句“我等你”的高呼呐喊，敲碎观众玻璃心，让人为这段<a href="http://m.so.com/s?q=%E5%9D%8E%E5%9D%B7%E7%9A%84%E6%81%8B%E6%83%85&amp;src=newstranscode" class="qkw">坎坷的恋情</a>动容心碎。虽然生存不易，但两人却都坚定地寻找对方。首支预告更带出许多悬念，其中，刘青云的身份是影片一大谜题，他几次遭遇暗杀，连父亲都惊心呐喊“你到底干的是什么差事!”。</p><p>除遭遇战乱分离和生命威胁外，两人的爱情还遭到金燕玲饰演的月荣母亲的反对。预告片最后，两人定情一吻戛然而止，定格在即将吻上的画面，究竟有情人能否终成眷属，曲折的过程成为故事最大的悬念。</p><p>预告片最后透露，该片将会在秋季上映。正如宣传语“你在深秋，给我春光”，华谊总裁王中磊表示，拍摄《三城记》是非常值得的事情，他还希望观众在深秋感受到爱情的春光和美好，“深秋有这样一个温暖的电影，让你怀念，虽然会掉眼泪，但看完出去的时候会觉得生活非常美好。”</p><p><img src="http://p35.qhimg.com/t0122d7d15dc072c54d.jpg?size=600x380"></p><p>导演张婉婷和监制罗启锐，携刘青云、汤唯、秦海璐、井柏然和黄觉五位主演全阵容亮相。</p><p><img src="http://p35.qhimg.com/t018c61980351250753.jpg?size=600x380"></p><p class="img-title">秦海璐、井柏然</p><p><img src="http://p34.qhimg.com/t0147ccfa721c00c403.jpg?size=600x380"></p><p><img src="http://p35.qhimg.com/t01e62d4bea1a627bb7.jpg?size=600x380"></p><p><img src="http://p33.qhimg.com/t01218917c7648b8417.jpg?size=600x380"></p><p><img src="http://p33.qhimg.com/t011e93f9ae27518256.jpg?size=600x380"></p><p><img src="http://p32.qhimg.com/t0183b1cf8a19e0eeb2.jpg?size=600x380"></p><p class="img-title">秦海璐</p><p><img src="http://p31.qhimg.com/t010c8bab4cdd9af9c7.jpg?size=600x380"></p><p class="img-title">井柏然</p><p><img src="http://p35.qhimg.com/t014c6c9e2a3bb23da7.jpg?size=600x380"></p><p class="img-title">黄觉</p><p><img src="http://p32.qhimg.com/t011f93b3606ecdcbf7.jpg?size=600x380"></p><p class="img-title">汤唯</p><p><img src="http://p34.qhimg.com/t0193d113b172ae3b51.jpg?size=600x380"></p><p class="img-title">汤唯、刘青云</p><p><img src="http://p32.qhimg.com/t01573fcda28ac82178.jpg?size=600x380"></p><p><img src="http://p32.qhimg.com/t0164e9158580c1d5bb.jpg?size=600x380"></p><p><img src="http://p31.qhimg.com/t01d899a6e5996f1904.jpg?size=600x380"></p><p><img src="http://p34.qhimg.com/t01c59a1e6464e1cb04.jpg?size=600x380"></p><p><img src="http://p33.qhimg.com/t017f29e09c2c7612ab.jpg?size=600x380"></p><p class="img-title">黄觉、汤唯</p><p><img src="http://p34.qhimg.com/t016ae309bd98f5e1fc.jpg?size=600x380"></p><p class="img-title">合影</p><p><img src="http://p33.qhimg.com/t015334093cd6624223.jpg?size=600x380"></p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://ent.ifeng.com/a/20150528/42412720_0.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='12fac15bf2fedf2cf2974346712198a2'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>旷世绝恋</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%97%B7%E4%B8%96%E7%BB%9D%E6%81%8B&amp;pn=1&amp;pos=7&amp;m=60fe33953228a98e73601e6957ac33cc49ca076c&amp;u=http%3A%2F%2Fent.ifeng.com%2Fa%2F20150528%2F42412720_0.shtml" data-pos="1"> 刘青云汤唯《三城记》演绎<b>旷世绝恋</b> 现打鸟枪定情画面(图) </a>   <li> <a href="/transcode?q=%E6%97%B7%E4%B8%96%E7%BB%9D%E6%81%8B&amp;pn=1&amp;pos=8&amp;m=4094a57fd187c343b810aff0cf57d974683368fa&amp;u=http%3A%2F%2Fpic.yule.sohu.com%2F911476%2Fgroup-660858.shtml" data-pos="2"> 三城记 缔造乱世美学 刘青云汤唯演绎<b>旷世绝恋</b> </a>   <li> <a href="/transcode?q=%E6%97%B7%E4%B8%96%E7%BB%9D%E6%81%8B&amp;pn=1&amp;pos=9&amp;m=89da923b1aa952c530bffddb58ddcbf2ad948742&amp;u=http%3A%2F%2Fculture.gmw.cn%2Fnewspaper%2F2015-06%2F08%2Fcontent_107137608.htm" data-pos="3"> 《三城记》表现<b>旷世绝恋</b> 汤唯不惧危险直面爆破 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '刘青云汤唯《三城记》演绎旷世绝恋 现打鸟枪定情画面(图)' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '刘青云汤唯《三城记》演绎旷世绝恋 现打鸟枪定情画面(图)'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";