s:18780:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>嘉和一品换股上市路恐难复制 同行业“壳”稀缺- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">嘉和一品换股上市路恐难复制 同行业“壳”稀缺</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2015-03-17 15:32:39</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t01f2882bb843e75966.jpg?size=300x193"></p><p>北京商报记者独家获悉，在经历多轮融资、IPO未果后，北京<a href="http://m.so.com/s?q=%E5%98%89%E5%92%8C%E4%B8%80%E5%93%81&amp;src=newstranscode" class="qkw">嘉和一品</a>企业管理股份有限公司(以下简称“嘉和一品”)与<a href="http://m.so.com/s?q=%E8%A5%BF%E5%AE%89%E9%A5%AE%E9%A3%9F&amp;src=newstranscode" class="qkw">西安饮食</a>(000721)达成换股协议，西安饮食正在筹划非公开发行股份收购嘉和一品100%股权。在餐企上市困难、IPO频频被终止的情况下，嘉和一品与西安饮食换股并购、曲线上市的方式能否为餐企上市打开一条新捷径成为了业内关注的焦点。但换股并购的高风险性以及业务的高协同性，也为其他餐企模仿嘉和一品与西安饮食模式埋下了风险。</p><p>换股并购为“<a href="http://m.so.com/s?q=%E5%80%9F%E8%88%B9%E4%B8%8A%E5%B8%82&amp;src=newstranscode" class="qkw">借船上市</a>”</p><p>今年1月初就宣布因重大事项停牌的西安饮食近日发布公告:公司正在筹划非公开发行股份收购北京嘉和一品企业管理股份有限公司100%股权事项。对此，西安饮食相关负责人表示，“目前正在做资产审计、评估等工作，收购价格等更多细节还不知道”。</p><p>不过，嘉和一品董事长刘京京在接受北京商报记者独家专访时，首度就与西安饮食合作一事做出说明，“不是卖身，是双方换股”。刘京京表示，按照双方计划，嘉和一品和西安饮食的合作采取的是换股方式，即嘉和一品以100%股权换取西安饮食相应的股份，双方相互持股。也就是说，西安饮食将成为嘉和一品的大股东，刘京京也将成为西安饮食的主要股东之一。“如果合作成功，我还是担任嘉和一品的总经理，公司还是由我们的团队进行管理。”刘京京称。一位连锁餐企老板指出，如果嘉和一品与西安饮食换股成功，应该是餐饮<a href="http://m.so.com/s?q=%E7%95%8C%E9%A6%96&amp;src=newstranscode" class="qkw">界首</a>个成功案例。对于这次换股并购，上述老板表示，民营餐企嘉和一品是“借船上市”，上市公司西安饮食则是正餐、<a href="http://m.so.com/s?q=%E5%BF%AB%E9%A4%90&amp;src=newstranscode" class="qkw">快餐</a>多业态发展，双方各取所需。这的确算是另辟蹊径的一条上市道路。</p><p class="header">投资人急于套现为诱因</p><p>不过，对于嘉和一品与西安饮食换股并购，也有业内人士直言，用100%的股权跟对方换股，连经营主体都变了，根本不能算曲线上市，实际就是把企业卖了，而且得到的还不是现金而是股份，要等到适当的时候才能套现。上述业内人士说:“持有上市公司股份，并不代表你就是上市公司。就像你买了某只上市公司的股票，可上市公司的经营与你有什么关系?”</p><p>但刘京京并不这样认为，“对我来说，换股并不代表失去这家企业，而是让嘉和一品更好地发展”。刘京京表示，只要利于企业长远发展，不一定都要家族传承。今后，企业间的竞合应该是个常态。</p><p>有知情人士透露，嘉和一品选择被上市公司并购也是无奈之举。嘉和一品此前引入了两轮投资，首轮融资至今已经满五年了，此前申报IPO又无果，上市遥遥无期。选择被并购也是为投资方退出寻找一条出路，此前<a href="http://m.so.com/s?q=%E4%BF%8F%E6%B1%9F%E5%8D%97&amp;src=newstranscode" class="qkw">俏江南</a>、小天鹅都曾面临类似局面。</p><p>为了争取上市，嘉和一品的运营完全比照上市公司的要求，非常规范，因此与其他企业相比其运用成本也大大增加。上述知情人士打出一个比喻，“就像在同一块足球场上，有的人赤膊上阵有的人则带着枷锁踢球”。如果上市成功，可以从资本市场募集资金，当然会有利于企业发展。但如果没上市，还按照上市公司那样规范运营，经营压力就会很大。</p><p>亦有分析人士指出，西安饮食亟待优质资产注入也是此番双方能够顺利合作的原因之一。作为A股3家餐饮上市公司之一的西安饮食，从2012年起业绩逐年下滑，2014年报虽未公布，但根据业绩预告，全年营业收入继续下降，净利润仅为900万-1340万元，下降幅度为9.43%-39.17%。</p><p class="header">“嘉和之路”难以复制</p><p>显然，在众多餐饮企业中，并非只有嘉和一品陷入投资人急于套现的尴尬。餐企上市公司中，也并非只有西安饮食处于业绩下滑的窘境。然而，嘉和一品与西安饮食换股并购的模式能否被餐饮界复制以便令更多企业实现共生共赢成为业界关注的问题。</p><p>有投行人士指出，换股并购很适合餐饮企业。首先，目前上市餐企业绩普遍不好，经营压力大。而换股并购避免了短期内支付大量现金，从而减轻财务压力，并且在一定程度上减轻了收购风险;同时，换股并购使得收购不受并购规模的限制。现金收购通常有“以大吃小”的特征，而换股并购可以在一定程度上摆脱并购中资金规模的限制，甚至达到“以小吃大”的奇效。</p><p>不过，其同时表示，换股并购相对于现金并购要花费更多的时间周期和费用。此外，换股并购尤其是增资换股必然会对原有公司控制权产生稀释，从而引起控股股东的控制权缩小。尽管如此，但目前餐饮业内普遍认为，嘉和一品与西安饮食换股并购，的确为企业上市寻找到了一条捷径，但不具备广泛的可复制性。</p><p>一位不愿透露姓名的餐企老总表示，换股具备操作简单的优点，换股双方可以各取所需、力争双赢。但是双方在主营业务上应当具备高度的相似性。</p><p>虽然西安饮食在西安没有批量的快餐业，但这几年快餐业绩都是不错的，市场需求很大。与快餐企业的密切合作，对西安饮食在<a href="http://m.so.com/s?q=%E8%A5%BF%E5%8C%97%E5%9C%B0%E5%8C%BA&amp;src=newstranscode" class="qkw">西北地区</a>快餐领域加快发展步伐有很大启示。同时，并购对嘉和一品的快餐走出北京特别是在西北地区发展提供了机会。并且，嘉和一品的中央厨房在餐饮界是数一数二的规模，这对于西安饮食集团集中采购、集中加工都有帮助。上述餐企老总指出，嘉和一品与西安饮食虽有差异，但主业处于同一业态，方向一致，换股之后，双方都不会“变味”，很有可能实现各自的目标。</p><p>然而，反观目前A股市场，上市的餐饮企业寥寥。换言之，可换的“壳”资源十分稀缺，而跨行业的换股具有相当的难度。餐饮企业之所以上市难，关键在于当前的政策环境不支持，尤其是税收体系不规范。正规餐企都希望守法经营，可采购青菜就是没有发票，没办法进行税项抵扣。因此，从政策层面就不支持餐企上市。餐饮企业上市道路的通畅，更多还在于政策面的理解和松绑。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://union.china.com.cn/kx/txt/2015-03/17/content_7754499.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='8f720c32fe3969a31aa0ae97f969aad6'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>嘉和一品</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%98%89%E5%92%8C%E4%B8%80%E5%93%81&amp;pn=1&amp;pos=5&amp;m=362f8dd9d3cba5fc3a48a2dcf218168632212f58&amp;u=http%3A%2F%2Fmoney.163.com%2F15%2F0306%2F05%2FAK0I4D5P00253B0H.html" data-pos="1"> IPO遇挫 <b>嘉和一品</b>欲卖身 </a>   <li> <a href="/transcode?q=%E5%98%89%E5%92%8C%E4%B8%80%E5%93%81&amp;pn=1&amp;pos=6&amp;m=21c2a30faf85458e14576ed77aacaf31c33ba5a3&amp;u=http%3A%2F%2Fbusiness.sohu.com%2F20150304%2Fn409357290.shtml" data-pos="2"> 西安饮食拟购<b>嘉和一品</b> 缘何来京"喝粥"? </a>   <li> <a href="/transcode?q=%E5%98%89%E5%92%8C%E4%B8%80%E5%93%81&amp;pn=1&amp;pos=7&amp;m=bd0dad26da4e9007eb1329d47cbbcd7a20237d15&amp;u=http%3A%2F%2Fpolitics.caijing.com.cn%2F20151202%2F4022982.shtml" data-pos="3"> <b>嘉和一品</b>并购遭弃 闹剧背后有隐情 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '嘉和一品换股上市路恐难复制 同行业“壳”稀缺' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '嘉和一品换股上市路恐难复制 同行业“壳”稀缺'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";