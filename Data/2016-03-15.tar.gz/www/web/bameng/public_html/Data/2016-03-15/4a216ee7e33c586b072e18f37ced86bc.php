s:18788:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>艺术品拍卖市场回暖尚需时日- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">艺术品拍卖市场回暖尚需时日</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2015-06-11 09:38:40</time></p> </header>  <div id="news-body"><p><img src="http://p34.qhimg.com/t012f48c6c389132cd7.jpg?size=400x270"></p><p>宋代画<a href="http://m.so.com/s?q=%E3%80%8A%E5%AE%8B%E4%BA%BA%E6%91%B9%E9%83%AD%E5%BF%A0%E6%81%95%E5%9B%9B%E7%8C%8E%E9%AA%91%E5%9B%BE%E3%80%8B&amp;src=newstranscode" class="qkw">《宋人摹郭忠恕四猎骑图》</a></p><p>“冰火两重天”，北京拍卖行业协会会长甘学军用这个词来形容两个市场--一边是火得一塌糊涂的股市，一边是冷清到谷底的<a href="http://m.so.com/s?q=%E8%89%BA%E6%9C%AF%E5%93%81%E6%8B%8D%E5%8D%96&amp;src=newstranscode" class="qkw">艺术品拍卖</a>。据了解，不少去年春拍“战绩”还不错的拍卖行，今年都选择了歇拍，包括北京传是国际拍卖、北京艺融国际拍卖、北京<a href="http://m.so.com/s?q=%E9%93%B6%E5%BA%A7%E5%9B%BD%E9%99%85&amp;src=newstranscode" class="qkw">银座国际</a>拍卖等京城拍场有名的拍行。对此，业内专家认为，艺术品拍卖行业将迎来一场最大的洗牌。</p><p class="header">当代书画面临崩盘?</p><p>北京苏富比春拍日前落槌，近90件拍品最终以4048万元成交。此次春拍为北京苏富比将当代书画和油雕板块合并为“现当代中国艺术”之后的第二场拍卖会，但或因当代书画板块正处于市场“风口”，导致本场拍卖会这两个板块在成交率方面形成两极分化。</p><p>油雕板块中，苏富比在征集难的市场大环境之下，仍有<a href="http://m.so.com/s?q=%E8%B5%B5%E6%97%A0%E6%9E%81&amp;src=newstranscode" class="qkw">赵无极</a>大尺幅作品撑场，且从市场一线艺术家作品到年轻艺术家作品均能呈系列呈现，近1/4拍品超过最高估价落槌。在策略上，除了赵无极的《15.2.93》属于千万元级别拍品，其余全部为中低价位拍品。百万元以下拍品以小尺幅风景作品和年轻艺术家作品为主，估价和成交额低，但悉数成交。当代书画板块中，虽然以“艺术消费”为策略，选择了市场一线艺术家的平价作品，但包括<a href="http://m.so.com/s?q=%E7%8E%8B%E6%98%8E%E6%98%8E&amp;src=newstranscode" class="qkw">王明明</a>、冯远、史国良、<a href="http://m.so.com/s?q=%E8%B4%BE%E5%8F%88%E7%A6%8F&amp;src=newstranscode" class="qkw">贾又福</a>、田黎明、江宏伟等在内的艺术家作品全部流拍，新推出的艺术家作品也多遭遇流拍，或以低估价落槌。</p><p>以油雕板块雄厚征集和销售实力示人的苏富比即使在市场低谷期也常能化险为夷，至少能保证较高的成交率来稳定市场。但同样以想求成交率来稳定市场的书画板块却没能让苏富比如愿。从现场来看，竞投当代书画部分的买家数量明显减少，委托也少有竞投。对此，一些业内人士认为，这意味着当代书画的“崩盘说”在苏富比这场拍卖中首先得到印证。</p><p class="header">高估价拍品成交仍有压力</p><p>6月6日晚，备受关注的<a href="http://m.so.com/s?q=%E3%80%8A%E5%AE%8B%E4%BA%BA%E4%B8%B4%E6%91%B9%E9%83%AD%E5%BF%A0%E6%81%95%E5%9B%9B%E7%8C%8E%E9%AA%91%E5%9B%BE%E3%80%8B&amp;src=newstranscode" class="qkw">《宋人临摹郭忠恕四猎骑图》</a>和两件南宋告身作品最终以1.29亿元的价格在北京匡时成交。在当晚的夜拍中，包括古代书画、近现代书画和历代书法专场在内的110余件的拍品，在经过了长达6个小时的拍卖之后，最终取得了5.65亿元的成交总额，三个专场的平均成交率超过80%，尤其高价位拍品成交率达100%。</p><p>然而北京匡时董事长<a href="http://m.so.com/s?q=%E8%91%A3%E5%9B%BD%E5%BC%BA&amp;src=newstranscode" class="qkw">董国强</a>坦言，在高估价拍品成交中可以看到市场还是有压力，“比如业内公认的宋画《宋人临摹郭忠恕四猎骑图》成交价是8050万元，低于我的预期价格。”董国强表示，两件南宋告身作品因为首次出现在拍卖市场，拍卖前一直以估价待询的方式出现，他没有办法提前预判这两件作品的价格，但他直言，最终的成交价也低于自己预期。“通场看下来，买家出价的时候比较谨慎，都是有经验的买家，大部分的价格不离谱，尤其是在高价位出现的时候，特别谨慎，每一口都会考虑很久。”</p><p>董国强认为，从现场的买家、竞拍、成交来看，市场并没有改变前期调整的状况，但从成交来对比，因为上一年秋拍的成交不好，今年春拍大家都在不同程度地努力，所以今年春拍整体成绩比去年好。“并不是说市场已经走出调整的状况，市场的回暖还是需要时间。”他表示。</p><p>亿元拍品难<a href="http://m.so.com/s?q=%E6%95%91%E5%B8%82&amp;src=newstranscode" class="qkw">救市</a></p><p>在不久前结束的中国嘉德春拍上，<a href="http://m.so.com/s?q=%E6%BD%98%E5%A4%A9%E5%AF%BF&amp;src=newstranscode" class="qkw">潘天寿</a>的《鹰石山花图》以2.79亿元创潘天寿画作拍卖价格纪录;紧接着，<a href="http://m.so.com/s?q=%E6%9D%8E%E5%8F%AF%E6%9F%93&amp;src=newstranscode" class="qkw">李可染</a>革命圣地山水巨制<a href="http://m.so.com/s?q=%E3%80%8A%E4%BA%95%E5%86%88%E5%B1%B1%E3%80%8B&amp;src=newstranscode" class="qkw">《井冈山》</a>同样表现出彩，以1.265亿元成交。然而，亿元拍品的出现并不代表艺术品拍卖市场走出困境。</p><p>中国<a href="http://m.so.com/s?q=%E5%98%89%E5%BE%B7&amp;src=newstranscode" class="qkw">嘉德</a>董事总裁兼CEO胡妍妍表示，亿元作品的成交，是印证艺术品市场珍稀优质资源恒久高价的定律，而“整体成交率略有下降，反映出市场调整期大资金锁定精品的同时，对普通拍品需求减弱。”业内普遍认为，珍稀拍品的高价易主并不能看出市场的走势。</p><p>值得注意的还有另外一件亿元拍品--此前估价逾10亿元的齐白石<a href="http://m.so.com/s?q=%E3%80%8A%E5%B1%B1%E6%B0%B4%E5%8D%81%E4%BA%8C%E6%9D%A1%E5%B1%8F%E3%80%8B&amp;src=newstranscode" class="qkw">《山水十二条屏》</a>由于未能找寻到合适的竞买人，最终止步拍场门外。创作于1925年的这组画作，每一屏高180厘米，宽47厘米，形制划齐规一，是目前民间唯一可流通，且尺幅最大的齐白石山水作品。据了解，由于其估价惊人，<a href="http://m.so.com/s?q=%E4%BF%9D%E5%88%A9&amp;src=newstranscode" class="qkw">保利</a>拍卖最初的打算是一边展览一边寻找合适买家私洽。虽然无缘此次春拍，但保利拍卖回应称，由于这套画作委托方已与保利拍卖签订了为期一年的租借协议，如果这期间有藏家愿意竞买，这套拍品还可能现身今年保利秋拍。</p><p>统计显示，近5个月来在北京新注册<a href="http://m.so.com/s?q=%E6%8B%8D%E5%8D%96%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">拍卖公司</a>的数量比往年明显下降，相比2014年同期，今年北京取消或延迟春拍的艺术品拍卖公司占总量的50%以上。对于未来走势，业内人士纷纷表示，今年的艺术品市场应该已处在谷底，但市场能否回暖，还要看当前机构和资本的运行能否拉动市场底层的信心。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://finance.china.com.cn/money/collection/yjjj/20150611/3172790.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='b331c8f3d69c2cd75d241bae22c7d77f'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>艺术品拍卖</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%89%BA%E6%9C%AF%E5%93%81%E6%8B%8D%E5%8D%96&amp;pn=1&amp;pos=7&amp;m=65b2837e561a304b2b3da6342d1dc89858504757&amp;u=http%3A%2F%2Fnews.sina.com.cn%2Fo%2F2016-03-09%2Fdoc-ifxqhfvp0643961.shtml" data-pos="1"> 中国<b>艺术品</b>金融市场呈现蓝海,艺条龙联合荣宝斋(上海)<b>拍卖</b>共同发力 </a>   <li> <a href="/transcode?q=%E8%89%BA%E6%9C%AF%E5%93%81%E6%8B%8D%E5%8D%96&amp;pn=1&amp;pos=8&amp;m=5f288dc05fc7ff2f61be31dbf3fa3f730f960456&amp;u=http%3A%2F%2Fwww.ctsbw.com%2Farticle-4015.html" data-pos="2"> 在线<b>艺术品拍卖</b>服务平台『掌拍艺术』获3000元Pre-A轮融资 </a>   <li> <a href="/transcode?q=%E8%89%BA%E6%9C%AF%E5%93%81%E6%8B%8D%E5%8D%96&amp;pn=1&amp;pos=9&amp;m=6a7167deb243a7a4cf3cec20ec70736bdfd0783d&amp;u=http%3A%2F%2Fwww.ce.cn%2Fculture%2Fgd%2F201603%2F15%2Ft20160315_9495791.shtml" data-pos="3"> 《<b>艺术品</b>经营管理办法》将实施:谁在受益? </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '艺术品拍卖市场回暖尚需时日' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '艺术品拍卖市场回暖尚需时日'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";