s:16765:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>香港商报:节日“过载” 我们究竟为了什么过节?- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">香港商报:节日“过载” 我们究竟为了什么过节?</h1> <p id="source-and-time"><span id=source>新浪</span><time id=time>2016-02-15 10:10:14</time></p> </header>  <div id="news-body"><p><img src="http://p34.qhimg.com/t011c4b23fab028ed89.jpg?size=550x355"></p><p>2月14日，情人节，济南一土豪花800元委托花店轧制了一束人民币“钱花”，这束花由20张五元、19张十元、35张二十元、40张五十元和40张100元组成共计6990元整，“钱花”的主人表示为了用崭新的人民币扎花他跑了十余家银行才换齐了钱。</p><p>视频:情人节的尴尬:玫瑰价高难配送  来源:<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E6%96%B0%E9%97%BB%E7%BD%91&amp;src=newstranscode" class="qkw">中国新闻网</a></p><p>中新网2月15日电 农历春节引发的全民欢庆热潮还没有过去，另一个节日又迅速的成为舆论热烈讨论的焦点，那就是2月14日的<a href="http://m.so.com/s?q=%E6%83%85%E4%BA%BA%E8%8A%82&amp;src=newstranscode" class="qkw">情人节</a>。对此，香港商报15日刊文称，尽管并不像香港一般有着浓厚的中西文化底蕴，内地民众过情人节也并不是什么稀罕事。但是，恰恰是这种没有文化底蕴的节日，令这些节日的面目显得十分可疑。从某种程度上说，我们正在面临一个节日“过载”的时代。</p><p>当我走在街头，看到象征着传统春节的大红灯笼、福字、春联与象征<a href="http://m.so.com/s?q=%E6%83%85%E4%BA%BA%E8%8A%82%E7%9A%84%E7%8E%AB%E7%91%B0&amp;src=newstranscode" class="qkw">情人节的玫瑰</a>花、巧克力、蝴蝶结交相辉映的时候，我不由得产生一个疑问:我们究竟为了什么过节?</p><p class="header">商业意味笼罩“佳节”</p><p>一个没有人可以否认的趋势是，中国人现在要过的节日是越来越多了:从“土产”的春节、<a href="http://m.so.com/s?q=%E5%85%83%E5%AE%B5%E8%8A%82&amp;src=newstranscode" class="qkw">元宵节</a>、清明节、中秋节，到西方的新年、情人节、<a href="http://m.so.com/s?q=%E6%84%9A%E4%BA%BA%E8%8A%82&amp;src=newstranscode" class="qkw">愚人节</a>、母亲节、圣诞节，再到近些年自创的“光棍节”、双十二乃至各种各样的“地球拯救日”，尤其随着中西文化的进一步交流和国人对传统文化的进一步发掘，一些曾经不受重视的节日也越来越受到国人的欢迎，如<a href="http://m.so.com/s?q=%E6%84%9F%E6%81%A9%E8%8A%82&amp;src=newstranscode" class="qkw">感恩节</a>、重阳节、七夕节等。从某种程度上说，我们正在面临一个节日“过载”的时代。</p><p>这样的“过载”，最大的推动者无疑是商业资本。现如今，对节日最为重要的推广人，无疑就是我们每日接触的各类商家了--每当一个节日来临之前，铺天盖地的广告和无处不在的商业预告都在提醒着我们:该过节了。那我们又应该如何过节呢?当然是“买买买”--春节买年货，情人节买玫瑰、<a href="http://m.so.com/s?q=%E7%AB%AF%E5%8D%88%E8%8A%82&amp;src=newstranscode" class="qkw">端午节</a>买粽子、中秋节买月饼、<a href="http://m.so.com/s?q=%E5%9C%A3%E8%AF%9E%E8%8A%82&amp;src=newstranscode" class="qkw">圣诞节</a>买礼物，甚至于一些我们并不真正需要的东西，都可以藉助节日的名号而显得正当及合理。</p><p>反倒是，节日真正的内涵和意义是什么，已经少有人关心和在乎了--圣瓦伦丁的典故、鞭炮驱<a href="http://m.so.com/s?q=%E5%B9%B4%E7%9A%84%E4%BC%A0%E8%AF%B4&amp;src=newstranscode" class="qkw">年的传说</a>、“五月花号”的历史，都远不及刷卡时的刺激和快递拆封时的兴奋。</p><p class="header">年味变淡不改过节期盼</p><p>如果说资本逐利的驱动是节日泛滥的主谋，那么我们自身也无法逃脱“同谋者”的嫌疑。首先，节日是特殊的日子，每一个节日都意味着对日常生活节奏的打破;其次，节日的特殊性亦令我们拥有了给予自身“特殊性”对待的理由。</p><p>对与已经深深的陷入程序化和重复性劳作的现代人来说，节日的上述特性无疑具有极大的诱惑力:通过节日，我们不仅可以通过休假、游玩等活动来舒缓平日里高压、重复的生活压力，亦给予了我们足够的借口和理由来奖励自己，体会平日里高度自制的生活中难以体验的美好享受。我们需要节日，远胜<a href="http://m.so.com/s?q=%E8%BF%87%E8%8A%82%E6%97%A5&amp;src=newstranscode" class="qkw">过节日</a>需要我们--这也是为何我们过越来越多的节日，甚至于不惜创造一个又一个理由牵强的“人造节日”来。</p><p>只不过这样的“过节”，就像是吸毒上瘾的瘾君子一样，只能够用越来越大的剂量来缓解，却永远无法依靠自身的力量来戒除;而每一次节日的体验，都像是效用不断递减的“最后一支烟”，令我们感叹作用不再的同时却又开始期待下一支的来临。</p><p>正如同近些年的春节，我们总会感叹“过年越来越没劲”、“年味变淡”、“春晚愈发难看”，但我们却并不会期待没有春节的日子，反而，在每一次离家的前一刻，在每一次归家的路上，在节后第一个工作日里，我们总会难掩小小的失落。毕竟，我们始终身处这座艰难的围城，无法逃脱。(流深)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.sina.com.cn/o/2016-02-15/doc-ifxpmpqr4394754.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='2f7eff0f39acb28cb1caaaf966674bd1'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>香港商报</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%A6%99%E6%B8%AF%E5%95%86%E6%8A%A5&amp;pn=1&amp;pos=7&amp;m=ed670954a9eac14977d57b933b32d50e4b8c19a2&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fkuaixun_0219%2F4180251.html" data-pos="1"> <b>香港商报</b>:沙特低价油策略难挤出页岩油商 </a>   <li> <a href="/transcode?q=%E9%A6%99%E6%B8%AF%E5%95%86%E6%8A%A5&amp;pn=1&amp;pos=8&amp;m=e01918fe99bfb2bd84d19a95224c84dd919998ef&amp;u=http%3A%2F%2Fintl.ce.cn%2Fsjjj%2Fqy%2F201602%2F18%2Ft20160218_8930463.shtml" data-pos="2"> <b>香港商报</b>:微信"嫁祸银行",能否如愿? </a>   <li> <a href="/transcode?q=%E9%A6%99%E6%B8%AF%E5%95%86%E6%8A%A5&amp;pn=1&amp;pos=9&amp;m=53a7bc2fbf77ebdc58d99229f20853907f0360be&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Fworld%2F2016-02%2F16%2Fc_128723355.htm" data-pos="3"> <b>香港商报</b>:春节投资效应正当时 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '香港商报:节日“过载” 我们究竟为了什么过节?' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '香港商报:节日“过载” 我们究竟为了什么过节?'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";