s:15486:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>周迅演清宫剧《如懿传》 喊话孙俪:请你多关照- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">周迅演清宫剧《如懿传》 喊话孙俪:请你多关照</h1> <p id="source-and-time"><span id=source>中国日报网</span><time id=time>2016-03-15 07:35:00</time></p> </header>  <div id="news-body"><p>[摘要]<a href="http://m.so.com/s?q=%E3%80%8A%E5%90%8E%E5%AE%AB%C2%B7%E5%A6%82%E6%87%BF%E4%BC%A0%E3%80%8B&amp;src=newstranscode" class="qkw">《后宫·如懿传》</a>为《后宫·甄嬛传》原著作者<a href="http://m.so.com/s?q=%E6%B5%81%E6%BD%8B%E7%B4%AB&amp;src=newstranscode" class="qkw">流潋紫</a>潜心五年、延续清宫叙事的又一力作。主要讲述了<a href="http://m.so.com/s?q=%E9%9B%8D%E6%AD%A3&amp;src=newstranscode" class="qkw">雍正</a>驾崩、干隆即位后，<a href="http://m.so.com/s?q=%E7%94%84%E5%AC%9B&amp;src=newstranscode" class="qkw">甄嬛</a>的儿媳如懿在干隆后宫中经历的波澜诡谲、<a href="http://m.so.com/s?q=%E7%88%B1%E6%81%A8%E4%BA%BA%E7%94%9F&amp;src=newstranscode" class="qkw">爱恨人生</a>。</p><p><img src="http://p32.qhimg.com/t012e8f48bca8dc3548.jpg?size=538x800"></p><p class="img-title">周迅</p><p>腾讯娱乐讯 昨日(3月14日)<a href="http://m.so.com/s?q=%E7%99%BD%E8%89%B2%E6%83%85%E4%BA%BA%E8%8A%82&amp;src=newstranscode" class="qkw">白色情人节</a>，周迅作为某品牌代言人一身白色精致短裙配干练短发亮相。事后采访环节，最受媒体关注的就是因为《后宫·如懿传》<a href="http://m.so.com/s?q=%E5%91%A8%E8%BF%85&amp;src=newstranscode" class="qkw">周迅</a>成为“最贵电视剧女演员”?《后宫·如懿传》是<a href="http://m.so.com/s?q=%E3%80%8A%E5%90%8E%E5%AE%AB%C2%B7%E7%94%84%E5%AC%9B%E4%BC%A0%E3%80%8B&amp;src=newstranscode" class="qkw">《后宫·甄嬛传》</a>的姐妹篇怕不怕与<a href="http://m.so.com/s?q=%E5%AD%99%E4%BF%AA&amp;src=newstranscode" class="qkw">孙俪</a>比较?还有就是什么时候让自己从“人妻”升级为“人母”?</p><p class="header">最贵电视剧女主?</p><p>周迅:<a href="http://m.so.com/s?q=%E5%A6%82%E6%87%BF%E4%BC%A0&amp;src=newstranscode" class="qkw">如懿传</a>卖多少钱跟我也没关系!</p><p>由周迅担任主角的《后宫·如懿传》一直备受关注，该剧上星卫视首播平台确定为江苏卫视和<a href="http://m.so.com/s?q=%E4%B8%9C%E6%96%B9%E5%8D%AB%E8%A7%86&amp;src=newstranscode" class="qkw">东方卫视</a>两家，预计明年播出。据传，该剧分别以单集300万元的价码卖给两家卫视，并以单集900万元将网络独播权卖给某视频网站，如真是这样，该剧即成为国内首部单集售价突破1500万元的电视剧。周迅也将成为“最贵电视剧女主角”。</p><p>更有业内人士分析，如果以片长90集算，该剧总售价将达13.5亿元。再加上二、三轮和海外版权售卖，这部剧的最终销售额会超过15亿元。对于此事，周迅表示完全不知情，“这还是听官方消息吧，你们让我说我也不知道，卖多少钱跟我其实也没什么关系……”至于“<a href="http://m.so.com/s?q=%E6%9C%80%E8%B4%B5%E7%94%B5%E8%A7%86%E5%89%A7%E5%A5%B3%E6%BC%94%E5%91%98&amp;src=newstranscode" class="qkw">最贵电视剧女演员</a>”周迅更是一副蒙圈脸:“我不知道，我不知道，我真的不知道”，重要事情讲三遍。</p><p class="header">如懿周迅与甄嬛孙俪比较哪家强?</p><p class="header">周迅:有跟孙俪交流，请她多多关照!</p><p>《后宫·如懿传》为《后宫·甄嬛传》原著作者流潋紫潜心五年、延续清宫叙事的又一力作。主要讲述了雍正驾崩、干隆即位后，甄嬛的儿媳如懿在干隆后宫中经历的波澜诡谲、爱恨人生。此次的编剧工作亦由作者流潋紫亲自担纲。该剧女主角如懿由周迅出演，也是她首次出演清宫戏。</p><p>然而，周迅所饰演的如懿难免会被大家拿来跟孙俪所饰演的甄嬛做比较，周迅直言有很多不一样的地方，“因为<a href="http://m.so.com/s?q=%E7%94%84%E5%AC%9B%E4%BC%A0&amp;src=newstranscode" class="qkw">甄嬛传</a>我也看了，孙俪也跟我说她很期待如懿传，我就跟她说‘那还得请你多关照呀’”。据悉，《后宫·如懿传》将于2016年8月开机，拍摄为期半年，预计将于2017年登陆卫视。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://cnews.chinadaily.com.cn/2016-03/15/content_23866206.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='b836a4ba0e893501f3c204264401050e'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>周迅</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%91%A8%E8%BF%85&amp;pn=1&amp;pos=4&amp;m=2a43da863ecdfe3fb3517973897402dddff17fc8&amp;u=http%3A%2F%2Fcnews.chinadaily.com.cn%2F2016-03%2F15%2Fcontent_23868875.htm" data-pos="1"> 范冰冰<b>周迅</b>张柏芝最销魂瞬间 女神柔情瞬间盘点 </a>   <li> <a href="/transcode?q=%E5%91%A8%E8%BF%85&amp;pn=1&amp;pos=5&amp;m=d10b35fd0789b1e83b58ca7d34f8a45db0ff76ca&amp;u=http%3A%2F%2Fd.youth.cn%2Fshrgch%2F201603%2Ft20160315_7744555.htm" data-pos="2"> <b>周迅</b>白色短裙配短发俏丽 </a>   <li> <a href="/transcode?q=%E5%91%A8%E8%BF%85&amp;pn=1&amp;pos=6&amp;m=b13c19b990cc0263649df12cc01e5b3237f60b59&amp;u=http%3A%2F%2Fcnews.chinadaily.com.cn%2F2016-03%2F15%2Fcontent_23866660.htm" data-pos="3"> 组图:<b>周迅</b>代言被夸肌肤似婴儿 现场直呼脸红 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '周迅演清宫剧《如懿传》 喊话孙俪:请你多关照' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '周迅演清宫剧《如懿传》 喊话孙俪:请你多关照'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";