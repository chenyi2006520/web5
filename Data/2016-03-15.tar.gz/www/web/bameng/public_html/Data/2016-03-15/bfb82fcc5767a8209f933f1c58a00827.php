s:16765:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>知己知彼百战不殆《战斗吧剑灵》七大职业介绍- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">知己知彼百战不殆《战斗吧剑灵》七大职业介绍</h1> <p id="source-and-time"><span id=source>口袋巴士</span><time id=time>2016-03-03 13:45:00</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E3%80%8A%E6%88%98%E6%96%97%E5%90%A7%E5%89%91%E7%81%B5%E3%80%8B&amp;src=newstranscode" class="qkw">《战斗吧剑灵》</a>中目前共有7个职业，除了端游中已有的力士、剑士、<a href="http://m.so.com/s?q=%E6%8B%B3%E5%B8%88&amp;src=newstranscode" class="qkw">拳师</a>、刺客、气功师、召唤师之外，手游中还加入了枪手这一独特的职业。今天小白就为大家做一个职业汇总介绍吧，看看你最适合哪个职业?</p><p>剑士:全能小王子 超高物理输出 &gt;&gt;剑士职业详解</p><p>《战斗吧剑灵》剑士职业是剑的驾驭者，有着不俗的输出和控制，常用于QTE连击起手，通过实战华丽的剑术展开丰富多样的攻击，令敌人胆战心惊。剑士在游戏中能担任坦克、输出、控制的位置，承担部分伤害并限制对方前排角色，非常全面。</p><p>需要补充的是，剑士职业的武器为单手剑，物理输出为主。剑士的技能可单独输出，可群体攻击，比如内测版本大热的英雄飞月就属于剑士。</p><p><img src="http://p31.qhimg.com/t019cb2a8f70ef5df45.jpg?size=500x281"></p><p>力士:坦克担当 靠谱的肉盾&gt;&gt;&gt;力士职业详解</p><p>《战斗吧剑灵》力士职业，用于承担伤害并给团队加防御<a href="http://m.so.com/s?q=BUFF&amp;src=newstranscode" class="qkw">BUFF</a>，经常放在中间用于吸引火力。这是以力破巧的职业，擅长使用巨斧;适合站在前排担任坦克的位置。力士可以吸收部分的伤害，甚至可以给全队增加各类防御BUFF。</p><p><img src="http://p32.qhimg.com/t019da4610da3e85c40.jpg?size=500x281"></p><p>气功师:团队输出型 恐怖范围输出&gt;&gt;&gt;气功师职业详解</p><p>《战斗吧剑灵》气功师职业有着恐怖的范围输出能力，类似于法师的职业，有控制有输出，技能多为高伤害范围AOE技能。但是，气功师自身非常脆弱，血量太低很容易被秒杀，需要对<a href="http://m.so.com/s?q=%E7%AB%99%E4%BD%8D&amp;src=newstranscode" class="qkw">站位</a>有着极其高的要求，属于后排英雄，法系输出。想要充分发挥气功师的价值，那就要把该职业的血量和防御好好撑起来。</p><p><img src="http://p34.qhimg.com/t013b051a6627f000c0.jpg?size=500x281"></p><p>拳师:可输出可坦克 高闪避高爆发&gt;&gt;&gt;拳师职业详解</p><p>《战斗吧剑灵》拳师职业拥有全职业中最高的闪避，可以在前排吸收对方大量的攻击;来回换下主坦克位置吸收伤害，配合奶妈的安全位置，回到后方补给血量。但相形见绌的是，拳师肉的程度不高，面对大量法系输出的时候会很吃亏。</p><p>拳师也有着很强的控制能力，可以在前排用于打断对方技能，属于前排英雄，气功输出。</p><p><img src="http://p34.qhimg.com/t01e54b4a5f89be5a63.jpg?size=500x281"></p><p>召唤师:奶妈辅助型 团队续航保障&gt;&gt;&gt;召唤师职业详解</p><p>召唤师职业，乃《战斗吧剑灵》中唯一的奶妈角色。可以有效提高团队的持续作战能力和整体属性。召唤师武器为法杖，可以增加恢复、气功攻击和暴击的能力;职业属于后排英雄，混合输出。</p><p>作为奶妈的通病，召唤师职业自身脆弱，需要好好调整该职业的站位，才能充分发挥职业特点，以此保证整个团队的续航输出。</p><p><img src="http://p31.qhimg.com/t017caaf908e21c517b.jpg?size=500x281"></p><p>刺客:攻守兼备型 最高暴击输出&gt;&gt;&gt;刺客职业详解</p><p>《战斗吧剑灵》刺客职业拥有全职业中最高的暴击能力，爆发伤害很高，用于起手秒杀对面的后排或者前排脆皮，也经常用于QTE的连击承接。值得一提的是，刺客的技能往往有减少对方内力的效果，可以防止敌方释放技能，可以说，刺客这个职业天生就是为了PVP而生的。</p><p>值得注意的是，刺客职业的血量比较少(与召唤师相比又略胜一筹)，需要玩家根据对面阵型调整站位。可作为前排英雄，也可放在后排输出，刺客以物理输出为主。</p><p><img src="http://p32.qhimg.com/t017875a543c2c7c397.jpg?size=500x281"></p><p>枪手:竞技型职业 高爆发高输出&gt;&gt;&gt;枪手职业详解</p><p>枪手职业，是《战斗吧剑灵》中专属的职业。该职业有着独特的降低对面内力的技能，同刺客一样，枪手也属于PVP中必带职业。控制力强，自身输出不凡，可以对敌方后排造成巨大的伤害和控制效果，往往能在一轮技能中造成成吨的伤害。枪手属于后排英雄，混合输出。</p><p>枪手的技能所需的内力往往比其他职业更少，所以枪手有更多的机会释放自己的技能，因此每个人上战场的第一件事，就是快速解决掉对方枪手，防止他们打出成吨的输出。</p><p><img src="http://p32.qhimg.com/t01bacaf19c62299f00.jpg?size=500x281"></p><p>《战斗吧剑灵》不删档测试即将强势来袭，力士、剑士、拳师、刺客、气功师、召唤师和枪手七大职业现已整装待发，找准最钟爱的职业开启一场属于你的剑灵之旅吧。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.ptbus.com/zdbjl/633724/">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='c11125144113631fda5c45dc8d9b931a'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>知己知彼百战不殆</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%9F%A5%E5%B7%B1%E7%9F%A5%E5%BD%BC%E7%99%BE%E6%88%98%E4%B8%8D%E6%AE%86&amp;pn=1&amp;pos=5&amp;m=a40af707efc48d70b08c7ab20ee9c0507bdeac9a&amp;u=http%3A%2F%2Fwww.ptbus.com%2Fqmfjdz%2F632474%2F" data-pos="1"> <b>知己知彼百战不殆</b> 最全敌机排序汇总一览 </a>   <li> <a href="/transcode?q=%E7%9F%A5%E5%B7%B1%E7%9F%A5%E5%BD%BC%E7%99%BE%E6%88%98%E4%B8%8D%E6%AE%86&amp;pn=1&amp;pos=6&amp;m=9f88e274d0fc24ae1c212c90a5c7d147be65cbc0&amp;u=http%3A%2F%2Fkitchen.ea3w.com%2F150%2F1504755.html" data-pos="2"> <b>知己知彼百战不殆</b>!美的安全王大数据分析 </a>   <li> <a href="/transcode?q=%E7%9F%A5%E5%B7%B1%E7%9F%A5%E5%BD%BC%E7%99%BE%E6%88%98%E4%B8%8D%E6%AE%86&amp;pn=1&amp;pos=7&amp;m=e8b899ea552e43c918020cb300299aa915951d60&amp;u=http%3A%2F%2Fwww.ptbus.com%2Fboombeach%2F631690%2F" data-pos="3"> 海岛奇兵2月29日哈莫曼图透 <b>知己知彼百战不殆</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '知己知彼百战不殆《战斗吧剑灵》七大职业介绍' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '知己知彼百战不殆《战斗吧剑灵》七大职业介绍'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";