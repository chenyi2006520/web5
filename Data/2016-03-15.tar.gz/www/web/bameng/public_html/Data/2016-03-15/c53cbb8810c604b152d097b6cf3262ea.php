s:18561:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>《破风》打响暑期电影校园宣传第一枪 林超贤自爆演员屁股上的“破风疤” - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">《破风》打响暑期电影校园宣传第一枪 林超贤自爆演员屁股上的“破风疤” </h1> <p id="source-and-time"><span id=source>国际在线</span><time id=time>2015-05-19 09:38:39</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t019828411f2d271103.jpg?size=550x366"></p><p><a href="http://m.so.com/s?q=%E9%99%88%E5%AE%B6%E4%B9%90&amp;src=newstranscode" class="qkw">陈家乐</a>领队骑行</p><p>由<a href="http://m.so.com/s?q=%E6%9E%97%E8%B6%85%E8%B4%A4&amp;src=newstranscode" class="qkw">林超贤</a>执导、梁凤英监制，<a href="http://m.so.com/s?q=%E5%BD%AD%E4%BA%8E%E6%99%8F&amp;src=newstranscode" class="qkw">彭于晏</a>、窦骁、崔始源、<a href="http://m.so.com/s?q=%E7%8E%8B%E7%8F%9E%E4%B8%B9&amp;src=newstranscode" class="qkw">王珞丹</a>、陈家乐、欧阳娜娜、<a href="http://m.so.com/s?q=%E8%BF%9E%E5%87%AF&amp;src=newstranscode" class="qkw">连凯</a>等主演的青春热血电影<a href="http://m.so.com/s?q=%E3%80%8A%E7%A0%B4%E9%A3%8E%E3%80%8B&amp;src=newstranscode" class="qkw">《破风》</a>将于今年暑期上映。5月16日-5月23日，导演林超贤携主演陈家乐等人开启了全国8城 《破风》“骑行进校园”活动，率先拉开暑期档电影校园宣传大旗，与高校学子近距离接触，畅谈电影《破风》与那些青春时燃起的<a href="http://m.so.com/s?q=%E7%83%AD%E8%A1%80%E6%A2%A6%E6%83%B3&amp;src=newstranscode" class="qkw">热血梦想</a>。</p><p>林超贤校园率队“破风”骑行最拉风 “看脚下才能走得更远”</p><p>近日，导演林超贤携主演陈家乐先后骑行走进<a href="http://m.so.com/s?q=%E6%B2%B3%E5%8C%97%E5%B7%A5%E4%B8%9A%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">河北工业大学</a>、东北大学、山东大学等高校。他浑身散发着年轻人的热血和活力，率队“破风”骑行，还信心满满地要与一众年轻的校园<a href="http://m.so.com/s?q=%E9%AA%91%E6%89%8B&amp;src=newstranscode" class="qkw">骑手</a>切磋车技，比拼速度与激情。一路惊起不少路人的尖叫声、加油声，俨然成为学校里一道最拉风、最热血的风景。众学子与导演聊电影、谈骑行，瞬间成为“骑友”，争相合影留念。</p><p>当同学们问《破风》是不是跟《激战》一样时，导演表示“《激战》是勉励中年人的故事，这次拍摄《破风》我要鼓励年轻人。《破风》更倾向于青春成长，在人生路上走时，如何面对挫败，愈挫愈勇。其中的热血梦想、兄弟情与爱情都是正<a href="http://m.so.com/s?q=%E5%A4%84%E9%9D%92%E6%98%A5&amp;src=newstranscode" class="qkw">处青春</a>启程阶段大学生的情感写照。这次<a href="http://m.so.com/s?q=%E6%95%85%E4%BA%8B%E4%BC%9A&amp;src=newstranscode" class="qkw">故事会</a>更加好!”这种面对青春热血洋溢的态度，恰好符合正要迈出校园走向各自人生的年轻人。而当同学问起离开校园后梦想与现实的平衡问题时，他说:“梦想的实现要脚踏实地，就像骑车不要看远，要看自己脚下，这样才能走得更远。”</p><p>林超贤自曝演员们的“<a href="http://m.so.com/s?q=%E7%A0%B4%E9%A3%8E%E7%96%A4&amp;src=newstranscode" class="qkw">破风疤</a>” “陈家乐代表了破风精神”</p><p>此次《破风》8城校园骑行活动，导演林超贤不仅亲率主创陈家乐与大学生组成“破风车队”展开<a href="http://m.so.com/s?q=%E7%9B%9B%E5%A4%8F&amp;src=newstranscode" class="qkw">盛夏</a>骑行，更为万千学子带来电影《破风》30分钟纪录片。谈到其中拍摄的艰辛时，林超贤坦言“这部电影大家付出了很多努力，参与拍摄的演员几乎都有受伤，每个人都摔得很精彩，每个人的屁股都留下了属于《破风》的伤疤。”</p><p>谈及拍摄受伤，学生们将焦点转向第一天拍摄就导致<a href="http://m.so.com/s?q=%E9%94%81%E9%AA%A8%E9%AA%A8%E6%8A%98&amp;src=newstranscode" class="qkw">锁骨骨折</a>的演员陈家乐，导演林超贤打趣道“不会吧?我第一天拍就有人受伤?”引得全场大笑，随后林超贤表示“陈家乐代表了破风精神。对他个人来说摔倒是好事，这让更多人知道他，大家都知道他是一个很敬业的演员，以后会有很多大片找他。”同时，导演仍不忘提醒在场的年轻人们“人生中有很多摔倒，不一定是坏事，要勇敢面对。”</p><p>林超贤不爱“魔鬼”导演称号 大赞彭于晏年轻肯拼</p><p>不管是与林超贤合作过<a href="http://m.so.com/s?q=%E3%80%8A%E8%AF%81%E4%BA%BA%E3%80%8B&amp;src=newstranscode" class="qkw">《证人》</a>的周杰伦，《魔警》中的吴彦祖，还是《破风》中的彭于晏、<a href="http://m.so.com/s?q=%E7%AA%A6%E9%AA%81&amp;src=newstranscode" class="qkw">窦骁</a>、崔始源、陈家乐等人都称导演是“魔鬼”导演，他为求影片完美，会“榨干”演员的每一分精力。当被问及这个称号的感受时，他说:“我不爱魔鬼导演，很多人会怕，现在工作人员都怕我，可能会阻止人家找我拍戏，我只是想拍完美好看的电影给观众看。”其实，林超贤私下里是一个很<a href="http://m.so.com/s?q=%E6%B8%A9%E9%9B%85&amp;src=newstranscode" class="qkw">温雅</a>和善的人，只是一拍戏就“不疯狂不成魔”。</p><p>校园见面会现场，同学们热火朝天地向导演打探彭于晏等演员戏里的角色和表现，林超贤表示，他们饰演的单车赛车手都像你们一样青春热血，满怀梦想，渴望成功。导演还盛赞“彭于晏年轻肯拼，如今这个社会，像他一样年轻又肯为事业付出、拼搏的演员不多见了，单车赛不像武打戏，基本上演员要自己骑，一骑就骑几公里，他们真的都付出了很多。比如拍冲线可能要连着拍好多条冲线的戏，这是很费体能的。连专业队看了都惊了，觉得从来没有那么的费劲，拍戏比比赛难多了。”导演还爆料，刚开始选王珞丹演戏里唯一的女赛车手时，还担心她太瘦演不了，但整个戏拍下来，她都做得很好。</p><p><img src="http://p31.qhimg.com/t0157099367a3e5d127.jpg?size=550x825"></p><p class="img-title">陈家乐与学生们交流</p><p><img src="http://p31.qhimg.com/t01e065ef22f3edfe8b.jpg?size=550x366"></p><p class="img-title">林超贤、陈家乐领队骑行</p><p><img src="http://p31.qhimg.com/t01010350444d91deed.jpg?size=550x366"></p><p class="img-title">林超贤、陈家乐骑行合影</p><p><img src="http://p35.qhimg.com/t01f2c9d87d39420392.jpg?size=550x366"></p><p class="img-title">林超贤、陈家乐谈拍摄过程</p><p><img src="http://p33.qhimg.com/t010548517c01daa65c.jpg?size=550x366"></p><p class="img-title">林超贤、陈家乐与学生们交流</p><p><img src="http://p33.qhimg.com/t016fcfeaa37e9c6968.jpg?size=550x366"></p><p class="img-title">林超贤领队合影</p><p><img src="http://p32.qhimg.com/t012c31d1eeb17cc28f.jpg?size=550x366"></p><p class="img-title">林超贤领队骑行</p><p><img src="http://p34.qhimg.com/t01385d3289ffa7b6ca.jpg?size=550x366"></p><p>破风文化衫</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://gb.cri.cn/27224/2015/05/19/1042s4967044.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='ad62addee376fbd52128adfb4571d3e5'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>林超贤</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9E%97%E8%B6%85%E8%B4%A4&amp;pn=1&amp;pos=4&amp;m=174473394819d7cb826a1959f47a55b54bee8547&amp;u=http%3A%2F%2Fnews.youth.cn%2Fyl%2F201505%2Ft20150519_6649833.htm" data-pos="1"> 《破风》复旦造势<b>林超贤</b>:再不热血我就老了 </a>   <li> <a href="/transcode?q=%E6%9E%97%E8%B6%85%E8%B4%A4&amp;pn=1&amp;pos=5&amp;m=6f5eeacea96b4ff1b5e6ee42477516700d8dca83&amp;u=http%3A%2F%2Fnews.youth.cn%2Fgn%2F201506%2Ft20150606_6722385.htm" data-pos="2"> 彭于晏:身材不如<b>林超贤</b> </a>   <li> <a href="/transcode?q=%E6%9E%97%E8%B6%85%E8%B4%A4&amp;pn=1&amp;pos=6&amp;m=43c1d68e4adcd5dfc3536ae4ac62bf20be8037e7&amp;u=http%3A%2F%2Fent.163.com%2F14%2F0820%2F23%2FA44K4HJK00032KMI.html" data-pos="3"> <b>林超贤</b>《破风》香港热拍 窦骁获外号"大仆街王" </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '《破风》打响暑期电影校园宣传第一枪 林超贤自爆演员屁股上的“破风疤” ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '《破风》打响暑期电影校园宣传第一枪 林超贤自爆演员屁股上的“破风疤” '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";