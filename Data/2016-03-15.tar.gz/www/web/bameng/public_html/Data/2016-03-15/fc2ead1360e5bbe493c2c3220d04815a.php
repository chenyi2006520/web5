s:18068:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>明治醇壹牛乳 提高品质的ESL制造工艺探访之旅- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">明治醇壹牛乳 提高品质的ESL制造工艺探访之旅</h1> <p id="source-and-time"><span id=source>国际在线</span><time id=time>2015-05-25 11:16:49</time></p> </header>  <div id="news-body"><p>5月21日(周四)，日本大型<a href="http://m.so.com/s?q=%E9%A3%9F%E5%93%81%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">食品公司</a>-株式会社明治(以下简称明治，董事长:<a href="http://m.so.com/s?q=%E5%B7%9D%E6%9D%91%E5%92%8C%E5%A4%AB&amp;src=newstranscode" class="qkw">川村和夫</a>)在中国的独资公司「明治乳业(苏州)有限公司」邀请专家、媒体以及关注健康的营养达人走进生产工厂，亲自见证国际先进的「ESL制造工艺」以及广受好评的明治商品的诞生过程。本次探访之旅展现了真实的明治，以及企业追求点滴品质安全孜孜不倦的努力。</p><p><img src="http://p35.qhimg.com/t0143891e006b963fd2.jpg?size=380x248"></p><p>明治创业以来，在日本已经累积了90年以上的乳制品行业经验。为让中国消费者能够品尝到明治高品质、安全、美味的乳制品，明治在苏州建立了占地3.5万平方米的工厂，成功引进日本成熟的制造、品质管理、研究开发等技术经验，并于2013年12月开始零售型乳制品的生产和销售，从而为<a href="http://m.so.com/s?q=%E9%95%BF%E6%B1%9F%E4%B8%89%E8%A7%92%E6%B4%B2&amp;src=newstranscode" class="qkw">长江三角洲</a>地区的顾客提供优质的低温牛奶、<a href="http://m.so.com/s?q=%E9%85%B8%E5%A5%B6&amp;src=newstranscode" class="qkw">酸奶</a>、稀奶油等商品。</p><p><img src="http://p34.qhimg.com/t013cf7056a703f7c10.jpg?size=430x198"></p><p>参观工厂期间，明治负责人就牛奶的生产过程、检测程序等内容为媒体和营养达人进行了详细讲解。「明治醇壹<a href="http://m.so.com/s?q=%E7%89%9B%E4%B9%B3&amp;src=newstranscode" class="qkw">牛乳</a>」采用100%优质生乳，符合明治独有的严格标准。生乳从牧场到工厂的运输中，明治全程使用保持低温的专业奶罐车，以确保生乳的品质和新鲜度。工厂接收生乳时，全面进行生乳风味、营养成分及是否有三聚氰胺混入等国家标准规定的各项检测，只使用检测合格的生乳。</p><p><img src="http://p33.qhimg.com/t01c159f37d444fb6a3.jpg?size=377x246"></p><p>牛奶是生鲜品，从出厂到顾客品尝产品，要经过配送过程。期间，温度上升、配送时间长短都会让风味产生变化、并存在变质的风险。据悉，为了降低风险，明治最终决定与日本极为严格的品质管理同步，采用「ESL制造工艺」(ESL:ExtendedShelfLife)。全新升级版「明治醇壹牛乳」已于2015年5月1日起在华东上海、苏州、杭州、宁波、<a href="http://m.so.com/s?q=%E6%97%A0%E9%94%A1&amp;src=newstranscode" class="qkw">无锡</a>、南京六地的超市、便利店、百货店新鲜销售。</p><p>工厂参观完成后，<a href="http://m.so.com/s?q=%E4%B8%8A%E6%B5%B7%E4%BA%A4%E9%80%9A%E5%A4%A7%E5%AD%A6%E5%8C%BB%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">上海交通大学医学院</a>营养系副主任、蔡美琴教授现场进行乳制品讲座，为参加者普及牛乳知识、解疑答惑。通过蔡教授的讲座，媒体和营养达人进一步加深了对明治「ESL制造工艺」的理解。</p><p><img src="http://p35.qhimg.com/t01b911f1ddcb713308.jpg?size=384x245"></p><p>蔡教授介绍说，「ESL制造工艺」是从生乳验收到牛乳灌装到产品包装的各个环节中，提高设备的清洁性和机器的杀菌性，彻底防止二次污染的制造方法。采用「ESL制造工艺」，能更有效地减少牛奶中残存的细菌数，更大限度地抑制牛奶中细菌的繁殖，从而提高了牛奶的品质和安全性，在相同的保存条件下(规定的冷藏温度等)，成功延长了商品保质期。由于「ESL制造工艺」具有高安全性，所以目前被国外很多乳制品生产企业所采用。</p><p>当被问及不同工艺处理过的牛奶在营养上是否有差异时，蔡教授指出，不同加工工艺的牛奶，在人体从中所摄取的最主要的营养物质--蛋白质、钙、维生素A?B2的吸收及健康功效上是没有差异的，「ESL制造工艺」牛奶和巴氏杀菌乳健康功效相当。</p><p>讲座最后，蔡教授总结“牛奶采用「ESL制造工艺」，在安全、安心的基础上最大限度保留生乳的营养与风味，牛奶香浓感更强，保质期更久，品质更高。商品在严格的卫生管理和品质管理下制造，实现安全安心零添加。”</p><p>关于「ESL制造工艺」，除蔡教授介绍的内容外，还包括使用特殊构造的包装盒。「明治醇壹牛乳」使用了可减少牛奶渗透到包材断面的反折边加工包材，并在灌装机内杀菌，以此维持产品的新鲜度，抑制变质。</p><p><img src="http://p34.qhimg.com/t01b62f290df1ab9d95.jpg?size=379x248"></p><p>明治专注于品质管理，在“传播[美味、快乐、健康、安心]的世界、为充实顾客每一天的生活做贡献”的集团理念下，通过发售安全安心的低温牛奶和酸奶，向消费者提供追求健康和美味的新价值，充实中国消费者的生活，并为推动中国乳制品行业发展做出贡献。</p><p>【明治醇壹牛乳(<a href="http://m.so.com/s?q=950ml&amp;src=newstranscode" class="qkw">950ml</a>/450ml/<a href="http://m.so.com/s?q=200ml&amp;src=newstranscode" class="qkw">200ml</a>) 商品概要】</p><p><img src="http://p35.qhimg.com/t01711c787b79fb314a.jpg?size=363x225"></p><p>【 950ml 】 【 <a href="http://m.so.com/s?q=450ml&amp;src=newstranscode" class="qkw">450ml</a> 】 【 200ml 】</p><p class="header">1.商品特征</p><p>■100%使用对<a href="http://m.so.com/s?q=%E4%B9%B3%E7%89%9B&amp;src=newstranscode" class="qkw">乳牛</a>的饲养管理(健康状态、饲养环境、饲料的营养配比等)技术水平高、所生产的生乳保持高品质(挤奶器的卫生、生乳的营养成分和卫生质量)的牧场所采购的生乳。</p><p>■在工厂严格的品质管理下，采用ESL(Extended Shelf Life)制造工艺，提高从生乳的验收、灌装到牛奶包装制造流程中各个环节的机器清洗和机器杀菌水平，彻底防止二次污染和提高产品品质。</p><p>■包装正面上部标示此次的变更点「用ESL制造工艺提高了产品品质」</p><p>■包装正面右上方标示奶香和浓郁感更强的宣传词「香浓升级」</p><p>■采用ESL制造工艺，使保质期延长至15日(冷藏 未开封状态)。</p><p class="header">2.主要销售区域</p><p class="header">上海、苏州、杭州、宁波、无锡、南京</p><p class="header">3.主要销售渠道</p><p>超市、便利店、百货店等零售店</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://gb.cri.cn/44571/2015/05/25/7872s4973753.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='ef3d0f8b8e8caecaf0b668ad86f12e63'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>牛乳</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%89%9B%E4%B9%B3&amp;pn=1&amp;pos=5&amp;m=4ec20db1f7e39055ec33cdd686f8f55b239a1311&amp;u=http%3A%2F%2Fgb.cri.cn%2F44571%2F2015%2F04%2F27%2F7872s4944363.htm" data-pos="1"> 「明治醇壹<b>牛乳</b>」全新升级 ESL制造工艺 牛奶安心更美味 </a>   <li> <a href="/transcode?q=%E7%89%9B%E4%B9%B3&amp;pn=1&amp;pos=6&amp;m=c65d52450c137e3b8343eb338669021e34992326&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0826%2F01%2FA4HNIS6400014AED.html" data-pos="2"> 巧克力还是<b>牛乳</b>糖你的月饼和谁最配 </a>   <li> <a href="/transcode?q=%E7%89%9B%E4%B9%B3&amp;pn=1&amp;pos=7&amp;m=ddd2debc41a373ae023881590f176e9e9dfff237&amp;u=http%3A%2F%2Ftw.haiwainet.cn%2Fn%2F2014%2F0327%2Fc345686-20463051.html" data-pos="3"> 放纵美食欲望 品尝台疯木瓜<b>牛乳</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '明治醇壹牛乳 提高品质的ESL制造工艺探访之旅' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '明治醇壹牛乳 提高品质的ESL制造工艺探访之旅'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";