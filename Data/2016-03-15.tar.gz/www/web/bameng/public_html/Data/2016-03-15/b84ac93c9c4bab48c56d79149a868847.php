s:17619:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>这些地方你可能没听过，却美过九寨沟(一)- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">这些地方你可能没听过，却美过九寨沟(一)</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-13 18:51:52</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E4%B9%9D%E5%AF%A8%E6%B2%9F&amp;src=newstranscode" class="qkw">九寨沟</a>、黄龙、郎木寺已经名声显赫，而那些鲜为人知的偏远之地，却更值得我们去探访。</p><p>今天小喵就给你介绍几个冷门到令人心疼却美到令人心醉的景点。</p><p><a href="http://m.so.com/s?q=%E7%89%9F%E5%B0%BC%E6%B2%9F&amp;src=newstranscode" class="qkw">牟尼沟</a></p><p class="header">________________</p><p class="header">探秘如九寨沟般的秘境</p><p><img src="http://p32.qhimg.com/t01f5eaad2e9f1ad99c.jpg?size=640x400"></p><p><img src="http://p33.qhimg.com/t0109226aa625e37136.jpg?size=640x400"></p><p>牟尼沟虽然不如九寨沟和<a href="http://m.so.com/s?q=%E9%BB%84%E9%BE%99&amp;src=newstranscode" class="qkw">黄龙</a>那样出名，但因为兼具了黄龙的钙化彩池和九寨沟的森林湖泊，再加上巨型的瀑布，赋予了这里比九寨沟更独特的魅力。最难得的是牟尼沟还有大部分未被开发，即使开发的景区内，游客也较少，所以少了旅游团的喧嚣，可以独享这片净土。</p><p><img src="http://p35.qhimg.com/t017dda476740ced5dc.jpg?size=640x400"></p><p><img src="http://p31.qhimg.com/t01b8eae528e8a2575b.jpg?size=640x400"></p><p>牟尼沟已开发的两大景区--<a href="http://m.so.com/s?q=%E4%BA%8C%E9%81%93%E6%B5%B7&amp;src=newstranscode" class="qkw">二道海</a>和扎嘎瀑布仅一山之隔。二道海是牟尼沟末端的一条狭长山沟，长达5公里，沿途可以观赏大小不一的<a href="http://m.so.com/s?q=%E6%B5%B7%E5%AD%90&amp;src=newstranscode" class="qkw">海子</a>，有的深邃，有的透明，完全不亚于九寨沟的水。</p><p><img src="http://p35.qhimg.com/t01813d3fc2f791f495.jpg?size=640x400"></p><p><a href="http://m.so.com/s?q=%E6%89%8E%E5%98%8E%E7%80%91%E5%B8%83&amp;src=newstranscode" class="qkw">扎嘎瀑布</a>是中国最高的钙化瀑布，从瀑布顶端到谷底层层叠叠的瀑布长度超过2公里，一条曲折的栈道<a href="http://m.so.com/s?q=%E9%A1%BA%E6%B5%81%E7%9B%B4%E4%B8%8B&amp;src=newstranscode" class="qkw">顺流直下</a>。</p><p><img src="http://p31.qhimg.com/t015b8a3814c264f702.jpg?size=640x400"></p><p class="img-title">推荐玩法:</p><p>从<a href="http://m.so.com/s?q=%E6%9D%BE%E6%BD%98&amp;src=newstranscode" class="qkw">松潘</a>开始骑马穿越牟尼沟那些未被开发的景区，一般为2天。骑在马背上翻越山谷，穿越森林，在海子旁边露营，尝尝马夫为你准备的山间野味。</p><p>地址:松潘县<a href="http://m.so.com/s?q=%E7%89%9F%E5%B0%BC%E4%B9%A1&amp;src=newstranscode" class="qkw">牟尼乡</a>(近2093县道)</p><p>到达方式:从松潘包车游览扎嘎瀑布和二道海景区，一天即可往返。</p><p class="header">金川梨花</p><p class="header">春季洁白如雪 深秋红艳似火</p><p><img src="http://p34.qhimg.com/t01c9ff82898303688a.jpg?size=640x400"></p><p><a href="http://m.so.com/s?q=%E9%87%91%E5%B7%9D%E5%8E%BF&amp;src=newstranscode" class="qkw">金川县</a>盛产雪梨，山坡上种满了雪梨树，每到春天3月，<a href="http://m.so.com/s?q=%E6%A2%A8%E8%8A%B1%E7%9B%9B%E5%BC%80&amp;src=newstranscode" class="qkw">梨花盛开</a>，这里便成为了梨花的海洋。展现在人们眼前的是雪域高原规模最大的梨花奇景。</p><p><img src="http://p33.qhimg.com/t0115afcd9b1551797c.jpg?size=640x400"></p><p><img src="http://p33.qhimg.com/t010819aba03343318e.jpg?size=640x400"></p><p>梨花的主要观赏点就在县城以北的一条梨花大道和大<a href="http://m.so.com/s?q=%E9%87%91%E5%B7%9D&amp;src=newstranscode" class="qkw">金川</a>河谷的沙耳乡一代。从高处可以拍摄到白色小花漫山遍野的全景。</p><p><img src="http://p35.qhimg.com/t01abfb40ab46fe0797.jpg?size=640x400"></p><p><img src="http://p31.qhimg.com/t012a391a53e97d7a53.jpg?size=640x400"></p><p>到了金秋时节，白色的梨花海洋蜕变成了绚丽的红色，百里红叶<a href="http://m.so.com/s?q=%E5%A8%87%E8%89%B3%E4%BC%BC%E7%81%AB&amp;src=newstranscode" class="qkw">娇艳似火</a>，恍若隔世。金川秋季最佳的观赏期从10月一直延续到11月中下旬，从最开始的色彩缤纷的彩林，到最后红彤彤的红叶，每一次到访都有不一样的景致。</p><p>地址:阿坝州西南部金川县，大金川河谷地带</p><p>到达方式:成都到金川的班车每天有3班，此外金川与壤塘、<a href="http://m.so.com/s?q=%E9%A9%AC%E5%B0%94%E5%BA%B7&amp;src=newstranscode" class="qkw">马尔康</a>、阿坝、小金、丹巴、汶川之间也有班车，都是早上7点到9点之间发车。</p><p class="header">年宝玉则</p><p class="header">沉醉在天神的后花园</p><p><img src="http://p34.qhimg.com/t012d2ee7a6fe2610db.jpg?size=640x400"></p><p><img src="http://p32.qhimg.com/t014bf83b6435cb069c.jpg?size=640x400"></p><p>年宝玉则位于青海与<a href="http://m.so.com/s?q=%E9%98%BF%E5%9D%9D&amp;src=newstranscode" class="qkw">阿坝</a>交界处，在青海的一半叫做年宝玉则，在四川的一半叫做莲宝叶则。虽然景区入口是在青海界内，但是从成都经阿坝班车前往更加方便。</p><p><img src="http://p32.qhimg.com/t01daa800c4bbcb9ee1.jpg?size=640x400"></p><p><img src="http://p32.qhimg.com/t0150d11c775a6439f4.jpg?size=640x400"></p><p>这里怪石嶙峋，奇峰高耸，年宝玉则的主峰由无数海拔在4000米以上的山峰组成，簇拥在一起，如同一朵圣洁美丽的雪莲花。景区内大大小小的海子不下300个，其中以神山脚下的<a href="http://m.so.com/s?q=%E4%BB%99%E5%A5%B3%E6%B9%96&amp;src=newstranscode" class="qkw">仙女湖</a>和妖女湖最为著名，一个蓝到深邃，大气雍容;一个清得见底，妩媚柔情。湖边碧绿的草甸上，是露营的最佳场地。特别是6-8月草原鲜花盛开的季节，美得醉人。</p><p><img src="http://p31.qhimg.com/t019deb52ba80573e2c.jpg?size=640x400"></p><p><img src="http://p33.qhimg.com/t011d8d7d1882bb031d.jpg?size=640x400"></p><p>如果不登山，你可能看不到雄伟连绵的雪山，不过，站在仙女湖变一眼望去，就足以令人怦然心动。户外玩家们特里来这里登山或穿越，而一般旅行者会选择转湖，只需一天的时间。</p><p>地址:青海省果洛藏族自治州<a href="http://m.so.com/s?q=%E4%B9%85%E6%B2%BB%E5%8E%BF&amp;src=newstranscode" class="qkw">久治县</a>索呼日麻乡境内</p><p>到达方式:从成都到达阿坝县，然后转乘阿坝到大武的班车，每天早晨6点一班，车票买到幸福桥，途中经过久治县城下车。</p><p>出发,遇见一程旅行,看见<a href="http://m.so.com/s?q=%E4%B8%80%E4%B8%AA%E4%BA%BA%E7%9A%84%E9%A3%8E%E6%99%AF&amp;src=newstranscode" class="qkw">一个人的风景</a>、打开地图,带上耳机,背包旅行,留下旅途的记忆</p><p>喜欢旅行的朋友加微信公众号:huanyou920(长按直接复制微信查找添加)</p><p>旅行,邂逅不一样的自己!每天为你分享旅行日记、留下旅途美好的记忆</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/article/4020943.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='0faf103fcdac2c13587b174724fea079'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>九寨沟</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '这些地方你可能没听过，却美过九寨沟(一)' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '这些地方你可能没听过，却美过九寨沟(一)'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";