s:17079:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>疯狂动物城"的启迪:中国动画缺了啥? 技术牛故事残- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">疯狂动物城"的启迪:中国动画缺了啥? 技术牛故事残</h1> <p id="source-and-time"><span id=source>光明网</span><time id=time>2016-03-14 17:56:00</time></p> </header>  <div id="news-body"><p>几乎所有看过<a href="http://m.so.com/s?q=%E3%80%8A%E7%96%AF%E7%8B%82%E5%8A%A8%E7%89%A9%E5%9F%8E%E3%80%8B&amp;src=newstranscode" class="qkw">《疯狂动物城》</a>的人对这部电影都给出了极高的评价。一部春季档上映的动画片，既没有大牌明星加持，也没有过多的前期宣传，然而却成了这个三月的票房和口碑上的双重赢家。面对这样的强势碾压，中国动画电影缺了什么?</p><p>普遍现状 技术牛故事残，基本放弃了成年人市场</p><p>其实说起来，中国本土动画特效制作简直堪称<a href="http://m.so.com/s?q=%E5%9B%BD%E5%AE%B6%E8%BD%AF%E5%AE%9E%E5%8A%9B&amp;src=newstranscode" class="qkw">国家软实力</a>代表。听起来不可置信?春节期间上映的<a href="http://m.so.com/s?q=%E3%80%8A%E5%8A%9F%E5%A4%AB%E7%86%8A%E7%8C%AB3%E3%80%8B&amp;src=newstranscode" class="qkw">《功夫熊猫3》</a>就是由梦工厂的中国分部--“东方梦工厂”制作的。《功夫熊猫3》还特地为汉语配音版重新建模了一版人物，以使得人物台词和口型能完美配合。</p><p>越来越多的好莱坞影片选择将特效制作这一块外包给中国的团队来做，在炫目的特效背后都是中国技术员们搬砖的心血。在动画制作方面，中国的技术堪称世界领先水平。好莱坞有<a href="http://m.so.com/s?q=%E3%80%8A%E5%8A%9F%E5%A4%AB%E7%86%8A%E7%8C%AB%E3%80%8B&amp;src=newstranscode" class="qkw">《功夫熊猫》</a>、《驯龙记》等大IP，做成系列动画。中国同样有自己的动画系列IP:<a href="http://m.so.com/s?q=%E3%80%8A%E5%96%9C%E7%BE%8A%E7%BE%8A%E3%80%8B&amp;src=newstranscode" class="qkw">《喜羊羊》</a>系列，《熊出没》系列，<a href="http://m.so.com/s?q=%E3%80%8A%E5%B7%B4%E6%8B%89%E6%8B%89%E5%B0%8F%E9%AD%94%E4%BB%99%E3%80%8B&amp;src=newstranscode" class="qkw">《巴拉拉小魔仙》</a>系列。然而这些影片的影响力和现象级程度跟《功夫熊猫》等<a href="http://m.so.com/s?q=%E5%A5%BD%E8%8E%B1%E5%9D%9E&amp;src=newstranscode" class="qkw">好莱坞</a>系列比起来，基本就是零。</p><p>《喜羊羊》系列，每年根据生肖出一部贺岁档大片，迄今为止已经出了整整七部。作为一部主打低龄向的2D动画片来说，喜羊羊系列是合格的。可是作为中国动画电影数一数二的大IP，喜羊羊系列的剧情着实就有点“怯”了。过于低龄化，剧情幼稚，人物性格单薄，这些致命伤让成年人连下载观看都嫌费流量，更别提走进电影院--陪孩子过年的爹妈除外。</p><p>当大家吐槽日本的<a href="http://m.so.com/s?q=%E3%80%8A%E5%A4%9A%E5%95%A6A%E6%A2%A6%E3%80%8B&amp;src=newstranscode" class="qkw">《多啦A梦》</a>、《火影忍者》都是卖情怀的动画电影时，中国的动画电影连情怀都没得卖，有句话必须要送给《喜羊羊》等大IP的制作团队:即使你们主打低幼向，也应该多花点心思在剧情上，好等这些孩子长大了依然能继续给他们卖情怀。</p><p>偶有亮点<a href="http://m.so.com/s?q=%E3%80%8A%E5%AE%9D%E8%8E%B2%E7%81%AF%E3%80%8B&amp;src=newstranscode" class="qkw">《宝莲灯》</a>《大圣归来》故事制作表现诚意</p><p>曾经中国的动画电影显然做得比现在好多了。这可不是什么“越旧越值钱”的心理作祟。早先的<a href="http://m.so.com/s?q=%E3%80%8A%E5%A4%A7%E9%97%B9%E5%A4%A9%E5%AE%AB%E3%80%8B&amp;src=newstranscode" class="qkw">《大闹天宫》</a>就是整整好几代人的童年经典。灵动的水墨画风，精良的制作，外加活灵活现的孙悟空的形象……当年这部电影在国外很是拿了一些奖项，着实给中国争了光。</p><p>1999年，同样是<a href="http://m.so.com/s?q=%E4%B8%8A%E6%B5%B7%E7%BE%8E%E6%9C%AF%E7%94%B5%E5%BD%B1%E5%88%B6%E7%89%87%E5%8E%82&amp;src=newstranscode" class="qkw">上海美术电影制片厂</a>制作的动画电影《宝莲灯》就算被称为中国动画电影迄今无法逾越的高峰都一点不为过。片头运用的2D和3D结合的技术在当时绝对是超一流水平，现在看来也并不显得“五毛钱特效”(<a href="http://m.so.com/s?q=%E5%B7%B4%E6%8B%89%E6%8B%89%E5%B0%8F%E9%AD%94%E4%BB%99&amp;src=newstranscode" class="qkw">巴拉拉小魔仙</a>什么的自己反省一下)。但讽刺的是，这部电影当年收到的最多的批评意见是:“模仿好莱坞的痕迹太重，夹杂歌曲太突兀，但是特效技术比好莱坞差太多了。 ”现在中国动画电影技术水平倒是上来了，可是动画作品大部分连《宝莲灯》的故事水平都赶不上了。</p><p>直到去年<a href="http://m.so.com/s?q=%E3%80%8A%E5%A4%A7%E5%9C%A3%E5%BD%92%E6%9D%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《大圣归来》</a>的成功，让人们看到了一丝希望。“论品质，《大圣归来》依然和好莱坞有着不小的差距，但是放眼中国动画影片里，已经是独一份的良心出品了。 ”《大圣归来》一个狂热的粉丝小雅在微博里写到。然而，这部现象化的动画电影，至今一部而已。</p><p>国产动画电影现在整体呈现出“好片不出头，烂片满地走”的形势背后是中国整体动漫产业的低迷。国内现在尚无一个行业标杆性的动画厂牌，动画导演、配音演员等更是长期处于“无名英雄”的境地。即使要做营销，卖点又从何而来呢?只能靠口碑口口相传。</p><p>据悉，2016年，仅立项的动画电影项目就有33部。如果这33部里有良心之作，希望它千万不要被埋没。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://tech.gmw.cn/2016-03/14/content_19287129.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='f47c6d5284dad721de95dd77e3693204'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>绝对疯狂</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%BB%9D%E5%AF%B9%E7%96%AF%E7%8B%82&amp;pn=1&amp;pos=4&amp;m=6445c1f2e3d49d633e94f9dbcd6bbb33b06331d4&amp;u=http%3A%2F%2Fnews.163.com%2F16%2F0314%2F08%2FBI3U0NSV00014Q4P.html" data-pos="1"> 《<b>疯狂</b>动物城》票房爆发式增长(图) </a>   <li> <a href="/transcode?q=%E7%BB%9D%E5%AF%B9%E7%96%AF%E7%8B%82&amp;pn=1&amp;pos=5&amp;m=662ce8aee360191a37d134b955f09577e4e1e2d5&amp;u=http%3A%2F%2Fauto.eastday.com%2Fauto%2F2012auto%2Fnode37551%2Fu1ai284791.html" data-pos="2"> 《<b>疯狂</b>动物城》里的汽车 </a>   <li> <a href="/transcode?q=%E7%BB%9D%E5%AF%B9%E7%96%AF%E7%8B%82&amp;pn=1&amp;pos=6&amp;m=9f3913ce3076125b85855fda4cf4f80ae920f51e&amp;u=http%3A%2F%2Fnews.youth.cn%2Fgn%2F201603%2Ft20160313_7738436.htm" data-pos="3"> 媒体调查深圳上海<b>疯狂</b>楼市:中央想法或被投资扭曲 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '疯狂动物城"的启迪:中国动画缺了啥? 技术牛故事残' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '疯狂动物城"的启迪:中国动画缺了啥? 技术牛故事残'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";