s:13831:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>2016贺岁杯再升级潘晓婷领衔出战四美女上阵- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">2016贺岁杯再升级潘晓婷领衔出战四美女上阵</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-12 01:04:08</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=MY147&amp;src=newstranscode" class="qkw">MY147</a>.com讯 又至岁末，中央电视台体育大戏“贺岁杯”再度来袭。近日记者从主办方处了解到，2016年的贺岁杯在阵容上有了升级，<a href="http://m.so.com/s?q=%E6%BD%98%E6%99%93%E5%A9%B7&amp;src=newstranscode" class="qkw">潘晓婷</a>、刘莎莎、欧斯纯和<a href="http://m.so.com/s?q=%E7%8F%8D%E5%A6%AE%E7%89%B9%C2%B7%E6%9D%8E&amp;src=newstranscode" class="qkw">珍妮特·李</a>将会在猴年的第一和第二天与大家见面。</p><p>贺岁杯可以算是<a href="http://m.so.com/s?q=%E5%A4%AE%E8%A7%86%E4%BD%93%E8%82%B2&amp;src=newstranscode" class="qkw">央视体育</a>的一项经典的“传统赛事”了。2013年，潘晓婷与韩国美女<a href="http://m.so.com/s?q=%E8%BD%A6%E4%BE%91%E8%93%9D&amp;src=newstranscode" class="qkw">车侑蓝</a>在演播大厅为观众奉献了一场精彩的表演，2014年，<a href="http://m.so.com/s?q=%E4%B9%9D%E7%90%83%E5%A4%A9%E5%90%8E&amp;src=newstranscode" class="qkw">九球天后</a>又与小魔女金佳映联手，2015年贺岁杯选手扩容至四人，潘晓婷、<a href="http://m.so.com/s?q=%E4%BB%98%E5%B0%8F%E8%8A%B3&amp;src=newstranscode" class="qkw">付小芳</a>、金佳映、车侑蓝组成的豪华阵容在节目中除了上演中韩对抗外，还分别奉献了热辣舞蹈、励志歌曲、魔术和钢琴演奏等才艺表演，让观众在<a href="http://m.so.com/s?q=%E6%96%B0%E6%98%A5%E4%BD%B3%E8%8A%82&amp;src=newstranscode" class="qkw">新春佳节</a>看到球员的另一面，大呼过瘾。</p><p>2016年的贺岁杯在选手选择上继续扩大“版图”，除潘晓婷、<a href="http://m.so.com/s?q=%E5%88%98%E8%8E%8E%E8%8E%8E&amp;src=newstranscode" class="qkw">刘莎莎</a>两位中国选手外，欧斯纯和“黑寡妇”珍妮特·李两位远道而来的大咖也将加入到节目中，届时四位美女将会携手登上央视舞台，并为大家带来精彩的表演。</p><p>2016年贺岁杯将会在2月8-9日(大年初一及初二)晚黄金时段的央视体育频道直播。(MY147.com 小凡)</p><p class="header">米兰连胜终结</p><p class="header">砍人战术或将修正</p><p class="header">擂战鼓 唱哪出?</p><p>禅师不满!尼克斯解雇<a href="http://m.so.com/s?q=%E8%B4%B9%E8%88%8D%E5%B0%94&amp;src=newstranscode" class="qkw">费舍尔</a> 兰比斯任临时主帅</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/article/3969688.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='68fb23d859e76596c2277fc7888571cc'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>贺岁杯</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%B4%BA%E5%B2%81%E6%9D%AF&amp;pn=1&amp;pos=4&amp;m=650fc09b1928e975101a8fdfaf0e70a0cdca4ed8&amp;u=http%3A%2F%2Fwww.nxing.cn%2Fwap%2Farticle%2F3960958.html" data-pos="1"> 国少队长温家宝已正式加盟恒大?<b>贺岁杯</b>首发出场 </a>   <li> <a href="/transcode?q=%E8%B4%BA%E5%B2%81%E6%9D%AF&amp;pn=1&amp;pos=5&amp;m=2c0897e30ca5ca542e55bd0ad443eef275128419&amp;u=http%3A%2F%2Fpic.sports.sohu.com%2F911203%2F911306%2F915101%2Fgroup-715160.shtml" data-pos="2"> 中甲动态:人和<b>贺岁杯</b>夺冠 权健热身赛连败(图) </a>   <li> <a href="/transcode?q=%E8%B4%BA%E5%B2%81%E6%9D%AF&amp;pn=1&amp;pos=6&amp;m=976a62ce3f20b4e255498148b320bc10c5d7d2a9&amp;u=http%3A%2F%2Fsports.sina.com.cn%2Fchina%2Fb%2F2016-02-22%2Fdoc-ifxprucs6368439.shtml" data-pos="3"> <b>贺岁杯</b>-北京人和0-1小负新疆 仍力压恒大获冠军 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '2016贺岁杯再升级潘晓婷领衔出战四美女上阵' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '2016贺岁杯再升级潘晓婷领衔出战四美女上阵'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";