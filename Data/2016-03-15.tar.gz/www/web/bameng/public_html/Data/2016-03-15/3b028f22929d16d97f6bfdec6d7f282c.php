s:15383:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>夫子庙上灯两天赏灯客超五十万 元宵夜冷雨难挡游兴- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">夫子庙上灯两天赏灯客超五十万 元宵夜冷雨难挡游兴</h1> <p id="source-and-time"><span id=source>中国广播网</span><time id=time>2016-02-22 20:06:00</time></p> </header>  <div id="news-body"><p><img src="http://p35.qhimg.com/t0137db16c4b242c1a9.jpg?size=540x405"></p><p><a href="http://m.so.com/s?q=%E5%85%83%E5%AE%B5%E8%8A%82&amp;src=newstranscode" class="qkw">元宵节</a>当晚七点，夫子庙赏灯客流已经超过二十万。 <a href="http://m.so.com/s?q=%E5%94%90%E5%A8%9F&amp;src=newstranscode" class="qkw">唐娟</a> 摄</p><p><img src="http://p31.qhimg.com/t01c04cd0a453106664.jpg?size=540x405"></p><p>热力图显示<a href="http://m.so.com/s?q=%E5%A4%AB%E5%AD%90%E5%BA%99%E5%A4%A7%E6%88%90%E6%AE%BF&amp;src=newstranscode" class="qkw">夫子庙大成殿</a>是游客最为聚集的区域。 唐娟 摄</p><p>中新网南京2月22日电 (记者 申冉)22日，是中国传统佳节上元元宵节，历史最为悠久的中国灯会之一、南京<a href="http://m.so.com/s?q=%E5%A4%AB%E5%AD%90%E5%BA%99&amp;src=newstranscode" class="qkw">夫子庙</a>秦淮灯会，自正月十三上灯，在两天内迎来了超五十万的赏灯游客。元宵节当天，尽管冷雨纷飞、气温猛降，但赏灯游客显然并未受到影响，短短数个小时十余万客流直涌<a href="http://m.so.com/s?q=%E5%A4%AB%E5%AD%90%E5%BA%99%E6%99%AF%E5%8C%BA&amp;src=newstranscode" class="qkw">夫子庙景区</a>。</p><p>当天下午五点多，天还没有黑，灯还未全亮，游兴正好的游客和市民就已经迫不及待游灯市了。</p><p>“从正月十三上灯日起，我们的营业时间就只有两三个小时。”位于夫子庙西门附近的一家银行，中午就大门紧闭。</p><p>银行内的工作人员李先生站在门口看热闹，他告诉记者，由于正在客流最为拥挤的景区入口附近，这家银行门口年年都是警戒重地，元宵节前后天天下午都挤满了排队赏灯的游客。</p><p>到了晚上六点多，进入夫子庙灯区的人流已经达到了当晚的第一个峰值。</p><p>在南京警方的指挥总部电子平台，记者看到，景区客流数字一直在不停向上跳动，从22日零点截至当晚六点，景区客流总量已经达到167301人次;下午六时三十分滞留在夫子庙景区内的赏灯人数就已经达到18万余人次。</p><p>今年是南京警方首次使用人流量热力图，该系统是与<a href="http://m.so.com/s?q=%E8%85%BE%E8%AE%AF%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">腾讯公司</a>合作，在景区内，只要有人使用手机上的腾讯QQ，就能够在热力图上接收到一个热点，随着人流量的增大，可以通过越来越红的热点面积，来计算人群聚集的地区，以及需要控制人流进出的节点。</p><p>在这张热力地图上，记者看到，夫子庙大成殿附近已经出现片状红色区域。</p><p>尽管今年<a href="http://m.so.com/s?q=%E7%A7%A6%E6%B7%AE&amp;src=newstranscode" class="qkw">秦淮</a>灯会分成多个灯区，但夫子庙大成殿灯会猜谜、<a href="http://m.so.com/s?q=%E6%96%87%E5%BE%B7%E6%A1%A5&amp;src=newstranscode" class="qkw">文德桥</a>赏灯观秦淮河河景依然是最为经典的“上元节”观灯路线。</p><p>在灯会核心区的<a href="http://m.so.com/s?q=%E5%A4%A7%E6%88%90%E6%AE%BF&amp;src=newstranscode" class="qkw">大成殿</a>门口，赏灯的大人孩子摩肩擦踵，记者站在人群中已经无法自由前行，只能跟着前方人潮一起往前走。</p><p>“我们甚至已经提醒游客和民众，今年最流行的齐天大圣<a href="http://m.so.com/s?q=%E9%87%91%E7%AE%8D%E6%A3%92&amp;src=newstranscode" class="qkw">金箍棒</a>最好不要让孩子拿在手中进入景区，由于人潮拥挤，很容易会刺到旁边的游客。”南京警方负责人向社会呼吁，之前已经发生过这样的案件。</p><p>“年年新年，不挤到夫子庙看一场灯，好像这年没有过完一样。”一位南京市民挤在人群中，尴尬地笑着跟记者说。(完)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.cnr.cn/native/gd/20160222/t20160222_521433792.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='cc3af7a3cc9505175755bba7592fc00e'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>元宵夜</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%85%83%E5%AE%B5%E5%A4%9C&amp;pn=1&amp;pos=3&amp;m=a9fe3366615deba3064b0d3739b7e4575e8020e3&amp;u=http%3A%2F%2Fnews.cnr.cn%2Fnative%2Fgd%2F20160222%2Ft20160222_521433792.shtml" data-pos="1"> 夫子庙上灯两天赏灯客超五十万 <b>元宵夜</b>冷雨难挡游兴 </a>   <li> <a href="/transcode?q=%E5%85%83%E5%AE%B5%E5%A4%9C&amp;pn=1&amp;pos=4&amp;m=5712985eaf319855fe32e97c64e054689a78c276&amp;u=http%3A%2F%2Fnews.youth.cn%2Fjsxw%2F201602%2Ft20160224_7670556.htm" data-pos="2"> <b>元宵夜</b>七旬老汉捡个"二踢脚" 没想在手里炸了 </a>   <li> <a href="/transcode?q=%E5%85%83%E5%AE%B5%E5%A4%9C&amp;pn=1&amp;pos=5&amp;m=b76f2fc184e0c901ae6b8b10302218f3df51b6e9&amp;u=http%3A%2F%2Ffinance.sina.com.cn%2Fsf%2Fnews%2F2016-03-03%2F095722541.html" data-pos="3"> 彩礼未兑现被解除婚约 遂宁男子<b>元宵夜</b>刺杀前女友 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '夫子庙上灯两天赏灯客超五十万 元宵夜冷雨难挡游兴' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '夫子庙上灯两天赏灯客超五十万 元宵夜冷雨难挡游兴'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";