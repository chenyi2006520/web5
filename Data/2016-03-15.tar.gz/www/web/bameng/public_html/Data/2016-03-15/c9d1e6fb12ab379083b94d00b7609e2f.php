s:16896:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>欢乐喜剧人第二季辽艺“MP3”上演离奇结婚计 大潘佳佳成“追梦兄弟” - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">欢乐喜剧人第二季辽艺“MP3”上演离奇结婚计 大潘佳佳成“追梦兄弟” </h1> <p id="source-and-time"><span id=source>新华网浙江频道</span><time id=time>2016-03-15 11:39:35</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t014643a3273c6fb846.jpg?size=550x366"></p><p><a href="http://m.so.com/s?q=%E6%BD%98%E9%95%BF%E6%B1%9F&amp;src=newstranscode" class="qkw">潘长江</a>表演中</p><p>“石榴姐”<a href="http://m.so.com/s?q=%E8%8B%91%E7%90%BC%E4%B8%B9&amp;src=newstranscode" class="qkw">苑琼丹</a>助阵潘长江 辽艺“<a href="http://m.so.com/s?q=MP3&amp;src=newstranscode" class="qkw">MP3</a>”上演离奇“结婚计”</p><p>上一场喜获单场冠军的老艺术家潘长江，本场比赛再次发威。面对紧张的赛程，不仅不喊累，甚至连续熬夜打磨作品，敬业精神值得敬佩。潘长江此次的作品再次关注“老年人和孩子”的问题。为了自家儿子能够顺利登记结婚，潘长江变身魅力“老太太”实施“美人计”，机智搞定“亲家”。更为惊喜的是“石榴姐”苑琼丹意外加 盟助阵，赢得场下掌声阵阵。</p><p>辽宁民间艺术团上期成绩不理想，面对终极<a href="http://m.so.com/s?q=%E6%B7%98%E6%B1%B0%E8%B5%9B&amp;src=newstranscode" class="qkw">淘汰赛</a>，肩负晋级重任的“MP3”组合更加不敢掉以轻心。于是，<a href="http://m.so.com/s?q=%E6%9D%A8%E5%86%B0&amp;src=newstranscode" class="qkw">杨冰</a>、胖丫夫妻齐上阵，饰演一对“闹矛盾”的恋人。<a href="http://m.so.com/s?q=%E5%AE%8B%E6%99%93%E5%B3%B0&amp;src=newstranscode" class="qkw">宋晓峰</a>则成为了一个冒充“假新郎”的小区保安，并与<a href="http://m.so.com/s?q=%E8%83%96%E4%B8%AB&amp;src=newstranscode" class="qkw">胖丫</a>上演了一场离奇的“结婚计”。表演过程中，辽宁民间艺术团再次发挥了他们在语言上的强大优势，尤其是宋晓峰独特的“结巴”和“吟诗作对”，趣味横生。他们的作品也在嬉笑怒骂中，向观众诠释了什么是<a href="http://m.so.com/s?q=%E7%88%B1%E6%83%85%E7%9A%84%E7%9C%9F%E8%B0%9B&amp;src=newstranscode" class="qkw">爱情的真谛</a>，引人深思。</p><p>由东方卫视携手<a href="http://m.so.com/s?q=%E6%AC%A2%E4%B9%90%E4%BC%A0%E5%AA%92&amp;src=newstranscode" class="qkw">欢乐传媒</a>共同打造的《欢乐喜剧人》第二季迎来终极淘汰赛。本场比赛不仅事关<a href="http://m.so.com/s?q=%E8%B0%81%E5%B0%86%E8%A2%AB%E6%B7%98%E6%B1%B0&amp;src=newstranscode" class="qkw">谁将被淘汰</a>，获得当场第一的喜剧人更能直通总决赛，可谓是机遇与挑战并存。面对这场竞争空前激烈的第八期竞演，各组喜剧团队为能突出重围，真真是花样迭出，爆笑不断。值得一提的是，“黑马”大潘、佳佳团队，将为观众带来一种从未在<a href="http://m.so.com/s?q=%E3%80%8A%E6%AC%A2%E4%B9%90%E5%96%9C%E5%89%A7%E4%BA%BA%E3%80%8B&amp;src=newstranscode" class="qkw">《欢乐喜剧人》</a>舞台出现过的表演形式。兄弟俩将变身“<a href="http://m.so.com/s?q=%E8%BF%BD%E6%A2%A6%E5%85%84%E5%BC%9F&amp;src=newstranscode" class="qkw">追梦兄弟</a>”，武斗“杀马特兄弟”，搞笑连连。更有著名<a href="http://m.so.com/s?q=%E6%91%87%E6%BB%9A%E4%B9%90%E9%98%9F&amp;src=newstranscode" class="qkw">摇滚乐队</a>二手玫瑰惊喜助演，嗨翻全场。</p><p>大潘、佳佳是《欢乐喜剧人》舞台上名副其实的“黑马”，他们的节目不仅贴地气儿，还十分具有创新性。本场竞演，大潘、佳佳在节目中饰演一对“追梦兄弟”欲进大城市发展。临走前，哥俩为争“屯花”<a href="http://m.so.com/s?q=%E5%BC%A0%E5%B0%8F%E6%96%90&amp;src=newstranscode" class="qkw">张小斐</a>大战村霸“杀马特三兄弟”，爆笑连连。众人乡村风情的服装和场景，也让这部喜剧作品特色鲜明，别有一番滋味。</p><p><img src="http://p34.qhimg.com/t01252ddf56d522e1a1.jpg?size=550x366"></p><p><a href="http://m.so.com/s?q=%E5%B2%B3%E4%BA%91%E9%B9%8F&amp;src=newstranscode" class="qkw">岳云鹏</a>暂替郭德纲当司仪</p><p><a href="http://m.so.com/s?q=%E8%A1%A5%E4%BD%8D&amp;src=newstranscode" class="qkw">补位</a>赛中排名垫底的开心麻花<a href="http://m.so.com/s?q=%E7%8E%8B%E5%AE%81&amp;src=newstranscode" class="qkw">王宁</a>、艾伦，此番终极淘汰赛压力倍增。但是，压力也能带来动力，两人再次向观众展示了“大片级”的喜剧表演。王宁、<a href="http://m.so.com/s?q=%E8%89%BE%E4%BC%A6&amp;src=newstranscode" class="qkw">艾伦</a>变身“怪盗”，勇闯险地寻宝，在过“机关门”时，兄弟俩“傻萌”的样子笑翻众人，而后，随着剧情的发展，恢弘大气的场面一一向观众袭来，引得现场不断发出赞叹声。道具的精美程度和情节的精妙设置，让观众看到开心麻花十足的诚意。</p><p>为在最后一轮淘汰赛上获得好成绩，各竞演团队发挥所长，让节目异彩纷呈，笑点不断。到底哪一组喜剧人将遗憾离场，谁又能直接进军总决赛，老艺术家潘长江能否延续上一场的优势，垫底的开心麻花能否<a href="http://m.so.com/s?q=%E7%BB%9D%E5%9C%B0%E5%8F%8D%E5%87%BB&amp;src=newstranscode" class="qkw">绝地反击</a>。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.zj.xinhuanet.com/yltd/2016-03/15/c_1118335377_6.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='18f9b4a463033eb2318994f11859b31b'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>欢乐喜剧人</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%AC%A2%E4%B9%90%E5%96%9C%E5%89%A7%E4%BA%BA&amp;pn=1&amp;pos=5&amp;m=755c1a17b1b2c408cddb3afef31c572a6b6c9e66&amp;u=http%3A%2F%2Fwww.zj.xinhuanet.com%2Fyltd%2F2016-03%2F15%2Fc_1118335377_6.htm" data-pos="1"> <b>欢乐喜剧人</b>第二季辽艺"MP3"上演离奇结婚计 大潘佳佳成"追梦兄弟" </a>   <li> <a href="/transcode?q=%E6%AC%A2%E4%B9%90%E5%96%9C%E5%89%A7%E4%BA%BA&amp;pn=1&amp;pos=6&amp;m=f94423c62e6e55266e1f7cd409022b38e6d6713c&amp;u=http%3A%2F%2Fah.people.com.cn%2Fn2%2F2016%2F0315%2Fc358331-27935732.html" data-pos="2"> <b>欢乐喜剧人</b>第二季:大潘佳佳遭淘汰 岳云鹏变司仪苑琼丹助阵 </a>   <li> <a href="/transcode?q=%E6%AC%A2%E4%B9%90%E5%96%9C%E5%89%A7%E4%BA%BA&amp;pn=1&amp;pos=7&amp;m=45dc939d24daabd7303973f2f2f5c323466b8d26&amp;u=http%3A%2F%2Fwww.zj.xinhuanet.com%2Fyltd%2F2016-03%2F15%2Fc_1118332178.htm" data-pos="3"> <b>欢乐喜剧人</b>第二季知多少 开心麻花团队面临淘汰 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '欢乐喜剧人第二季辽艺“MP3”上演离奇结婚计 大潘佳佳成“追梦兄弟” ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '欢乐喜剧人第二季辽艺“MP3”上演离奇结婚计 大潘佳佳成“追梦兄弟” '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";