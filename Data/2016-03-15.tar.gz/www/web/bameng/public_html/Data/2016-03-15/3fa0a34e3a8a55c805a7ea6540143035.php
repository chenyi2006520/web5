s:15186:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>韩子荣任北京冬奥组委秘书长 曾任门头沟区委书记- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">韩子荣任北京冬奥组委秘书长 曾任门头沟区委书记</h1> <p id="source-and-time"><span id=source>中国新闻网</span><time id=time>2016-03-15 10:33:00</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E9%9F%A9%E5%AD%90%E8%8D%A3&amp;src=newstranscode" class="qkw">韩子荣</a>任北京冬奥组委秘书长</p><p>此前担任<a href="http://m.so.com/s?q=%E9%97%A8%E5%A4%B4%E6%B2%9F&amp;src=newstranscode" class="qkw">门头沟</a>区委书记;曾任<a href="http://m.so.com/s?q=%E5%8C%97%E4%BA%AC%E5%A5%A5%E8%BF%90%E4%BC%9A&amp;src=newstranscode" class="qkw">北京奥运会</a>组委会秘书行政部部长</p><p>(记者温薷 <a href="http://m.so.com/s?q=%E6%9D%8E%E5%A9%B7%E5%A9%B7&amp;src=newstranscode" class="qkw">李婷婷</a>)近日，门头沟区委原书记韩子荣的新去向披露，其已出任北京冬奥组委秘书长。</p><p>上月，门头沟区长<a href="http://m.so.com/s?q=%E5%BC%A0%E8%B4%B5%E6%9E%97&amp;src=newstranscode" class="qkw">张贵林</a>出任该区区委书记。而门头沟区委原书记韩子荣卸任后，新去向一直未获官方披露。</p><p>此前有消息称，北京2022年<a href="http://m.so.com/s?q=%E5%86%AC%E5%A5%A5%E4%BC%9A&amp;src=newstranscode" class="qkw">冬奥会</a>组委会将落户首钢。3月9日，<a href="http://m.so.com/s?q=%E3%80%8A%E9%A6%96%E9%92%A2%E6%97%A5%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《首钢日报》</a>一则消息称，“北京冬奥组委秘书长韩子荣等领导赴首钢调研”，韩子荣的新职务也由此公开。昨天，新京报记者也从相关人士处证实了该消息。</p><p>据首钢日报报道，韩子荣当时先后参观了陶楼一层规划沙盘、西十冬奥广场及龙烟厂史馆。她表示，将按市委市政府要求，以高质量设计、高标准建设和高水平管理，将西十冬奥广场建成有世界影响力的、具有示范性和可持续性的绿色办公场所。</p><p>公开资料显示，韩子荣做过教师，做过共青团工作。1996年，刚过30岁的韩子荣就已经是朝阳区委常委。2011年，她从<a href="http://m.so.com/s?q=%E5%B8%82%E6%80%BB%E5%B7%A5%E4%BC%9A&amp;src=newstranscode" class="qkw">市总工会</a>党组书记、副主席调任门头沟区委书记，卸任时刚好干满5年。</p><p>韩子荣此前亦有奥运相关工作经历。在北京奥运会期间，韩子荣就曾出任北京奥运会组委会秘书行政部部长。</p><p class="header">■ 相关新闻</p><p>刘印春、<a href="http://m.so.com/s?q=%E5%BE%90%E5%BF%97%E5%86%9B&amp;src=newstranscode" class="qkw">徐志军</a>拟任市政府副秘书长</p><p>近日，北京市委组织部发布了两则任前公示，均是关于市政府副秘书长(正局级)的新人选。其中一位是北京市发改委党组副书记、副主任刘印春;另一位是北京人力社保局党组成员、副局长徐志军。</p><p>据悉，刘印春拥有管理学博士学位。他在发改委多个处室担任过处长，2011年7月出任市发改委副主任。前年底北京调整公交地铁票价时，刘印春是<a href="http://m.so.com/s?q=%E5%90%AC%E8%AF%81%E4%BC%9A&amp;src=newstranscode" class="qkw">听证会</a>的听证人。</p><p>现任市人力社保局副局长的徐志军曾在奥组委任职。2002年到2008年，他先后担任<a href="http://m.so.com/s?q=%E5%8C%97%E4%BA%AC%E5%A5%A5%E7%BB%84%E5%A7%94&amp;src=newstranscode" class="qkw">北京奥组委</a>人事部任免处处长、人事部副部长等职。他还曾任<a href="http://m.so.com/s?q=%E4%BD%8F%E5%BB%BA%E5%A7%94&amp;src=newstranscode" class="qkw">住建委</a>委员，在内蒙古自治区<a href="http://m.so.com/s?q=%E4%B9%8C%E5%85%B0%E5%AF%9F%E5%B8%83&amp;src=newstranscode" class="qkw">乌兰察布</a>挂职市委常委、副市长。2013年1月任北京市人力资源和社会保障局党组成员、副局长。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.chinanews.com/gn/2016/03-15/7797731.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='8057eaef33f9d251684964dc869c899a'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>秘书长</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%A7%98%E4%B9%A6%E9%95%BF&amp;pn=1&amp;pos=3&amp;m=f0c2c19040c5bfe30a3e826bc8660bce0c0161be&amp;u=http%3A%2F%2Fnews.163.com%2F16%2F0315%2F13%2FBI6VB2DF00014SEH.html" data-pos="1"> 驻阿联酋大使常华会见国际电信联盟<b>秘书长</b>赵厚麟(组图) </a>   <li> <a href="/transcode?q=%E7%A7%98%E4%B9%A6%E9%95%BF&amp;pn=1&amp;pos=4&amp;m=28eaf3d4874e86b6bb1647bd3312d8184cf956ae&amp;u=http%3A%2F%2Fnews.youth.cn%2Fgn%2F201603%2Ft20160315_7744381.htm" data-pos="2"> 北京门头沟区委原书记韩子荣任冬奥组委<b>秘书长</b> </a>   <li> <a href="/transcode?q=%E7%A7%98%E4%B9%A6%E9%95%BF&amp;pn=1&amp;pos=5&amp;m=bec94cf2163a51d21f0d651cd111a440a2e0b679&amp;u=http%3A%2F%2Fwww.bj.xinhuanet.com%2Fbjzw%2F2016-03%2F15%2Fc_1118334880.htm" data-pos="3"> 原门头沟书记韩子荣出任北京冬奥组委<b>秘书长</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '韩子荣任北京冬奥组委秘书长 曾任门头沟区委书记' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '韩子荣任北京冬奥组委秘书长 曾任门头沟区委书记'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";