s:17716:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>警惕极度危险的创业板滚雪球游戏- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">警惕极度危险的创业板滚雪球游戏</h1> <p id="source-and-time"><span id=source>新浪</span><time id=time>2015-05-04 10:35:00</time></p> </header>  <div id="news-body"><p>文/<a href="http://m.so.com/s?q=%E6%96%B0%E6%B5%AA%E8%B4%A2%E7%BB%8F&amp;src=newstranscode" class="qkw">新浪财经</a>专栏作家 熊锦秋</p><p>即使管理层不捅破<a href="http://m.so.com/s?q=%E5%88%9B%E4%B8%9A%E6%9D%BF&amp;src=newstranscode" class="qkw">创业板</a>泡沫，创业板在今后一段时间仍然继续上涨，但市场资金毕竟是有限的，创业板泡沫最终仍将自生自灭，崩盘的结果就是将有更多投资者损失惨重、甚至倾家荡产。</p><p><img src="http://p34.qhimg.com/t01674a67bb37677866.jpg?size=520x308"></p><p>警惕极度危险的创业板<a href="http://m.so.com/s?q=%E6%BB%9A%E9%9B%AA%E7%90%83&amp;src=newstranscode" class="qkw">滚雪球</a>游戏</p><p>创业板目前上涨势头非常疯狂，似乎地球人也无法阻挡其上涨步伐，这其中公募基金功不可没，一季度主动偏股型基金<a href="http://m.so.com/s?q=%E5%87%8F%E4%BB%93&amp;src=newstranscode" class="qkw">减仓</a>主板20%，加仓<a href="http://m.so.com/s?q=%E4%B8%AD%E5%B0%8F%E6%9D%BF&amp;src=newstranscode" class="qkw">中小板</a>11%，加仓创业板10%;公募基金投资创业板，复制了2005年至2007年的做法，通过扎堆投资推动股价上涨，由此形成“<a href="http://m.so.com/s?q=%E5%88%9B%E4%B8%9A%E6%9D%BF%E8%82%A1%E7%A5%A8&amp;src=newstranscode" class="qkw">创业板股票</a>涨-基金赚钱-更多<a href="http://m.so.com/s?q=%E5%9F%BA%E6%B0%91&amp;src=newstranscode" class="qkw">基民</a>申购基金-创业板继续涨”的模式，形成滚雪球游戏。笔者认为，要尽快制止公募基金在创业板大玩滚雪球<a href="http://m.so.com/s?q=%E9%87%91%E9%92%B1%E6%B8%B8%E6%88%8F&amp;src=newstranscode" class="qkw">金钱游戏</a>。</p><p>创业板开设之初，是否允许公募基金投资创业板股票都存在不少争论，后来对公募基金放开了口子，公募基金利用<a href="http://m.so.com/s?q=%E5%88%9B%E4%B8%9A%E6%9D%BF%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">创业板公司</a>流通盘小、市场容量相对较小的特点，扎堆投资。在目前形势下，管理层希望出现慢牛，如果大盘蓝筹暴涨就将成为疯牛，由此投资者不敢对大盘蓝筹轻举妄动、其涨势被抑制，一些主力趁此“良机”将市场资金源源不断引导流入创业板等庄股，一旦市场有利多消息，庄股可以更多分享、借机更多上涨;一旦市场有利空消息，其影响却主要由无庄股来承担，而庄股在庄家呵护下可以屹立不倒、甚至逆势上涨。</p><p>目前创业板与大盘蓝筹形成跷跷板走势，在公募基金等实力机构的引导下，创业板在与主板的资金抢夺战中屡屡处于上风;尽管创业板市场估值水平越来越高、泡沫越来越大，但由于基金资产是基民资产而非管理人资产，管理人罔顾泡沫风险、仍然进一步鼓吹创业板泡沫。比如，创业板某只股价最高的股票市盈率达1000多倍、市净率接近100倍，且仍有上涨势头，翻看其前十大流通股东，其中布满了公募基金。</p><p>公募基金在创业板滚雪球金钱游戏，短期来看似乎大家都可赚钱，但卖出者赚的钱都是由后入场投资者所提供的。一旦后入场的资金赶不上离场资金，泡沫就必然破裂，接最后一棒的投资者就要承受高位套牢风险。在笔者看来，即使管理层不捅破创业板泡沫，创业板在今后一段时间仍然继续上涨，但市场资金毕竟是有限的，创业板泡沫最终仍将自生自灭，崩盘的结果就是将有更多投资者损失惨重、甚至倾家荡产。</p><p>前段<a href="http://m.so.com/s?q=%E8%AF%81%E7%9B%91%E4%BC%9A&amp;src=newstranscode" class="qkw">证监会</a>[微博]发言人表示，近期部署开展“2015证监法网专项执法行动”，第一批针对上市公司<a href="http://m.so.com/s?q=%E5%B9%B6%E8%B4%AD%E9%87%8D%E7%BB%84&amp;src=newstranscode" class="qkw">并购重组</a>中的财务造假、以市值管理名义内外勾结的市场操纵、内幕交易、证券从业人员利用未公开信息交易行为(俗称老鼠仓)、期货市场操纵等五类违法违规行为进行集中打击。笔者认为，要控制当前创业板结构性泡沫风险，防止由此引发社会问题，通过加大创业板股票供给难以解决这个问题，只要有公募基金等主力引导，资金仍会持续进入创业板、或者进入创业板某些个股，泡沫仍难阻止、直至最终崩溃，对此对此唯有加大对市场操纵的定向打击力度。证监会拟开展的专项执法行动，包含打击“以市值管理名义内外勾结的市场操纵”的内容，如涉嫌犯罪，还可能移交公安机关查处，这无疑切中时弊。</p><p>目前社保基金不少投资组合是由公募<a href="http://m.so.com/s?q=%E5%9F%BA%E9%87%91%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">基金公司</a>在管理，在公募基金管理人的操盘下，一些社保基金投资组合也在高位抢入创业板股票，对这种情况，也要对其中涉嫌操纵行为进行查处，当然其中违法违规者应是操盘的公募基金公司。这方面社保基金应该完善对管理人的监督制约制度，委托公募基金管理人投资股票，并不能放任其随便买入高风险泡沫股、甚至进行变相利益输送，对此必须完善制度、同时也要进一步完善对管理人的遴选制度。</p><p>无论是谁也不能凌驾于法律之上，无论谁触及市场操纵高压线，都要严厉查处。不过，打击市场操纵等违法违规，不可能靠一次专项行动就能解决问题，不可能毕其功于一役，关键是要形成常态化的监管执法工作机制，要形成露头就打、持续高压机制。笔者认为，目前市场操纵绝非个例，市场流行“人有多大胆、股有多高价”的说法，股价靠庄家实力来决定，有些操纵者甚至产生法不责众的错觉，这都提醒监管部门要加强对市场操纵常态化的高压打击力度，要及时出手，不能<a href="http://m.so.com/s?q=%E5%85%BB%E7%97%88%E6%88%90%E6%82%A3&amp;src=newstranscode" class="qkw">养痈成患</a>。</p><p>(本文作者介绍:资深市场评论人士。)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://finance.sina.com.cn/zl/stock/20150504/103522098553.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='3d0f38ec4d96236f392b97dfa7156d5f'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>危险的游戏</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%8D%B1%E9%99%A9%E7%9A%84%E6%B8%B8%E6%88%8F&amp;pn=1&amp;pos=4&amp;m=4e8063e972032ec74d9e693dc299fbf27fee7a3e&amp;u=http%3A%2F%2Fnews.163.com%2F15%2F0831%2F03%2FB2AKV1NF00014Q4P.html" data-pos="1"> "租友":一场<b>危险的游戏</b> </a>   <li> <a href="/transcode?q=%E5%8D%B1%E9%99%A9%E7%9A%84%E6%B8%B8%E6%88%8F&amp;pn=1&amp;pos=5&amp;m=f34fe45186bb36523144ed66a59563e88122888c&amp;u=http%3A%2F%2Fnews.163.com%2F15%2F0831%2F02%2FB2AHT7FT00014AED.html" data-pos="2"> 网络有偿交友一场<b>危险的游戏</b> </a>   <li> <a href="/transcode?q=%E5%8D%B1%E9%99%A9%E7%9A%84%E6%B8%B8%E6%88%8F&amp;pn=1&amp;pos=6&amp;m=9eff6c8072b7eba9bec75202f1bcf45c4526925a&amp;u=http%3A%2F%2Fbj.house.163.com%2F15%2F1105%2F08%2FB7L4KMM800073SD3.html" data-pos="3"> <b>危险的</b>地王<b>游戏</b> 未来北京顶级豪宅供求比为20:1 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '警惕极度危险的创业板滚雪球游戏' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '警惕极度危险的创业板滚雪球游戏'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";