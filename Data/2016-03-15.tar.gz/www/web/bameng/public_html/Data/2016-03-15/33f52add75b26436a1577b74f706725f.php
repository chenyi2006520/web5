s:14691:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>谣传!安海一男子看电影发现老婆出轨大打出手泉州(图)- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">谣传!安海一男子看电影发现老婆出轨大打出手泉州(图)</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-11 00:00:00</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E5%AE%89%E6%B5%B7&amp;src=newstranscode" class="qkw">安海</a>一男子看《叶问3》 发现老婆出轨大打出手 谣传!</p><p>泉州网警:未接到类似报警，造谣<a href="http://m.so.com/s?q=%E5%BE%AE%E4%BF%A1&amp;src=newstranscode" class="qkw">微信</a>已被删除</p><p><img src="http://p35.qhimg.com/t01ab7dfad7d52c4562.jpg?size=550x428"></p><p>网传视频中显示当事人在影院内扭打成一团</p><p><img src="http://p33.qhimg.com/t016a3c7001308405ff.jpg?size=550x397"></p><p>近日有网友曝出一段男子看完电影<a href="http://m.so.com/s?q=%E3%80%8A%E5%8F%B6%E9%97%AE3%E3%80%8B&amp;src=newstranscode" class="qkw">《叶问3》</a>，与他人扭打的视频，称该男子看完电影后，发现老婆与别的男人坐在影厅前排，几人纠缠在一起，从而展开“叶问4”的神剧情。<a href="http://m.so.com/s?q=%E6%B3%89%E5%B7%9E&amp;src=newstranscode" class="qkw">泉州</a>本地一微信公众号推出文章称，这事发生在安海某电影院。前日晚上泉州网警在微博辟谣，表示该事件并非发生在安海。</p><p class="header">□早报记者 傅恒 文/截图</p><p>网传视频 安海一男子看电影撞见老婆搞外遇</p><p>这段视频只有短短的15秒，视频中显示，坐在后排的一名男子发现情况后，上前撕扯前方一对男女。女子要将两名男子拉开，三人纠缠在一起，后排男子一拳挥去，这对男女直接摔到前面的座位上。视频在微信群、<a href="http://m.so.com/s?q=%E6%9C%8B%E5%8F%8B%E5%9C%88&amp;src=newstranscode" class="qkw">朋友圈</a>疯传。然而该事件发生在哪儿，却有多种版本，有人说发生在长春，有人说发生在浙江，有人说发生在广州，等等。网友们纷纷吐槽:“哈哈哈哈，这比《叶问3》好看多了!”“一张票看两部电影，值!”“《叶问3》看着看着直接变成了<a href="http://m.so.com/s?q=%E3%80%8A%E5%8F%B6%E9%97%AE4%E3%80%8B&amp;src=newstranscode" class="qkw">《叶问4》</a>，花3D的钱看了一场5D的实况。”……</p><p>前日下午，泉州本地一微信公众号推出文章称，这事发生在晋江安海。该微信公众号称:“昨晚安海某影院火了，两男女大打出手，网友爆料，原来竟是老婆带着情人看电影，巧遇老公也带情人坐后排，灯亮后，结果……”</p><p>警方辟谣 近日未接到类似报警 传谣微信已删除</p><p>虽然只有简单的文字、视频和图片，这条微信的转发量却很大，不少市民信以为真。</p><p>好在@泉州网警巡查执法及时监控到该信息。前晚，@泉州网警巡查执法 核实后发布微博称，该事件发生在安海系谣言，工作人员从<a href="http://m.so.com/s?q=%E6%99%8B%E6%B1%9F&amp;src=newstranscode" class="qkw">晋江</a>110指挥中心了解到，近两日均未接到类似报警，这篇微信也被删除。</p><p>警方提醒广大群众，不要轻易相信网络上的谣言，不造谣，不传谣。网络属于公共空间，并非不法之地，在网上散布谣言或者虚假信息，不管是原创还是转发，都要承担相应的法律责任，警方将加大巡查防控力度，尽力打击造谣传谣事件。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/wap/article/3965925.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='b0968805dd23ed59aa809932bcbdca06'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>安海</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%AE%89%E6%B5%B7&amp;pn=1&amp;pos=7&amp;m=9564cf1c8f8610cffb978dbd1156f15b12c3a750&amp;u=http%3A%2F%2Fwww.nxing.cn%2Fwap%2Farticle%2F3965925.html" data-pos="1"> 谣传!<b>安海</b>一男子看电影发现老婆出轨大打出手泉州(图) </a>   <li> <a href="/transcode?q=%E5%AE%89%E6%B5%B7&amp;pn=1&amp;pos=8&amp;m=2a5129a8076e8212a571375e0625f1148156b7fb&amp;u=http%3A%2F%2Fwww.mnw.cn%2Fjinjiang%2Fnews%2F1124149.html" data-pos="2"> 晋江<b>安海</b>司法所社区服刑人员助力慈善 </a>   <li> <a href="/transcode?q=%E5%AE%89%E6%B5%B7&amp;pn=1&amp;pos=9&amp;m=b2f9abdd9a3072f41003ebd09002e4ef3e7e2a1f&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Ffjnews_0301%2F4444091.html" data-pos="3"> 13岁男孩被父亲教训 赌气出走竟从<b>安海</b>走到南安 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '谣传!安海一男子看电影发现老婆出轨大打出手泉州(图)' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '谣传!安海一男子看电影发现老婆出轨大打出手泉州(图)'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";