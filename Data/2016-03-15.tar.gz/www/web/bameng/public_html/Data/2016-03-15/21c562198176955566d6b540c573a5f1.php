s:17456:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>试论禽类胃肠道病的防御机制- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">试论禽类胃肠道病的防御机制</h1> <p id="source-and-time"><span id=source>中国禽病网</span><time id=time>2016-02-25 01:29:44</time></p> </header>  <div id="news-body"><p>导读:搜牧·中国禽病网讯，禽类<a href="http://m.so.com/s?q=%E8%83%83%E8%82%A0%E9%81%93&amp;src=newstranscode" class="qkw">胃肠道</a>是由数十亿个代谢率很高的上皮细胞组成。这种高的代谢率对支持这些上皮细胞的分泌和吸收功能所必需。</p><p>搜牧·中国禽病网讯，禽类胃肠道是由数十亿个代谢率很高的上皮细胞组成。这种高的代谢率对支持这些上皮细胞的分泌和吸收功能所必需。在生命的开始几周中，胃肠道的生长远远超过其它器官系统的生长。禽类的生长要想达到其最大遗传潜力，胃肠道的表面积就必须快速增加。在孵出后的最初5-7天中，胃肠道的生长超过身体其余部分的生长5倍之多。从孵化开始，胃肠道就一直面临着化学、物理和微生物学的挑战。本文重点概述禽类胃肠道的<a href="http://m.so.com/s?q=%E9%98%B2%E5%BE%A1%E7%B3%BB%E7%BB%9F&amp;src=newstranscode" class="qkw">防御系统</a>。</p><p>一、胃肠道的<a href="http://m.so.com/s?q=%E5%BE%AE%E7%94%9F%E7%89%A9%E5%AD%A6&amp;src=newstranscode" class="qkw">微生物学</a></p><p>自然环境下，在所有<a href="http://m.so.com/s?q=%E6%B8%A9%E8%A1%80%E5%8A%A8%E7%89%A9&amp;src=newstranscode" class="qkw">温血动物</a>的肠道中建立微生物菌群，是不可避免的。多数情况下，首先建立的微生物类别，就是那些能最终定值并能在动物生命的整个成年阶段持续存在的最终微生物的先行者。各种类别的定植细菌均对宿主胃肠道的变化很敏感。因此，胃肠道必须提供任何将要定值<a href="http://m.so.com/s?q=%E5%BE%AE%E7%94%9F%E7%89%A9%E7%9A%84%E7%94%9F%E5%AD%98&amp;src=newstranscode" class="qkw">微生物的生存</a>所必需的因子。这些因子包括:适宜的温度、恒定提供的养分和必需的液体。在这些条件下，微生物在宿主肠道提供的环境中繁衍，宿主动物则从这些非致病性微生物菌群中得到益处。</p><p class="header">二、非免疫性防御机制</p><p>微生物的竞争排斥。任何功能完好的肠道的极重要方面是由微生物菌群的平衡决定的。正常情况下，象乳酸杆菌和<a href="http://m.so.com/s?q=%E9%93%BE%E7%90%83%E8%8F%8C&amp;src=newstranscode" class="qkw">链球菌</a>这样的乳酸产生菌占优势，将有助于维持胃肠道的健康。这些有益微生物尤其在动物很年幼时在肠道中的定植，有助于保护动物免受游动的沙门氏菌及致病大肠杆菌侵害的影响。应激和<a href="http://m.so.com/s?q=%E6%8A%97%E8%8F%8C%E8%8D%AF%E7%89%A9&amp;src=newstranscode" class="qkw">抗菌药物</a>的使用已表明可改变肠道的正常微生物菌群。</p><p class="header">三、免疫性防御机制</p><p>微生物定植:如前面讨论的那样，胃肠道微生物对通过竞争排斥来发育和维持“物理屏障”极为重要，而竞争排斥使得病原微生物不能附着于粘膜内皮细胞上。而且，有益微生物能在粘膜和系统水平上促进免疫机制的发育和有效性。在<a href="http://m.so.com/s?q=%E6%97%A0%E8%8F%8C%E5%8A%A8%E7%89%A9&amp;src=newstranscode" class="qkw">无菌动物</a>上，所有主要免疫器官都发育不良，直到感染微生物后才会得到充分发育。</p><p class="header">四、影响消化道完整性的因素</p><p>禽类和任何其它动物消化道的完整性决不应受到损害。消化道从头到尾都必须总是保持健康和发挥正常功能。消化道完整性的破坏将导致疾病的发生，进而影响养分的消化和吸收。下面将列出并简要讨论一些因素是如何对禽类胃肠道的完整性产生负面影响，进而损害其防御机制的。</p><p><a href="http://m.so.com/s?q=%E9%9C%89%E8%8F%8C%E6%AF%92%E7%B4%A0&amp;src=newstranscode" class="qkw">霉菌毒素</a>:不论何时饲料污染了真菌，这些真菌的次级代谢产物都可能在饲料中积累，并对家禽产生毒性。</p><p>蛋白黑素:氨基酸的一些Maillard类<a href="http://m.so.com/s?q=%E8%A1%8D%E7%94%9F%E7%89%A9&amp;src=newstranscode" class="qkw">衍生物</a>已报道对肠道的结构完整性有不良影响。</p><p>生物胺:生物胺的浓度通常很低，正常情况下对动物不会有问题。但是，当饲料原料发生细菌腐败时，这些胺类的数量增加，对动物尤其是家禽可能产生毒性。</p><p>肌胃糜烂素:给雏鸡饲喂过度加工的鱼粉可影响消化道上段的完整性。日本科学家从过热加工的<a href="http://m.so.com/s?q=%E9%B2%AD%E9%B1%BC&amp;src=newstranscode" class="qkw">鲭鱼</a>粉中分离到一种很强力的致肌胃糜烂的物质，他们把此物质称为“肌胃糜烂素”。</p><p>铜:<a href="http://m.so.com/s?q=%E5%97%89%E5%9B%8A&amp;src=newstranscode" class="qkw">嗉囊</a>霉菌病影响胃肠道的完整性，是多见于<a href="http://m.so.com/s?q=%E7%81%AB%E9%B8%A1&amp;src=newstranscode" class="qkw">火鸡</a>上的一种散发病。</p><p>疾病:有大量致病因子均对消化道的完整性有不良影响。引起家禽<a href="http://m.so.com/s?q=%E8%82%A0%E7%82%8E&amp;src=newstranscode" class="qkw">肠炎</a>最常见的因素之一是球虫。正常情况下，垫草上饲养的健康禽类对球虫应能产生免疫反应。由这种<a href="http://m.so.com/s?q=%E5%AF%84%E7%94%9F%E8%99%AB&amp;src=newstranscode" class="qkw">寄生虫</a>低水平的恒定刺激对发育和维持免疫功能所必需。抗球虫药物在控制这种疾病方面是有效的。肠炎也能由线虫和<a href="http://m.so.com/s?q=%E7%BB%A6%E8%99%AB&amp;src=newstranscode" class="qkw">绦虫</a>引起。这种寄生虫当其在肠道中的浓度很高时常常导致<a href="http://m.so.com/s?q=%E8%82%A0%E6%A2%97%E9%98%BB&amp;src=newstranscode" class="qkw">肠梗阻</a>。坏死性肠炎最常见的诱因之一是细菌，而与此有关的最常见细菌为产气荚膜梭状芽胞杆菌。这种微生物产生的毒素可引起肠衬的大面积破坏。坏死性肠炎已表明与亚临床球虫病及当给家禽喂给<a href="http://m.so.com/s?q=%E9%BB%91%E9%BA%A6&amp;src=newstranscode" class="qkw">黑麦</a>、大麦和小麦这样的谷物时常发生肠道粘性增加有关。这些谷物所含的非淀粉多糖能减慢肠道<a href="http://m.so.com/s?q=%E9%A3%9F%E7%B3%9C&amp;src=newstranscode" class="qkw">食糜</a>的正常流通速率，进而导致产气荚膜梭状芽胞杆菌的过度生长。出血性肠炎直接由<a href="http://m.so.com/s?q=%E8%85%BA%E7%97%85%E6%AF%92%E6%84%9F%E6%9F%93&amp;src=newstranscode" class="qkw">腺病毒感染</a>引起。这种病常见于火鸡。肠绒毛尖端破坏，引起小肠上部出血。其它病毒，如呼肠孤病毒、轮状病毒、冠状病毒、细小病毒、类肠病毒及钙质病毒，已表明可引起最终导致肠炎的消化道衬的破坏。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.qinbing.cn/html/details/ece64c72-d4af-4448-9cd4-878a26938b5c.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='adcf52688501165d4fea1b98f5159b40'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>胃肠道</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '试论禽类胃肠道病的防御机制' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '试论禽类胃肠道病的防御机制'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";