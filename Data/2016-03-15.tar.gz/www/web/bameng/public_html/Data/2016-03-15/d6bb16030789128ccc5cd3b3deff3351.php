s:15913:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>东南卫视与北油所所BZ031号勘博石油强强联手- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">东南卫视与北油所所BZ031号勘博石油强强联手</h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2015-03-17 14:09:00</time></p> </header>  <div id="news-body"><p>2015年3月16日，北京石油所(简称“<a href="http://m.so.com/s?q=%E5%8C%97%E6%B2%B9%E6%89%80&amp;src=newstranscode" class="qkw">北油所</a>”)BZ031号会员单位勘博石油投资管理有限公司(简称“<a href="http://m.so.com/s?q=%E5%8B%98%E5%8D%9A%E7%9F%B3%E6%B2%B9&amp;src=newstranscode" class="qkw">勘博石油</a>”)与东南卫视结成战略合作伙伴关系，共同打造了一档金融投资类栏目<a href="http://m.so.com/s?q=%E3%80%8A%E8%B4%A2%E7%BB%8F%E6%96%B0%E8%A7%86%E9%87%8E%E3%80%8B&amp;src=newstranscode" class="qkw">《财经新视野》</a>。</p><p>《财经新视野》在周一至周五早间7:30--8:00播出，是一档以中国市场投资交易为主要内容，面向广大投资者的新闻类实时证券类资讯栏目，实现资源整合共享。栏目以北京勘博石油投资管理有限公司和北京石油所为依托，<a href="http://m.so.com/s?q=%E6%8A%8A%E6%8F%A1%E8%B6%8B%E5%8A%BF&amp;src=newstranscode" class="qkw">把握趋势</a>，针对每日财经新闻和投资资讯，对正在进行的石油、<a href="http://m.so.com/s?q=%E8%B4%B5%E9%87%91%E5%B1%9E&amp;src=newstranscode" class="qkw">贵金属</a>交易作及时报道。勘博石油资深投资分析师田卫军和洪远对投资宏观趋势、投资操作等进行解析并解答观众的疑问，以引导投资者正确投资，传播最新石油投资理念，提供最权威的投资建议和市场分析、理财经验，是百姓投资的好帮手。</p><p>田卫军，勘博石油资深投资分析师，在宏观分析领域也取得了长足发展，编写了<a href="http://m.so.com/s?q=%E3%80%8A%E5%9B%BD%E9%99%85%E9%87%91%E8%9E%8D%E3%80%8B&amp;src=newstranscode" class="qkw">《国际金融》</a>的教材。田老师曾在<a href="http://m.so.com/s?q=%E5%B9%BF%E4%B8%9C%E5%8D%AB%E8%A7%86&amp;src=newstranscode" class="qkw">广东卫视</a>，陕西卫视做财经类特约嘉宾。在2010年后受贵金属行业邀请，田老师兼职于贵金属行业，独创了“趋势下博弈”的经典贵金属战法，在趋势下思考博弈，在博弈中判断方向，在他的指导下客户在2012年之后的大的下跌趋势中获取了几倍甚至几十倍的利润，在此期间田老师再次担任了深圳卫视即宁夏卫视的财经类特约嘉宾。目前在石油投资领域颇有研究，他将以独到的观点，灵活的思维为投资者保驾护航。</p><p><img src="http://p32.qhimg.com/t011ec58ebad46af41f.jpg?size=550x368"></p><p class="img-title">勘博石油资深分析师洪远</p><p>洪远，勘博石油资深投资分析师，13年期货、外汇、大宗商品研究、投资经验。资深期货、外汇、大宗商品投资分析师，是国内贵金属投资行业最早的拓荒者之一。早期在香港大型投资机构担任外汇分析师兼操盘手，历任沪浙地区数家实力机构的期货贵金属交易员、分析师。具有敏锐的商品期货、贵金属和石油交易嗅觉，不仅对国际贵金属、石油市场尤为熟悉，而且对大宗商品未来的趋势也是卓具远见，尤其擅长在变幻莫测的现货石油投资领域展开灵活的波段操作。独创的k线分型结构系统，对大宗商品现货投资的频繁短线操作具有非常有效的实战效果。曾长期担任<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E6%95%99%E8%82%B2&amp;src=newstranscode" class="qkw">中国教育</a>1频道，内蒙卫视，青海卫视，甘肃卫视，<a href="http://m.so.com/s?q=%E5%8E%A6%E9%97%A8&amp;src=newstranscode" class="qkw">厦门</a>卫视等卫视财经节目嘉宾。</p><p><img src="http://p31.qhimg.com/t0144870f83db592682.jpg?size=550x261"></p><p>北京勘博石油投资管理有限公司网站截图</p><p>北京勘博石油投资管理有限公司(简称“勘博石油”)于2014年12月9日注册成立，注册资本人民币2000万元，是北京石油交易所(简称“北油所”，由<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E7%9F%B3%E6%B2%B9&amp;src=newstranscode" class="qkw">中国石油</a>、中国海油、中化股份、北京国资等企业参股)第BZ031号会员单位。主要经营原油、成品油、燃料油、燃气、润滑油、综合类化工品等现货交易业务。公司依托北京丰富的石油石化资源和雄厚的金融资源，拥有专业的投资管理团队，为用户提供专业、权威、及时准确的咨询服务和指导，使用户放心投资、交易。勘博石油坚持公开、公平、公正的原则，投资者在现货订购系统中按国际报价成交，实行集中清算统一配送的买卖方式，同时提供询价等作为辅助买卖方式。交易商可以自行选择通过线上或线下的方式参与买卖。</p><p><img src="http://p35.qhimg.com/t0169c04f25aed26d85.jpg?size=550x371"></p><p class="img-title">北京勘博石油投资管理有限公司</p><p>勘博石油与<a href="http://m.so.com/s?q=%E4%B8%9C%E5%8D%97%E5%8D%AB%E8%A7%86&amp;src=newstranscode" class="qkw">东南卫视</a>的此次合作，不仅可以给观众提供正确、安全的投资引导，而且给观众普及了更多所投资方面的知识，有利于投资者在投资过程中少走弯路，正确投资，规避风险，取得收益。欢迎大家如期收看，了解投资技巧，创造收益新高峰。(吴苗苗)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://nb.people.com.cn/n/2015/0317/c365610-24183697.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='9ce5b71d584ba0a42d6f3f2b9792ed71'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>东南卫视</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '东南卫视与北油所所BZ031号勘博石油强强联手' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '东南卫视与北油所所BZ031号勘博石油强强联手'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";