s:15583:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>周年庆玩转英伦风 《魔范学院》新地图华丽开放- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">周年庆玩转英伦风 《魔范学院》新地图华丽开放</h1> <p id="source-and-time"><span id=source>超好玩游戏网</span><time id=time>2016-03-09 14:26:00</time></p> </header>  <div id="news-body"><p>在精彩纷呈的周年庆典即将到来之际，全球首款<a href="http://m.so.com/s?q=%E8%8C%83%E5%86%B0%E5%86%B0&amp;src=newstranscode" class="qkw">范冰冰</a>定制明星养成游戏<a href="http://m.so.com/s?q=%E3%80%8A%E8%8C%83%E5%86%B0%E5%86%B0%E9%AD%94%E8%8C%83%E5%AD%A6%E9%99%A2%E3%80%8B&amp;src=newstranscode" class="qkw">《范冰冰魔范学院》</a>已推出版本更新:不仅开放了极具魅力的“雾都”--伦敦，更有神秘帅哥空降!一起来围观吧!</p><p>【魅力雾都 <a href="http://m.so.com/s?q=%E6%B3%B0%E6%99%A4%E5%A3%AB%E6%B2%B3&amp;src=newstranscode" class="qkw">泰晤士河</a>的小资情调】</p><p>作为英国的首都，<a href="http://m.so.com/s?q=%E4%BC%A6%E6%95%A6&amp;src=newstranscode" class="qkw">伦敦</a>既是四大世界级城市之一，也是旅游揽胜和感受多元文化的绝佳之地:各具风情的哥特式和巴洛克式建筑矗立在<a href="http://m.so.com/s?q=%E6%B3%B0%E6%99%A4%E5%A3%AB%E6%B2%B3%E7%95%94&amp;src=newstranscode" class="qkw">泰晤士河畔</a>，安静地等待夕阳的余晖漫过塔尖;古老的街景与现代化的元素相辅相成，从悠久的历史积淀中孕育出鲜活的文明。</p><p><img src="http://p34.qhimg.com/t01f62d9b5164b60738.jpg?size=500x206"></p><p>伦敦的豪宅现已对玩家开放，追求高品质生活的各位不要错过哦!翻开一张油墨香气扑鼻的报纸，泡一杯小资情调的红茶，在魅力雾都享受<a href="http://m.so.com/s?q=%E6%B5%AA%E6%BC%AB%E7%9A%84%E9%BB%84%E6%98%8F&amp;src=newstranscode" class="qkw">浪漫的黄昏</a>吧!</p><p><img src="http://p33.qhimg.com/t01296c16da9ac3754a.jpg?size=500x235"></p><p class="img-title">【男神空降 邪魅帅气惹你尖叫!】</p><p>让玩家拥有与众多大牌男星亲密接触的机会，是<a href="http://m.so.com/s?q=%E3%80%8A%E9%AD%94%E8%8C%83%E5%AD%A6%E9%99%A2%E3%80%8B&amp;src=newstranscode" class="qkw">《魔范学院》</a>的亮点之一。此次版本更新又为男神名单添了一位新成员:这位名叫“塔塔”的帅哥拥有十分酷炫的发色，据说他是某当红组合的成员之一呢!对他感兴趣的童鞋，可以去<a href="http://m.so.com/s?q=%E9%A6%99%E6%B8%AF&amp;src=newstranscode" class="qkw">香港</a>参加他的派对哦!</p><p><img src="http://p33.qhimg.com/t01a9ee0e4dd931a9af.jpg?size=460x933"></p><p class="img-title">【神奇卡券 豪宅萌宠一券照看】</p><p>刚喂饱<a href="http://m.so.com/s?q=%E5%A4%A7%E9%98%AA&amp;src=newstranscode" class="qkw">大阪</a>和居里的萌宠，又惦记着上海家中的小宝贝?牵着戛纳游艇里的大<a href="http://m.so.com/s?q=%E9%87%91%E6%AF%9B&amp;src=newstranscode" class="qkw">金毛</a>散完步，还要去照顾香港家中的<a href="http://m.so.com/s?q=%E5%8F%98%E8%89%B2%E9%BE%99&amp;src=newstranscode" class="qkw">变色龙</a>?饲养萌宠是甜蜜的负担?没关系，学院商店全新推出神奇的“委托券”，大家可以一键照看所有豪宅里的宠物啦!</p><p><img src="http://p34.qhimg.com/t01d65dc20e3bece14a.jpg?size=500x357"></p><p>此外，新版本还将玩家等级提升至130级，同时新增了可爱的宝宝服饰哦。如果你想玩转英伦风、与新任男神甜蜜约会，那就快来《魔范学院》体验非一般的精彩人生吧!</p><p><img src="http://p35.qhimg.com/t01936ccc506b3e2bf3.jpg?size=500x300"></p><p class="img-title">关于游戏</p><p>《范冰冰魔范学院》是由掌上纵横发行，上海掌梦研发，<a href="http://m.so.com/s?q=%E8%8C%83%E5%86%B0%E5%86%B0%E5%B7%A5%E4%BD%9C%E5%AE%A4&amp;src=newstranscode" class="qkw">范冰冰工作室</a>唯一授权的全球首款范冰冰定制明星养成游戏。游戏以范冰冰为核心，力求全方位再现明星们闪耀的演艺生活，实现你成为<a href="http://m.so.com/s?q=%E6%98%8E%E6%98%9F%E7%9A%84%E6%A2%A6%E6%83%B3&amp;src=newstranscode" class="qkw">明星的梦想</a>!玩家通过参加游戏里的各种活动提升自己的知名度，一步一步走向成功，最终在游戏里成为与范冰冰齐名的巨星。难得的是范冰冰将在游戏中与广大粉丝进行互动，粉丝们可不要错过哦!</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.18touch.com/mfxyxdt.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='c35534dedac2c974a3d0a1e37012700f'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>魔范学院</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%AD%94%E8%8C%83%E5%AD%A6%E9%99%A2&amp;pn=1&amp;pos=8&amp;m=6dc8765d74b4a6d1faf3313eee999a66fdc41482&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F3953976.html" data-pos="1"> 终于等到你《<b>魔范学院</b>》神秘占卜免费开放啦 </a>   <li> <a href="/transcode?q=%E9%AD%94%E8%8C%83%E5%AD%A6%E9%99%A2&amp;pn=1&amp;pos=9&amp;m=427d3a82c9f245e9cfaa21e59fb688ab6a08bae6&amp;u=http%3A%2F%2Fwww.anqu.com%2Ffbbmfxy%2Fnews%2F179583.shtml" data-pos="2"> 白色情人节《<b>魔范学院</b>》围观塔塔GD秀恩爱 </a>   <li> <a href="/transcode?q=%E9%AD%94%E8%8C%83%E5%AD%A6%E9%99%A2&amp;pn=1&amp;pos=10&amp;m=4ba739f6a6e2a29b20de14e8bb19377668c1cf8f&amp;u=http%3A%2F%2Fwww.ptbus.com%2Ffbbmfxy%2F635426%2F" data-pos="3"> 让家更温馨《<b>魔范学院</b>》上海萌宠大盘点 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '周年庆玩转英伦风 《魔范学院》新地图华丽开放' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '周年庆玩转英伦风 《魔范学院》新地图华丽开放'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";