s:19825:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>走进苏童的书房 读书是一辈子受用的事- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">走进苏童的书房 读书是一辈子受用的事</h1> <p id="source-and-time"><span id=source>中国青年网</span><time id=time>2015-04-21 08:53:00</time></p> </header>  <div id="news-body"><p><img src="http://p34.qhimg.com/t01e956ec0009d8a2c0.jpg?size=399x600"></p><p><img src="http://p35.qhimg.com/t010205729429452402.jpg?size=400x380"></p><p><a href="http://m.so.com/s?q=%E8%8B%8F%E7%AB%A5&amp;src=newstranscode" class="qkw">苏童</a>书房里，有他自己作品的国外译作。</p><p class="header">被绿色包围的书房。</p><p>读书写作之余，苏童还喜欢打理花花草草。</p><p class="header">家中角落随性放着书。</p><p class="header">能进入苏童书房的人可不多。</p><p class="header">苏童收集的红酒瓶塞。</p><p>书房有大有小，藏书有多有少，书房作为读书人的私密空间，每个书房都有自己的个性。在第一个“江苏全民阅读日”即将到来之际，我们为您带来了一场不同寻常的“书香之旅”--走进名家书房。</p><p class="header">苏童语录</p><p class="header">读书是一辈子受用的事</p><p>别指望读书会给你涨工资，给你找工作，有什么看得见的效益，但在你人生的某一阶段，你会突然体会到它的作用，出其不意来到你的生活中。它不是一个短期效应，读书是一辈子受用的事。千万不要埋怨书白读了。</p><p class="header">留住阅读中的诗意</p><p>现在阅读变得面目繁多， 有纸质上的阅读，也有电子媒介的阅读。但我想，人到了一定年龄，他会觉得阅读还是要捧着一本书。书的厚度，纸张的潮湿感，拿在手上的质感，与冷冰冰的电子媒介相比，感觉还是不一样的。尤其是一本旧书，也许流转过十几个人，每个人都在上面留下痕迹。这本书到你手上，上面有许多陌生的名字。这样的纸质阅读，本身就是有故事的，是很有意思的事。纸质阅读的诗意，是电子阅读所无法替代的，是不会消亡的。人，毕竟还是想留住一点点在阅读中的诗意。</p><p class="header">苏童简介</p><p>苏童，1963年出生于江苏苏州，1984年毕业于北京师范大学中文系。1983年发表小说与诗歌处女作，当过教师和文学编辑。现居南京，为江苏省作家协会专业作家。</p><p>主要代表作为中篇小说<a href="http://m.so.com/s?q=%E3%80%8A%E5%A6%BB%E5%A6%BE%E6%88%90%E7%BE%A4%E3%80%8B&amp;src=newstranscode" class="qkw">《妻妾成群》</a>、《红粉》、《罂粟之家》、<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%89%E7%9B%8F%E7%81%AF%E3%80%8B&amp;src=newstranscode" class="qkw">《三盏灯》</a>，长篇小说《米》、<a href="http://m.so.com/s?q=%E3%80%8A%E6%88%91%E7%9A%84%E5%B8%9D%E7%8E%8B%E7%94%9F%E6%B6%AF%E3%80%8B&amp;src=newstranscode" class="qkw">《我的帝王生涯》</a>、《河岸》、《黄雀记》，另有<a href="http://m.so.com/s?q=%E3%80%8A%E8%A5%BF%E7%93%9C%E8%88%B9%E3%80%8B&amp;src=newstranscode" class="qkw">《西瓜船》</a>、《拾婴记》、<a href="http://m.so.com/s?q=%E3%80%8A%E7%99%BD%E9%9B%AA%E7%8C%AA%E5%A4%B4%E3%80%8B&amp;src=newstranscode" class="qkw">《白雪猪头》</a>、《茨菰》等百余篇短篇小说。</p><p>长篇小说<a href="http://m.so.com/s?q=%E3%80%8A%E6%B2%B3%E5%B2%B8%E3%80%8B&amp;src=newstranscode" class="qkw">《河岸》</a>获得第三届英仕曼亚洲文学奖(2009)和第八届华语传媒文学大奖(2010)。短篇小说<a href="http://m.so.com/s?q=%E3%80%8A%E8%8C%A8%E8%8F%B0%E3%80%8B&amp;src=newstranscode" class="qkw">《茨菰》</a>获第五届鲁迅文学奖(2010)。2011年获得布克国际文学奖提名。</p><p class="header">很多人想拍书房，都被我拒绝了</p><p>家中角落随性放着书，喜欢听乡村民谣，闲来品红酒，很有魅力的声音配上温暖的笑容--他就是苏童。</p><p>这样文艺款的男神，拥有什么样的书房?</p><p>进门迎面是扇百叶窗，左手一面墙连带拐角是顶天立地的书橱，书橱对面是一张不算大的书桌。桌上有一台黑色电脑，<a href="http://m.so.com/s?q=%E3%80%8A%E9%BB%84%E9%9B%80%E8%AE%B0%E3%80%8B&amp;src=newstranscode" class="qkw">《黄雀记》</a>里的保润、白小姐、柳生就是从这里诞生，走进现实世界的。</p><p>午后，没有阳光，这间以低沉色调为主的书房特别沉静。</p><p>苏童的书房，远没有他笔下女人的心理那么复杂，甚至可以说有点简单--长方形，面积10多平方米，比想像中的要小了些，但这书房又似乎很不简单--在这里，你似乎感觉不到时间的流逝，你会很从容地闲站，或坐在椅子上发呆。</p><p>对记者的造访，苏童是网开一面的。“很多人想来拍我的书房，都被我拒绝了。”也许，他不愿意外人打破这里的简单，这里的沉静。</p><p>没读过<a href="http://m.so.com/s?q=%E3%80%8A%E5%AE%89%E5%A8%9C%C2%B7%E5%8D%A1%E5%88%97%E5%B0%BC%E5%A8%9C%E3%80%8B&amp;src=newstranscode" class="qkw">《安娜·卡列尼娜》</a>是遗憾的</p><p>在谈到推荐书目时，苏童一连串报出多个作家的名字:列夫·托尔斯泰、<a href="http://m.so.com/s?q=%E7%A6%8F%E6%A5%BC%E6%8B%9C&amp;src=newstranscode" class="qkw">福楼拜</a>、福克纳、卡夫卡……几乎都是外国作家。</p><p>请他挑选最值得读的一本书时，他毫不犹豫地选中托尔斯泰的《安娜·卡列尼娜》。“《安娜·卡列尼娜》没有读过，那一定是遗憾的。它不仅是经典，而且很好看。”</p><p>听起来苏童似乎偏爱外国作家，但在他的藏书里，还是中国作家的作品偏多一些，书橱里周作人的全集、唐宋八大家的散文都有;上世纪七八十年代买的书，虽已陈旧，苏童也整齐地收在书橱里。</p><p>比较特殊的是最里面、靠近百叶窗的书橱，那里主要摆放的是苏童自己作品的各种译本，其中有英文、法文、意大利文、德文、荷兰文、日文、韩文、西班牙文、土耳其文等。</p><p class="header">读书写作之余，我是个园丁</p><p>原先，苏童是一笔一画在稿纸上“手工”创作的。1997年他开始使用<a href="http://m.so.com/s?q=%E7%94%B5%E8%84%91%E5%86%99%E4%BD%9C&amp;src=newstranscode" class="qkw">电脑写作</a>。虽然现在已非常熟悉电脑创作了。但苏童记忆中最恐怖的事是，“写出来七万字的东西，一下子全没了”。坐在电脑前，燃起一支烟回忆往事，苏童显得特别轻松，“那时用的还是WPS呢，现在的年轻人好多都不知道了。”</p><p>有了<a href="http://m.so.com/s?q=%E7%94%B5%E8%84%91%E7%9A%84%E5%B8%AE%E5%8A%A9&amp;src=newstranscode" class="qkw">电脑的帮助</a>，创作省了许多“爬格子”之苦，但对苏童来说，这份活依然不轻松。在电脑屏幕旁的一瓶安眠药，便是证明。不过，这书房里的世界，只是苏童的一半。他的另一半，在书房之外。</p><p>书房之外，是一座<a href="http://m.so.com/s?q=%E8%8A%B1%E6%9E%9C%E5%9B%AD&amp;src=newstranscode" class="qkw">花果园</a>。之所以称花果园，因为这里有花草，更有许多果木， 樱桃树、枇杷树、柠檬树、柿子树……推开百叶窗，即可看到花果园的一景，<a href="http://m.so.com/s?q=%E6%9E%9D%E5%8F%B6%E6%89%B6%E7%96%8F&amp;src=newstranscode" class="qkw">枝叶扶疏</a>，绿意扑面。</p><p>“我们去园子看看吧。”在大家的建议下，苏童带我们走出书房，来到外面的世界。他略带遗憾地说，你们迟来了几天，杏花、桃花、梨花全开过了，那株海棠也才谢。但我们并未失望，因为我们看到灯笼花开得正盛、郁金香不仅花枝招展，而且是罕见的品种，花瓣边缘有如锯齿般，美得不像真的!苏童说，这是妻子从欧洲带回来的。</p><p>这座美丽的花果园，是苏童的另一件作品。他说，“读书、写作之余，我就是一个园丁。”打理园子，占据了苏童大半的业余时间。他描述自己的园丁生活--“南京夏天太阳强的时候，在园子里浇水就要浇两个小时。<a href="http://m.so.com/s?q=%E6%A8%B1%E6%A1%83%E6%88%90%E7%86%9F%E6%97%B6&amp;src=newstranscode" class="qkw">樱桃成熟时</a>，要张网防鸟来偷吃。”但他权且将之当作读书、写作后的放松与休息，并不觉得辛苦，尤其是看到果实结果、成熟的过程，喜悦自心底而生。</p><p>追求生活中的诗意，享受阅读中的诗意。这就是苏童。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://wenhua.youth.cn/xwjj/xw/201504/t20150421_6590716.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='dac0dc130d38680e81c30f22763ca2d7'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>枝叶扶疏</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9E%9D%E5%8F%B6%E6%89%B6%E7%96%8F&amp;pn=1&amp;pos=6&amp;m=2c1c49e63530dab26fd464f5ee6f6cb15b3bb9a6&amp;u=http%3A%2F%2Fnews.china.com.cn%2Flive%2F2015-04%2F08%2Fcontent_32202442.htm" data-pos="1"> 利川存600岁水杉王 当今世界存活水杉大多是其后代 </a>   <li> <a href="/transcode?q=%E6%9E%9D%E5%8F%B6%E6%89%B6%E7%96%8F&amp;pn=1&amp;pos=7&amp;m=b2ec7b670e452c006003de2c2ce2947d28a37da4&amp;u=http%3A%2F%2Fwww.qstheory.cn%2Fwp%2F2016-01%2F27%2Fm_1117904463.htm" data-pos="2"> 以林业快速发展助推生态文明建设 </a>   <li> <a href="/transcode?q=%E6%9E%9D%E5%8F%B6%E6%89%B6%E7%96%8F&amp;pn=1&amp;pos=8&amp;m=183cca136cd4582f273804e1f869e229bbeed751&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0913%2F01%2FA601N46300014AED.html" data-pos="3"> 享受"野趣"远离"野蛮" </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '走进苏童的书房 读书是一辈子受用的事' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '走进苏童的书房 读书是一辈子受用的事'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";