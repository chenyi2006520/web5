s:15648:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>全台“灭顶”顶新有罪 道德审判不能取代程序正义- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">全台“灭顶”顶新有罪 道德审判不能取代程序正义</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2015-12-11 00:30:17</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E5%8F%B0%E6%B9%BE%E7%BD%91&amp;src=newstranscode" class="qkw">中国台湾网</a>12月10日讯 综合台媒报道，近日来，“<a href="http://m.so.com/s?q=%E9%A1%B6%E6%96%B0%E6%A1%88&amp;src=newstranscode" class="qkw">顶新案</a>”在台持续延烧，<a href="http://m.so.com/s?q=%E5%BD%B0%E5%8C%96&amp;src=newstranscode" class="qkw">彰化</a>地检署今天(10日)针对顶新制油自<a href="http://m.so.com/s?q=%E8%B6%8A%E5%8D%97&amp;src=newstranscode" class="qkw">越南</a>进口猪脂原料油案提起上诉。顶新制油则回应，进口原料以食用级规格采购、报关、受检、缴税，“黑心油”根本不存在。</p><p>自11月27日彰化地方法院判决被告魏应充等6人无罪以来，全台再掀“灭顶”<a href="http://m.so.com/s?q=%E6%B5%AA%E6%BD%AE&amp;src=newstranscode" class="qkw">浪潮</a>，从普通民众到学校医院处处都在拒用、拒售顶新产品。台湾第一高校--台湾大学校长杨泮池痛批顶新无罪是让全世界看笑话，并且宣布台大将“无限期抵制”顶新产品。不仅如此，恰逢2016台湾地区领导人选举前夕，国民党、民进党难得的一致表态，对判决强烈不满。台北市长柯文哲更是直言:这是2016选举迄今为止，“最大的催票行为”。</p><p>“顶新案”激起如此之大的民怨，彰化地方法院为何敢冒天下之大不韪判其无罪?</p><p>据台湾“中央社”报道，彰化地院法官在判决中指出，法官根据专业鉴定认为检方提出的证据--全案油品酸价、总极性化合物、重金属等均不足以认定是妨害卫生的饮食品，检察官也未能举证油品是来自于非健康猪只所熬制。简而言之，此案证据不足。</p><p>“顶新案”法官吴永梁、张琇涵与吕美玲在本案判决书中表示，舆论激情只在一时，追求程序正义却是永恒。法官工作非顺从舆论，任务是保障各基本权利，揭示核心价值。“如果我们做了不一样的判决，也许民众会比较高兴，但我们不能媚于舆论，只为了大快人心而做出令民众欢欣鼓舞的讨好判决。”被告的基本权利，不应是作为安抚民意的祭品。如果证据不足，即使眼前被告看起来依过去经历都是严重可疑，仍须勇敢判决无罪。</p><p>法官引述台湾<a href="http://m.so.com/s?q=%E8%BE%85%E4%BB%81%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">辅仁大学</a>法律系副教授吴豪人说法:“全世界的冤狱，结构都是一样的:残忍的犯罪，耸动的媒体报导，激愤的舆论，先入为主的警察，<a href="http://m.so.com/s?q=%E4%BB%A3%E7%BD%AA%E7%BE%94%E7%BE%8A&amp;src=newstranscode" class="qkw">代罪羔羊</a>的锁定，刑求逼供得来的唯一证据却是‘证据之王’的自白，跟随警察起舞的检察官，面对社会压力的法官。”等语，“本院心有戚戚焉”。</p><p>台湾名嘴唐湘龙就此事发表文章称，彰化地院法官敢做这种判决，“简直是对社会宣战，要非常<a href="http://m.so.com/s?q=%E5%B8%A6%E7%A7%8D&amp;src=newstranscode" class="qkw">带种</a>。判决书最好写的够漂亮。坦白说，判决的理由，和我一年多前的理解差不多。大家都困在‘原料’、‘饲料’、‘报关’、‘精炼’几个字眼里，做训诂、考据。好像一口咬定‘顶新’是‘明知而且恶意’进口了不能给人吃的原料油，再用无所不能的食品科技魔术‘精炼’成高价油品毒品消费者。是这样吗?判决书说:不是。”</p><p>台湾民众尽可以用道德标准全面抵制顶新，用实际行动让这个“黑心”企业快速倒闭，这无可厚非。但不必让食品安全成为最廉价的“选举诉求”，为政治人物所利用，也不必以“常识”之心质疑专业之道，更不应以道德审判取代程序正义。正如彰化地院法官所言:舆论激情只在一时，追求程序正义却是永恒。(中国台湾网 于斯文)</p><p>本文来源:中国台湾网</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/ent/hot/3007811_1.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='828bcf98c3c2aeb9e4194c921791b768'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>不能被代替</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%B8%8D%E8%83%BD%E8%A2%AB%E4%BB%A3%E6%9B%BF&amp;pn=1&amp;pos=5&amp;m=2eddf43fe1beffb9088e77e153f0d2cd86d5ef38&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fent%2Fhot%2F3007811_1.html" data-pos="1"> 全台"灭顶"顶新有罪 道德审判<b>不能取代</b>程序正义 </a>   <li> <a href="/transcode?q=%E4%B8%8D%E8%83%BD%E8%A2%AB%E4%BB%A3%E6%9B%BF&amp;pn=1&amp;pos=6&amp;m=fd855cd60cc4b3e5f372553ee752e48cc390dc66&amp;u=http%3A%2F%2Fenergy.chinanews.com%2Ftw%2F2015%2F12-11%2F7666321.shtml" data-pos="2"> 全台"灭顶"≠顶新有罪 道德审判<b>不能取代</b>程序正义 </a>   <li> <a href="/transcode?q=%E4%B8%8D%E8%83%BD%E8%A2%AB%E4%BB%A3%E6%9B%BF&amp;pn=1&amp;pos=7&amp;m=f2028971a76d64384d9a77eff7a888e7c10eefe6&amp;u=http%3A%2F%2Fdigi.163.com%2F16%2F0314%2F08%2FBI3T1BSV00162OUT.html" data-pos="3"> 刀叉<b>代替</b>筷子?海尔美的竞购德国百年厨具品牌 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '全台“灭顶”顶新有罪 道德审判不能取代程序正义' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '全台“灭顶”顶新有罪 道德审判不能取代程序正义'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";