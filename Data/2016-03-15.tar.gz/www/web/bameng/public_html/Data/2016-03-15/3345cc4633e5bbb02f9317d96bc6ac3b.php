s:17418:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>出门问问CTO雷欣:AlphaGo首场为何能赢李世石- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">出门问问CTO雷欣:AlphaGo首场为何能赢李世石</h1> <p id="source-and-time"><span id=source>网易</span><time id=time>2016-03-10 07:00:36</time></p> </header>  <div id="news-body"><p><img src="http://p32.qhimg.com/t01163d3a08ef0018f9.jpg?size=500x340"></p><p>编者按:3月9日，<a href="http://m.so.com/s?q=%E8%B0%B7%E6%AD%8C&amp;src=newstranscode" class="qkw">谷歌</a>AI系统AlphaGo大战世界<a href="http://m.so.com/s?q=%E5%9B%B4%E6%A3%8B&amp;src=newstranscode" class="qkw">围棋</a>冠军李世石，首场比赛<a href="http://m.so.com/s?q=AlphaGo&amp;src=newstranscode" class="qkw">AlphaGo</a>以1:0首战告捷，<a href="http://m.so.com/s?q=%E6%9D%8E%E4%B8%96%E7%9F%B3&amp;src=newstranscode" class="qkw">李世石</a>最终认输。这一结果震惊了围棋界，也令科技界对谷歌AI系统有了全新的认识。AlphaGo是如何战胜李世石的?如何评价AlphaGo的表现?这次胜利意味着什么?带着这些问题，<a href="http://m.so.com/s?q=%E7%BD%91%E6%98%93%E7%A7%91%E6%8A%80&amp;src=newstranscode" class="qkw">网易科技</a>采访了出门问问CTO<a href="http://m.so.com/s?q=%E9%9B%B7%E6%AC%A3&amp;src=newstranscode" class="qkw">雷欣</a>，听听这位科技人士怎么说。</p><p class="header">AlphaGo首场为何能赢李世石</p><p>雷欣称，在比赛开始前，我曾预测过机器会以3:2的比分获胜，不止是今天，我一直觉得谷歌既然敢发起这个挑战，一定是有了相当的把握机器会赢得最终的胜利。所以今天第一场AlphaGo赢，我没有丝毫的意外。</p><p>雷欣认为，AlphaGo 有一个非常大的优势，就是它是依靠强大的计算能力算法来进行决策的，而且不会受情绪的干扰，几乎不会出错。围棋是一个需要长时间的很费脑力的比赛，随着时间的推移，越到后期，人类的体力、心理承受能力都受到严峻的考验，但对于机器来说，时间越靠后，搜索空间越小，需要计算的量越小，决策的准确性越高。而且机器由于不会受到情绪干扰，会一直稳扎稳打，时间越往后，对机器越有利。如果人类不能在开局阶段一举奠定胜局，拖到收官阶段就非常困难了。此外，机器的特点是遇强则强，遇弱也不会很展现太强的实力，一旦碰到对方失误时只会采取最稳妥的方案去获胜，而不会去追求大胜而增加比赛的不确定性。</p><p>其实，<a href="http://m.so.com/s?q=Alpha&amp;src=newstranscode" class="qkw">Alpha</a> Go也有弱点。雷欣称，Alpha Go是一个算法，也就是一个软件，是通过 “剪枝”(通过一些启发式规则来避免搜索不太有胜算的局面)算法来计算棋局的，即使经过剪枝，棋局搜索空间也是巨大的。在开局的时候，需要计算的空间非常大，所以 Alpha Go 在开启的时候看起来棋力会有些弱。</p><p>有人说过，李世石的棋风也是开局弱，越到后面棋力越强，如果是这样的话，是和机器的风格比较像的，但前面我们也说过，越到后面，机器的优势越强，人类出错的机会越大，所以Alpha Go获胜，也是顺理成章的。</p><p class="header">AlphaGo第二场还会赢吗</p><p>雷欣认为，Alpha Go的表现比较稳健，这次的胜利其实从大局上并不能说明什么问题，毕竟对战的是人类的个体，和棋手的风格和情绪有很大关系，但不容忽视的是，机器每一次和 人类对决的都会越来越强，因为机器可以利用海量的数据和强大的计算资源不断学习，与人类相比，机器有更大的进步空间，这一点对人类对手来说是很恐怖的。</p><p>雷欣认为，下 一场Alpha Go赢的可能性还是非常大，因为目前Alpha Go很可能并没有发挥出真正的实力，并且Alpha Go并不会收到情绪的影响，而对于第一局已经认输的李世石来说，不仅要面对前面说的困难，可能还要面对第一局失败的阴影，干扰变得更大。不过一切皆有可 能，人类的情绪也不一定完全是负面的作用，也可能会起到一些激励的作用，或许李世石能发现Alpha Go的弱点，但总的来说5局比赛机器获胜的可能性要大很多。</p><p><a href="http://m.so.com/s?q=%E4%BA%BA%E5%B7%A5%E6%99%BA%E8%83%BD&amp;src=newstranscode" class="qkw">人工智能</a>什么时候能够超越人类?</p><p>雷欣称，在很多确定性的任务方面，机器已经超越人类。但是要全面超越人类，从目前的技术来讲，还需要比较长的时间，但人工智能今后会在越来越多的领域超越人类已经是不争的事实。</p><p>在未来，AI将更多会成为人类的工具。但是雷欣称自己非常反对“人工智能威胁论”，那个是属于一种臆想，我觉得人类研发的技术，完全可以被人类所用，并增强人类的能力。</p><p class="header">(小羿)</p><p>本文来源:网易科技报道 责任编辑:王超_NT4133</p><p><img src="http://p32.qhimg.com/t017b8de39b4bf9b403.jpg?size=600x422"></p><p><a href="http://m.so.com/s?q=%E4%BA%BA%E6%9C%BA%E5%A4%A7%E6%88%98&amp;src=newstranscode" class="qkw">人机大战</a>正在进行中</p><p><img src="http://p32.qhimg.com/t0175aec3f937f4109c.jpg?size=600x338"></p><p><img src="http://p32.qhimg.com/t019ddd373c95802df0.jpg?size=600x407"></p><p><img src="http://p31.qhimg.com/t01b6711921f2e4213b.jpg?size=325x450"></p><p class="img-title">李世石携爱女入场</p><p><img src="http://p31.qhimg.com/t017de967e0fa4480a2.jpg?size=293x450"></p><p><img src="http://p32.qhimg.com/t012f28ab9a91a227cb.jpg?size=266x450"></p><p class="img-title">谷歌董事长施密特入场</p><p><img src="http://p32.qhimg.com/t01345ebfd689ada054.jpg?size=279x450"></p><p><a href="http://m.so.com/s?q=%E6%9D%8E%E6%98%8C%E9%95%90&amp;src=newstranscode" class="qkw">李昌镐</a>现身</p><p><img src="http://p33.qhimg.com/t01a7bc83768420af64.jpg?size=600x389"></p><p class="img-title">人机大战现场图</p><p><img src="http://p31.qhimg.com/t01ada8dc19f648695f.jpg?size=600x352"></p><p><img src="http://p35.qhimg.com/t012fcbdae47b1e1265.jpg?size=600x401"></p><p><img src="http://p32.qhimg.com/t01f7eae107ceabbd1a.jpg?size=600x425"></p><p>赛前李世石合影</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://tech.163.com/16/0310/07/BHPF14VD00094P0U.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='d35ba6de77d52157a4afe0bfd4041f5c'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>雷欣</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%9B%B7%E6%AC%A3&amp;pn=1&amp;pos=2&amp;m=57cb41e80b979eacffd6e072bf032bd4106a7689&amp;u=http%3A%2F%2Fwww.donews.com%2Fidonews%2Farticle%2F8129.shtm" data-pos="1"> 出门问问CTO<b>雷欣</b>:我们并不需要强人工智能 </a>   <li> <a href="/transcode?q=%E9%9B%B7%E6%AC%A3&amp;pn=1&amp;pos=3&amp;m=35ebd9aaa40b4e9ccdb2250fe8eda4670ee9f808&amp;u=http%3A%2F%2Fscitech.people.com.cn%2Fn%2F2015%2F0512%2Fc1057-26983816.html" data-pos="2"> 格<b>雷欣</b>法则 </a>   <li> <a href="/transcode?q=%E9%9B%B7%E6%AC%A3&amp;pn=1&amp;pos=4&amp;m=abbea8240928eaf2c787658680b9628e8584a289&amp;u=http%3A%2F%2Fhouse.nen.com.cn%2Ffangchan%2Fweb%2Fhtml%2F100328%2F2014211%2F1392079232785.shtml" data-pos="3"> 热水器行业要对"格<b>雷欣</b>法则"说"不" </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '出门问问CTO雷欣:AlphaGo首场为何能赢李世石' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '出门问问CTO雷欣:AlphaGo首场为何能赢李世石'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";