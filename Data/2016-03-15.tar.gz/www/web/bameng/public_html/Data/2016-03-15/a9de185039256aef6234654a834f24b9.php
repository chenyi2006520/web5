s:14485:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>天猫双11预售不止5折 订吉列007特别版- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">天猫双11预售不止5折 订吉列007特别版</h1> <p id="source-and-time"><span id=source>中关村在线</span><time id=time>2015-10-16 05:06:00</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E5%A4%A9%E7%8C%AB&amp;src=newstranscode" class="qkw">天猫</a>2015双11全球狂欢节归来，<a href="http://m.so.com/s?q=%E5%90%89%E5%88%97&amp;src=newstranscode" class="qkw">吉列</a>天猫旗舰店配绝密武器，上演<a href="http://m.so.com/s?q=007%E5%BD%92%E6%9D%A5&amp;src=newstranscode" class="qkw">007归来</a>。预售活动现已打响，选购属于你的007时刻，另有预付定金15抵23元活动。</p><p>活动时间:10月13日0:00~11月10日23:59</p><p>1. 吉列007特别版天猫限量预售，买就送<a href="http://m.so.com/s?q=%E6%A0%BC%E7%93%A6%E6%8B%89&amp;src=newstranscode" class="qkw">格瓦拉</a>电影券(已含在礼盒内)</p><p>2. 吉列<a href="http://m.so.com/s?q=%E9%94%8B%E9%9A%90&amp;src=newstranscode" class="qkw">锋隐</a>手动剃须刀套装，下单即多送一支剃须泡</p><p class="header">3. 预付定金15元，能抵23元。</p><p><img src="http://p32.qhimg.com/t016aaa0c9ff6c997a7.jpg?size=640x410"></p><p>吉列致顺007特别版(吉列致顺1刀架1刀头+2刀头+啫喱+电影券)</p><p class="header">专柜价:231.9元</p><p class="header">定 金: 15元</p><p><a href="http://m.so.com/s?q=%E9%A2%84%E5%94%AE%E4%BB%B7&amp;src=newstranscode" class="qkw">预售价</a>:148元</p><p><img src="http://p32.qhimg.com/t01b5bc85b4669d7bb4.jpg?size=640x338"></p><p>致顺007™特别版，全球顺贴球科技无死角剃须。凭借优秀的刀锋技术，使剃须、强度和安全都达到完美的平衡。采用独创的5层超薄弹性感应刀片设计，挑战零摩擦，降低皮肤敏感，在剃须时能体验到皮肤顺滑的感觉。</p><p>刀头顶端的升级版Indicator显示型润滑条，蕴含更多<a href="http://m.so.com/s?q=%E8%8A%A6%E8%8D%9F&amp;src=newstranscode" class="qkw">芦荟</a>与维他命E精华，让剃须更顺滑并有效保护皮肤;配合而灵活感应刀头带来的前转轴技术，拥有比医学手术刀更薄更坚韧的刀锋，让剃须不留死角，更有突破性的&quot;精修刀&quot;背刀设计，轻松修剪鬓发、清理鼻下胡须、打理细节，个性塑型。</p><p>此外，还有锋隐致顺多种组合供网友选择，更多活动点击吉列天猫旗舰店。</p><p>吉列锋隐手动剃须刀套装 (1刀架1刀片+4刀头/片+剃须泡*2)</p><p class="header">专柜价:280.8元</p><p class="header">预售价:149元</p><p><img src="http://p34.qhimg.com/t01a5d66774695f40dd.jpg?size=640x235"></p><p>锋隐剃须刀荟萃吉列领先剃须技术，带来无比舒适顺畅剃须体验。独特5刀片弹性感应力，高精密度排列，均匀分散压力让你感觉不到刀锋。升级版显示型润滑条，含润滑成分让剃须更顺滑，效果更持久。柔软皮肤保护鳍帮助竖起须根，让须根更顺贴、平滑皮肤。</p><p>在设计上，采用大角度灵活感应刀头，前转轴技术带来更大角度，贴合面部轮廓。流畅性刀柄采用人体工学设计，手感舒适。</p><p>吉列天猫旗舰店双11预售，不止5折，还有更多个护产品及组合套装，优惠活动请点击。</p><p>2吉列锋隐致顺手动剃须刀详细参数</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jd.zol.com.cn/546/5461572_all.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='9d6a88851fdae9a913611b512da1adb7'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>吉列</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%90%89%E5%88%97&amp;pn=1&amp;pos=7&amp;m=94496d0849e08e31a6cdb31e53bfdd0f7ed3fea3&amp;u=http%3A%2F%2Fjd.zol.com.cn%2F550%2F5505632_all.html" data-pos="1"> 美女vs特工现身帝都 引<b>吉列</b>VR现场沸腾 </a>   <li> <a href="/transcode?q=%E5%90%89%E5%88%97&amp;pn=1&amp;pos=8&amp;m=e7928cd3300867971ad5c0b7c29f6ede9b50df2a&amp;u=http%3A%2F%2Ffinance.china.com.cn%2Fstock%2F20141124%2F2806176.shtml" data-pos="2"> 上海<b>吉列</b>三成股权17亿元挂牌 </a>   <li> <a href="/transcode?q=%E5%90%89%E5%88%97&amp;pn=1&amp;pos=9&amp;m=68583c8c1aa37a6bfecb69f0ec7be594d5d25ef5&amp;u=http%3A%2F%2Fnews.china.com.cn%2Frollnews%2Fnews%2Flive%2F2014-10%2F25%2Fcontent_29471698.htm" data-pos="3"> 汪民会见秘鲁能矿部副部长<b>吉列</b>墨·西诺·华玛尼 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '天猫双11预售不止5折 订吉列007特别版' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '天猫双11预售不止5折 订吉列007特别版'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";