s:15303:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>2016上海樱花节赏樱指南(最美视角+拍摄心经)- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">2016上海樱花节赏樱指南(最美视角+拍摄心经)</h1> <p id="source-and-time"><span id=source>上海本地宝</span><time id=time>2016-03-14 11:06:00</time></p> </header>  <div id="news-body"><p>【导语】:在上海想一睹樱花胜景，最不容错过的当属位于<a href="http://m.so.com/s?q=%E5%AE%9D%E5%B1%B1&amp;src=newstranscode" class="qkw">宝山</a>的顾村公园了。<a href="http://m.so.com/s?q=%E9%A1%BE%E6%9D%91%E5%85%AC%E5%9B%AD&amp;src=newstranscode" class="qkw">顾村公园</a>樱花节怎么玩?顾村公园这么大，进公园赏花应该往哪走?赏樱攻略来了!</p><p>每年3月中旬到4月上旬，都是樱花的当道之季。樱花在很多人心里意味着浪漫:花瓣以每秒5厘米的速度缓缓飘落在人们肩头、小道上，将地上染成一片美丽的粉红色，这场景想想，都醉了。</p><p>在上海想一睹樱花胜景，最不容错过的当属位于宝山的顾村公园了。目前，顾村公园种植的樱花面积是<a href="http://m.so.com/s?q=%E4%B8%8A%E6%B5%B7%E4%B9%8B%E6%9C%80&amp;src=newstranscode" class="qkw">上海之最</a>，达1100亩。樱花品种有60多种，数量达1.2万株。</p><p>从3月初开始，顾村公园内的樱花便依次开放。记者日前在公园内的樱花林木栈道和秋季观赏园看到，500多株河津樱中的大部分已经开花。公园负责人<a href="http://m.so.com/s?q=%E5%BC%A0%E5%BF%A0&amp;src=newstranscode" class="qkw">张忠</a>透露，顾村公园的樱花主力--近1万株的<a href="http://m.so.com/s?q=%E6%9F%93%E4%BA%95%E5%90%89%E9%87%8E&amp;src=newstranscode" class="qkw">染井吉野</a>预计要到3月下旬才会大面积开放。之后，其他姊妹品种也会争相斗艳，最后一批晚樱的盛开期可延续到4月15日左右。赏樱踏青，速速走起。</p><p><img src="http://p34.qhimg.com/t01870609c652f183b9.jpg?size=700x449"></p><p class="img-title">赏樱攻略:</p><p>3月初:根据往年的经验及今年的气候观察，顾村公园最早开放的河津樱、钟花樱、大渔樱等早樱品种在3月初进入盛花期，花色以深粉色、淡紫色为主，数量大约为1000株左右，颜色非常艳丽。</p><p>3月中下旬:此时开放的樱花数量最多，品种有阳春、神代曙、越之彼岸、染井吉野、美国等。花色以白色、淡粉色为主，单瓣居多。盛花期时满眼粉色的花海，非常壮观。</p><p>4月上旬:晚樱的盛花期，开放的樱花有松月，<a href="http://m.so.com/s?q=%E5%BE%A1%E8%A1%A3%E9%BB%84&amp;src=newstranscode" class="qkw">御衣黄</a>，郁金，兰兰，红豆等2000余株，有红、粉、黄、绿等重瓣品种，是色彩最丰富的时期哦。</p><p><img src="http://p35.qhimg.com/t015d609b5f6f11bb3c.jpg?size=700x494"></p><p class="img-title">最美视角:</p><p>顾村公园这么大，进公园赏花应该往哪走?</p><p>有经验的人剧透:进门直奔樱花林。樱花林是顾村公园最早播种的樱花区域，总面积约130000平方米，种有28种樱花树，近4000株。目前樱花林中的部分河津樱已经盛开。樱花木栈道、赏樱亭等都是赏樱的绝佳视角。</p><p><img src="http://p31.qhimg.com/t01fa9c5cd174a0aa9a.jpg?size=700x1007"></p><p class="img-title">拍摄心经:</p><p>不少专业和非专业的摄影爱好者都会扛着“长枪短炮”去拍花。以下几个简单的拍摄技巧可能会给您的照片增色不少，达到最佳效果哦。</p><p>时间:清晨和傍晚是拍摄的最佳时机，正午时分一般不推荐，因为阳光过于强烈容易曝光过度。</p><p>背景:可以仰拍以蓝天作背景，俯拍以绿色草地等作背景。切记不要选择太过繁多杂乱的树枝为背景。</p><p>微距:可以选取一朵或一簇樱花，用微距模式拍摄，可以使樱花花瓣的纹理、花蕊清晰可见。</p><p>动态:注意抓拍花间的蜜蜂<a href="http://m.so.com/s?q=%E8%9D%B4%E8%9D%B6&amp;src=newstranscode" class="qkw">蝴蝶</a>等，增加樱花作品的趣味和灵动。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://sh.bendibao.com/tour/2016314/157200.shtm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='d5025b64eff23244cefc2bf6f4a0d933'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>樱花盛开之季</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%A8%B1%E8%8A%B1%E7%9B%9B%E5%BC%80%E4%B9%8B%E5%AD%A3&amp;pn=1&amp;pos=8&amp;m=2f58278878cb2f3e5c2b0e2d3faf184a89044c11&amp;u=http%3A%2F%2Ffinance.ifeng.com%2Fa%2F20150306%2F13535582_0.shtml" data-pos="1"> 全世界的<b>樱花</b>都在等你 </a>   <li> <a href="/transcode?q=%E6%A8%B1%E8%8A%B1%E7%9B%9B%E5%BC%80%E4%B9%8B%E5%AD%A3&amp;pn=1&amp;pos=9&amp;m=7609e49c4a7a5f5798cac53cb1d18dad5dfecaa7&amp;u=http%3A%2F%2Fgd.sina.com.cn%2Fyf%2Flife%2F2016-01-18%2F11457867.html" data-pos="2"> 2016赏樱盛典:中山(三乡)<b>樱花</b>旅游文化节 </a>   <li> <a href="/transcode?q=%E6%A8%B1%E8%8A%B1%E7%9B%9B%E5%BC%80%E4%B9%8B%E5%AD%A3&amp;pn=1&amp;pos=10&amp;m=865428feb3a1e462a284b6f151f92dae13b38ead&amp;u=http%3A%2F%2Flady.southcn.com%2F6%2F2015-03%2F09%2Fcontent_119592622.htm" data-pos="3"> 春暖花开满浪漫 正是<b>樱花</b>好时节 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '2016上海樱花节赏樱指南(最美视角+拍摄心经)' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '2016上海樱花节赏樱指南(最美视角+拍摄心经)'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";