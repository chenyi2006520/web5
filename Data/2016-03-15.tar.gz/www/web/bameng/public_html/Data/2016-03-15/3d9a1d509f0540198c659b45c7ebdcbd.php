s:20945:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>科技大事件:俄罗斯裁定Android垄断 谷歌或将面临罚款- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">科技大事件:俄罗斯裁定Android垄断 谷歌或将面临罚款</h1> <p id="source-and-time"><span id=source>中国青年网</span><time id=time>2016-03-15 09:05:27</time></p> </header>  <div id="news-body"><p><img src="http://p32.qhimg.com/t01d51e410a7dd21458.jpg?size=592x500"></p><p>俄罗斯裁定<a href="http://m.so.com/s?q=Android&amp;src=newstranscode" class="qkw">Android</a>垄断 谷歌或将面临罚款</p><p>俄罗斯仲裁法院当地时间3月14日驳回了<a href="http://m.so.com/s?q=%E8%B0%B7%E6%AD%8C&amp;src=newstranscode" class="qkw">谷歌</a>的上诉，认定谷歌要求Android手机厂商预装谷歌搜索和<a href="http://m.so.com/s?q=%E8%B0%B7%E6%AD%8C%E5%9C%B0%E5%9B%BE&amp;src=newstranscode" class="qkw">谷歌地图</a>等服务违反了反垄断法。俄罗斯反垄断监管部门联邦反垄断局(以下简称“FAS”)去年9月裁定，谷歌在移动设备上预装搜索等应用的做法违反了相关法律。FAS称，谷歌一直允许Android手机厂商使用Google Play商店，但作为交换条件，手机厂商必须要在产品中预装谷歌的服务，其中包括搜索、谷歌地图等，这不利于第三方应用在Android操作系统中运行。因此FAS要求谷歌修改其与<a href="http://m.so.com/s?q=%E6%99%BA%E8%83%BD%E6%89%8B%E6%9C%BA&amp;src=newstranscode" class="qkw">智能手机</a>厂商之间的合作协议。如果未能遵守FAS的要求，谷歌可能面临最高相当于2014年该公司在俄罗斯市场移动应用营收15%的罚款。</p><p><img src="http://p31.qhimg.com/t01ae73dfe4da24242a.jpg?size=592x500"></p><p>继苹果之后美国政府再要求<a href="http://m.so.com/s?q=WhatsApp&amp;src=newstranscode" class="qkw">WhatsApp</a>协助解密手机</p><p>继苹果解锁案之后，近日美国司法部门又要求Facebook旗下的WhatsApp(网络信使)协助其展开窃听工作。据悉，因为WhatsApp用户的消息在发送过程中是经过加密的，所以美国政府的调查员无法在查案中顺利开展窃听工作。不同于之前苹果手机涉嫌的圣贝纳迪诺枪击案，WhatsApp涉及的案件目前还未公开，但据称不是恐怖主义案件。另外，美国政府要求WhatsApp协助的并不是仅仅“交出”案件涉嫌用户的相关存储数据，而是要实时得到他们的信息内容。</p><p><img src="http://p32.qhimg.com/t01f78a2a4d5204111b.jpg?size=592x500"></p><p>谷歌获<a href="http://m.so.com/s?q=%E6%97%A0%E4%BA%BA%E9%A9%BE%E9%A9%B6%E6%B1%BD%E8%BD%A6&amp;src=newstranscode" class="qkw">无人驾驶汽车</a>检测大巴专利</p><p>今年2月14日，谷歌公司的一辆测试用无人驾驶汽车与一辆大巴相撞，这是谷歌无人驾驶汽车首起系统判断错误而导致的事故。就在此次事故发生近一个月之后的3月8日，谷歌公司的两位研究人员申请的相关专利获批，这项专利主题为“无人驾驶汽车检测大巴”。这项专利详细描述了一项特殊图像识别技术，此技术能够识别校车的大小和颜色，从而让无人驾驶汽车更加谨慎的行驶。在上周的SXSW活动上，谷歌无人驾驶汽车业务负责人克里斯·乌尔姆森(Chris Urmson)声称，自从与大巴的车祸之后，谷歌公司已经对其无人驾驶汽车进行了约3500次的测试，以此确保类似的事故不再发生。</p><p><img src="http://p35.qhimg.com/t01296fb47698c0fc9f.jpg?size=592x500"></p><p><a href="http://m.so.com/s?q=%E8%BF%AA%E6%8B%9C&amp;src=newstranscode" class="qkw">迪拜</a>宣布将举办机器人<a href="http://m.so.com/s?q=%E5%A5%A5%E8%BF%90%E4%BC%9A&amp;src=newstranscode" class="qkw">奥运会</a></p><p>在日前举办的世界无人机大赛上，迪拜宣布将于2017年12月举办机器人奥运会。这场官方名为“世界未来运动会”的竞赛将会持续三天。机器人奥运会包括9个运动项目，包括无人驾驶汽车比赛、机器人足球、机器人运行载人无人机比赛、机器人游泳、机器人乒乓球、机器人摔跤和仿生运动员比赛等。迪拜政府宣称将建立机器人运动联盟。哈曼丹王子表示，在过去两年里，无人机大赛吸引了成百上千的来自世界各地的队伍。据悉，如果举办成功，迪拜打算每两年举办一次机器人奥运会。</p><p><img src="http://p35.qhimg.com/t01de42ec8c330e9d0b.jpg?size=592x500"></p><p>IHS:组装成一部<a href="http://m.so.com/s?q=Galaxy&amp;src=newstranscode" class="qkw">Galaxy</a> S7只需$255</p><p>IHS的一份尚未发表的报告显示，一部<a href="http://m.so.com/s?q=%E4%B8%89%E6%98%9F&amp;src=newstranscode" class="qkw">三星</a>Galaxy S7的所有零件和组装的成本只需$255，这与几年前的Galaxy S5造价相同。据悉，Galaxy S7中最贵的零件是<a href="http://m.so.com/s?q=%E9%AB%98%E9%80%9A&amp;src=newstranscode" class="qkw">高通</a>最新出的处理器骁龙820，但这款处理器也只花费三星$62，而且这款处理器只应用于销往中国、美国和日本的设备，三星在其他海外市场中使用的是更廉价的处理器。此外，Galaxy S7的摄像头价格仅为$13.70，其余零件则更便宜。将Galaxy S7定价为$670意味着三星公司将从中获得巨大的利益。</p><p><img src="http://p34.qhimg.com/t01a71666d1dd461f36.jpg?size=592x500"></p><p class="img-title">高通为骁龙芯片推出虚拟现实开发套件</p><p><a href="http://m.so.com/s?q=%E9%AB%98%E9%80%9A%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">高通公司</a>为以骁龙为处理器的手机和虚拟现实耳机推出了一款虚拟现实<a href="http://m.so.com/s?q=%E8%BD%AF%E4%BB%B6%E5%BC%80%E5%8F%91%E5%A5%97%E4%BB%B6&amp;src=newstranscode" class="qkw">软件开发套件</a>(SDK)。该套件显著提高了以骁龙820为处理器的手机和虚拟现实耳机的虚拟现实功能和电源使用效率，并且该套件还可以帮助开发人员快速地在一堆处理内核中分配处理工作量。高通SDK将在今年第二季度通过高通开发者网络免费提供给开发者。在本周的游戏开发大会上，高通公司会在三星的硬件上演示该套件的功能。</p><p><img src="http://p33.qhimg.com/t0122894d42b817bea0.jpg?size=592x500"></p><p><a href="http://m.so.com/s?q=%E5%BE%AE%E8%BD%AF&amp;src=newstranscode" class="qkw">微软</a>欲通过Minecraft开发人工智能技术</p><p>微软计划用25亿美元收购游戏软件<a href="http://m.so.com/s?q=Minecraft&amp;src=newstranscode" class="qkw">Minecraft</a>(我的世界)，旨在帮助孩子们进一步了解虚拟现实。当地时间3月14日，微软开展了新项目AIX--可以将人工智能技术添加到Minecraft中的软件开发平台。项目领导人Katja Hofmann表示，Minecraft的开放性和创造性将会让它在人工智能开发方面有更大的发展，且这是一种让年轻人在学习的同时获得乐趣的有效途径。微软表示已经邀请相关人员对AIX进行测试，并计划在2016年夏天获得软件的开放资源许可证。</p><p><img src="http://p35.qhimg.com/t01ef23f98b1085b799.jpg?size=592x500"></p><p>Adobe推出<a href="http://m.so.com/s?q=Project&amp;src=newstranscode" class="qkw">Project</a> Comet升级版:<a href="http://m.so.com/s?q=Experience&amp;src=newstranscode" class="qkw">Experience</a> Design</p><p>Adobe公司在2015年的Max大会上曾推出全新的桌面端UX原型工具Project <a href="http://m.so.com/s?q=Comet&amp;src=newstranscode" class="qkw">Comet</a>。当地时间3月14日，公司推出该软件的升级版并将其更名为Experience <a href="http://m.so.com/s?q=Design&amp;src=newstranscode" class="qkw">Design</a> (XD)。Adobe表示，XD可以与草图大师Sketch相媲美。据悉，XD配备了Artboards功能，允许用户在Photoshop的一个窗口中创建多个构图并进行大规模改变和创作。另外，XD还会预先装入一个UI工具包，且会为用户展示“最近文件”，供用户直接打开想要的文件。早期的Project Comet被计划设计为扩展Photoshop的照片编辑功能，目前，Adobe已将其发展成了“新一代”网页与移动应用的UX设计工具。</p><p><img src="http://p34.qhimg.com/t0172d29733ee471f6e.jpg?size=592x500"></p><p><a href="http://m.so.com/s?q=OnePlus&amp;src=newstranscode" class="qkw">OnePlus</a>推出新App:管理照片更方便直观</p><p>日前，OnePlu发布了新的App，意在为其智能手机用户提供更便捷的照片管理和编辑体验。这款实用无赘余的App仅配备了OnePlus最需要的功能，或者是用户最可能想用的功能。像很多的照片管理App一样，OnePlus的App可以自动按时间或种类编排照片，它提供的裁剪、旋转照片的工具更为简单，用户甚至还可以用绘画工具在自己的照片上涂画。目前，该App已在谷歌商店上架，可供免费下载且与OnePlus 2 的系统兼容。</p><p><img src="http://p32.qhimg.com/t0112d341bb30d50b71.jpg?size=592x500"></p><p>美国政府欲实施开源代码政策以支持软件业发展</p><p>认为开放源代码有助于更好制作软件的似乎并不仅仅是微软。美国首席信息官托尼·斯科特表示，联邦政府正在广泛征求公众意见，着手草拟联邦源代码政策来支持软件业的发展。斯科特表示，这项政策将会要求新开发软件的源代码为联邦政府所用。同时也将会使一部分新的联邦指定代码开源，为公众所知。其实早在2009年，SUN的CEO斯科特·麦克尼利就建议联邦政府应该授权软件。</p><p>中国青年网编译原创，转载请注明来源中国青年网(www.youth.cn)，否则将追究法律责任。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://d.youth.cn/tech_focus/201603/t20160315_7744637.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='9b0e46f147da9cc1cc8ba33ba434d826'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>安卓网</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%AE%89%E5%8D%93%E7%BD%91&amp;pn=1&amp;pos=7&amp;m=4b193d00cf961301ed3fa29d4a95ba21975d49d1&amp;u=http%3A%2F%2Fwww.techweb.com.cn%2Fdigitallife%2F2016-03-15%2F2296258.shtml" data-pos="1"> 挑战Windows!<b>Android</b> 7.0新功能帅气 </a>   <li> <a href="/transcode?q=%E5%AE%89%E5%8D%93%E7%BD%91&amp;pn=1&amp;pos=8&amp;m=1e52f7608314a25a182b338e0c3fc365c1d9eb23&amp;u=http%3A%2F%2Fgame.people.com.cn%2Fn1%2F2016%2F0314%2Fc210053-28198511.html" data-pos="2"> GMGC泛娱乐时代 手游PC无缝连接<b>安卓</b>模拟器大热 </a>   <li> <a href="/transcode?q=%E5%AE%89%E5%8D%93%E7%BD%91&amp;pn=1&amp;pos=9&amp;m=39efc020b674c0d57fda0ffab33d0b1a9348df48&amp;u=http%3A%2F%2Fnews.10jqka.com.cn%2Fcomment%2F588510635.shtml" data-pos="3"> 话题:谷歌加密<b>安卓</b>遭手机厂商抵制 担心运行速度变慢 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '科技大事件:俄罗斯裁定Android垄断 谷歌或将面临罚款' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '科技大事件:俄罗斯裁定Android垄断 谷歌或将面临罚款'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";