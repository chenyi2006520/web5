s:14649:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>FCA在美提升菲亚特销量 拟取缔独立经销店- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">FCA在美提升菲亚特销量 拟取缔独立经销店</h1> <p id="source-and-time"><span id=source>网易</span><time id=time>2016-03-14 08:01:33</time></p> </header>  <div id="news-body"><p>据<a href="http://m.so.com/s?q=%E3%80%8A%E5%BA%95%E7%89%B9%E5%BE%8B%E6%96%B0%E9%97%BB%E3%80%8B&amp;src=newstranscode" class="qkw">《底特律新闻》</a>报道，随着菲亚特汽车品牌销量持续下滑，<a href="http://m.so.com/s?q=%E8%8F%B2%E4%BA%9A%E7%89%B9&amp;src=newstranscode" class="qkw">菲亚特</a>-克莱斯勒汽车公司(FCA)近日为该品牌经销商提供了救助方案。</p><p class="header">盖世汽车网3月14日报道</p><p><img src="http://p33.qhimg.com/t019add53fee5240a3c.jpg?size=500x374"></p><p>盖世汽车讯 据《底特律新闻》报道，随着菲亚特汽车品牌销量持续下滑，菲亚特-<a href="http://m.so.com/s?q=%E5%85%8B%E8%8E%B1%E6%96%AF%E5%8B%92%E6%B1%BD%E8%BD%A6%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">克莱斯勒汽车公司</a>(FCA)近日为该品牌经销商提供了救助方案。</p><p>9日，FCA在与经销商的一次两小时的单独会议中提出了新的计划，该公司将允许经销商们在“<a href="http://m.so.com/s?q=%E5%85%8B%E8%8E%B1%E6%96%AF%E5%8B%92&amp;src=newstranscode" class="qkw">克莱斯勒</a>-Jeep-道奇-Ram”经销店中销售菲亚特汽车，并将修改产品价格。</p><p>FCA一位发言人表示，“这是为了促进销量增长。这些措施使经销商们能够拓展自己的业务，帮助他们提高自己的盈利能力。”</p><p>目前，经销商们拥有两种不同的经销模式，其中一种为菲亚特独立经销店，另一种为“克莱斯勒-<a href="http://m.so.com/s?q=Jeep&amp;src=newstranscode" class="qkw">Jeep</a>-道奇-Ram”经销店。FCA提出的方案使经销商们可以将两种模式的经销方式合并，虽然合并后菲亚特经销商将失去每月的租金补贴，然而却能够减少费用支出。</p><p><a href="http://m.so.com/s?q=%E3%80%8A%E7%BE%8E%E5%9B%BD%E6%B1%BD%E8%BD%A6%E6%96%B0%E9%97%BB%E3%80%8B&amp;src=newstranscode" class="qkw">《美国汽车新闻》</a>为首家报道FCA提出经销商救助方案的媒体，其在报道中称，在新的方案下，一位每月售出15辆菲亚特的经销商平均每年可以节省18万美元的费用。</p><p>每个州区业务的合并方案并不完全相同。FCA表示，其不打算关闭所有的菲亚特独立经销店。该公司一位发言人在一份声明中表示，“大部分菲亚特经销商同时拥有<a href="http://m.so.com/s?q=%E9%98%BF%E5%B0%94%E6%B3%95%C2%B7%E7%BD%97%E5%AF%86%E6%AC%A7&amp;src=newstranscode" class="qkw">阿尔法·罗密欧</a>的特许经营权，除菲亚特以外，我们同样计划在美国<a href="http://m.so.com/s?q=%E6%8F%90%E5%8D%87%E9%98%BF%E5%B0%94%E6%B3%95&amp;src=newstranscode" class="qkw">提升阿尔法</a>·罗密欧的销量。”</p><p>菲亚特于2011年回归美国市场，然而美国消费者至今未能接受这一来自异国的“古怪”品牌。菲亚特上月美国销量同比下跌9%，前两个月则下跌14.6%。</p><p>菲亚特去年最新推出了500X跨界车，加入500与500L的行列，今年后期该公司或还将添加一款124 Spider跑车至产品线。该公司在美国共拥有206家菲亚特经销店，其中包括126家菲亚特/阿尔法·罗密欧经销店和80家菲亚特独立经销店。</p><p>本文来源:盖世汽车网  责任编辑:王灏_NA3186</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://auto.163.com/16/0314/08/BI3R7EB800084TV0.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='72e0daf7c8684a184267fd6887dc3f2d'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>菲亚特</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%8F%B2%E4%BA%9A%E7%89%B9&amp;pn=1&amp;pos=3&amp;m=432b55d38e59274106626608f55703694dada838&amp;u=http%3A%2F%2Fauto.tom.com%2Fnews%2Fstorys_89054.html" data-pos="1"> <b>菲亚特</b>轿跑-采用全新平台 搭小排量引擎 </a>   <li> <a href="/transcode?q=%E8%8F%B2%E4%BA%9A%E7%89%B9&amp;pn=1&amp;pos=4&amp;m=161e1aeecd59cb5c6bab4e8592c7f4a3237ec219&amp;u=http%3A%2F%2Fwww.chexun.com%2F2016-03-14%2F103046228.html" data-pos="2"> FCA欲提升<b>菲亚特</b>销量 取缔部分独立经销店 </a>   <li> <a href="/transcode?q=%E8%8F%B2%E4%BA%9A%E7%89%B9&amp;pn=1&amp;pos=5&amp;m=355a5a91ed38b70cbd94ec7a18a004b78e11de77&amp;u=http%3A%2F%2Fauto.163.com%2F16%2F0311%2F09%2FBHS8K6V4000859EU.html" data-pos="3"> <b>菲亚特</b>克莱斯勒搭载麦格纳新一代视觉系统 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + 'FCA在美提升菲亚特销量 拟取缔独立经销店' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + 'FCA在美提升菲亚特销量 拟取缔独立经销店'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";