s:19750:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>“米市小红帽”--米市巷街道新时尚包勇 汤纯- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">“米市小红帽”--米市巷街道新时尚包勇 汤纯</h1> <p id="source-and-time"><span id=source>浙江日报</span><time id=time>2016-03-07 03:30:53</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E7%B1%B3%E5%B8%82%E5%B7%B7&amp;src=newstranscode" class="qkw">米市巷</a>，自古繁华， 风景秀丽，久负盛名的“湖墅八景”有两景就在米市巷。其中，“半道春红”地名保留至今，据<a href="http://m.so.com/s?q=%E3%80%8A%E8%A5%BF%E6%B9%96%E6%B8%B8%E8%A7%88%E5%BF%97%E3%80%8B&amp;src=newstranscode" class="qkw">《西湖游览志》</a>载:相传旧时夹路栽桃数里，<a href="http://m.so.com/s?q=%E6%98%A5%E5%A4%A9%E6%A1%83%E8%8A%B1%E5%BC%80&amp;src=newstranscode" class="qkw">春天桃花开</a>时，如火如荼，花落如红雨。</p><p>如今，这一抹红依旧在<a href="http://m.so.com/s?q=%E7%B1%B3%E5%B8%82%E5%B7%B7%E8%A1%97%E9%81%93&amp;src=newstranscode" class="qkw">米市巷街道</a>延续，他们的名字叫“<a href="http://m.so.com/s?q=%E7%B1%B3%E5%B8%82%E5%B0%8F%E7%BA%A2%E5%B8%BD&amp;src=newstranscode" class="qkw">米市小红帽</a>”，在路口，在街边，在小区内……都有着他们的身影。</p><p>买小学英语<a href="http://m.so.com/s?q=%E4%B9%A6%E5%AD%A6&amp;src=newstranscode" class="qkw">书学</a>英语8天学会8句话</p><p>对着镜子，戴上红色帽子，穿上崭新的红色马甲，用手轻轻抚摸胸口“<a href="http://m.so.com/s?q=%E6%9D%AD%E5%B7%9E%E5%B8%82%E5%8A%9F%E5%8B%8B%E5%BF%97%E6%84%BF%E8%80%85&amp;src=newstranscode" class="qkw">杭州市功勋志愿者</a>”的标识，标识下面写着<a href="http://m.so.com/s?q=%E6%9D%A8%E6%B4%81&amp;src=newstranscode" class="qkw">杨洁</a>两字。</p><p>“这是去年杭州市志愿者协会奖励的衣服，一直舍不得穿，国际盛会就要在杭州举办了，我们也要有崭新的形象。”杨洁说着，拿起桌上的小<a href="http://m.so.com/s?q=%E7%BA%A2%E6%97%97&amp;src=newstranscode" class="qkw">红旗</a>和矿泉水走出家门，开始一天的志愿者生活。</p><p>今年已经46岁的杨洁由于出生时大脑发育的不完善，智力比普通人略低，但是这丝毫没有影响到她一颗志愿服务的热心。</p><p>从2003年加入杭州市志愿者协会开始，杨洁先后参加了<a href="http://m.so.com/s?q=%E6%9D%AD%E5%B7%9E%E5%B8%82&amp;src=newstranscode" class="qkw">杭州市</a>敬老志愿者队、<a href="http://m.so.com/s?q=%E5%A4%A7%E8%BF%90%E6%B2%B3&amp;src=newstranscode" class="qkw">大运河</a>博物馆志愿者活动等三十几个志愿者活动，获得“浙江省红十字会抗震救灾优秀志愿者”“杭州市功勋志愿者”等荣誉。</p><p><a href="http://m.so.com/s?q=%E8%8E%AB%E5%B9%B2%E5%B1%B1%E8%B7%AF&amp;src=newstranscode" class="qkw">莫干山路</a>与文晖路交叉口便是杨洁岗位。“你好，现在是红灯，请不要闯红灯，在这里等候。”这句话，杨洁不知道已重复了多少遍，但她知道每天至少要喝两瓶矿泉水，因为说得口干了。</p><p>“早上从7点半到9点半，下午4点半到6点半，这早晚高峰闯红灯的人比较多，都是赶时间，多的时候要劝阻100多次。”杨洁说，每当别人硬闯红灯时，她会不开心，因为行人闯红灯意味着多了一份危险。</p><p>最近，杨洁的生活又多了一项兴趣，就是为了国际盛会学习英语。“Please，How do you do，Can I help you……”杨洁掰着数了数，学了8天，现在已经会说8句英语了。</p><p>“每天对着电脑学，每天学1句，家里还买了小学英语书。”杨洁说，希望峰会期间可以派上用场，能为国际友人服务。</p><p>一天的志愿工作很辛苦，但杨洁却很满足。“小时候得到很多人的帮助，现在，我要用我的能力，将这些温暖传递给更多人。”杨洁挥了挥手上的小红旗说，最喜欢的颜色就是红色，给人以温暖。</p><p>4000多名“米市小红帽”在城市中跳动</p><p>其实，杨洁是米市巷街道众多志愿者中一个小小的缩影，并且，他们还有一个共同的名字--“米市小红帽”。</p><p>目前，街道积极发挥党员的先锋模范作用，建立了由党员干部、居民群众和共建单位员工共4000余人组成的“米市小红帽”志愿服务队伍，达到市、区对街道平安巡防队伍建设人数要求的143%。</p><p>“街道125个党支部近2000名党员全部加入‘米市<a href="http://m.so.com/s?q=%E5%B0%8F%E7%BA%A2%E5%B8%BD&amp;src=newstranscode" class="qkw">小红帽</a>’，辖区内60余家文明单位和共建单位，包括学校、医院、酒店等，利用专业资源和职工力量认领‘米市小红帽’责任岗。”米市巷街道负责人说。</p><p>还有一股力量值得一提，那就是群众的力量。米市巷街道依托社区志愿服务站、工青妇等群团组织作用，通过社区宣传栏、新媒体平台、短信平台等途径，引导居民群众参与志愿服务。</p><p>“现在已经有900多名普通居民主动申请加入‘米市小红帽’。”这位负责人说，现在，加入“米市小红帽”已逐渐成为街道的一种精神时尚，“小红帽”也已成为米市巷一道独特的风景线。</p><p>而志愿者的服务不仅仅停留在文明劝导上，“米市小红帽”还活跃在困难帮扶、环境卫生、平安巡逻、“<a href="http://m.so.com/s?q=%E4%BA%94%E6%B0%B4%E5%85%B1%E6%B2%BB&amp;src=newstranscode" class="qkw">五水共治</a>”等各个角落。</p><p>这位负责人举例说，就在不久前，辖区内的4名志愿者在巡逻时，发现有人涉嫌向路边小店出售私自灌装的瓶装液化气，立即向公安机关汇报。</p><p>经过公安机关调查，瓶装液化气确实属于私自灌装，涉事当事人违反国家有关售卖液化气规定，给予相应行政处罚。</p><p>“群众的力量不容小觑，一个安全隐患就这样被排除了。”街道负责人说，2015年，街道零发案小区19个、占45%，其中沈塘苑小区连续三年实现“零发案”。</p><p class="header">服务国际盛会坚持“四点发力”</p><p>面对国际盛会，作为杭州市委、市政府所在地街道，米市巷街道按照市里提出的“米市巷要做好国际盛会志愿服务”的要求，开展“服务盛会、米市当先锋”主题专项行动。</p><p>“志愿者服务工作将围绕服务保障国际盛会这个圆心，在环境提升、平安稳定、文明劝导、信息收集等多个重点领域，坚持‘四点发力’。”街道负责人说，让这一抹红在城市中跳动。</p><p>在环境提升方面，组建环境提升巡查志愿服务队伍，每天固定时段对峰会环境提升项目、“五水共治”、小区环境卫生、道路停车秩序等进行巡查。</p><p>“我们还将建立志愿者非固定巡查举报奖励机制，鼓励热心居民及时发现并上报问题，确保第一时间抓好整改。”街道负责人说，通过人人参与，让辖区环境得到显著提升。</p><p>在平安稳定方面，街道将依托街道110社会应急联动中心、100余人巡防特保队伍，建立居民参与的平安巡防志愿服务队伍，形成平安防控“大联动”体系，每天早中晚3个时段以1+2模式，也就是1名执法队员及1名协警各带2名志愿者，分两组在小区和支辅路开展治安巡逻，切实提高对不稳定因素排查和突发事件应对的应急联动反应能力。</p><p>在文明劝导方面，重点在辖区莫干山路、<a href="http://m.so.com/s?q=%E6%B9%96%E5%A2%85%E8%B7%AF&amp;src=newstranscode" class="qkw">湖墅路</a>、密渡桥路等“两纵六横”主要交通干道路口设置文明劝导岗位。上下班两个高峰时段，每个重要路口分别落实4名“米市小红帽”对过往行人、车辆进行文明劝导，确保道路畅通。</p><p>此外，信息收集方面，街道将按照“横到边、纵到底、布局广、触角深、覆盖大”的原则，有效依托网格化工作平台，发挥网格员和信息员的基层触角力量，建立起覆盖不同层次、各行各业的信息员队伍。</p><p>“在‘两网融合’的基础上，配齐配全‘平安通’等信息化工具，利用电话、短信、网络等快速便捷的信息手段，将信息情报以最快的速度、最高的效率直报到街道和公安分局大情报平台，确保各类信息第一时间掌握到位。”街道负责人说。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://zjrb.zjol.com.cn/html/2016-03/07/content_2952906.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='ff8af94d4815bcce99d109274512591a'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>包勇</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%8C%85%E5%8B%87&amp;pn=1&amp;pos=2&amp;m=5fa5183c24b33b359bb402e106457aa2bbbb4c7e&amp;u=http%3A%2F%2Fcul.qq.com%2Fa%2F20160312%2F032286.htm" data-pos="1"> 《红楼梦》中假清高的妙玉 </a>   <li> <a href="/transcode?q=%E5%8C%85%E5%8B%87&amp;pn=1&amp;pos=3&amp;m=3c760c2a0eb77267edb60fb3727af23c333fdfbe&amp;u=http%3A%2F%2Fnews.163.com%2F16%2F0308%2F04%2FBHJVC27G00014AEF.html" data-pos="2"> 杭州跨境电商闯出大名堂 </a>   <li> <a href="/transcode?q=%E5%8C%85%E5%8B%87&amp;pn=1&amp;pos=4&amp;m=9fa32009f2dcb528cd91f7408b73dc5374a17b51&amp;u=http%3A%2F%2Fhangzhou.zjol.com.cn%2Fsystem%2F2016%2F03%2F11%2F021061711.shtml" data-pos="3"> 杭州跨贸电商产业园下沙园区2015年交易额达25.2亿元 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '“米市小红帽”--米市巷街道新时尚包勇 汤纯' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '“米市小红帽”--米市巷街道新时尚包勇 汤纯'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";