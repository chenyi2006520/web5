s:15718:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>孩子，不要埋怨!- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">孩子，不要埋怨!</h1> <p id="source-and-time"><span id=source>中国日报网</span><time id=time>2015-04-28 10:46:00</time></p> </header>  <div id="news-body"><p>[提要]  女儿最近总是对一些事情提出意见，比如菜做咸了，淡了。话说，我不是个整天希望让孩子或者逼迫孩子，或者以洗脑的方式让孩子来感恩父母，女儿偶尔的小埋怨，我也会深思。就是这么样一个孩子，偶尔会埋怨，偶尔又会自我安慰，偶尔又<a href="http://m.so.com/s?q=%E5%BF%8D%E9%9A%90&amp;src=newstranscode" class="qkw">忍隐</a>得让人心疼。</p><p class="header">文图/闫晓苹</p><p><img src="http://p35.qhimg.com/t01d6e82645a7b5f11f.jpg?size=500x332"></p><p>女儿最近总是对一些事情提出意见，比如菜做咸了，淡了。吃的东西不如她的意了。虽然有句话说为什么大人不挑食，因为大人买的都是自己爱东西。这话虽然有些笑意，但也确实是这么个理儿。可是我们家里吃饭，基本是按营养和女儿挑选的食物来做饭。有时候也看时间，偶尔外面吃，偶尔<a href="http://m.so.com/s?q=%E5%BF%AB%E9%A4%90&amp;src=newstranscode" class="qkw">快餐</a>一下。</p><p>女儿有阵子迷<a href="http://m.so.com/s?q=%E9%B8%A1%E8%9B%8B%E7%B3%95&amp;src=newstranscode" class="qkw">鸡蛋糕</a>，爸爸做得也不错。但每次爱往里放葱，这个葱就是女儿讨厌的东西，所以每次吃的时候都要埋怨几句。我说孩子，你应该感谢爸爸为你做饭，而且<a href="http://m.so.com/s?q=%E8%91%B1%E8%8A%B1&amp;src=newstranscode" class="qkw">葱花</a>是浮在上面的，爸爸都会吃掉的，你有什么好担心的呢?</p><p>偶尔早餐时，给女儿梳头，她会说，我要你梳个漂亮的，我喜欢的。我说这需要时间，妈妈是根据时间来决定给你梳什么头型。你应该因为有个会梳头的妈妈而觉得开心，而不应该是不是你喜欢的头型，进行埋怨或者不开心。</p><p>其实很多事情只有三个方向，要么喜欢，要么讨厌，要么漠然。女儿小激烈的性格，一般表达比较明显。</p><p>由于她已经六周岁了，我会是不是地指派一些活给她干。清晨叠被子，女儿会说，我不会叠，这被子好大。我问她:你晚上盖被子时候为什么不嫌被子大呢?被子大你可以慢慢叠，你越不去叠，你永远也学不会叠被子。这只是简单的生活，甚至离生存两字都很远。你都学不会?</p><p>话说，我不是个整天希望让孩子或者逼迫孩子，或者以洗脑的方式让孩子来感恩父母，女儿偶尔的小埋怨，我也会深思。比如今天清晨她吃昨天去超市自己精选的一小桶方便面，吃的时候她说好香啊，真香。我说妈妈偿一口，我偿了一下，有些淡。我说你为什么不要求放些调料呢?女儿在这之前刚把我手机摔散在地上，被我说了几句，所以她对方便面有些淡没敢再要求加盐。我当时就很内疚，对女儿说:合理要求你可以提，比如你说淡，妈妈如果坚持不用加调料的话，你可以让妈妈偿一口，来证明你说的是事实。何必忍隐呢?</p><p><a href="http://m.so.com/s?q=%E7%94%9F%E6%B4%BB%E5%A6%82%E6%AD%A4%E7%90%90%E7%A2%8E&amp;src=newstranscode" class="qkw">生活如此琐碎</a>，细节如此零落，我所说所做所想，只是想让女儿从小长颗感恩的心，因为只要不埋怨，充满感激，就会快乐。与人，与己都是好事。但并不是所有事情都要去忍，比如确实某些事情让自己不舒服，确实伤害到自己一些不应该被伤害的利益，就要去提出要求。</p><p>这个度真是难<a href="http://m.so.com/s?q=%E6%92%91%E6%8E%A7&amp;src=newstranscode" class="qkw">撑控</a>啊。</p><p>但是孩子，还是请你不要埋怨，生活多了埋怨，你就会活在不快乐中，你眼中只有埋怨，不再有快乐。</p><p>而女儿有时候又是个超会安慰自己的孩子。其实她更是个有心的孩子，前阵子我总说她站姿不行，走姿不行，结果她真的放在心上。不消一个月时间，把这俩个姿式全部改正标准。现在唯有坐姿不是很正确，经常要说。女儿却自我安慰说:总算有进步了，站姿和走姿是可以了，就差坐姿了，我要好好再练练了。</p><p>就是这么样一个孩子，偶尔会埋怨，偶尔又会自我安慰，偶尔又忍隐得让人心疼。</p><p>可是，无论如何，先要把埋怨从孩子生活中的字典去掉，因为少些埋怨，人才过得更开心。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.chinadaily.com.cn/hqcj/xfly/2015-04-28/content_13617172.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='3dfaf92b0d301d123bfe1f2b34f31ed0'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>忍隐</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%BF%8D%E9%9A%90&amp;pn=1&amp;pos=7&amp;m=d63a55141a2481d7aff3fef9e4ced7557a475e1c&amp;u=http%3A%2F%2Fnews.sh.xkhouse.com%2Fhtml%2FOther%2F140825%2FD1PPO1408936461.html" data-pos="1"> 楼市压力增大 大盘抢跑小盘调整"<b>忍隐</b>捂盘"策略 </a>   <li> <a href="/transcode?q=%E5%BF%8D%E9%9A%90&amp;pn=1&amp;pos=8&amp;m=0b7ee5ccb65864cc9f74ca6ec6f3e30343c9c603&amp;u=http%3A%2F%2Fwww.cnqiang.com%2Fjunshi%2Fjunbai%2F201603%2F012688932.html" data-pos="2"> B-21来了:究竟是量产型B-2还是终极版隐轰 </a>   <li> <a href="/transcode?q=%E5%BF%8D%E9%9A%90&amp;pn=1&amp;pos=9&amp;m=0102f3b1df906427f5052e8804364f154a6b242f&amp;u=http%3A%2F%2Fwww.91danji.com%2Fnews%2F132693.html" data-pos="3"> LOL撸圈盘点 隐于幕后的操盘手:论辅助的重要性 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '孩子，不要埋怨!' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '孩子，不要埋怨!'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";