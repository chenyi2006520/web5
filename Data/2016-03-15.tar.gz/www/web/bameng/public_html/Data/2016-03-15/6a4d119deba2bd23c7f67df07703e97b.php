s:20668:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>中国艺术品金融市场呈现蓝海，艺条龙联合荣宝斋(上海)拍卖共同发力- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">中国艺术品金融市场呈现蓝海，艺条龙联合荣宝斋(上海)拍卖共同发力</h1> <p id="source-and-time"><span id=source>新浪</span><time id=time>2016-03-09 17:44:41</time></p> </header>  <div id="news-body"><p>看“最贵在世国宝艺术家”崔如琢谈中国的艺术品升值空间</p><p><img src="http://p31.qhimg.com/t01c3ede659218175c2.jpg?size=513x408"></p><p>艺术家 <a href="http://m.so.com/s?q=%E5%B4%94%E5%A6%82%E7%90%A2&amp;src=newstranscode" class="qkw">崔如琢</a></p><p>近日，艺术家崔如琢向北京故宫文物保护基金会捐赠1亿元人民币，用于故宫的文化遗产保护和博物馆事业发展，成为目前为止故宫文物保护基金收到的最大一笔个人现金捐赠，此举在社会上引起极大反响。</p><p>崔如琢，著名书画家、鉴赏家、收藏家，在全球最贵的在世艺术家中位列前三，其作品曾多次在艺术品市场掀起腥风血雨，被称为“最贵在世国宝艺术家”。</p><p>崔如琢作品<a href="http://m.so.com/s?q=%E3%80%8A%E7%91%9E%E9%9B%AA%E4%B8%B9%E6%9E%AB%E6%BA%AA%E5%B1%B1%E6%97%A0%E5%B0%BD%E3%80%8B&amp;src=newstranscode" class="qkw">《瑞雪丹枫溪山无尽》</a></p><p>在谈及中国艺术品的升值空间时，崔老师说，<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E8%89%BA%E6%9C%AF%E5%93%81&amp;src=newstranscode" class="qkw">中国艺术品</a>还有很大的升值空间，因为美国当代的一个75岁的艺术家的作品最高价是3500万美金。毕加索的一幅作品去年拍卖成交价为1.14亿美金，<a href="http://m.so.com/s?q=%E6%A2%B5%E9%AB%98&amp;src=newstranscode" class="qkw">梵高</a>最贵的卖到了8000万美金。而中国的近百年的艺术大家，最贵的就是张大千的2200万港币，虽然古代的有卖到三四千万的，但是总体来说和西方的差距还是很大的。那是不是<a href="http://m.so.com/s?q=%E7%9F%B3%E6%B6%9B&amp;src=newstranscode" class="qkw">石涛</a>、“八大”就不如梵高、<a href="http://m.so.com/s?q=%E6%AF%95%E5%8A%A0%E7%B4%A2&amp;src=newstranscode" class="qkw">毕加索</a>，不是的。梵高、毕加索在西方是艺术大家，代表了西方的绘画艺术，而石涛、“八大”代表的是东方的艺术。梵高、毕加索的价位就比石涛、“八大”高上百倍，你说这可能吗?我敢说，不远的将来，我们的艺术大师作品的艺术价值会超过西方的。当初我买<a href="http://m.so.com/s?q=%E6%9D%8E%E5%8F%AF%E6%9F%93&amp;src=newstranscode" class="qkw">李可染</a>、李苦禅的作品也就200元人民币，现在增值了上千倍，是不是说他们的艺术成就就增值了上千倍呢?我们现在刚改革开放25年，随着国家的富强，人民的富裕，我们的艺术品收藏价值会大大的提高，最起码来讲，我们历史上的大师跟毕加索、梵高可以并驾齐驱。我们中华民族对艺术的厚爱绝对不亚于西方。</p><p>我们也可以从德勘与ARTTACTIC联合出版的<a href="http://m.so.com/s?q=%E3%80%8A2014%E8%89%BA%E6%9C%AF%E5%93%81%E9%87%91%E8%9E%8D%E6%8A%A5%E5%91%8A%E3%80%8B&amp;src=newstranscode" class="qkw">《2014艺术品金融报告》</a>中看到艺术品的升值潜力，报告显示，艺术品在过去的80-90年平均增长率高达14.4%，远高于同期的股票和房产。而纵观国内投资现状，大量资金从楼市、股市流入到艺术品市场，艺术品成为股票和房地产之外的第三大投资工具。</p><p>中国艺术品质押变现困难，艺条龙金融联合<a href="http://m.so.com/s?q=%E8%8D%A3%E5%AE%9D%E6%96%8B&amp;src=newstranscode" class="qkw">荣宝斋</a>(上海)拍卖共同发力</p><p><img src="http://p31.qhimg.com/t01837bf1e5b607a9fe.jpg?size=560x307"></p><p>近年来国内艺术品市场需求急增、交易活跃，占文化产业的比重不断上升，大量资金从楼市、股市流入其中。据兴业银行与BCG<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E5%9B%BD%E7%A7%81%E4%BA%BA%E9%93%B6%E8%A1%8C2015%3A%E5%8D%83%E5%B8%86%E7%AB%9E%E6%B8%A1+%E5%BE%A1%E9%A3%8E%E8%80%8C%E8%A1%8C%E3%80%8B&amp;src=newstranscode" class="qkw">《中国私人银行2015:千帆竞渡 御风而行》</a>报告显示，2015年中国私人财富将达到人民币110万亿元。按照国际标准5%的投资用于艺术品，艺术品的投资需求将达到5.5万亿元。根据我们初步测算，仅10%的艺术品有流通周转需求，就可以产生5500亿元的艺术品质押变现市场。作为国家监管层鼓励的创新领域，艺术品市场领域的金融创新已经被业内人士公认是一片待开发的<a href="http://m.so.com/s?q=%E8%93%9D%E6%B5%B7&amp;src=newstranscode" class="qkw">蓝海</a>。</p><p>在艺术品市场，很多艺术品经营机构和个人投资者都面临资金链紧张的困境，为了避免因暂时“缺血”而惨遭市场淘汰，他们都迫切希望有金融机构能够利用他们的广阔资源平台直接为市场和投资者“输血”。因此，在所有的理财产品当中，艺术品质押贷款业务是最为业界所期待的。</p><p>然而，相比其他产业，文化产业获得金融支持通常不易。作为资金供应主体的银行，目前并没有大规模给艺术品市场提供信用。最关键的还是业务的系统性机制未能建立起来。所以整体来看，艺术品质押变现市场需求量大，但变现困难，很难真正解决艺术品经营机构和个人艺术品收藏者的资金难题。</p><p><img src="http://p32.qhimg.com/t01d5df9f89c2d3d4a1.jpg?size=548x213"></p><p class="img-title">荣宝斋(上海)拍卖拍品</p><p>在艺术品质押变现困难的市场环境下，艺条龙金融联手荣宝斋(上海)拍卖共同发力，对接艺术品的质押变现和投资需求，一方面为拥有文化艺术资产的用户提供高效便捷的质押变现服务，另一方面为有闲置资金的投资者提供安全可靠的高收益理财服务。</p><p>在艺条龙金融，审核通过的艺术品交由荣宝斋(上海)拍卖的专家团队对其进行估值，并出具评估报告，质押率一般在20%-50% ;由专业博物馆(<a href="http://m.so.com/s?q=%E9%87%91%E5%88%9A&amp;src=newstranscode" class="qkw">金刚</a>博物馆)对其进行线下保管，保险公司对其进行承保;若逾期则由担保机构或大型集团公司先行垫付，再由合作拍卖行进行拍卖。多重措施保证艺术品的安全和投资用户的资金安全。与此同时，<a href="http://m.so.com/s?q=%E7%8E%8B%E5%80%9A%E5%B1%B1&amp;src=newstranscode" class="qkw">王倚山</a>、俞晓夫、周玉峰等<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E8%89%BA%E6%9C%AF&amp;src=newstranscode" class="qkw">中国艺术</a>行业的领军人物全程参与指导，全力打造安全的艺术品投融资环境。保证借款人和投资人的权益。</p><p>据工作人员介绍，作为国内首家专注<a href="http://m.so.com/s?q=%E4%BA%8E%E6%96%87%E5%8C%96&amp;src=newstranscode" class="qkw">于文化</a>·艺术·影视·供应链领域的互联网金融服务平台，艺条龙金融在不断探索“互联网+金融+文化艺术“的跨界<a href="http://m.so.com/s?q=%E5%95%86%E4%B8%9A%E6%A8%A1%E5%BC%8F&amp;src=newstranscode" class="qkw">商业模式</a>。在与荣宝斋(上海)拍卖有限公司达成深度合作的同时，联合中国国家美术馆、中国国家画院、<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E5%9B%BD%E5%AE%B6%E5%8D%9A%E7%89%A9%E9%A6%86&amp;src=newstranscode" class="qkw">中国国家博物馆</a>、中国美术家协会等专业机构，将互联网技术与金融服务相融合，深耕文化艺术领域，致力于推动我国普惠金融和文化艺术行业的创新与发展。</p><p>艺条龙PC版官网上线送壕礼，万元体验金等你来拿!</p><p>经过长时间的筹备与调试，艺条龙金融PC版将于3月中旬正式上线。全新的界面、全新的视觉体验、全新的操作享受，是艺条龙金融平台一个新的开始。为了更好回馈社会各界，艺条龙平台PC版上线即将推出【万元体验金全民共分享】活动!</p><p>新用户注册即送万元体验金，独享新人特惠。</p><p>从艺条龙金融PC版上线起，广大投资者只要在艺条龙金融理财端成功注册认证，即可享受1万元体验金，首次投资100元再送1万元体验金，瞬间成为万元户，再也不是梦。</p><p>老用户累计投资，最高可获得50万体验金。</p><p>投资者最高可获得50倍的专享体验金(50万元)，与此同时，每邀请1名好友任意投资即可再得1万元体验金(上不封顶)。</p><p>伴随着三月女神节，艺条龙金融还将推出更多精彩活动，广大艺术品收藏爱好者及有投资需求的朋友，可关注微信服务号【艺条龙】 (Etiaolong-02)，参与更多优惠活动，实现安全便捷理财。本稿件所含文字、图片和音视频资料，版权均属<a href="http://m.so.com/s?q=%E9%BD%90%E9%B2%81%E6%99%9A%E6%8A%A5&amp;src=newstranscode" class="qkw">齐鲁晚报</a>所有，任何媒体、网站或个人未经授权不得转载，违者将依法追究责任。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.sina.com.cn/o/2016-03-09/doc-ifxqhfvp0643961.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='7c9493e1880d4b8116efdffc6b0ea89c'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>艺术品拍卖</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%89%BA%E6%9C%AF%E5%93%81%E6%8B%8D%E5%8D%96&amp;pn=1&amp;pos=5&amp;m=65b2837e561a304b2b3da6342d1dc89858504757&amp;u=http%3A%2F%2Fnews.sina.com.cn%2Fo%2F2016-03-09%2Fdoc-ifxqhfvp0643961.shtml" data-pos="1"> 中国<b>艺术品</b>金融市场呈现蓝海,艺条龙联合荣宝斋(上海)<b>拍卖</b>共同发力 </a>   <li> <a href="/transcode?q=%E8%89%BA%E6%9C%AF%E5%93%81%E6%8B%8D%E5%8D%96&amp;pn=1&amp;pos=6&amp;m=d1e7ae42b70402449210e6497cbcd37966918843&amp;u=http%3A%2F%2Fmoney.eastmoney.com%2Fnews%2F1617%2C20160307601462630.html" data-pos="2"> 2016年<b>艺术品拍卖</b>趋势预测:供给侧改革或引发新黑马 </a>   <li> <a href="/transcode?q=%E8%89%BA%E6%9C%AF%E5%93%81%E6%8B%8D%E5%8D%96&amp;pn=1&amp;pos=7&amp;m=5f288dc05fc7ff2f61be31dbf3fa3f730f960456&amp;u=http%3A%2F%2Fwww.ctsbw.com%2Farticle-4015.html" data-pos="3"> 在线<b>艺术品拍卖</b>服务平台『掌拍艺术』获3000元Pre-A轮融资 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '中国艺术品金融市场呈现蓝海，艺条龙联合荣宝斋(上海)拍卖共同发力' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '中国艺术品金融市场呈现蓝海，艺条龙联合荣宝斋(上海)拍卖共同发力'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";