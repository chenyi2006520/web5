s:17883:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>“白袍萨鲁曼”走了 关于他的7件事你可能不知道- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">“白袍萨鲁曼”走了 关于他的7件事你可能不知道</h1> <p id="source-and-time"><span id=source>中国台湾网</span><time id=time>2015-06-12 09:51:00</time></p> </header>  <div id="news-body"><p>据<a href="http://m.so.com/s?q=%E3%80%8A%E5%8D%AB%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《卫报》</a>等外媒报道，塑造了包括<a href="http://m.so.com/s?q=%E7%99%BD%E8%A2%8D%E5%B7%AB%E5%B8%88&amp;src=newstranscode" class="qkw">白袍巫师</a>萨鲁曼在内众多经典角色的<a href="http://m.so.com/s?q=%E5%85%8B%E9%87%8C%E6%96%AF%E6%89%98%E5%BC%97%C2%B7%E6%9D%8E&amp;src=newstranscode" class="qkw">克里斯托弗·李</a>爵士，于6月7日早晨在伦敦切尔西和威斯敏斯特医院去世，享年93岁。</p><p>之前他因呼吸道问题和心脏衰竭入院治疗，5月27日他刚刚度过了93岁的生日。</p><p>关于克里斯托弗·李，有以下不得不提的几件事:</p><p>1.他是爵士，<a href="http://m.so.com/s?q=%E6%9F%A5%E5%B0%94%E6%96%AF%E7%8E%8B%E5%AD%90&amp;src=newstranscode" class="qkw">查尔斯王子</a>亲自受勋</p><p><img src="http://p35.qhimg.com/t0171f6f9198fbb24cf.jpg?size=480x226"></p><p>2009年，因为在表演和慈善方面的贡献，他被授予爵士称号，由查尔斯王子为他授勋，由于他的年龄，在仪式上他不用向王子下跪，所以现在称呼他的名字时要在后面加上“爵士”二字。</p><p class="header">2.他出身本就是贵族</p><p><img src="http://p31.qhimg.com/t010406a6e27b731bfd.jpg?size=480x320"></p><p>其实，克里斯托弗是贵族出身，他的母亲是女伯爵埃斯特·玛丽，是<a href="http://m.so.com/s?q=%E7%88%B1%E5%BE%B7%E5%8D%8E%E6%97%B6%E4%BB%A3&amp;src=newstranscode" class="qkw">爱德华时代</a>著名的美人，曾作为模特，成为当时著名肖像画家的画中人，以及雕塑家克莱尔·F·谢里丹的雕塑原型;他的父亲是英国皇家步枪队的中校杰弗里·特洛普·李;远房亲戚还包括美国内战中的著名将领罗伯特·E·李，以及著名天文学家约翰·李……</p><p class="header">3.天生长着一张法师脸</p><p><img src="http://p32.qhimg.com/t01bafbe6b20d6ba6f5.jpg?size=480x320"></p><p>老爷子最被年轻人熟知的角色就是<a href="http://m.so.com/s?q=%E3%80%8A%E6%8C%87%E7%8E%AF%E7%8E%8B%E3%80%8B&amp;src=newstranscode" class="qkw">《指环王》</a>系列里的白袍萨鲁曼了，他和甘道夫(上图左)在里面的组合把无数人萌翻。在明年1月要上映的<a href="http://m.so.com/s?q=%E3%80%8A%E9%9C%8D%E6%AF%94%E7%89%B9%E4%BA%BA3%E3%80%8B&amp;src=newstranscode" class="qkw">《霍比特人3》</a>里，他继续出演法师。</p><p>4.他是世界纪录上演过最多角色的演员，尤其恐怖片</p><p><img src="http://p32.qhimg.com/t01206a56d6f2951408.jpg?size=480x619"></p><p>上图是克里斯托弗·李演的<a href="http://m.so.com/s?q=%E6%81%90%E6%80%96%E7%94%B5%E5%BD%B1&amp;src=newstranscode" class="qkw">恐怖电影</a>《傅满洲的城堡》剧照。40年代末期，退伍后的李投身表演，1米96的高大身材和邪恶的面貌特质让他很快成为“恶魔”的化身，随后的20年间，克里斯托弗·李出演了大量恐怖电影，代表作包括<a href="http://m.so.com/s?q=%E3%80%8A%E7%A7%91%E5%AD%A6%E6%80%AA%E4%BA%BA%E7%9A%84%E8%AF%85%E5%92%92%E3%80%8B&amp;src=newstranscode" class="qkw">《科学怪人的诅咒》</a>、《傅满洲的城堡》<a href="http://m.so.com/s?q=%E3%80%8A%E6%81%90%E6%80%96%E5%90%B8%E8%A1%80%E9%AC%BC%E3%80%8B&amp;src=newstranscode" class="qkw">《恐怖吸血鬼》</a>和《永眠的诅咒》等，他最著名的角色之一应该是德库拉伯爵。</p><p>5.在<a href="http://m.so.com/s?q=%E3%80%8A%E5%93%88%E5%A7%86%E9%9B%B7%E7%89%B9%E3%80%8B&amp;src=newstranscode" class="qkw">《哈姆雷特》</a>里跑龙套</p><p><img src="http://p32.qhimg.com/t01f1e7ccbbbaa036e1.jpg?size=480x530"></p><p>这是李当年在Laurence Olivier版《哈姆雷特》里跑龙套的照片，他演一个拿着长矛的卫兵，这是他的第三个银幕角色。</p><p class="header">6.回归正题:那些他演的主流电影</p><p><img src="http://p35.qhimg.com/t0114c209f8220f92fc.jpg?size=448x978"></p><p>70年代中期，李老爷子厌倦了以往的戏路，开始尝试出演主流电影，陆续出演了<a href="http://m.so.com/s?q=%E3%80%8A%E7%A6%8F%E5%B0%94%E6%91%A9%E6%96%AF%E7%A7%98%E5%8F%B2%E3%80%8B&amp;src=newstranscode" class="qkw">《福尔摩斯秘史》</a>、《豪情三剑客》和<a href="http://m.so.com/s?q=%E3%80%8A%E9%93%81%E9%87%91%E5%88%9A%E5%A4%A7%E7%A0%B4%E9%87%91%E6%9E%AA%E5%AE%A2%E3%80%8B&amp;src=newstranscode" class="qkw">《铁金刚大破金枪客》</a>等，也正因为这些影片的成功，克里斯托弗·李开始引起好莱坞的关注，转战好莱坞的他出现在大量经典影片之中，恩，应该算大器晚成型。(上图为纪录片BBC的纪录片<a href="http://m.so.com/s?q=%E3%80%8A%E5%A6%82%E4%BD%95%E6%88%90%E4%B8%BA%E7%A6%8F%E5%B0%94%E6%91%A9%E6%96%AF%E3%80%8B&amp;src=newstranscode" class="qkw">《如何成为福尔摩斯》</a>，在老版福尔摩斯里李老爷子演过麦考夫)。</p><p>7.风一样的<a href="http://m.so.com/s?q=%E9%87%91%E5%B1%9E%E9%AA%91%E5%A3%AB&amp;src=newstranscode" class="qkw">金属骑士</a></p><p><img src="http://p33.qhimg.com/t01a3e59e71c589b18b.jpg?size=480x320"></p><p>2014年5月，他推出了一张名为<a href="http://m.so.com/s?q=%E3%80%8AMetal+Knight%E3%80%8B&amp;src=newstranscode" class="qkw">《Metal Knight》</a>的重金属专辑作为自己的生日礼物。在此之前的2010年和2013年，他还分别推出了一张重金属专辑，而每年圣诞节期间发行重金属<a href="http://m.so.com/s?q=%E5%9C%A3%E8%AF%9E%E6%AD%8C%E6%9B%B2&amp;src=newstranscode" class="qkw">圣诞歌曲</a>也已经成为了“<a href="http://m.so.com/s?q=%E8%90%A8%E9%B2%81%E6%9B%BC&amp;src=newstranscode" class="qkw">萨鲁曼</a>”的一个传统。</p><p>但是老爷子做音乐绝不是玩票，吉他手福克纳称，“我记得那天我坐在那里，听着‘萨鲁曼’发出简直要爆破扬声器的声音，那一幕真是超现实!我都不敢想邻居会怎么想。”</p><p>有粉丝总结称，“他的风格属于新古典、交响金属、叙事史诗金属，专辑的灵感来自于堂吉诃德，那歌声中气十足、斗志昂扬。”</p><p><img src="http://p35.qhimg.com/t0104f36c986df34cc9.jpg?size=480x320"></p><p>原稿件来源:新京报即时新闻</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.taiwan.cn/xwzx/qwqs/201506/t20150612_10020314.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='f413c5e3edfc7762867ccf2f8cd418d3'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>傅满洲的城堡</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%82%85%E6%BB%A1%E6%B4%B2%E7%9A%84%E5%9F%8E%E5%A0%A1&amp;pn=1&amp;pos=5&amp;m=dd9bbf61edd88c233a6cddecd4474ddfdf1097dd&amp;u=http%3A%2F%2Fwww.taiwan.cn%2Fxwzx%2Fqwqs%2F201506%2Ft20150612_10020314.htm" data-pos="1"> "白袍萨鲁曼"走了 关于他的7件事你可能不知道 </a>   <li> <a href="/transcode?q=%E5%82%85%E6%BB%A1%E6%B4%B2%E7%9A%84%E5%9F%8E%E5%A0%A1&amp;pn=1&amp;pos=6&amp;m=6c6b7e93d372f8348b1827c579a6228ce4c80419&amp;u=http%3A%2F%2Fnews.cnr.cn%2Fgjxw%2Fgnews%2F20150612%2Ft20150612_518831233.shtml" data-pos="2"> 魔戒白袍术士扮演者克里斯托弗-李去世 享年93岁 </a>   <li> <a href="/transcode?q=%E5%82%85%E6%BB%A1%E6%B4%B2%E7%9A%84%E5%9F%8E%E5%A0%A1&amp;pn=1&amp;pos=7&amp;m=032e3fab5438da2d2ddb208c0b1f0f14d5f19e31&amp;u=http%3A%2F%2Fnews.china.com.cn%2Flive%2F2015-06%2F12%2Fcontent_33099254.htm" data-pos="3"> "萨鲁曼"扮演者李魂归中土 88岁高龄还出摇滚专辑 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '“白袍萨鲁曼”走了 关于他的7件事你可能不知道' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '“白袍萨鲁曼”走了 关于他的7件事你可能不知道'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";