s:24348:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>勇士获评最佳数据分析队 已广泛使用投篮追踪仪- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">勇士获评最佳数据分析队 已广泛使用投篮追踪仪</h1> <p id="source-and-time"><span id=source>网易</span><time id=time>2016-03-13 12:43:04</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E7%BD%91%E6%98%93%E4%BD%93%E8%82%B2&amp;src=newstranscode" class="qkw">网易体育</a>3月13日报道:</p><p>据勇士队官网报道，2016年度<a href="http://m.so.com/s?q=%E9%BA%BB%E7%9C%81%E7%90%86%E5%B7%A5%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">麻省理工学院</a>斯隆体育分析峰会目前正在波士顿会议展览中心召开。2015年NBA总冠军<a href="http://m.so.com/s?q=%E9%87%91%E5%B7%9E%E5%8B%87%E5%A3%AB%E9%98%9F&amp;src=newstranscode" class="qkw">金州勇士队</a>被本届峰会评选为最佳数据分析球队。勇士队总经理鲍勃-迈尔斯出席了颁奖典礼，并代表球队发表了获奖感言。</p><p>本届麻省理工学院<a href="http://m.so.com/s?q=%E6%96%AF%E9%9A%86&amp;src=newstranscode" class="qkw">斯隆</a>体育分析峰会的最佳数据分析球队一共有四支球队，分别是NBA的金州勇士队、冰球联盟的芝加哥黑鹰队、职业棒球大联盟的休斯敦太空人队以及来自丹麦足球超级联赛的中日德兰足球俱乐部。</p><p>勇士队总经理鲍勃-迈尔斯参加了本届体育分析峰会，他在发表获奖感言时表示:“能获得这个奖项，我们深感荣幸和自豪。数据分析已经成为了职业体育界的一大组成部分。尤其是在过去的几年时间里，我们更是把数据分析上升到了球队的重要层面。勇士队老板乔-拉科布对于数据分析工作非常重视，也非常认可我们的研究成果，他为我们提供了充足的经费以进行各项数据分析。”</p><p>勇士队是整个NBA联盟中最早引入<a href="http://m.so.com/s?q=SportVU&amp;src=newstranscode" class="qkw">SportVU</a>系统的几支球队之一。SportVU是比赛场上的球员追踪分析系统，现在已经被普遍NBA球队所广泛使用。SportVU可以记录下球员在正式的比赛时间里所发生的一切。如今这套系统已经被逐渐地运用于体育领域，不仅仅是NBA，还有棒球和冰球等各大职业体育联盟。</p><p>除了SportVU系统，勇士队还使用了其他的一些高科技手段来帮助球员训练。如他们继续使用的可穿戴装置监测球员的疲劳度，他们通过这个装置监测球员的心率、下肢承重力来评估球员的疲劳程度。此外，他们还运用了一种名为“投篮追踪仪”的设备，用于追踪球员的投篮，全套设备包括一个可以戴在<a href="http://m.so.com/s?q=%E6%8A%A4%E8%85%95&amp;src=newstranscode" class="qkw">护腕</a>或护肘里的人体感应器，一个装在篮网上的投篮感应器、配套护腕或<a href="http://m.so.com/s?q=%E6%8A%A4%E8%82%98&amp;src=newstranscode" class="qkw">护肘</a>以及统计分析数据的手机app，能记录投篮精确度。</p><p>麻省理工学院斯隆体育分析峰会创立于2006年，休斯敦火箭总经理达雷尔-莫雷是峰会联合主席之一。在2015年度该体育分析峰会上，来自NBA的圣安东尼奥马刺队同样获得了最佳数据分析球队的奖项。</p><p>本文来源:网易体育 作者:萨尔虎 责任编辑:周峻涛_NS4573</p><p><img src="http://p31.qhimg.com/t01644990a3ffa6941e.jpg?size=600x445"></p><p>美国大选初选阶段正在如火如荼地进行，共和党的特朗普和民主党的<a href="http://m.so.com/s?q=%E5%B8%8C%E6%8B%89%E9%87%8C&amp;src=newstranscode" class="qkw">希拉里</a>，似乎每天都会出现在各大媒体上。他们各自为了党内提名而拼得你死我活时，却出现了一匹“黑马”。</p><p><img src="http://p31.qhimg.com/t01d8a0500ce8dec08e.jpg?size=600x338"></p><p>在勇士的比赛中，观众直接举起了看板，呼吁库里去竞选总统。如今人气暴涨的MVP本赛季更加逆天，在球衣销售榜上美国的47个州都排在第一位，远远碾压这些总统候选人的投票比例。</p><p>其实，库里早就去过<a href="http://m.so.com/s?q=%E7%99%BD%E5%AE%AB&amp;src=newstranscode" class="qkw">白宫</a>了!作为卫冕冠军，勇士全队都受到了奥巴马的接见。看库里的眼神……</p><p>当然，库里现在肯定不会去竞选，他还有好多事要做呢!夺冠、破连胜纪录、再刷新三分纪录、从后场扔三分绝杀……</p><p><img src="http://p35.qhimg.com/t015fb1b188bec09232.jpg?size=600x374"></p><p>所以，接见球队的事，还是留给政客们参加吧!当然，勇士可能是奥巴马接见的最后一支球队了，他的任期到明年1月20日，要看新冠军什么时候客场打奇才才能确定<a href="http://m.so.com/s?q=%E5%A5%A5%E5%B7%B4%E9%A9%AC&amp;src=newstranscode" class="qkw">奥巴马</a>见不见得到。相对来说，冠军似乎已经被勇士锁定了，他们去见谁反倒不确定。奥巴马?希拉里?特朗普?还是真的出现黑马?</p><p><img src="http://p33.qhimg.com/t016dc7d1d88cb29c16.jpg?size=600x401"></p><p>奥巴马之前接见的是<a href="http://m.so.com/s?q=%E9%A9%AC%E5%88%BA&amp;src=newstranscode" class="qkw">马刺</a>，2014年的总冠军。</p><p><img src="http://p35.qhimg.com/t01cc6db973deaf01af.jpg?size=600x378"></p><p>奥巴马获赠1号球衣，这件球衣曾经是麦蒂的，现在是凯尔-安德森的。</p><p><img src="http://p34.qhimg.com/t01618ef38064f654f3.jpg?size=342x450"></p><p>球衣印着“POTUS(Presidents of the United States)”，不过看表情似乎不太乐意呢?</p><p><img src="http://p33.qhimg.com/t01fdc0b3e479382b03.jpg?size=600x400"></p><p>再往前，奥巴马是迈阿密热火队的“44号 Potus”。</p><p>又不是真的引援，这哥俩怎么高兴成这样?</p><p><img src="http://p33.qhimg.com/t01ed0471dccd0b6b36.jpg?size=592x450"></p><p>这件球衣有两件，2012年的也是44号。</p><p><img src="http://p33.qhimg.com/t018ae6cecad875d6cb.jpg?size=367x450"></p><p class="img-title">那时候还是眼镜詹。</p><p><img src="http://p34.qhimg.com/t012f47afc43ca317e6.jpg?size=900x600"></p><p>2011年总冠军小牛则送给了奥巴马23号，大概因为他是乔丹的死忠粉丝吧。</p><p><img src="http://p31.qhimg.com/t01cd975a4580149f3b.jpg?size=900x600"></p><p class="img-title">小牛队史第一个冠军，隆重一点。</p><p><img src="http://p31.qhimg.com/t018945d87231fa8ff2.jpg?size=881x600"></p><p>奥巴马任期内第一次接见的就是<a href="http://m.so.com/s?q=%E6%B9%96%E4%BA%BA&amp;src=newstranscode" class="qkw">湖人</a>，他们也在09和10年获得两连冠。</p><p>那时候的拜纳姆还得到了奥巴马特别青睐，让总统俯身握手。</p><p><img src="http://p32.qhimg.com/t01e8aa0de771e5770b.jpg?size=442x600"></p><p><a href="http://m.so.com/s?q=%E7%A7%91%E6%AF%94&amp;src=newstranscode" class="qkw">科比</a>送了奥巴马签名<a href="http://m.so.com/s?q=%E7%AF%AE%E7%90%83&amp;src=newstranscode" class="qkw">篮球</a>。</p><p><img src="http://p32.qhimg.com/t010132423681d54518.jpg?size=831x600"></p><p>成为湖人队1号。(湖人的1号都给过谁?)</p><p><img src="http://p31.qhimg.com/t01b4ecda56dbf12923.jpg?size=900x599"></p><p>其实早在奥巴马之前就有这个传统了。早在1985年，美国总统接见NBA总冠军队伍就已经是例行公事。</p><p><img src="http://p35.qhimg.com/t0147f970385d2387c2.jpg?size=900x600"></p><p>当时的湖人冠军成员魔术师约翰逊与美国前总统<a href="http://m.so.com/s?q=%E9%87%8C%E6%A0%B9&amp;src=newstranscode" class="qkw">里根</a>握手，献上球衣与篮球。</p><p><img src="http://p35.qhimg.com/t0151be6b3d7174cf76.jpg?size=900x600"></p><p>贾巴尔为美国前总统双手献上球衣，里根双手接过大礼。他也是1号。</p><p><img src="http://p33.qhimg.com/t01dfad54f7509aadaa.jpg?size=900x600"></p><p>里根总统获赠湖人队帽、湖人球衣、湖人T恤以及签名篮球多样礼物。</p><p><img src="http://p34.qhimg.com/t01b41499cb0f1a3db8.jpg?size=399x600"></p><p class="img-title">里根获赠球衣篮球帽子T恤心满意足。</p><p><img src="http://p34.qhimg.com/t01e53d85eb6275eb4f.jpg?size=900x599"></p><p>时任NBA总裁斯特恩随总冠军球队到访白宫参与接见仪式。</p><p><img src="http://p34.qhimg.com/t01c62c564bb9c75700.jpg?size=490x600"></p><p><a href="http://m.so.com/s?q=%E5%85%8B%E6%9E%97%E9%A1%BF&amp;src=newstranscode" class="qkw">克林顿</a>接见1997年总冠军公牛队，阵势浩荡场面壮观。</p><p><img src="http://p31.qhimg.com/t011e04cc56fc43f601.jpg?size=490x600"></p><p>生涯6次夺冠的<a href="http://m.so.com/s?q=%E4%B9%94%E4%B8%B9&amp;src=newstranscode" class="qkw">乔丹</a>多次拜访白宫，与克林顿早就是亲朋密友。</p><p><img src="http://p35.qhimg.com/t010c82fa6d05ddfd36.jpg?size=482x600"></p><p>菲尔-杰克逊携手大虫罗德曼逛白宫犹如逛花园，惬意十足。</p><p><img src="http://p34.qhimg.com/t01ea7fd10882a78f1f.jpg?size=900x599"></p><p>克林顿:欢迎芝加哥<a href="http://m.so.com/s?q=%E5%85%AC%E7%89%9B&amp;src=newstranscode" class="qkw">公牛</a>来到白宫!接下来我要把话筒交给迈克尔。</p><p><img src="http://p31.qhimg.com/t01f5aed25e23a8cd08.jpg?size=900x600"></p><p class="img-title">乔丹与克林顿握手，忘情闭眼。</p><p><img src="http://p34.qhimg.com/t01717736565cd2115b.jpg?size=900x599"></p><p>乔丹讲话显大将之风，克林顿凝望帮主。</p><p><img src="http://p35.qhimg.com/t014b6da0433c3f3225.jpg?size=900x599"></p><p>乔丹与皮蓬不可分割，帮主之后皮二登场。</p><p><img src="http://p35.qhimg.com/t01f08207773491f1a5.jpg?size=400x600"></p><p>克林顿收获公牛夹克，上下比试颇为满意。</p><p><img src="http://p34.qhimg.com/t0101cf5b0263cbd818.jpg?size=399x600"></p><p>克林顿见证公牛夺冠征程，获赠球衣纪念意义非凡。</p><p><img src="http://p34.qhimg.com/t019458b64da21ca310.jpg?size=900x599"></p><p>克林顿还接见了1999年总冠军马刺队。</p><p><img src="http://p32.qhimg.com/t016f5b6d39ac389b49.jpg?size=832x600"></p><p>罗宾逊赠予克林顿马刺1号球衣，总统甚感荣幸。</p><p><img src="http://p35.qhimg.com/t01359de41553049dfb.jpg?size=900x595"></p><p class="img-title">克林顿展示获赠1号马刺球衣。</p><p><img src="http://p34.qhimg.com/t01e0e1ca0ff0fbefd1.jpg?size=900x586"></p><p>换届了。小布什接见2002年总冠军湖人队，科比与总统眼神交汇。</p><p><img src="http://p33.qhimg.com/t01a2870578b06b8868.jpg?size=900x586"></p><p>禅师接见仪式上讲话，<a href="http://m.so.com/s?q=%E5%B8%83%E4%BB%80&amp;src=newstranscode" class="qkw">布什</a>聆听投入。</p><p><img src="http://p33.qhimg.com/t0179782d8a8a8c9b74.jpg?size=900x586"></p><p>接见仪式上<a href="http://m.so.com/s?q=%E5%A5%A5%E5%B0%BC%E5%B0%94&amp;src=newstranscode" class="qkw">奥尼尔</a>与布什握手，持全队签名篮球献给总统。</p><p><img src="http://p34.qhimg.com/t01ffe4e99211f98187.jpg?size=900x586"></p><p class="img-title">奥尼尔与科比白宫搞怪。</p><p><img src="http://p35.qhimg.com/t01131b5cd5dd6bae77.jpg?size=390x600"></p><p class="img-title">奥尼尔白宫耍宝轻吻雕像。</p><p><img src="http://p34.qhimg.com/t013dbe1099bd20ad49.jpg?size=900x586"></p><p class="img-title">布什接见2003年总冠军马刺队。</p><p><img src="http://p31.qhimg.com/t013f5404a733f21200.jpg?size=837x600"></p><p class="img-title">邓肯发表总冠军感言，布什心领神会。</p><p><img src="http://p34.qhimg.com/t01e9f5cab19f7bf0d7.jpg?size=336x600"></p><p class="img-title">MVP邓肯让布什也敬仰三尺。</p><p><img src="http://p35.qhimg.com/t01dde491154aced734.jpg?size=900x586"></p><p>布什接见2003-04赛季总冠军活塞队。</p><p><img src="http://p31.qhimg.com/t01f0637752ca3f19ff.jpg?size=585x600"></p><p>MVP比卢普斯为布什献上活塞球衣，04年的冠军，所以是04号。</p><p><img src="http://p35.qhimg.com/t01ae6417e7dc5add42.jpg?size=342x600"></p><p>06年总冠军接见仪式上鲨鱼代表热火讲话，布什仰望“高高在上”的奥尼尔。</p><p><img src="http://p33.qhimg.com/t0114da78b68750cc50.jpg?size=900x600"></p><p class="img-title">奥尼尔双手为布什送上签名篮球。</p><p><img src="http://p33.qhimg.com/t01805ceb634640458f.jpg?size=900x527"></p><p>布什接见2008年总冠军凯尔特人队。</p><p><img src="http://p33.qhimg.com/t017e81f5340218012d.jpg?size=900x600"></p><p>加内特白宫开讲，绿军三巨头夺冠他是功臣。</p><p><img src="http://p33.qhimg.com/t0171ac0d16cb9a107d.jpg?size=484x600"></p><p class="img-title">MVP皮尔斯和布什亲密接触。</p><p><img src="http://p31.qhimg.com/t01a97fd03a7e087c3c.jpg?size=775x600"></p><p class="img-title">布什小露一手，皮尔斯会心一笑。</p><p>勇士的库里、汤普森和格林一起登上了新一期的《体育画报》封面。</p><p>他们还接受了SI的专访，谈及许多话题。</p><p>拍摄花絮。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://sports.163.com/16/0313/12/BI1OU6HC00051CA1.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='2039f3a7dc880060abe6ca65d7c303ef'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>芝加哥黑鹰队</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%8A%9D%E5%8A%A0%E5%93%A5%E9%BB%91%E9%B9%B0%E9%98%9F&amp;pn=1&amp;pos=9&amp;m=d51c24389183832e0557496560b1a6ad8fa3cf04&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2014%2Fgdxw_1204%2F652939.html" data-pos="1"> 于嘉专栏:对<b>芝加哥</b>马拉松失望 40天共跑435公里 </a>   <li> <a href="/transcode?q=%E8%8A%9D%E5%8A%A0%E5%93%A5%E9%BB%91%E9%B9%B0%E9%98%9F&amp;pn=1&amp;pos=10&amp;m=6e91879cdfecee6623a3c974bfe44a395d45d92a&amp;u=http%3A%2F%2Fwww.shuaijiao.com%2Fnews%2Fview%2F42843.html" data-pos="2"> CM 朋克今日在<b>芝加哥</b>观看本土冰球赛事? </a>   <li> <a href="/transcode?q=%E8%8A%9D%E5%8A%A0%E5%93%A5%E9%BB%91%E9%B9%B0%E9%98%9F&amp;pn=2&amp;pos=1&amp;m=dc5816c48892a3c7164b34cffd0a8edb27d8cd70&amp;u=http%3A%2F%2Fwww.91danji.com%2Fnews%2F132812.html" data-pos="3"> EA的钱不好挣啊!封面人物必输魔咒殃及《UFC 2》 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '勇士获评最佳数据分析队 已广泛使用投篮追踪仪' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '勇士获评最佳数据分析队 已广泛使用投篮追踪仪'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";