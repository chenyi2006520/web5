s:14247:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>元宵节特别节目《军营合家欢》即将在央视播出- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">元宵节特别节目《军营合家欢》即将在央视播出</h1> <p id="source-and-time"><span id=source>中国青年网</span><time id=time>2016-02-22 14:30:43</time></p> </header>  <div id="news-body"><p><img src="http://p34.qhimg.com/t012cb33c8d7277d5de.jpg?size=667x453"></p><p><img src="http://p34.qhimg.com/t014e433557739659dd.jpg?size=638x425"></p><p class="img-title">晚会视频截图</p><p>人民网北京2月22日电 由中央电视台军事节目中心制作的2016年元宵特别节目<a href="http://m.so.com/s?q=%E3%80%8A%E5%86%9B%E8%90%A5%E5%90%88%E5%AE%B6%E6%AC%A2%E3%80%8B&amp;src=newstranscode" class="qkw">《军营合家欢》</a>将于22日16时在CCTV-7播出。晚会高唱时代主旋律，紧紧围绕改革强军的主题，歌颂军人一家不圆万家圆的奉献精神，表达全军将士实现强军梦、中国梦的坚定信念和决心。</p><p>作为<a href="http://m.so.com/s?q=%E3%80%8A%E5%86%9B%E8%90%A5%E5%A4%A7%E6%8B%9C%E5%B9%B4%E3%80%8B&amp;src=newstranscode" class="qkw">《军营大拜年》</a>的姊妹篇，《军营合家欢》由军旅老中青艺术家共计300余人参加了录制，很多人都是刚刚跟随《军营大拜年》从高原哨所、边疆海岛慰问一线官兵，风尘仆仆返回。</p><p>晚会在蓝天幼儿园艺术团的小朋友表演的舞蹈<a href="http://m.so.com/s?q=%E3%80%8A%E9%87%91%E7%8C%B4%E9%97%B9%E5%85%83%E5%AE%B5%E3%80%8B&amp;src=newstranscode" class="qkw">《金猴闹元宵》</a>中拉开了序幕，精彩的表演轮番上演。晚会上，由老中青三代文艺战士联袂演绎经典作品，唤起了人们很多美好的回忆;由<a href="http://m.so.com/s?q=%E9%82%B9%E5%BE%B7%E6%B1%9F&amp;src=newstranscode" class="qkw">邹德江</a>、周小斌、魏积安、郭达、<a href="http://m.so.com/s?q=%E5%85%A8%E7%BB%B4%E6%B6%A6&amp;src=newstranscode" class="qkw">全维润</a>、范雷 表演的祝福话即兴接龙，引得全场掌声笑声不断。来自西北边陲、雪域高原和草原戈壁的边疆少数民族地区的军旅艺术家们，表演了多姿多彩、独具少数民族地域风情的文艺节目;由陶玉玲、<a href="http://m.so.com/s?q=%E6%9E%97%E4%B8%AD%E5%8D%8E&amp;src=newstranscode" class="qkw">林中华</a>、柏文、汤非、<a href="http://m.so.com/s?q=%E6%9D%8E%E7%82%9C%E9%B9%8F&amp;src=newstranscode" class="qkw">李炜鹏</a>、袁东方、王国栋、李思思共同演绎《团圆饭》，充满了合家团圆的节日味道;晚会还以一组军歌，表达了广大官兵“听党指挥、能打胜仗、作风优良”，做新一代“四有”革命军人的坚定决心;阎维文演唱最新军旅歌曲《强军之路》，更将晚会推向了高潮;最后晚会在<a href="http://m.so.com/s?q=%E7%8E%8B%E4%BC%A0%E8%B6%8A&amp;src=newstranscode" class="qkw">王传越</a>、王凯、郑洁、张莉莉演唱的<a href="http://m.so.com/s?q=%E3%80%8A%E4%BB%8A%E5%A4%9C%E6%97%A0%E7%9C%A0%E3%80%8B&amp;src=newstranscode" class="qkw">《今夜无眠》</a>歌声中，落下帷幕。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.youth.cn/js/201602/t20160222_7660482.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='1f6316b1ada21d32653c3f7643ae46d1'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>合家欢</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%90%88%E5%AE%B6%E6%AC%A2&amp;pn=1&amp;pos=9&amp;m=75ec12bfe0da3516d819e58a13c73de411ccdef7&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Flocal%2F2016-02%2F25%2Fc_128749221.htm" data-pos="1"> 生时<b>合家欢</b> 身后再聚难 </a>   <li> <a href="/transcode?q=%E5%90%88%E5%AE%B6%E6%AC%A2&amp;pn=1&amp;pos=10&amp;m=f497f2e453b15b4f8629c6f1326ab8bf5dfff1d7&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Flnnews_0226%2F4361379.html" data-pos="2"> 《美人鱼》票房大卖 "<b>合家欢</b>"电影火爆(图) </a>   <li> <a href="/transcode?q=%E5%90%88%E5%AE%B6%E6%AC%A2&amp;pn=2&amp;pos=1&amp;m=ff554a1789a18843c8f2eedd721af58231c7e8b4&amp;u=http%3A%2F%2Fnews.youth.cn%2Fjs%2F201602%2Ft20160222_7660482.htm" data-pos="3"> 元宵节特别节目《军营<b>合家欢</b>》即将在央视播出 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '元宵节特别节目《军营合家欢》即将在央视播出' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '元宵节特别节目《军营合家欢》即将在央视播出'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";