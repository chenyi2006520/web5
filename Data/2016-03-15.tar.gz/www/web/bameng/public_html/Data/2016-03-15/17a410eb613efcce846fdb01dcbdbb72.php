s:21600:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>失眠怎么办 男人告别失眠烦恼有妙招 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">失眠怎么办 男人告别失眠烦恼有妙招 </h1> <p id="source-and-time"><span id=source>三九养生堂</span><time id=time>2016-03-10 17:14:00</time></p> </header>  <div id="news-body"><p>现在很多男人大半夜都不睡觉，不是他们不想睡觉，而是睡不着也就是失眠了。那么男人失眠怎么办才好呢?我们应该如何治疗失眠呢?又有什么特别有效治失眠的偏方能帮助我们呢?不要着急，接下来赶紧跟着小编一起去文章中看一看吧!</p><p>一般来说，如果男人有失眠的问题，不应急着吃安眠药，建议先试试一些自然的助眠方法，这样才是对身体好。那么男人失眠应该怎么做呢?</p><p>1.晚上避免酒精与<a href="http://m.so.com/s?q=%E5%92%96%E5%95%A1%E5%9B%A0&amp;src=newstranscode" class="qkw">咖啡因</a></p><p>酒精能够男人助眠，但是无法帮助我们进入较深层的睡眠;身体真正进入休息与修复阶段是在<a href="http://m.so.com/s?q=%E5%BF%AB%E9%80%9F%E5%8A%A8%E7%9C%BC&amp;src=newstranscode" class="qkw">快速动眼</a>期，而快速动眼期只有在进入深层睡眠的时候才会发生，若在睡前摄取酒精或咖啡因，都会导致我们无法达快速动眼期。</p><p><img src="http://p33.qhimg.com/t016c60e4717144f0e1.jpg?size=400x294"></p><p class="img-title">2.养成规律作息</p><p>男人的身体状态在规律的生活作息下，会开始维持稳定的动态平衡，身体的反应与机能也会表现的较好，因此只要我们养成每天定时上床睡觉的习惯，就能够加强身体的睡眠─清醒周期。另外，培养一些睡前习惯也能够帮助身体进入睡眠模式，例如泡澡、阅读等，养成习惯以后身体也会自动记忆为睡前行为，帮助进入睡眠模式。</p><p class="header">3.避免睡前激烈运动</p><p>男人睡前做高强度运动容易造成体温升高、唤醒<a href="http://m.so.com/s?q=%E7%A5%9E%E7%BB%8F%E7%B3%BB%E7%BB%9F&amp;src=newstranscode" class="qkw">神经系统</a>而导致失眠，但是轻度的运动是可以进行的，且最好与睡觉时间间隔三小时以上。不过最重要的是好好观察身体和心理的状态，追踪、注意哪种运动方式最能够让你放松，这对你的睡眠周期相当有帮助。</p><p class="header">4.避免电视与蓝光</p><p>所有的电子设备都含有蓝光，但是其中有些蓝光会阻碍男人身体褪黑激素的分泌，导致无法维持稳定的睡眠品质，因此睡前2-3小时应避免受到太多蓝光照射，最快的方法就是不要使用手机、电脑与看电视。如果无法避免，可以在电子设备上加装滤蓝光软硬体，多少能够减少吸收蓝光。</p><p class="header">5.练习放松技巧</p><p>男人练习放松与呼吸技巧，可以让我们专注在睡眠上。呼吸:躺在床上放轻松，用鼻子缓慢吸气约8-10秒，<a href="http://m.so.com/s?q=%E6%91%92%E4%BD%8F%E5%91%BC%E5%90%B8&amp;src=newstranscode" class="qkw">摒住呼吸</a>几秒后慢慢吐气，持续至少4秒以上，重复此动作直到想睡觉。肌肉放松:趟在床上闭上双眼，将脚指头往自己的脸拉近，数到10，之后放松脚趾，再数到10，重复10次。</p><p class="header">6.睡前不要吃太多</p><p>男人睡前吃太多会导致腹胀或消化不良，这些都会影响你的睡眠，且为了消化大量的食物，身体机制也会加速运转，更不利于入睡，因此睡前切忌吃太饱。不过若过度饥饿也会使我们无法入眠，因此可以适当补充一些蛋白质、坚果类或<a href="http://m.so.com/s?q=%E6%B2%99%E6%8B%89&amp;src=newstranscode" class="qkw">沙拉</a>填填肚子。</p><p class="header">7.别强迫自己睡着</p><p>如果男人发现自己在上床20分钟之后仍然睡不着，最好起床做些温和的事做，不要继续强迫自己紧闭双眼或数羊，因为你愈是逼迫自己睡着，就愈不容易进入睡眠。此时我们可以起床找些事做，像是阅读、听音乐或尝试一些放松的方法，让这些睡前习惯再次发挥效用。</p><p>说到男性失眠，不妨试试<a href="http://m.so.com/s?q=%E6%B0%B8%E5%AE%89&amp;src=newstranscode" class="qkw">永安</a>康健百合康牌褪黑素维生素B6<a href="http://m.so.com/s?q=%E8%83%B6%E5%9B%8A&amp;src=newstranscode" class="qkw">胶囊</a>。治疗失眠效果特别好，用过的朋友都知道。</p><p>永安康健百合康牌<a href="http://m.so.com/s?q=%E8%A4%AA%E9%BB%91%E7%B4%A0&amp;src=newstranscode" class="qkw">褪黑素</a>维生素B6胶囊特别添加维生素B6，可进一步改善大脑兴奋中区的平衡，使睡眠更加稳定。</p><p>而且，永安康健百合康牌褪黑素维生素B6胶囊没100g含维生素B6是4.3g，腿色素1.86g,高含量黄金配比，每天睡前一粒，轻松入眠，长期吃也不会有依赖性的哦!</p><p>用过永安康健百合康牌褪黑素维生素B6胶囊的客户都会来反馈，是永安康健百合康牌褪黑素维生素B6胶囊让他们能够一夜睡到天亮，再也不用担心晚上睡不着觉了，以下是用户对永安康健百合康牌褪黑素维生素B6胶囊的评价。</p><p><img src="http://p35.qhimg.com/t0119de6d8ef4c73b46.jpg?size=600x378"></p><p>永安康健百合康牌褪黑素维生素B6胶囊大品牌，实力见证，品质放心，精湛的科研团队工艺技术严格把控，消费者使用放心哦!</p><p>友情提醒:永安康健百合康牌褪黑素维生素B6胶囊不能代替药品，本品添加了营养素，与同类营养素同时食用不宜超过推荐量，从事机械、驾驶作业或危险操作者，不要在操作前或操作中食用，自身免疫证(<a href="http://m.so.com/s?q=%E7%B1%BB%E9%A3%8E%E6%B9%BF&amp;src=newstranscode" class="qkw">类风湿</a>等)及甲亢患者慎用哦!了解这么多，心动了吧!点击这里还可了解更多产品信息哦!</p><p class="header">按摩治疗男人失眠</p><p>许多男人都有失眠的习惯，如果不能及时改善就容易对身体造成伤害。</p><p>那么有什么比较好的方法能帮助我们改善睡眠质量呢?下面给大家介绍有益老人睡眠的几种方法，供大家参考。</p><p class="header">交叉搓脚</p><p>右脚掌心搓摩左脚背所有部位，再用左脚心搓摩右脚背所有部位，然后用右脚跟搓摩左脚心，再用左脚跟搓摩右脚心，共2~3分钟。</p><p>此法可消除双足疲劳，<a href="http://m.so.com/s?q=%E8%B4%AF%E9%80%9A%E9%98%B4%E9%98%B3&amp;src=newstranscode" class="qkw">贯通阴阳</a>经脉。</p><p class="header">拇指搓耳</p><p>两手大拇指侧面紧贴耳下端，自下而上，由前向后，用力搓摩双耳1~2分钟。可以疏通经脉、清热安神，防止听力退化。</p><p><img src="http://p34.qhimg.com/t0177a6a82c7b1993cc.jpg?size=400x400"></p><p class="img-title">双掌搓面</p><p>两手掌紧贴面部，用力缓缓搓面部所有部位1~2分钟。可以疏通面部经脉、防止皱纹产生、缓解精神疲劳。</p><p class="header">双掌搓肩</p><p>两手掌用力搓摩颈肩肌群1~2分钟，重点在颈后脊柱两侧。可缓解疲劳，预防颈肩病变。</p><p>叠掌<a href="http://m.so.com/s?q=%E6%91%A9%E8%85%B9&amp;src=newstranscode" class="qkw">摩腹</a></p><p>两掌重叠紧贴腹部，先顺时针、再逆时针环摩腹部所有部位，重点在脐部及周围，共2~3分钟。可以强健脾胃，促进消化吸收。</p><p class="header">指尖摩头</p><p>两手食指、中指、无名指弯曲成45度，用指端往返按摩头部1~2分钟。可以加强脑部供血、强健脑细胞、促进入睡。</p><p class="header">推摩胸背</p><p>两手掌自上而下用力推摩前胸、后背、后腰，可以疏通脏腑经脉。</p><p class="header">掌推双腿</p><p>两手掌心相对，分别放在左腿内外侧，从大腿根部开始，由上而下顺推下肢1分钟。</p><p>再以此方法推摩右腿1分钟，可缓解疲劳。</p><p class="header">治疗男人失眠的偏方</p><p>1、麦仁30克，大枣15枚，甘草15克。</p><p>小麦去皮，与后2味入锅，加水3碗，煎至1碗。每晚睡前顿服。</p><p>2、干<a href="http://m.so.com/s?q=%E9%BE%99%E7%9C%BC%E8%82%89&amp;src=newstranscode" class="qkw">龙眼肉</a>、芡实各15克，<a href="http://m.so.com/s?q=%E7%B2%B3%E7%B1%B3&amp;src=newstranscode" class="qkw">粳米</a>100克，去心<a href="http://m.so.com/s?q=%E8%8E%B2%E5%AD%90&amp;src=newstranscode" class="qkw">莲子</a>6克，白糖适量。</p><p>将芡实煮熟去壳，捣碎成米粒状。粳米淘洗干净放入锅中，加莲子、龙眼肉、<a href="http://m.so.com/s?q=%E8%8A%A1%E5%AE%9E&amp;src=newstranscode" class="qkw">芡实</a>及清水，煮成粥后调入<a href="http://m.so.com/s?q=%E7%99%BD%E7%B3%96&amp;src=newstranscode" class="qkw">白糖</a>，每日1剂。</p><p>3、枸杞30克，炒<a href="http://m.so.com/s?q=%E6%9E%A3%E4%BB%81&amp;src=newstranscode" class="qkw">枣仁</a>40克，五味子10克。</p><p>和匀，分成5份。每日取1份，放入茶杯中开水冲泡，代茶频饮。或日饮3次，但每次不少于500毫升。</p><p>4、将<a href="http://m.so.com/s?q=%E8%8A%B1%E7%94%9F%E5%8F%B6&amp;src=newstranscode" class="qkw">花生叶</a>(鲜叶最好)用白开水冲水入壶内或杯内。</p><p>等花生叶的色泽泡下后饮下，约10分钟左右，即能入睡，有效率达95%以上。</p><p>5、丹参、远志、<a href="http://m.so.com/s?q=%E7%9F%B3%E8%8F%96%E8%92%B2&amp;src=newstranscode" class="qkw">石菖蒲</a>、硫黄各20克。</p><p>将材料研成细末，加白酒适量，调成膏状，贴于脐中，再以棉花垫于脐上，用胶布固定，每晚换药一次。</p><p>在平时也可以通过改善日常习惯来缓解失眠症状</p><p class="header">1、晚上不要玩游戏</p><p>年轻人睡觉前不会受游戏中明亮闪烁屏幕的影响，但是成年人则会觉得过于兴奋，该睡觉时大脑还在高速运转。</p><p class="header">2、保持规律的作息时间</p><p>养成规律的作息时间有助于调节睡眠周期;周末时不要长时间赖床。</p><p class="header">3、不必强求一天睡够8小时</p><p>有人认为一天要睡足8小时才行，其实睡觉时间多少是因人而异的。有人要睡8~9小时，才有充沛的精力，而有的人却只需睡5~6小时就够了。有人提出如果你少睡了几小时，就要在第二天补睡几小时，才能恢复精力，也有人说连续几天没睡觉，只要熟睡一整夜，就可补足几天的少睡时间了，这些都是不科学的。</p><p class="header">4、卧室保持洁净</p><p>室内要做到清洁卫生，空气流通，室温适宜，周围安静。床上用品要适宜，被褥要软轻舒适，经常晾，勤拆洗。枕头高低要选当，一般成人枕头高5-8厘米为宜，枕芯选用透气性大、流动性好的荞麦皮、谷壳较理想。</p><p>结语:很多男士朋友都饱受痛苦的折磨，想要彻底治疗失眠那就一定要从平时的生活习惯入手。今天小编给大家讲解了关于男人治疗失眠的方法，希望能够对大家有所帮助，每一个人人都能有一个好梦。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.39yst.com/nanxbj/383676.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='c85373ef0536c47f2736b049eafd6959'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>快速动眼</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '失眠怎么办 男人告别失眠烦恼有妙招 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '失眠怎么办 男人告别失眠烦恼有妙招 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";