s:20726:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>日本百年以来最漂亮的10大女优 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">日本百年以来最漂亮的10大女优 </h1> <p id="source-and-time"><span id=source>光明网</span><time id=time>2015-06-12 17:36:00</time></p> </header>  <div id="news-body"><p>日本《文艺春秋》季刊于2009年邀请作者和读者投票选出了日本最漂亮和最有魅力的十个女演员。这次选出的十大女优，出生于东京的占了7人，出生于20年代、30年代、40年代、50年代和70年代的各有2人，于20年前曾入选的亦有6人。今回名列十大的两个新面孔是36岁的<a href="http://m.so.com/s?q=%E5%AE%AB%E6%B3%BD%E9%87%8C%E6%83%A0&amp;src=newstranscode" class="qkw">宫泽里惠</a>和32岁的松隆子。分量稍轻的<a href="http://m.so.com/s?q=%E6%9D%BE%E9%9A%86%E5%AD%90&amp;src=newstranscode" class="qkw">松隆子</a>的入选十大无疑令人感到意外。至于位居榜首的<a href="http://m.so.com/s?q=%E5%90%89%E6%B0%B8%E5%B0%8F%E7%99%BE%E5%90%88&amp;src=newstranscode" class="qkw">吉永小百合</a>，迄今从影51年，拍了101部昭和电影和12部平成影片，一向只当主角，曾四度荣获日本学院的最佳女主角奖，也是日本电影观众最喜爱的女星。</p><p><img src="http://p34.qhimg.com/t013d97fcbef69dd241.jpg?size=334x501"></p><p class="img-title">吉永小百合</p><p>在 1970年代她也有一段低迷时期，恰巧这段时期又正处日本电影界的衰退期，加之吉永小百合的结婚对象是大她15岁的商业界人士，两人的职业面貌在常人眼里极不相符，于是遭到父母反对后吉永小百合与他们的关系一度僵持。此事被报道后，越发使得吉永小百合的演艺活动骤减。当时的日本影片界涌现出许多敢于塑造无畏裸露的现代女性形象的年轻女演员，以至于吉永小百合从1960年代开始一成不变地演绎“清纯姑娘”的套路早已让人觉得陈旧不新了。</p><p><img src="http://p31.qhimg.com/t01fb01c362e58425d5.jpg?size=326x296"></p><p><a href="http://m.so.com/s?q=%E5%8E%9F%E8%8A%82%E5%AD%90&amp;src=newstranscode" class="qkw">原节子</a></p><p>原节子幼年时的志愿是成为一名老师，1935年为补贴家计，经作为导演的姐夫熊谷久虎介绍，退学从影，处女作为1935年的&lt;年轻人勿犹豫不决!&gt;。</p><p>原节子--1920年生于神奈川县，战前已活跃于影坛，1949-1951年主演了《晚春》、《白痴》及《饭》等<a href="http://m.so.com/s?q=%E6%97%A5%E6%9C%AC%E7%94%B5%E5%BD%B1%E5%8F%B2&amp;src=newstranscode" class="qkw">日本电影史</a>上的名作，1962年于《忠臣藏》中扮演了大石内藏助的妻子理玖后引退。</p><p>原节子演艺事业的高峰出现于二战结束后。一九四六年，她在黑泽明的电影《我于青春无悔》中担任女主角，饰演一位政治犯的妻子，虽历经磨难却坚韧不拔。</p><p><img src="http://p34.qhimg.com/t0182e9faa680d3adc0.jpg?size=405x500"></p><p><a href="http://m.so.com/s?q=%E9%AB%98%E5%B3%B0%E7%A7%80%E5%AD%90&amp;src=newstranscode" class="qkw">高峰秀子</a></p><p>高峰秀子--1924年生于北海道，战前已活跃于影坛，战中多演出明朗的角色鼓舞人心，战后与<a href="http://m.so.com/s?q=%E6%9C%A8%E4%B8%8B%E6%83%A0%E4%BB%8B&amp;src=newstranscode" class="qkw">木下惠介</a>及成濑巳喜男合作主演多部名作，1979年拍完《冲动杀人，儿子啊》后息影。</p><p><img src="http://p33.qhimg.com/t01c19f1288cc2b19cc.jpg?size=407x500"></p><p><a href="http://m.so.com/s?q=%E5%A4%8F%E7%9B%AE%E9%9B%85%E5%AD%90&amp;src=newstranscode" class="qkw">夏目雅子</a></p><p>夏目雅子--1957年生于东京都，1977年演出《货车小子桃次郎》后引人注目，1982年于《鬼龙院花子的生涯》中开创新境界，正期待更大发展时却因<a href="http://m.so.com/s?q=%E6%80%A5%E6%80%A7%E9%AA%A8%E9%AB%93%E6%80%A7%E7%99%BD%E8%A1%80%E7%97%85&amp;src=newstranscode" class="qkw">急性骨髓性白血病</a>于1985年逝世。</p><p>夏目雅子出生在1957年， 1976年19岁出道拍电视剧「爱が见えますか」一炮而红，两年后拍西游记时已经是影、视、广告三栖的红星，她的清纯外貌，苗条身材，宜古宜今，赢得观众的一致赞美。她也穿比坚尼泳衣拍湿身照和广告片，看得人人傻了眼，但没有一丝猥亵的感觉。</p><p>夏目雅子曾经在1978年的日本《西游记》中，夏目雅子出演温文尔雅的三藏法师，开创了日本神话剧最受欢迎女主角之先河，与雅子有对手戏的老演员仲代达矢也称赞她演技出众，敬业无比。</p><p><img src="http://p32.qhimg.com/t014aab1698b94e2367.jpg?size=387x500"></p><p><a href="http://m.so.com/s?q=%E5%B2%B8%E6%83%A0%E5%AD%90&amp;src=newstranscode" class="qkw">岸惠子</a></p><p>岸惠子--1932年生于神奈川县，1953-1954年主演了空前卖座及成为社会现象的《请问芳名》三部作，1957年婚后往来于法国和日本，继续演出不少电影，现以日本为据点，演戏外也亮相电视及从事写作。</p><p><img src="http://p32.qhimg.com/t019ca242c1accbbe97.jpg?size=445x450"></p><p><a href="http://m.so.com/s?q=%E5%B2%A9%E4%B8%8B%E5%BF%97%E9%BA%BB&amp;src=newstranscode" class="qkw">岩下志麻</a></p><p>岩下志麻--1941年生于东京都，1960年在小津安二郎的《秋日和》初显才华后，主演了小津的遗作《秋刀鱼之味》(1962)，成为松竹的首席女优长逾16年，曾以《孤苦盲女阿玲》(1977)荣获第一届日本学院的最佳女主角奖。</p><p>岩下志麻Iwashita Shima(いわしたしま)日本女演员，1941年1月3日生于东京，父亲岩下清是一名演员和电影制作人，她的伯父是著名歌舞伎演员第四代河原崎长十郎。岩下少年时就读于东京都立武藏高中并同时入选明星学院高中部。高中毕业后，她考入<a href="http://m.so.com/s?q=%E6%88%90%E5%9F%8E%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">成城大学</a>文艺学院，后中途退学。岩下先是在电视剧中出演配角，随后于1960年进入松竹株式会社，同年在木下惠介导演的《干枯的湖》中首次亮相，因出色地扮演了一位自甘堕落的大学生的恋人而被称为“岸惠子第二”。成为<a href="http://m.so.com/s?q=%E6%9D%BE%E7%AB%B9%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">松竹公司</a>的新秀。并1961年参与演出了《女舞》、《好人好日》、《我们的恋爱之路》等片，获当年制作者协会新人奖和第十二届“蓝绶带奖”的新人奖。</p><p><img src="http://p35.qhimg.com/t01efeea4a5462258d1.jpg?size=398x500"></p><p><a href="http://m.so.com/s?q=%E5%AE%AB%E6%B3%BD%E7%90%86%E6%83%A0&amp;src=newstranscode" class="qkw">宫泽理惠</a></p><p>宫泽理惠--1973生于东京都，十岁后已当模特儿，以第一部电影《我们的七日战争》(1988)荣获日本学院的新人奖，2002年以《黄昏清兵卫》荣获日本学院的最佳女主角奖，近年的舞台活动亦受注目。</p><p><img src="http://p31.qhimg.com/t0165958435d687e992.jpg?size=338x500"></p><p><a href="http://m.so.com/s?q=%E8%8B%A5%E5%B0%BE%E6%96%87%E5%AD%90&amp;src=newstranscode" class="qkw">若尾文子</a></p><p>若尾文子--1933年生于东京都，战争中疏散到仙台居住，高中毕业后立志当女优前往东京，成为大映的台柱明星，1971年大映破产后转至电视及舞台发展，2005年重上银幕参演了<a href="http://m.so.com/s?q=%E8%A1%8C%E5%AE%9A%E5%8B%8B&amp;src=newstranscode" class="qkw">行定勋</a>的《春雪》。</p><p>若尾文子(わかおあやこ)，日本女演员，生于1933年11月8日，于东京出生及成长。有“日本美人映画女优”之称，与效力大映的京町子、<a href="http://m.so.com/s?q=%E5%B1%B1%E6%9C%AC%E5%AF%8C%E5%A3%AB%E5%AD%90&amp;src=newstranscode" class="qkw">山本富士子</a>齐名。1952年若尾文子代替患上急病的久我美子在小石荣一导演的《逃离死之城》中第一次登场。若尾文子是<a href="http://m.so.com/s?q=%E5%A2%9E%E6%9D%91%E4%BF%9D%E9%80%A0&amp;src=newstranscode" class="qkw">增村保造</a>的御用女演员，由此也造就了若尾文子演艺生涯的高峰，她先后和川岛雄三、市川昆等众多名导演合作，至今共参与了160多部电影的演出。1970年淡出影坛，转向舞台剧的演出，2005年参与了行定勋<a href="http://m.so.com/s?q=%E3%80%8A%E6%98%A5%E9%9B%AA%E3%80%8B&amp;src=newstranscode" class="qkw">《春雪》</a>的拍摄。</p><p><img src="http://p35.qhimg.com/t011a5a8cf413530ca1.jpg?size=369x491"></p><p class="img-title">松隆子</p><p>松隆子--1977年生于东京都，银幕处女作是1997年竹中直人的《东京日和》，2004年在《隐剑鬼爪》中饰演女仆喜惠广受好评，主要在舞台演出，但亦活跃于歌坛。</p><p>松隆子，日本歌手、艺人。出生于东京都，原名为“藤间隆子”。所从事的“松本幸华”为她在舞台剧上的艺名(舞俑名)，是Papado, Inc.旗下艺人，及隶属于日本BMG唱片公司。2007年12月28日和知名音乐人佐桥佳幸闪电结婚。</p><p><img src="http://p32.qhimg.com/t01c53e8a5d7e457a2d.jpg?size=426x400"></p><p><a href="http://m.so.com/s?q=%E6%9D%BE%E5%9D%82%E5%BA%86%E5%AD%90&amp;src=newstranscode" class="qkw">松坂庆子</a></p><p>松坂庆子--1952年生于东京都，1970年首次演出大映的电影，大映破产后改投松竹，1978年以《事件》的玩命演技成为优秀明星，戏路广阔，擅演古装片到喜剧的成熟女性角色。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://history.gmw.cn/2015-06/12/content_15967207.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='feda7f7ad40041e676d2d9a029084dd0'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>秋日和</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%A7%8B%E6%97%A5%E5%92%8C&amp;pn=1&amp;pos=9&amp;m=de5953a183f568aaed78e71fdbc2a37a8caac2eb&amp;u=http%3A%2F%2Fhistory.gmw.cn%2F2015-07%2F29%2Fcontent_16455645.htm" data-pos="1"> 日本百年来最漂亮的十名女优(图) </a>   <li> <a href="/transcode?q=%E7%A7%8B%E6%97%A5%E5%92%8C&amp;pn=1&amp;pos=10&amp;m=f31d69ce7f0465d465c60c33aa3cb5f1f9663d3b&amp;u=http%3A%2F%2Fnews.china.com.cn%2Flive%2F2015-03%2F02%2Fcontent_31583233.htm" data-pos="2"> 美人如玉 中日娱乐圈中的绝色女神(组图) </a>   <li> <a href="/transcode?q=%E7%A7%8B%E6%97%A5%E5%92%8C&amp;pn=2&amp;pos=1&amp;m=0bbe20929cb58cc37a23c91562f54e54bdc1b7a9&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0325%2F13%2F9O6EFOVJ00014AED.html" data-pos="3"> 香港国际电影节致敬姜文 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '日本百年以来最漂亮的10大女优 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '日本百年以来最漂亮的10大女优 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";