s:19830:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>《栀子花开》携《速7》来袭沙发院线刮秋季风暴- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">《栀子花开》携《速7》来袭沙发院线刮秋季风暴</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-13 18:17:41</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t0178b9d4d7d78dd96d.jpg?size=499x233"></p><p><img src="http://p32.qhimg.com/t01b3972a1f180babe7.jpg?size=500x233"></p><p><img src="http://p34.qhimg.com/t01693a7b080534a2d7.jpg?size=500x230"></p><p><img src="http://p34.qhimg.com/t01b36b344c4f4819ba.jpg?size=498x231"></p><p><img src="http://p34.qhimg.com/t01985665ed879627f0.jpg?size=503x234"></p><p>继好莱坞动作大片<a href="http://m.so.com/s?q=%E3%80%8A%E9%80%9F%E5%BA%A6%E4%B8%8E%E6%BF%80%E6%83%857%E3%80%8B&amp;src=newstranscode" class="qkw">《速度与激情7》</a>之后，近日，又有三部国产大片已经席卷沙发院线，青春文艺片<a href="http://m.so.com/s?q=%E3%80%8A%E6%A0%80%E5%AD%90%E8%8A%B1%E5%BC%80%E3%80%8B&amp;src=newstranscode" class="qkw">《栀子花开》</a>、动画大电影《猪猪侠之终极决战》以及新派武侠电影<a href="http://m.so.com/s?q=%E3%80%8A%E6%83%85%E5%89%91%E3%80%8B&amp;src=newstranscode" class="qkw">《情剑》</a>三箭齐发，也于近期与沙发院线的观众们见面。这个夏季，沙发院线可谓好礼不断，大家不仅可以看到好莱坞动作大片《速度与激情7》、也能看到青春校园《栀子花开》，不仅能看到武侠影片《情剑》，还能看到NBA篮球明星<a href="http://m.so.com/s?q=%E5%8B%92%E5%B8%83%E6%9C%97&amp;src=newstranscode" class="qkw">勒布朗</a> 詹姆斯参演的真人大电影。不同类型影片在沙发院线的上映，也陪我们度过完美的暑假。请备足零食，备好纸巾，带上微笑与心跳，时刻准备着开启这段美妙的观影之旅!</p><p>风暴第一波:《栀子花开》<a href="http://m.so.com/s?q=%E4%BD%95%E7%82%85&amp;src=newstranscode" class="qkw">何炅</a>首次执导李易峰、<a href="http://m.so.com/s?q=%E8%92%8B%E5%8A%B2%E5%A4%AB&amp;src=newstranscode" class="qkw">蒋劲夫</a>等小鲜肉大秀芭蕾舞</p><p>十年前，何炅演唱的那首栀子花开曾引发校园学生对青春的集体告别。如今，这部让90后眼泪狂飙的影片已经在沙发院线上映。电影里没有花哨炫酷的转场切换，也没有破碎烧脑的片段式镜头，而是娓娓道来一件为梦想去完成一个&quot;看似不可能成功&quot;的故事。影片《栀子花开》由何炅导演，<a href="http://m.so.com/s?q=%E6%9D%8E%E6%98%93%E5%B3%B0&amp;src=newstranscode" class="qkw">李易峰</a>、蒋劲夫等小鲜肉倾情加盟，而男神李易峰和&quot;谋女郎&quot;<a href="http://m.so.com/s?q=%E5%BC%A0%E6%85%A7%E9%9B%AF&amp;src=newstranscode" class="qkw">张慧雯</a>的校园&quot;CP&quot;组合也将给你带来全新的体验。影片中，&quot;谋女郎&quot;张慧雯首献银幕初吻，一改她在张艺谋影片《归来》叛逆清纯的表现，李易峰、蒋劲夫等四个&quot;好基友&quot;大跳<a href="http://m.so.com/s?q=%E8%8A%AD%E8%95%BE%E8%88%9E&amp;src=newstranscode" class="qkw">芭蕾舞</a>，也令观众笑到抽筋。与此同时，在颜值爆表的背后，这部正能量满满的校园青春影片还在鼓励人们在追求梦想中不要放弃。</p><p>风暴第二波:《速度与激情7》全网首播狂野的速度根本就停不下来</p><p>不知不觉，<a href="http://m.so.com/s?q=%E3%80%8A%E9%80%9F%E5%BA%A6%E4%B8%8E%E6%BF%80%E6%83%85%E3%80%8B&amp;src=newstranscode" class="qkw">《速度与激情》</a>这个系列已经伴影迷走了十四年。但谁能想到，《速度与激情7》却成了保罗的银幕告别作。这次，《速度与激情7》在沙发院线全网首播，影迷们也将可以第一时间与我们的保罗亲密接触，与他告别了。值得一提的是，《速度与激情7》在我国实体院线上映一个月，总票房24亿，以及日票房四亿，这样的纪录依旧令其他影片望洋兴叹。而在高票房之外，影片在动作效果更加火爆，场面上也越做越大。更重要的是，范 迪塞尔、巨石强森、杰森 斯坦森三大动作男星首次汇合，单纯的公路狂飙已经升级为全方位军事向高科技空地大战，继续四处乱撞，汽车零件漫天飞舞，这样的动作场面也令观众的肾上腺素飙升，根本就停不下来。</p><p>风暴第三波:《情剑》沙发院线与院线同步上映<a href="http://m.so.com/s?q=%E8%B0%A2%E9%9C%86%E9%94%8B&amp;src=newstranscode" class="qkw">谢霆锋</a>演绎古龙最帅剑客</p><p>沙发院线在实现院线新片准同步上映的同时，也不断开启与院线同步上映新片的创举。继《我要你开花》之后，由谢霆锋、阿娇、<a href="http://m.so.com/s?q=%E4%B9%94%E6%8C%AF%E5%AE%87&amp;src=newstranscode" class="qkw">乔振宇</a>等全明星主演的《情剑》也于近期在沙发院线上映，影片将成为电视院线与实体院线同步上映的神话。《情剑》改编于古龙的武侠小说<a href="http://m.so.com/s?q=%E3%80%8A%E6%B5%A3%E8%8A%B1%E6%B4%97%E5%89%91%E5%BD%95%E3%80%8B&amp;src=newstranscode" class="qkw">《浣花洗剑录》</a>。武侠迷都知道，《浣花洗剑录》与《大旗英雄传》、《武林外史》、《绝代双骄》堪称<a href="http://m.so.com/s?q=%E5%8F%A4%E9%BE%99&amp;src=newstranscode" class="qkw">古龙</a>中期“四大名著”。这四部名著不仅在古龙小说系列占有重要的地位，它们在整个武侠文学中，都是重量级的作品。而影片中对于武侠的演绎也给武侠这种类型带来全新的感受。影片里，谢霆锋和阿娇的虐恋戏不断升级，二者相爱相杀将令观众虐到哭;而谢霆锋和乔振宇由兄弟到反目，也同样令人期待。</p><p>风暴第四波:<a href="http://m.so.com/s?q=%E3%80%8A%E7%8C%AA%E7%8C%AA%E4%BE%A0%E4%B9%8B%E7%BB%88%E6%9E%81%E5%86%B3%E6%88%98%E3%80%8B&amp;src=newstranscode" class="qkw">《猪猪侠之终极决战》</a>10年告别演出<a href="http://m.so.com/s?q=%E7%8C%AA%E7%8C%AA%E4%BE%A0&amp;src=newstranscode" class="qkw">猪猪侠</a>已成国产动漫大IP</p><p>猪猪侠系列自2004年开始创作，于2005年春节推出国内第一部动画电视电影《猪猪侠之大闹皇宫》。已经十周岁的猪猪侠，此前已推出两部银幕大作:《猪猪侠之囧囧危机》和《猪猪侠之勇闯巨人岛》。前者是继《喜羊羊》之后第二个被改编成电影的国产动画，后者则创造了上映3天斩获5000万票房的佳绩。动画电影《猪猪侠之终极决战》延续了猪猪侠系列电视动画的剧情，而在第九部动画《猪猪侠之百变联盟》中神秘消失的巴罗，也将在电影中现身;另外，首次露面的“猪猪侠妈妈”颜值惊艳，秒杀了一大票“猪猪粉”。在终结篇大电影《猪猪侠之终极决战》里，升级后的CG特效加强了角色的动作质感，场面恢弘逼真，颜色细腻协调，战斗场面极具炫酷的视觉效果，该片获赞“2015年最有大片范儿的动画电影”。近期沙发院线已经上映的这四部影片将陪小伙伴们度过完美假期，请小伙伴们莫失良机，快看快看!因为接下来还有<a href="http://m.so.com/s?q=%E3%80%8A%E7%94%9F%E6%B4%BB%E6%AE%8B%E9%AA%B8%E3%80%8B&amp;src=newstranscode" class="qkw">《生活残骸》</a>等一大波影片在拍队，等待着登陆沙发院线!</p><p>风暴第五波:《生活残骸》勒布朗 <a href="http://m.so.com/s?q=%E8%A9%B9%E5%A7%86%E6%96%AF&amp;src=newstranscode" class="qkw">詹姆斯</a>喜剧首秀首周票房仅次于好莱坞热门大片《蚁人》</p><p>近期，<a href="http://m.so.com/s?q=%E4%BB%8D%E5%9C%A8%E5%8C%97%E7%BE%8E&amp;src=newstranscode" class="qkw">仍在北美</a>热映的轻喜剧《生活残骸》将于近期，先于国内各大院线，率先在沙发院线最先上映。影片由美国喜剧导演贾德 阿帕图执导，艾米 <a href="http://m.so.com/s?q=%E8%88%92%E9%BB%98&amp;src=newstranscode" class="qkw">舒默</a>主演兼编剧，比尔 哈德尔、NBA篮球明星勒布朗 詹姆斯等人主演。颇为令影迷惊喜的是，本片还是NBA篮球明星勒布朗 詹姆斯主演的首部真人大电影。虽然是首次加盟喜剧影片，但他在影片中饰演的引人发笑的吝啬鬼一角获得影评者的一致好评，尤其是勒布朗 詹姆斯和艾米 舒默在影片中上演的感情戏，也非常出彩。《生活残骸》目前在国内还没有引进计划，沙发院线将先于国内各大院线，率先上映。观众们也将先于实体院线看到该片。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/article/4020303.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='464b1ce30ab6f368d043d1c8964ffe51'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>桅子</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%A1%85%E5%AD%90&amp;pn=1&amp;pos=3&amp;m=ee115a6b75b71c21a0790e4bdf211e70719bc8a7&amp;u=http%3A%2F%2Fwww.nxing.cn%2Fwap%2Farticle%2F4006256.html" data-pos="1"> 第七届金扫帚启动《<b>栀子</b>花开》《恶棍天使》领跑 </a>   <li> <a href="/transcode?q=%E6%A1%85%E5%AD%90&amp;pn=1&amp;pos=4&amp;m=563390f9893d3742791920c22597085b26fedf13&amp;u=http%3A%2F%2Fzhongzi.jinnong.cn%2Fufengmao88888%2F2016%2F03%2F12%2F2016031213551277458.shtml" data-pos="2"> <b>栀子</b>的种子如何卖价格 </a>   <li> <a href="/transcode?q=%E6%A1%85%E5%AD%90&amp;pn=1&amp;pos=5&amp;m=31883cddfbb8865c71a9607a322d005a9d1a586b&amp;u=http%3A%2F%2Fyule.sanxia193.com%2Fbuyazhao%2F40137.html" data-pos="3"> 泰国博仁大学独家爆料:《<b>栀子</b>花开》的台前幕后 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '《栀子花开》携《速7》来袭沙发院线刮秋季风暴' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '《栀子花开》携《速7》来袭沙发院线刮秋季风暴'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";