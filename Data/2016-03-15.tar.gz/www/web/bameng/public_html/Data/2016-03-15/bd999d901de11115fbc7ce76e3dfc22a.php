s:20266:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>贵州人惦记的那碗米粉具备哪些“修养”?- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">贵州人惦记的那碗米粉具备哪些“修养”?</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-14 22:19:09</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E4%BD%95%E6%99%BA%E4%B8%BD&amp;src=newstranscode" class="qkw">何智丽</a>的一天，是从一碗<a href="http://m.so.com/s?q=%E7%B1%B3%E7%B2%89&amp;src=newstranscode" class="qkw">米粉</a>开始的。</p><p>每天凌晨6点，供货商会将两百斤米粉送到何智丽时常光顾的<a href="http://m.so.com/s?q=%E7%BE%8A%E8%82%89%E7%B2%89&amp;src=newstranscode" class="qkw">羊肉粉</a>馆，它们会被做成红烧、清汤口味的羊肉粉，供应给这一天小店里的近千名食客。</p><p>然而，尽管吃了二十多年的米粉，平时买一瓶酱油都会下意识地翻看一下生产日期和厂家的何智丽，却忽视一个问题:米粉的来源是否安全。</p><p>作为贵州人食谱中占有极其重要位置的米粉，其供应保障主要来自小作坊，规模化企业较少。</p><p>于是，生产者的自律与诚信，相关部门的监管与引导，成为市民舌尖安全的重要保障。</p><p class="header">米粉多来自小作坊</p><p>贵州米粉市场上的米粉，绝大多数来自小作坊。</p><p>据贵州省<a href="http://m.so.com/s?q=%E9%A3%9F%E5%93%81%E8%8D%AF%E5%93%81%E7%9B%91%E7%9D%A3%E7%AE%A1%E7%90%86%E5%B1%80&amp;src=newstranscode" class="qkw">食品药品监督管理局</a>(下简称省食药监局)统计，我省现有米粉生产企业46家，米粉生产小作坊1394家。</p><p><img src="http://p34.qhimg.com/t01fed3b1d475931c9c.jpg?size=600x399"></p><p>(工人们进入车间前，必须换上工作服，戴上口罩、手套。)</p><p><img src="http://p35.qhimg.com/t01ef03130f766590bd.jpg?size=600x399"></p><p class="img-title">(大米侵泡之后，机器打成米酱。)</p><p>这两个数据透露出一个尴尬现状:相比小作坊，企业的安全更让人放心。然而，由于产能和销路限制，这46家企业并不能做到完全覆盖全省88个区县。</p><p>比如威宁县，人口过百万，合法的米粉生产企业和小作坊只有20家。</p><p>这意味着，贵州人早餐桌扮演主角的米粉，却主要依靠小作坊来供应。</p><p><img src="http://p31.qhimg.com/t01354a2cf33b51fd6e.jpg?size=600x399"></p><p class="img-title">(米酱经过加温，成为一整块米皮。)</p><p><img src="http://p33.qhimg.com/t0105e2538a09c566e1.jpg?size=600x399"></p><p class="img-title">(切成米粉之后，顺着水槽流出。)</p><p>省食<a href="http://m.so.com/s?q=%E8%8D%AF%E7%9B%91%E5%B1%80&amp;src=newstranscode" class="qkw">药监局</a>食品生产监督处副处长张体勇介绍，通常来说，米粉生产环节方面存在的主要问题是:一是生产场所环节卫生状况较差，未按照要求安装灭蝇设施、防鼠网，从业人员未着工作衣帽操作，索证索票记录不全，出厂检验记录不规范;二是原辅料进货登记、索证索票记录不全，原辅料大米存放未离地离墙，成品米粉存放设施清洁不足，生产设备清理维护不到位。</p><p>2015年，省食药监局组织在全省范围内开展米粉生产企业及小作坊专项监督检查和抽检，重点检查滥用<a href="http://m.so.com/s?q=%E9%A3%9F%E5%93%81%E6%B7%BB%E5%8A%A0%E5%89%82&amp;src=newstranscode" class="qkw">食品添加剂</a>、添加非食用物质、使用陈化粮等情况。</p><p>行动中，共出动执法人员2847人次，检查全省46家米粉生产工厂，1394家米粉生产小作坊，共抽检93批次米粉，实物合格率100%，标签合格率97.8%。</p><p>发现存在风险隐患的工厂6家，存在风险隐患的小作坊289家，查处案件3件，已整改存在问题的企业6家，小作坊274家。</p><p>这组数据也昭示着:小作坊的管理和引导成功与否，在很大程度上直接决定着消费者舌尖上的安全。</p><p class="header">监管+自律=安全</p><p>对小作坊进行引导，是目前保证米粉安全的重要工作。</p><p>由于生产工艺和原材料简单，开设小作坊的门槛很低。再加上米粉的利润很小，要求从业者投入大量资金到米粉生产商，对于多数人而言并不现实。于是，小作坊便越来越多，成为市场主导。</p><p><img src="http://p32.qhimg.com/t018fc4c89e921f0f7e.jpg?size=600x399"></p><p class="img-title">(将米粉理顺，装入篮中。)</p><p><img src="http://p34.qhimg.com/t01a177d1b2dadb7404.jpg?size=600x399"></p><p>(最后，把产出的米粉泡在冷水中冷却，之后晾干就可以出厂了。)</p><p>“如果取缔了小作坊，市民就吃不到米粉了。”由于小作坊目前有一定的必然和合理性，监管部门只能对其进行正确的引导。</p><p class="header">这并不是对小作坊的妥协。</p><p>按照省食药监局要求，生产米粉的小作坊，必须带上从业人员健康证、生产场地、设施设备、车间仓库等相关证明材料，到每个区县市的市场监管局去申报备案。</p><p><img src="http://p35.qhimg.com/t01727b002d135ecb03.jpg?size=600x399"></p><p>(每一道程序都有工人负责，保证每一个环节都做到最好。)</p><p>得益于食药监部门的监管，在记者随机走访的<a href="http://m.so.com/s?q=%E8%B4%B5%E9%98%B3%E5%B8%82&amp;src=newstranscode" class="qkw">贵阳市</a>内多家农贸市场、超市和较大的米粉店中，商家均能提供相关的合格证件和相关部门的抽检证明。</p><p>“开水烫一下，再多的细菌都被杀死了嘛!”遗憾的是，记者随机走访的多家路边早餐摊点，均未能提供相应的米粉安全证明，由于多为无照经营，脱离市场监管，大多数摊主对米粉安全表现得轻描淡写。</p><p>张体勇表示，使用陈化粮当原料，添加<a href="http://m.so.com/s?q=%E7%84%A6%E4%BA%9A%E7%A1%AB%E9%85%B8%E9%92%A0&amp;src=newstranscode" class="qkw">焦亚硫酸钠</a>、脱氢乙酸及其钠盐、<a href="http://m.so.com/s?q=%E6%98%8E%E7%9F%BE&amp;src=newstranscode" class="qkw">明矾</a>、吊白块等添加剂和非食用物质等行为，恰恰是小部分不自律的小作坊和黑作坊的惯用手段，如果长期食用此类米粉，会对人的身体健康带来些不良影响。</p><p>“不备案的，一律视为‘黑作坊’!”张体勇说，过去在米粉等食品安全的监管过程中，往往是质监、工商和卫生等多部门各司其职，需要多部门联合执法才能取得成效。</p><p>期间难免存在有利益就抢着上，有工作就互相推诿的情况，现在多部门整合为一家，有共同的执法目标，在执法力度和执法效力上更加高效。</p><p>执法中，对不符合规定要求的小作坊和生产企业，将责令限期整改，情节严重的则立案查处;涉嫌犯罪的，将移送政法机关处理。</p><p>期待更多的“<a href="http://m.so.com/s?q=%E6%90%85%E5%B1%80%E8%80%85&amp;src=newstranscode" class="qkw">搅局者</a>”</p><p>湄潭商人<a href="http://m.so.com/s?q=%E5%91%A8%E5%BB%BA%E5%8D%8E&amp;src=newstranscode" class="qkw">周建华</a>是米粉市场的一名“搅局者”。</p><p>2015年，伴随着被称为史上最严的<a href="http://m.so.com/s?q=%E3%80%8A%E9%A3%9F%E5%93%81%E5%AE%89%E5%85%A8%E6%B3%95%E3%80%8B&amp;src=newstranscode" class="qkw">《食品安全法》</a>的实施，从事粮油加工行业的周建华从中嗅到了商机。他决定投资两千万，在<a href="http://m.so.com/s?q=%E6%B9%84%E6%BD%AD&amp;src=newstranscode" class="qkw">湄潭</a>修建一个省内最大规模的米粉生产企业。</p><p>周建华长期从事粮油加工业，手下还有一家大米生产企业，在米粉的原材料上能够拿到主动权，这是许多小作坊不具备的优势。</p><p>由于湿米粉保质期应不低于1天(半湿米粉应不低于5天、干米粉应不低于30天)，为保证米粉尽可能新鲜，每天晚上9点，是周建华的米粉企业开工的时候。</p><p>40多名工人在生产线上各司其职。一袋袋大米被倒入泡米机内，经过温水浸泡将大米软化并淘洗后，进行自动磨浆。</p><p>经过高温蒸片，米浆被蒸成一块块米皮，被送到不同直径的挤丝机里，挤出一根根米粉。米粉再次经过气蒸和水泡进行杀菌。</p><p>这时的米粉才来到工人手中，这是整个工序中最少的人工直接接触米粉环节。带着手套和口罩的工人将米粉进行分量包装装箱，再经过检验和运输，这些米粉将在凌晨6点之前，被运到各个米粉店和市场，来到食客们的餐桌上。</p><p>按照周建华的加工厂200吨米粉的日产量，供应整个湄潭县城的米粉需求是绰绰有余。</p><p class="header">然而，周建华现在却不敢满负荷生产。</p><p>“小作坊太多，市民对米粉安全也不够重视。”<a href="http://m.so.com/s?q=%E9%81%B5%E4%B9%89%E5%B8%82&amp;src=newstranscode" class="qkw">遵义市</a>湄潭县市场监管局副局长何兴俊说，区县市场对小作坊的依赖更大。对此监管部门联合学校、幼儿园和农贸市场等米粉需求大户，优先采购米粉生产企业生产的放心米粉，用这样的方式让黑作坊和小作坊的市场变小，以此促使市场洗牌，引导帮扶有责任心的小作坊做大做强。</p><p>湄潭的模式，对省内其他地区有借鉴意义。</p><p>“希望这样的‘搅局者’越来越多。”张体勇说，目前贵州成规模的米粉生产企业数量，与庞大的米粉市场不成正比，如果每个县都有一家这样的米粉生产企业，加上政府的引导，小作坊也就没了市场，全省的米粉需求和安全也就得到了保障。</p><p>(文/本报首席记者 李易霖 图/本报记者 杨兴波 编辑 廖尚海)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/wap/article/4059703.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='cfa8173d37ead8efdedd9192151013a6'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>米粉</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '贵州人惦记的那碗米粉具备哪些“修养”?' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '贵州人惦记的那碗米粉具备哪些“修养”?'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";