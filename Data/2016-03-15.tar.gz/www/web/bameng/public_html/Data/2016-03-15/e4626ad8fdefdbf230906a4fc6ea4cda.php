s:19510:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>记者探访基层单位:公务员缺岗早退上班看视频- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">记者探访基层单位:公务员缺岗早退上班看视频</h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2016-02-16 08:18:00</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t01ae7e9a4d1239322a.jpg?size=300x251"></p><p>节后工作状态是观察干部作风的重要窗口。随着全面从严治党持续深入，猴年春节假期过后，“春节不出正月十五，进机关难找干部”陋习是否改观?从节后上班到岗情况能看到基层干部作风出现哪些变化?记者深入北京、吉林、湖北、安徽、宁夏等地基层部门进行了探访。</p><p class="header">好转 领导督促纪委抽查</p><p>银川市民大厅是宁夏最大的政务服务综合体，700多个服务窗口为市民和企业提供400多项审批和公共服务事项办理。14日早晨刚到上班时间，记者在市民大厅内看到，前来办理业务的市民不多，但除少数机动窗口外，各服务窗口均有工作人员在岗可办理业务。</p><p>记者看到，上班后不久，<a href="http://m.so.com/s?q=%E9%93%B6%E5%B7%9D%E5%B8%82&amp;src=newstranscode" class="qkw">银川市</a>行政审批局相关负责人就来到市民大厅，挨个业务窗口向工作人员拜年。一位工作人员介绍，局领导节后首日来向窗口干部拜年，既是表达祝福心意，也是对窗口到岗率的监督检查，“挨个窗口边走边看，哪个窗口迟到，哪个缺岗一目了然”。</p><p>上午8时50分，记者来到合肥市地税局<a href="http://m.so.com/s?q=%E7%BB%8F%E6%B5%8E%E5%BC%80%E5%8F%91%E5%8C%BA&amp;src=newstranscode" class="qkw">经济开发区</a>分局办税大厅，各个业务窗口的工作人员都已到岗。除少数正在为群众办税的窗口外，其余工作人员都被召集在一位负责人旁开会，记者听到负责人多次提及节后上班不准迟到早退。</p><p>北京市一位基层街道办干部表示，过去春节过后事儿不多，晚几天上班，或者只上半天班等情况不少。今年放假前领导专门强调，决不允许节后迟到旷工，“回家过年怕路途耽误，早就买好返程机票”。</p><p>不少地区纪检监察部门节后首日组织明察暗访。结果反映，到岗情况和工作状态比往年明显好转。宁夏吴忠市<a href="http://m.so.com/s?q=%E5%88%A9%E9%80%9A%E5%8C%BA&amp;src=newstranscode" class="qkw">利通区</a>第一纪工委书记<a href="http://m.so.com/s?q=%E5%BC%A0%E5%B9%BF%E5%86%9B&amp;src=newstranscode" class="qkw">张广军</a>说，节后一上班，全区纪检系统就分组突击检查区直部门和乡镇街道，“检查发现各单位业务开展正常，不少部门在组织开会或扫雪，除个别人员请假外，到岗情况良好”。</p><p>一些地区纪检部门介绍，目前，对上班出勤、工作纪律等作风检查早已常态化，如果有人迟到、缺岗，遇上检查就少不了要被处分，“尤其是节后第一天这个关键节点，相信绝大多数人都不会往枪口上撞”。</p><p class="header">溜号 上午签到下午关门</p><p>不过，记者采访发现，虽然单位内部强调纪律、纪检部门突击检查，但仍然存在缺岗<a href="http://m.so.com/s?q=%E6%97%A9%E9%80%80&amp;src=newstranscode" class="qkw">早退</a>、上班闲聊娱乐等现象。</p><p>--上班考勤“露个脸”。记者14日上午在<a href="http://m.so.com/s?q=%E9%95%BF%E6%98%A5%E5%B8%82&amp;src=newstranscode" class="qkw">长春市</a>高新技术开发区双德街道办事处等地看到，一些办公室和工位“灯亮人不在”，一段时间内无人进出，敲门也无应答。</p><p>有基层工作人员透露，现在各单位对工作作风抓得严，一些部门甚至要求上下班都考勤，以制止迟到早退等不良现象。但是，还有一些工作人员早上签到后就回家或外出办私事，下班前再赶回来签退。有的遇上检查就借口外出办事，一般也能过关，“春节期间这种现象还是比较多见”。</p><p>--未到下班时间办公室“关门”。记者14日两次来到安徽<a href="http://m.so.com/s?q=%E8%82%A5%E8%A5%BF%E5%8E%BF&amp;src=newstranscode" class="qkw">肥西县</a>桃花镇政府，却看到前后不一的现象。上午10时许，记者在镇政府大楼内转了一圈，门上挂牌办公室大都有人在岗;下午4时许，记者再度探访，发现不少办公室都已关门，敲门也无人应答。</p><p>桃花镇国土所挂牌办公室共有三间，下午均已关门，记者多次敲门也无人应答。记者询问旁边办公室，得到国土所一位工作人员电话。记者多次拨打电话后，这名工作人员回电话称，下午“学习”去了。</p><p>--身虽到心已远。在武汉市江岸区丹水池街便民服务大厅内，各窗口都有工作人员上班。记者以咨询政策为由，推开城市管理科办公室大门看到，一名女性工作人员正在观看视频网站节目。在记者咨询过程中，这名工作人员一直在看视频，直到记者问完问题才关闭。</p><p>四川一位乡镇党委书记表示，春节假期过后、正月十五之前，基层部门来办事群众不多，干部有私事处理，一般会要求走请假程序，而且保证相关部门都得有人在岗，不影响群众办理业务，“上班就要有岗位纪律，迟到早退，炒股看片肯定不允许”。</p><p class="header">建议 作风建设还需精细</p><p>一些专家表示，多<a href="http://m.so.com/s?q=%E5%9C%B0%E8%8A%82&amp;src=newstranscode" class="qkw">地节</a>后上班作风较往年明显改善，体现出制度建设完善、政治生态净化;同时，一些地方出现的迟到早退“走过场”等现象，表明今后作风建设应该更加精细化，持之以恒预防反弹。</p><p>记者采访了解到，不少地区正在采取多项举措，推动作风建设立体化。北京市<a href="http://m.so.com/s?q=%E8%A5%BF%E5%9F%8E%E5%8C%BA&amp;src=newstranscode" class="qkw">西城区</a>除了纪检监察部门不定期抽查外，还建立了电子行政监察系统，全程监督工作人员在岗和服务情况，如果有工作人员上班玩电脑游戏、工作懈怠等都会被“电子眼”揪住。</p><p>北京市西城区纪委相关负责人表示，除实时观看视频画面，系统还可以进行同步视频、音频录像，以便于对违规事件进行历史查询和视频取证，“这些措施对于监督节后干部作风，营造清正政治生态效果明显”。</p><p>“对基层而言没有大政，只要具体小事都做好了，新风正气就来了。”<a href="http://m.so.com/s?q=%E5%9B%BD%E5%AE%B6%E8%A1%8C%E6%94%BF%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">国家行政学院</a>教授汪玉凯表示，节后窗口单位人员的到岗情况、服务态度、精神面貌也是政治生态的一部分。尤其是在当前经济下行压力大，急需各级干部充分发挥主观能动性的背景下，在作风建设精细化等方面还需下功夫。据新华社</p><p><a href="http://m.so.com/s?q=%E4%BA%BA%E6%B0%91%E6%97%A5%E6%8A%A5&amp;src=newstranscode" class="qkw">人民日报</a>:万亿科研经费到底去哪了</p><p>湖南<a href="http://m.so.com/s?q=%E6%B9%98%E6%BD%AD&amp;src=newstranscode" class="qkw">湘潭</a>问责28名党政一把手</p><p>各地破养老难题 陕西给70岁以上老人发高龄津贴</p><p class="header">京津冀“十三五”规划 印发实施</p><p>高清:<a href="http://m.so.com/s?q=%E6%83%85%E4%BA%BA%E8%8A%82&amp;src=newstranscode" class="qkw">情人节</a>成都街头兜售玫瑰花的<a href="http://m.so.com/s?q=%E5%8D%96%E8%8A%B1%E5%A5%B3&amp;src=newstranscode" class="qkw">卖花女</a></p><p>高清:大连机场300多航班取消 滞留旅客约1.4万人</p><p>高清:江苏盐城新春招聘会人气爆棚 1.5万人现场找工作</p><p>高清:<a href="http://m.so.com/s?q=%E8%B5%B0%E8%BF%9B%E5%9B%9B%E5%B7%9D&amp;src=newstranscode" class="qkw">走进四川</a>茂县曲谷羌寨 探秘古老的<a href="http://m.so.com/s?q=%E5%9F%BA%E5%8B%92&amp;src=newstranscode" class="qkw">基勒</a>俄足节</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://leaders.people.com.cn/n1/2016/0216/c58278-28126631.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='16ec562e239229fc89f5f036d93233d6'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>早退</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%97%A9%E9%80%80&amp;pn=1&amp;pos=9&amp;m=f2007b7e9adf9f7d73834e86ce9e87621157998b&amp;u=http%3A%2F%2Fleaders.people.com.cn%2Fn1%2F2016%2F0216%2Fc58278-28126631.html" data-pos="1"> 记者探访基层单位:公务员缺岗<b>早退</b>上班看视频 </a>   <li> <a href="/transcode?q=%E6%97%A9%E9%80%80&amp;pn=1&amp;pos=10&amp;m=3766e0db7dba3f50300ff755aba80b924e2761c1&amp;u=http%3A%2F%2Fpaper.chinaso.com%2Fdetail%2F20160304%2F1000200032869521457047470923964011_1.html" data-pos="2"> 九成受访者不愿延迟退休 希望<b>早退</b>的多是普通工人 </a>   <li> <a href="/transcode?q=%E6%97%A9%E9%80%80&amp;pn=2&amp;pos=1&amp;m=3ba50dd7bbff8567913d6a24e0d0de1c2e275f6b&amp;u=http%3A%2F%2Fnews.cnr.cn%2Fnative%2Fgd%2F20160215%2Ft20160215_521382901.shtml" data-pos="3"> 节后第一天探访基层政府部门:迟到<b>早退</b>现象仍不少 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '记者探访基层单位:公务员缺岗早退上班看视频' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '记者探访基层单位:公务员缺岗早退上班看视频'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";