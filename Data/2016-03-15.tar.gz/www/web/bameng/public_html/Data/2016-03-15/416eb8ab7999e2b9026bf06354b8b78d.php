s:21011:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>深圳御宝轩展出《程意亭花鸟瓷板画两条屏》- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">深圳御宝轩展出《程意亭花鸟瓷板画两条屏》</h1> <p id="source-and-time"><span id=source>环球网</span><time id=time>2015-04-30 10:50:00</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E7%A8%8B%E7%94%AB&amp;src=newstranscode" class="qkw">程甫</a>，名意亭，字体孚，斋名佩古，别号<a href="http://m.so.com/s?q=%E7%BF%A5%E5%B1%B1&amp;src=newstranscode" class="qkw">翥山</a>樵子。江西乐平人，1911年入<a href="http://m.so.com/s?q=%E9%84%B1%E9%98%B3&amp;src=newstranscode" class="qkw">鄱阳</a>江西窑业学堂图画班，师从张晓耕、<a href="http://m.so.com/s?q=%E6%BD%98%E9%99%B6%E5%AE%87&amp;src=newstranscode" class="qkw">潘陶宇</a>，后赴上海，拜上海浙派画家<a href="http://m.so.com/s?q=%E7%A8%8B%E7%91%B6&amp;src=newstranscode" class="qkw">程瑶</a>生门下，成为程瑶生的入室弟子，在上海数年，其花鸟画艺术，深得南宋画院派的艺术精髓，画艺日渐成熟和完美。<a href="http://m.so.com/s?q=%E7%A8%8B%E6%84%8F%E4%BA%AD&amp;src=newstranscode" class="qkw">程意亭</a>花鸟画擅长工兼写，多以松鹤、荷塘、<a href="http://m.so.com/s?q=%E6%B0%B4%E9%B8%9F&amp;src=newstranscode" class="qkw">水鸟</a>、紫藤、秋菊等为题材，常以瓷板、四方镶器为装饰载体。</p><p>在他的众多瓷板画的题款中，几乎均有“拟南沙老人大意”、“拟鸳湖老人笔意”、“拟鸳湖老人法”、“拟廷锡相国大意”、“师南沙翁法”、“仿鸳湖老人画法”等字样，反映了程先生聪慧好悟、勤学苦练、师古人之心而不师古人之迹的治学精神。“南沙老人”、“鸳湖老人”即清代杰出画家<a href="http://m.so.com/s?q=%E8%92%8B%E5%BB%B7%E9%94%A1&amp;src=newstranscode" class="qkw">蒋廷锡</a>。善画花卉，多用逸笔，或奇或正，或率或工，或赋色，或晕墨，自然、生动、恬雅。程意亭受其影响，程意亭的作品在笔法上多兼工带写，用笔飘逸洒脱且工整细腻;在赋色上清新雅丽、不浮不躁;在构图上奇中求正、穿插自如，错综而又空灵;在形象上刻画细腻入微，却又注重动势神态，突破了一般花鸟画的媚世艳俗、烦琐臃杂之弊端。</p><p><img src="http://p35.qhimg.com/t019f203f2ebf27619f.jpg?size=342x509"></p><p>深圳御宝轩展出<a href="http://m.so.com/s?q=%E3%80%8A%E7%A8%8B%E6%84%8F%E4%BA%AD%E8%8A%B1%E9%B8%9F%E7%93%B7%E6%9D%BF%E7%94%BB%E4%B8%A4%E6%9D%A1%E5%B1%8F%E3%80%8B&amp;src=newstranscode" class="qkw">《程意亭花鸟瓷板画两条屏》</a></p><p>近期，深圳御宝轩正在展出程意亭花鸟瓷板，1组2件 长:73.5cm宽:21cm，瓷板画汲取了中国画的营养，画中山水花卉光彩传神，栩栩如生，文字画面挥洒自如，精湛纯熟，充满着别样的意境，非常符合中国人传统的审美习惯和审美趣味。该瓷板画瓷质优美，温润细腻，精致优美，古色古香，施以木质精装体现出高贵雅致的气质。瓷板画整体大度的气势与局部工细的描绘相得益彰。密不透风的荷花<a href="http://m.so.com/s?q=%E8%8C%8E%E5%8F%B6&amp;src=newstranscode" class="qkw">茎叶</a>与空旷虚无的水塘，灵巧生动的水鸟与静中寓动的花叶所形成的强烈反差，给人留下了深刻的印象。</p><p>整体看来，程意亭小写意笔法作花鸟画，清新灵动，意趣<a href="http://m.so.com/s?q=%E9%AB%98%E5%8D%8E&amp;src=newstranscode" class="qkw">高华</a>，恬淡冲和，风格独具。从程氏花鸟画的笔墨特点来看，可以概括为几个方面:</p><p>一是程氏画花鸟，多用勾描填色之法，讲究骨法用笔，线条细润劲挺，工整圆润，刚柔相济。特别是以“钉头鼠尾”描法勾勒的花叶，行笔有繁有简，有粗有细。而仿制品的勾勒多落笔随意，收笔飘浮，凝涩枯竭，笔韵含蓄不足，少韧练之气。</p><p>二是程氏画鸟惯用工笔丝羽法，在勾勒的基础上，用尖细的枯笔丝羽，再以色罩染，以求<a href="http://m.so.com/s?q=%E9%B8%9F%E7%9A%84%E7%BE%BD%E6%AF%9B&amp;src=newstranscode" class="qkw">鸟的羽毛</a>整体有厚度，工细入微，严谨精致。而模仿品细腻不够，层次缺少，工整者多板实僵硬，用工少者又显单薄，丝羽之法难得要领。</p><p>三是程氏画鸟头部均较大，但鸟的形体却很生动，有人问他是否合适，他说:“一幅花卉翎毛画上的鸟，多半是作为主将出现，头小就不威武，更难传神。”</p><p>另外，程意亭花鸟画的设色，也有几个独有特点:一是程氏所用颜料经过自己的漂研凋配，色泽妍丽而不娇媚，在填色时义能轻拂丹青，以薄为贵，呈现出特有的清丽娟秀，既有文人画清雅的一面，又有工笔重彩的艳丽，<a href="http://m.so.com/s?q=%E8%89%B3%E8%80%85&amp;src=newstranscode" class="qkw">艳者</a>无飘浮感，淡者也非苍白无神，厚重浅淡之处，均以笔法皴擦染而成。二是填色下艺达到运用自如，驾轻就熟的程度。如程氏画花多用胭脂红洗染，浓淡相宜，过渡自然，颜色莹润;而填画荷花却着意淡雅，表现到<a href="http://m.so.com/s?q=%E8%B5%AD%E8%89%B2&amp;src=newstranscode" class="qkw">赭色</a>，既丰富画面色彩，又增添了生活的真实。</p><p>“珠山四友”在每个人自身长达几十年的绘画生涯中，每个人各尽所长，他们兼工带写、构思严谨、用笔流畅的特点不管是人还是景色刻画得惟妙惟肖，其画面的线条，精细而不失力度;灵动、准确、飘逸、凝重、流畅、顿挫，笔笔到位。“珠山四友”凭借自己的画风、对生活的感悟、人文情感和人格的魅力作为其艺术底蕴，使俊雅飘逸、超凡脱俗的瓷板画风尽展无遗。可以说他们笔下的一人一花一草一鸟都充满了“文人画”的意趣美、意境美和形式美。采用古粉彩法着色，淡雅古朴，人物形态逼真，有静穆之美，将历史典故淋漓尽致表现出来，装饰性极强、釉面见有晕光、光泽柔和，将四景用一种釉色轻快明丽的方式展现出来，有一种呼之欲出的奇妙感觉，此时此景非常令人神往。</p><p>此件瓷板画正是程意亭艺术创作的鼎盛成熟时期作品，代表了其极富标志性的花鸟瓷板画的最高水平，笔法灵动，疏简，境界清旷，题款行书圆润厚实，笔力苍劲，堪称大师重笔。瓷板画千古年来流传至今，可谓延绵不衰，究其原因。其一，瓷板画具有瓷板平整光洁之美，以瓷当纸，充分发挥作者的绘画天才和展示瓷画的审美意境。其二，瓷板画将中国最美的瓷和中国最具特色的山水画合二为一，瓷板画便于表现中国画的神韵和意味，符合中国人传统的审美习惯和审美趣味。其三，瓷板画由其物理性质和化学性能决定，不怕潮湿，不怕霉变，只需防碰撞。其四，瓷板画样式多样，可以根据家居装饰自由选择，且装饰范围广，即可独立成体挂于客厅、书房，又可作家具的镶嵌之饰，或制成插屏或围屏。据专家介绍，瓷板画最早始于秦汉时期，而真正意义上的瓷板画则出现在明代中期。在清代达到鼎盛阶段。而收藏市场上老的瓷板画多是清代、民国时期，新中国成立后也有不少民家制作的瓷板画受到藏友的热捧。目前，现代瓷板画行情逐渐走高，一些经营现代瓷器的人士邀请<a href="http://m.so.com/s?q=%E6%9D%A5%E8%87%AA%E6%99%AF%E5%BE%B7%E9%95%87&amp;src=newstranscode" class="qkw">来自景德镇</a>的名家，或是一些书画名家定制瓷板画，收藏爱好者的增加也使得现代瓷板画行情逐年看涨。</p><p>纵观目前市场上瓷板画市场，尽管瓷板画历史并不悠久，但其在海内外的极高声誉地位和中国画的深厚文化底蕴，深受藏家喜爱。近年来，随着人们生活水平的提高，艺术品收藏越来越走入人们的视线，尤其是高端艺术品价格不断攀升，民国时期最负盛名的“<a href="http://m.so.com/s?q=%E7%8F%A0%E5%B1%B1%E5%85%AB%E5%8F%8B&amp;src=newstranscode" class="qkw">珠山八友</a>”瓷板画成为了收藏家们竞购的热门藏品，并现身各类拍卖会及展览会。事实上，民国瓷板画在艺术市场中一直处于价值被低估的状态。但从近几年来“珠山八友”瓷板画的拍卖行情来看，其作品成交额呈逐年攀升的趋势。2008年拍卖的王琦粉彩瓷板<a href="http://m.so.com/s?q=%E3%80%8A%E6%B8%94%E7%BF%81%E5%9B%BE%E3%80%8B&amp;src=newstranscode" class="qkw">《渔翁图》</a>以241.5万元成交;2009年拍卖的<a href="http://m.so.com/s?q=%E7%8E%8B%E5%A4%A7%E5%87%A1&amp;src=newstranscode" class="qkw">王大凡</a>一件《黄山四千仞》瓷板拍出780万元的高价;而在2011年的嘉德春季拍卖会上，王大凡的粉彩瓷板画<a href="http://m.so.com/s?q=%E3%80%8A%E7%A6%B9%E7%8E%8B%E6%B2%BB%E6%B0%B4%E5%9B%BE%E3%80%8B&amp;src=newstranscode" class="qkw">《禹王治水图》</a>以920万元创个人成交纪录。在不到数十年的时间里，“珠山八友”瓷板画的成交价格从几万元直线上升到几十万，甚至数百万元。从市场价位来看，目前“珠山八友”瓷板画的价格远远低于当年同时期、同名气的画家的价格，可以断言，“珠山八友”的瓷板画还具有广阔的升值空间，其作品非常值得珍藏。目前深圳御宝轩正在展出的此件“珠山八友”瓷板画，不管是从瓷品、品相、作品意境来说，都是上等佳品，值得期待。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://finance.huanqiu.com/zl/2015-04/6316942.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='a5e1df5863ef940b84f418f5d51306aa'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>渔翁图</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%B8%94%E7%BF%81%E5%9B%BE&amp;pn=1&amp;pos=6&amp;m=21d64053a002c39ce8d35d12cbec54b89a837ff0&amp;u=http%3A%2F%2Ffinance.huanqiu.com%2Fzl%2F2015-04%2F6316942.html" data-pos="1"> 深圳御宝轩展出《程意亭花鸟瓷板画两条屏》 </a>   <li> <a href="/transcode?q=%E6%B8%94%E7%BF%81%E5%9B%BE&amp;pn=1&amp;pos=7&amp;m=5b2a2b47388755571a388e443c71d9f136f31ea2&amp;u=http%3A%2F%2Ffinance.huanqiu.com%2Fzl%2F2015-04%2F6316944.html" data-pos="2"> 王琦麻姑献寿桃瓷板画》典雅韵致 独具风骨 </a>   <li> <a href="/transcode?q=%E6%B8%94%E7%BF%81%E5%9B%BE&amp;pn=1&amp;pos=8&amp;m=74d0eaa5a02de45c517d93712595c4f677458406&amp;u=http%3A%2F%2Fpolitics.caijing.com.cn%2F2014-04-13%2F114093121.html" data-pos="3"> 珠山八友用文人画艺替代康雍粉彩其瓷板画成交额逐年攀升渐成热门 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '深圳御宝轩展出《程意亭花鸟瓷板画两条屏》' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '深圳御宝轩展出《程意亭花鸟瓷板画两条屏》'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";