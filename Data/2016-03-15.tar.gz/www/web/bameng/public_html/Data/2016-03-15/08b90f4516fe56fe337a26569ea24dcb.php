s:14686:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>吴兴企业引入智慧资本- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">吴兴企业引入智慧资本</h1> <p id="source-and-time"><span id=source>光明网</span><time id=time>2015-06-21 07:52:00</time></p> </header>  <div id="news-body"><p class="header">记者郑嵇平</p><p>本报讯会场上已是座无虚席，来自<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E7%A7%91%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">中国科学院</a>、中国工程院、<a href="http://m.so.com/s?q=%E8%A5%BF%E5%AE%89%E4%BA%A4%E9%80%9A%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">西安交通大学</a>及华中科技大学等高校院所的19位院士专家齐聚一堂，与企业代表侃侃而谈起来。这是近日发生在2015院士专家<a href="http://m.so.com/s?q=%E5%90%B4%E5%85%B4&amp;src=newstranscode" class="qkw">吴兴</a>行百日专项活动启动仪式上的一幕。当天，共有3家企业与院士团队现场签订了长期合作协议，7家企业与院士进行了深入对接，达成初步的合作意向。“我们现在正在攻关物联网技术在智能物流中的应用，如果有高端人才的技术支持，就能加快研发项目的实施。”来自该区的浙江<a href="http://m.so.com/s?q=%E6%B1%87%E6%99%BA&amp;src=newstranscode" class="qkw">汇智</a>物流装备技术有限公司有关负责人，把技术需求直接带到了会场。通过匹配，在<a href="http://m.so.com/s?q=%E6%9C%BA%E5%99%A8%E4%BA%BA&amp;src=newstranscode" class="qkw">机器人</a>研发领域享有话语权的<a href="http://m.so.com/s?q=%E7%86%8A%E6%9C%89%E4%BC%A6&amp;src=newstranscode" class="qkw">熊有伦</a>院士团队将进驻企业，为其量身定制解决方案。</p><p>据了解，院士专家吴兴行活动已成为该区每年的“固定节目”。区委组织部有关负责人告诉记者，近年来，该区通过搭平台，送政策，办活动等方式，不断加强院士专家的智囊团与企业交流，从思想和行动上激发企业创新驱动的主体意识。“特别是针对具有发展优势但又存在人才短缺或有技术需求的企业，通过院士专家的帮助，给企业输入‘<a href="http://m.so.com/s?q=%E6%99%BA%E5%8A%9B%E8%B5%84%E6%9C%AC&amp;src=newstranscode" class="qkw">智力资本</a>’。”该位负责人说。目前，该区共建有省级企业院士专家工作站2家，市级企业院士专家工作7家，对引领企业技术创新起到了显著作用。</p><p><a href="http://m.so.com/s?q=%E9%82%B1%E7%88%B1%E6%85%88&amp;src=newstranscode" class="qkw">邱爱慈</a>院士是我国强流脉冲粒子束加速器和高功率脉冲技术领域的主要开拓者之一。当天，她所领衔的院士团队与该区的浙江大东吴汽车电机有限公司结成了技术合作伙伴。团队成员――来自西安交通大学的专家梁得亮博士成为了企业的技术顾问。</p><p>据了解，该团队将为企业发展战略规划、战略性新产品、新技术如新能源电机等提供技术指导和咨询，并且还将提供行业发展相关的前沿技术信息，并结合企业的需求，以讲座等形式，对企业高层管理和科技人员进行培训。“作为国家重点扶持高新技术企业，我们致力于车用电机的开发和生产，为汽车发动机提供安全可靠和高性能、高效率、环保节能绿色驱动电机的解决方案。”大东吴相关负责人说，在新项目的技术攻关上，确实需要高端人才的技术支持，“这次活动帮我们请到了‘贵人’，我们会为团队提供优质的科研环境。”</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://edu.gmw.cn/newspaper/2015-06/21/content_107427612.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='5d1f0c8bc2c981d3a2f1b37ff15f84c2'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>智慧资本</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%99%BA%E6%85%A7%E8%B5%84%E6%9C%AC&amp;pn=1&amp;pos=7&amp;m=428c65eb29d061424e95c9e079944f5445d64e21&amp;u=http%3A%2F%2Flohas.china.com.cn%2F2016-03%2F07%2Fcontent_8618207.htm" data-pos="1"> 杨树<b>资本智慧</b>生态战略开局 沐禾节水智能灌溉现大手笔 </a>   <li> <a href="/transcode?q=%E6%99%BA%E6%85%A7%E8%B5%84%E6%9C%AC&amp;pn=1&amp;pos=8&amp;m=bfbe12fafa9d98b425717f58a59453235680e294&amp;u=http%3A%2F%2Fedu.gmw.cn%2Fnewspaper%2F2015-06%2F21%2Fcontent_107427612.htm" data-pos="2"> 吴兴企业引入<b>智慧资本</b> </a>   <li> <a href="/transcode?q=%E6%99%BA%E6%85%A7%E8%B5%84%E6%9C%AC&amp;pn=1&amp;pos=9&amp;m=f1e020093cfd387acfb7669b966f4fcac06b3fbe&amp;u=http%3A%2F%2Fnews.163.com%2F15%2F1025%2F00%2FB6NURV1L00014AED.html" data-pos="3"> 《瞬间的<b>资本智慧</b>》北大首发 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '吴兴企业引入智慧资本' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '吴兴企业引入智慧资本'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";