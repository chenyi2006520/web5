s:16366:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>安徽农大“绿色课堂”为孩子解惑- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">安徽农大“绿色课堂”为孩子解惑</h1> <p id="source-and-time"><span id=source>新浪</span><time id=time>2015-06-16 06:00:08</time></p> </header>  <div id="news-body"><p>本报记者 王磊<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E5%9B%BD%E9%9D%92%E5%B9%B4%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《中国青年报》</a>(2015年06月16日07版)</p><p>“现在很多孩子，特别是城市长大的孩子，从小就知道<a href="http://m.so.com/s?q=%E9%BB%91%E6%B4%9E&amp;src=newstranscode" class="qkw">黑洞</a>、太阳黑子，但是他们却分不清水稻与小麦之间的区别。”</p><p>“一个孩子看到带蛋壳的鸡蛋不愿吃，原来他只见过剥了壳的鸡蛋。”</p><p>“一个孩子说起动漫片‘<a href="http://m.so.com/s?q=%E7%BE%8E%E5%9B%BD%E9%98%9F%E9%95%BF&amp;src=newstranscode" class="qkw">美国队长</a>’如数家珍，可他对于<a href="http://m.so.com/s?q=%E7%A5%9E%E5%86%9C%E6%B0%8F&amp;src=newstranscode" class="qkw">神农氏</a>的历史一无所知。”……</p><p>这是<a href="http://m.so.com/s?q=%E5%AE%89%E5%BE%BD%E5%86%9C%E4%B8%9A%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">安徽农业大学</a>的志愿者们在对城区孩子自然认识状况调研时发现的现象。</p><p>身处“钢筋水泥”中，<a href="http://m.so.com/s?q=%E5%9F%8E%E5%B8%82%E5%AD%A9%E5%AD%90&amp;src=newstranscode" class="qkw">城市孩子</a>对自然中的动物、植物越来越陌生。为了破解这一教育难题，自2014年起，安徽农业大学联合团蜀山区委，整合高校志愿者资源，在辖区的小学统一开展“<a href="http://m.so.com/s?q=%E7%BB%BF%E8%89%B2%E8%AF%BE%E5%A0%82&amp;src=newstranscode" class="qkw">绿色课堂</a>”支教活动。</p><p>据了解，该活动借助安农大农林类专业办学优势，让小学生在学习过程中了解农林知识，拓宽视野。活动以3+1的课程模式(即三节集体授课和一节实践活动)、项目化运作的方式开展。</p><p>授课内容主要包括农作物、茶文化、环境保护等方面的基础知识。而实践活动则注重小学生的体验教育，带领小学生走进农业园，让学生了解果树的生长规律，懂得如何鉴别果树的种类。通过观察体验多肉植物生长过程及茶叶制作过程，感受<a href="http://m.so.com/s?q=%E5%A4%A7%E8%87%AA%E7%84%B6%E7%9A%84%E9%AD%85%E5%8A%9B&amp;src=newstranscode" class="qkw">大自然的魅力</a>，从而提升小学生的探索创新能力。通过亲身学习、体验，他们可以了解农村、农业、农民，从而培养 “悯农，爱农，学农”的精神。</p><p>“现在很多小学的自然老师都是语数外老师兼职，缺少相关的专业知识，所以上课时只能局限于教材。”一位合肥教育界人士分析道，农大学生可以依托专业优势，拓展学生的知识面，而且通过互动性的教学方式，活跃课堂气氛，激发学生的学习兴趣。在他看来，最关键的是，“<a href="http://m.so.com/s?q=%E8%87%AA%E7%84%B6%E8%AF%BE&amp;src=newstranscode" class="qkw">自然课</a>这样的课程，一定要在自然当中上，否则学生只会从画面上了解水稻”。</p><p>“传授是互动的，对<a href="http://m.so.com/s?q=%E6%94%AF%E6%95%99%E8%80%81%E5%B8%88&amp;src=newstranscode" class="qkw">支教老师</a>来说，这本身也是一个学习过程。”<a href="http://m.so.com/s?q=%E6%9D%8E%E5%A7%97%E5%A7%97&amp;src=newstranscode" class="qkw">李姗姗</a>是安徽农业大学农学院的学生，入校没多久，她就参加了这项支教活动。“我曾经也是个留守儿童，成长过程中受到了很多人的关爱，因而我要把爱心传递下去”。</p><p>“尽管我是农村孩子，而且学的又是农学专业，但是备课过程中可没少下功夫。”李姗姗说，尽管是给小学生上课，但丝毫不能出错，每次备课，都要查阅很多资料，不懂的还要问老师。</p><p>据了解，为了确保教学质量，安徽农业大学团委还组织了植物、农学等学科的教授指导学生的课程设计与研发，为他们的教学质量把关。</p><p>“我们希望更多的大学生参与进来，我们的初衷就是把志愿者活动与人才培养结合起来，让大学生在支教过程中增加专业知识、提升专业技能，树立起正确的专业思想，坚定从事农业的信念。”安徽农业大学团委负责人张建说。</p><p>“对团区委来说，这也是共青团‘校地共建’模式的创新， 我们将联合安农大团委不断拓宽‘绿色课堂’的覆盖面。”团蜀山区委书记<a href="http://m.so.com/s?q=%E8%83%A1%E6%B0%B8%E7%94%9F&amp;src=newstranscode" class="qkw">胡永生</a>告诉记者，团区委还将围绕着<a href="http://m.so.com/s?q=%E7%A4%BE%E4%BC%9A%E4%B8%BB%E4%B9%89%E6%A0%B8%E5%BF%83%E4%BB%B7%E5%80%BC%E8%A7%82&amp;src=newstranscode" class="qkw">社会主义核心价值观</a>，整合周边高校志愿者资源，发挥他们的专业优势，开展一系列的“送课堂进小学”活动。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.sina.com.cn/o/2015-06-16/060031954338.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='e53b773700a24beaec4e9d44a4f236dd'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>安徽农大</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%AE%89%E5%BE%BD%E5%86%9C%E5%A4%A7&amp;pn=1&amp;pos=6&amp;m=bac7410bf7978bb9eafc6ece6d2e95a9a191dcb1&amp;u=http%3A%2F%2Fedu.people.com.cn%2Fn%2F2015%2F0112%2Fc1053-26366928.html" data-pos="1"> <b>安徽农业大学</b>茶业楼 </a>   <li> <a href="/transcode?q=%E5%AE%89%E5%BE%BD%E5%86%9C%E5%A4%A7&amp;pn=1&amp;pos=7&amp;m=5a441ae94985853b4ab5481481ea2a8ca8994eab&amp;u=http%3A%2F%2Fcunguan.youth.cn%2F2015%2F0430%2F1161148.shtml" data-pos="2"> <b>安徽农业大学</b>举办"青春献沃土 共筑中国梦"大学生村官先进事迹省级宣讲活动 </a>   <li> <a href="/transcode?q=%E5%AE%89%E5%BE%BD%E5%86%9C%E5%A4%A7&amp;pn=1&amp;pos=8&amp;m=bddc44ad0c525df79063b1d40464bfc4b1221a86&amp;u=http%3A%2F%2Fwww.chinadaily.com.cn%2Fhqcj%2Fxfly%2F2015-01-15%2Fcontent_13048693.html" data-pos="3"> 创意茶时尚校园创业 祥源茶吧落户<b>安徽农业大学</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '安徽农大“绿色课堂”为孩子解惑' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '安徽农大“绿色课堂”为孩子解惑'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";