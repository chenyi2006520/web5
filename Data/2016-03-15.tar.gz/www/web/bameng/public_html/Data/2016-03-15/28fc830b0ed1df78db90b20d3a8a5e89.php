s:20866:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>李鸿章英国看球赛:为什么不雇些佣人去踢?- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">李鸿章英国看球赛:为什么不雇些佣人去踢?</h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2016-03-15 08:59:00</time></p> </header>  <div id="news-body"><p>文史频道转载本文只以信息传播为目的，不代表认同其观点和立场</p><p><a href="http://m.so.com/s?q=%E6%9D%8E%E9%B8%BF%E7%AB%A0&amp;src=newstranscode" class="qkw">李鸿章</a>访英期间，主人邀请他去看一场足球赛。一百年前的<a href="http://m.so.com/s?q=%E8%8B%B1%E5%BC%8F%E8%B6%B3%E7%90%83&amp;src=newstranscode" class="qkw">英式足球</a>，正是草创阶段，自然没有当代足球这样成熟和精彩。李合肥作为清政府的特使，客随主便，自然也就穿着盛装，出席这次<a href="http://m.so.com/s?q=%E8%B6%B3%E7%90%83%E6%AF%94%E8%B5%9B&amp;src=newstranscode" class="qkw">足球比赛</a>。尽管他在清廷总理各国事务的衙门行走，是搞洋务的，但此公从来不穿夷服。而清廷的朝服，是长袍加御赐<a href="http://m.so.com/s?q=%E9%BB%84%E9%A9%AC%E8%A4%82&amp;src=newstranscode" class="qkw">黄马褂</a>，胸前挂着朝珠和别的零碎，戴的帽子上缀着宝石顶子和鲜艳的翎毛。此刻，坐在温布里露天体育场边上，不知足球为何物的天朝大臣，看来看去，不得要领。况且，这一身行头，只配坐在太师椅上，要不就在八人大轿里，在露天球场上，便很不舒服，很不自在。于是，他就要告退了。</p><p>不知有人做过考证没有?中国人第一个到国外去看足球比赛，而且，还是公费派出的看球名人，这光荣大概非李鸿章莫属了。</p><p>这位清朝特使，看了半场以后，莫名其妙，又觉得有点匪夷所思，问陪他一起观战，并看得津津有味的英国勋爵、子爵们:“那些汉子，把一只球踢来踢去，什么意思?”英国人说:“这是比赛，而且他们不是汉子，他们是绅士，是贵族。”李氏摇摇头说:“这种天气(英国伦敦的二月，虽然黄水仙开放了，但气候还是寒意甚重的)，为什么不雇些佣人去踢?为什么要自己来，跑得满头大汗?回头内热外感，伤风感冒可就不妥了，谬矣哉，谬矣哉!”</p><p>主人很窘，面面相觑，不知该怎样回答这位中国客人。</p><p>这是发生在1896年，清光绪二十二年的事情。清政府的洋务派李鸿章，作为皇帝的钦差头等出使大臣，访问英国，在伦敦，自然是上宾款待，优礼有加。如果说对他那套<a href="http://m.so.com/s?q=%E8%A2%8D%E5%AD%90&amp;src=newstranscode" class="qkw">袍子</a>马褂，翎子顶戴的穿着，英国上层社会的绅士淑女，还能忍受的话，对他那种万邦皆臣于我的思维方式和颐指气使的官僚做派，肯定就看不惯了，但洋人利之所趋，还是想办法巴结他。因为，日不落帝国和沙皇俄国，都想在中国扩大势力范围，李是个用得着的关键人物。所以，英国政府想尽办法，在他前往庆贺俄皇加冕以后，特地派船到<a href="http://m.so.com/s?q=%E5%85%8B%E9%87%8C%E7%B1%B3%E4%BA%9A&amp;src=newstranscode" class="qkw">克里米亚</a>去接他，一路军舰护航，到达朴茨茅斯，于礼炮声中登岸，这也是大英帝国生怕俄国独吞中国这块肥肉，才到底把李鸿章请去伦敦一游的。</p><p>记得高尔基的长篇小说<a href="http://m.so.com/s?q=%E3%80%8A%E5%85%8B%E9%87%8C%E8%90%A8%E6%9C%A8%E9%87%91%E7%9A%84%E4%B8%80%E7%94%9F%E3%80%8B&amp;src=newstranscode" class="qkw">《克里萨木金的一生》</a>，其中描写了李鸿章到俄国后，在彼得堡参观博览会时的一个小镜头。这位洋务派居然呸的一声，在大庭广众间，在前呼后拥中，随地吐出了一口痰。<a href="http://m.so.com/s?q=%E9%AB%98%E5%B0%94%E5%9F%BA&amp;src=newstranscode" class="qkw">高尔基</a>虽是革命的进步作家，但他对中国的看法，也还摆脱不了西方人的偏见。一直到如今，还是有些外国议员，总是想办法挑你的不是和不足，糟蹋中国或中国人。所以，高尔基在作品中使用了这个细节，不过是<a href="http://m.so.com/s?q=%E4%BD%99%E9%A3%8E&amp;src=newstranscode" class="qkw">余风</a>所及。但这件事在我国并未太传开，知者甚少。而知者甚少的原因，正如<a href="http://m.so.com/s?q=%E9%B2%81%E8%BF%85%E5%85%88%E7%94%9F&amp;src=newstranscode" class="qkw">鲁迅先生</a>在谈照相的文章里指出的，为什么中国人到<a href="http://m.so.com/s?q=%E7%85%A7%E7%9B%B8%E9%A6%86%E6%8B%8D%E7%85%A7&amp;src=newstranscode" class="qkw">照相馆拍照</a>，非要有一只痰盂放在脚下?这说明中国人气管里多分泌物，随时都吐，吐成习惯，李鸿章这一口痰，也就<a href="http://m.so.com/s?q=%E4%B8%8D%E4%BB%A5%E4%B8%BA%E5%A5%87&amp;src=newstranscode" class="qkw">不以为奇</a>了。</p><p>但李鸿章到英伦以后，却有许多不知是真还是假的演义，流传下来，成为趣谈。据说，英国绅士们在<a href="http://m.so.com/s?q=%E9%A4%90%E6%A1%8C%E4%B8%8A%E7%9A%84%E7%A4%BC%E4%BB%AA&amp;src=newstranscode" class="qkw">餐桌上的礼仪</a>极多，譬如吃烤鸡，原来是不允许用手抓来吃的，先用叉按住，再用刀一小块一小块切割下来，然后，把插在鸡身上的叉子抽出来，戳上一块鸡肉，送进嘴里。老实说，这种相当繁琐的吃法，并不可取，而且，在光滑的盘子上，肢解这只滚来蹭去的淋<a href="http://m.so.com/s?q=%E8%BF%87%E6%B2%B9&amp;src=newstranscode" class="qkw">过油</a>的烤鸡，是一种高难度的动作，要比刘姥姥用象牙筷夹鸽子蛋还费劲。李鸿章不听洋人这一套，毫不客气地就用手抓起撕来吃。在座的主人和陪客，都是戴着莎士比亚式褶领的文明人士，面露愕然之色，不知所措。一是出于礼貌，一是出于对贵客的尊敬，大家也就照方抓药，仿效李鸿章先生吃鸡的方式。开了这个先例，从此英国人在餐桌上吃鸡的时候，就得到了解放，可以直接动手而不必使用刀叉了。还有一件笑谈，也是有关饮食的。据说，这位大臣，在<a href="http://m.so.com/s?q=%E4%BC%A6%E6%95%A6&amp;src=newstranscode" class="qkw">伦敦</a>做客期间，上顿下顿的西餐，吃得很不耐烦了。官居相国的李鸿章，与明朝那位宰相张居正同好，每天给他上二十几道菜，他说没有值得下筷子的，皆喜美味佳肴，皆有一份好口福。那时，伦敦还没有中国人开的餐馆，不像现在，中餐走向世界，有华人的地方，就有中国人开的馆子。于是，李鸿章就让他带去的厨子，将用来做西餐的各式原材料，统统烩在一起，给他送上来。当那些陪同他的英国官员，闻到从厨房里飘出来的扑鼻香味，忍不住馋涎欲滴，就向通事打听，这是给李大人做的一道什么菜?回答说，不过是<a href="http://m.so.com/s?q=%E6%9D%82%E7%A2%8E&amp;src=newstranscode" class="qkw">杂碎</a>而已。然后李氏示意，非正式场合，请他们无妨入座，把这些老外，一个个吃得舔嘴咂舌，赞赏不已。据说，后来英国的饭店菜单上，就有了名叫“李鸿章杂碎”的一道菜目。</p><p>有一年，我到英国，走了几个地方，吃了一些饭店，却从来没在菜单上看到“李鸿章杂碎”，颇掩饰不住内心的失望。或许要到更高级的餐厅，才能点到这道名菜;或许压根儿就是一种姑妄言之，<a href="http://m.so.com/s?q=%E5%A7%91%E5%A6%84%E5%90%AC%E4%B9%8B&amp;src=newstranscode" class="qkw">姑妄听之</a>的演义。但我通过李鸿章的这些趣闻轶事，不禁想到，中国人和外国人的这种传统的不同，也就是东西方文化的差异，是一种正常的现象，因此也就没有什么高低之别，好坏之分。外国的，就一定好，中国的，就一定不好;洋人说的话，就一定高明，中国人说的话，就一定人微言轻，我是不大相信的。</p><p>某些先生脑海中的这种思维定势，一定说外国的月亮比中国的圆，很大程度上是自<a href="http://m.so.com/s?q=%E9%B8%A6%E7%89%87%E6%88%98%E4%BA%89&amp;src=newstranscode" class="qkw">鸦片战争</a>以来，中国人的屁股由于落后挨打得太多，所形成的精神上的自我矮化现象，一下子先矮上半截。所以，也就难怪阿Q一见假洋鬼子的文明棍，脖子就不由自主地缩起来，准备挨揍。</p><p>妄自尊大，不能提倡;妄自菲薄，也大可不必;数典忘祖，那就更不应该。东西方文化都有它自身发展变革的过程，凡落后的民风民俗，陈旧的陋规恶习，抵制文明的野蛮行径，杜绝开化的民族惰性，都会在时代的进步中或快或慢地改变过来。李鸿章在彼得堡的博览会的那一口痰，受到高尔基的讥诮，其实，这位无产阶级革命作家也许并不知道，<a href="http://m.so.com/s?q=%E5%8D%81%E5%AD%97%E5%86%9B%E4%B8%9C%E5%BE%81&amp;src=newstranscode" class="qkw">十字军东征</a>时，中亚地区早就有了公共澡堂的卫生设施，可那时的欧洲人，连厕所的概念还没有呢!</p><p>因此，我常常怀疑那些吃了太多的洋杂碎，而食洋不化的“精英”之类，对中国文学指手画脚、说三道四时那一脸的鄙夷和不屑，离<a href="http://m.so.com/s?q=%E6%9E%97%E8%AF%AD%E5%A0%82&amp;src=newstranscode" class="qkw">林语堂</a>先生所说的“西崽相”，离鲁迅先生所说的“奴才相”，到底还有多远?</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://sc.people.com.cn/n2/2016/0315/c345528-27935133.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='e9688baed22c164ac13dabf74f2fc8a0'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>姑妄听之</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%A7%91%E5%A6%84%E5%90%AC%E4%B9%8B&amp;pn=1&amp;pos=9&amp;m=4f04376c4fddda65a107d227496280b7d1266f9c&amp;u=http%3A%2F%2Fnews.ifeng.com%2Fa%2F20151112%2F46207959_0.shtml" data-pos="1"> 植物油致癌 <b>姑妄听之</b> </a>   <li> <a href="/transcode?q=%E5%A7%91%E5%A6%84%E5%90%AC%E4%B9%8B&amp;pn=1&amp;pos=10&amp;m=4945110e8cd1aa3c0b11ee75a2987c7ae3461da1&amp;u=http%3A%2F%2Fview.news.qq.com%2Fa%2F20150117%2F012329.htm" data-pos="2"> 白崇禧"战神"之誉只能<b>姑妄听之</b> </a>   <li> <a href="/transcode?q=%E5%A7%91%E5%A6%84%E5%90%AC%E4%B9%8B&amp;pn=2&amp;pos=1&amp;m=9b4ba76d8dd7cc84e8af0554fe352badce320505&amp;u=http%3A%2F%2Fwww.tianjinwe.com%2Ftianjin%2Ftjxwcg%2F201410%2Ft20141031_724138.html" data-pos="3"> 评论:"屌丝生存报告"只能<b>姑妄听之</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '李鸿章英国看球赛:为什么不雇些佣人去踢?' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '李鸿章英国看球赛:为什么不雇些佣人去踢?'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";