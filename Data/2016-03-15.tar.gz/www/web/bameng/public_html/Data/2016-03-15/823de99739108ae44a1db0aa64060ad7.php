s:26098:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>褪黑素惹争议 脑白金商业神话难续- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">褪黑素惹争议 脑白金商业神话难续</h1> <p id="source-and-time"><span id=source>凤凰网</span><time id=time>2015-06-20 10:41:00</time></p> </header>  <div id="news-body"><p>今年以来，关于<a href="http://m.so.com/s?q=%E8%84%91%E7%99%BD%E9%87%91&amp;src=newstranscode" class="qkw">脑白金</a>的争议尘嚣再起。</p><p>2月，已经处于“退休状态”的<a href="http://m.so.com/s?q=%E5%B7%A8%E4%BA%BA%E9%9B%86%E5%9B%A2&amp;src=newstranscode" class="qkw">巨人集团</a>前CEO史玉柱在微博上发长文，再次为脑白金站台，批驳相关媒体的质疑文章。他在微博上说:“虽然我不管脑白金业务了，我仍坚持每天睡前吃脑白金，18年了。在职或离职的我身边工作人员都知道这事。”</p><p><a href="http://m.so.com/s?q=%E5%8F%B2%E7%8E%89%E6%9F%B1&amp;src=newstranscode" class="qkw">史玉柱</a>是否连续18年服用脑白金，这是外界无法证实或证伪的事情。目前，媒体和消费者最关心的问题集中于两点:一、脑白金中含有的<a href="http://m.so.com/s?q=%E8%A4%AA%E9%BB%91%E7%B4%A0&amp;src=newstranscode" class="qkw">褪黑素</a>是否对人体有害;二、脑白金广告宣传中提到的“脑白金体”是否子虚乌有，偷换概念。</p><p>与退而不休的马云不同，仅从“史玉柱大闲人”微博页面来看，他似乎确实在安心享受退休生活:游荡各国，饕餮美食，偶尔在微博上指点一下江山。直到今年，因“刚看一篇恶毒文章”而跳出来发声，也让人感到雾里看花:史玉柱是否真的脱离了他一手打造出来的脑白金?而脑白金又究竟是一个怎样的产品?</p><p class="header">“神话”</p><p>“今年过节不收礼，收礼只收脑白金”连续十年被评为“十大恶俗广告”，但这却是脑白金撬开市场的万能钥匙。同时，伴随着百亿元销售成绩的，则是连续十多年的争议。</p><p>网络上一篇名为《脑白金连续16年荣获保健品单品销量第一》的文章显示:截止到2014年，脑白金在中国畅销了17年，连续16年成为国内销量第一的保健食品。</p><p>史玉柱在今年2月份发的微博长文里最末一句是:5年前我就下定决心了，以后坚决不碰吃的产业，包括食品、保健品和药品。这与他在1992年后雄心勃勃投资生物工程项目的态度形成戏剧化的对照。那时候，史玉柱刚在美国得知，IT和生物工程将会是发展速度最快的行业。</p><p>1995年，巨人推出脑黄金，为当时资金告急的<a href="http://m.so.com/s?q=%E5%B7%A8%E4%BA%BA%E5%A4%A7%E5%8E%A6&amp;src=newstranscode" class="qkw">巨人大厦</a>“输血”，很快，因为管理不善和资金“失血”，脑黄金也陷入停滞。1997年，巨人大厦烂尾，并拖垮了巨人集团。</p><p>而同年，脑白金这款产品在史玉柱的主导之下诞生。由此，中国人的电视屏幕上，开始了连续十多年狂轰滥炸的脑白金广告，在商业上取得的巨大成功，史玉柱偿还了巨人大厦欠下的2亿多元债务，并再次走到了事业巅峰。</p><p>2004年初，当时的香港上市公司四通电子(后更名为<a href="http://m.so.com/s?q=%E5%9B%9B%E9%80%9A&amp;src=newstranscode" class="qkw">四通</a>控股)宣布12亿元的收购计划，<a href="http://m.so.com/s?q=%E6%AE%B5%E6%B0%B8%E5%9F%BA&amp;src=newstranscode" class="qkw">段永基</a>接掌脑白金。同年8月，史玉柱出任四通控股CEO，并持有20%多的四通控股的股权。2009年，四通控股私有化通过，这家主营脑白金、<a href="http://m.so.com/s?q=%E9%BB%84%E9%87%91%E6%90%AD%E6%A1%A3&amp;src=newstranscode" class="qkw">黄金搭档</a>等保健品的上市公司退市。直到2011年，史玉柱宣布辞去CEO一职，但继续留任执行董事职位。</p><p>可见，在各种眼花缭乱的交易和变动之后，史玉柱仍然是脑白金的背后操纵者之一。进入保健品和网络游戏行业，为史玉柱带来了商业上的腾飞和巨额的财富。</p><p>中国打假第一人<a href="http://m.so.com/s?q=%E7%8E%8B%E6%B5%B7&amp;src=newstranscode" class="qkw">王海</a>与脑白金也有多年的渊源，并于今年5月底在微博上再次公开叫板脑白金，他表示:“据称美国新药研发需大约10年，经费需要8.8亿美元。1997年脑白金上市，2008年脑白金销量突破100亿元。当年史玉柱仅投资50万元，花了几个月时间策划广告、包装。”</p><p>王海对<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E5%9B%BD%E7%BB%8F%E8%90%A5%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《中国经营报》</a>记者表示，支撑脑白金的第一点是暴利，随便淘宝一下褪黑素产品的价格比较一下便知;第二点是企业导向社会的原因造成，立法、行政、司法都是企业利益优先，行政处罚税收化;第三点是谎言，从赠书(如<a href="http://m.so.com/s?q=%E3%80%8A%E5%B8%AD%E5%8D%B7%E5%85%A8%E7%90%83%E3%80%8B&amp;src=newstranscode" class="qkw">《席卷全球》</a>等)到软文(如《人类可以“长生不老”吗》<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%A4%E9%A2%97%E7%94%9F%E7%89%A9%E5%8E%9F%E5%AD%90%E5%BC%B9%E3%80%8B&amp;src=newstranscode" class="qkw">《两颗生物原子弹》</a>等)到广告，脑白金生生打造了一个概念。王海认为，脑白金从一开始就是一个骗局。</p><p class="header">争议</p><p>史玉柱在今年2月份发布的微博长文中首先强调了“不该把脑白金和褪黑素画等号”，他表示，脑白金有低聚糖和褪黑素两种功效成分，低聚糖更重要，改善体内菌群，对睡眠、排便有益。</p><p>这种反应显然是针对网络上盛传的、围绕脑白金跟褪黑素之间的争议和说法。有媒体报道业内人士的说法称:褪黑素改善睡眠的效果被夸大其词，而且长期大剂量服用，还会导致一系列不良反应，还可能导致内分泌系统紊乱继而引发其他疾病。</p><p>有业内人士认为，史玉柱在此时提出“低聚糖更重要”，有些试图转移话题的嫌疑。人体肠道内<a href="http://m.so.com/s?q=%E5%8F%8C%E6%AD%A7%E6%9D%86%E8%8F%8C&amp;src=newstranscode" class="qkw">双歧杆菌</a>的数量是检验身体是否健康的一个重要指标，而低聚糖是一类能够被双歧杆菌吸收利用而进行自身增殖的物质，所以又被称作益生元，它的主要作用在于改善肠胃功能。</p><p>记者发现，在脑白金的官网上，今年3月份贴出了一篇名为<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%96%E7%95%8C%E7%9D%A1%E7%9C%A0%E6%97%A5%E8%84%91%E7%99%BD%E9%87%91%E8%AE%A9%E4%B8%AD%E8%80%81%E5%B9%B4%E4%BA%BA%E8%BD%BB%E6%9D%BE%E7%9D%A1%E5%A5%BD%E8%A7%89%E3%80%8B&amp;src=newstranscode" class="qkw">《世界睡眠日脑白金让中老年人轻松睡好觉》</a>的文章。此外，记者在百度搜索“脑白金、睡眠”关键词，百度显示找到67.5万个相关结果，而搜索“脑白金、肠道”“脑白金、润肠”等关键词，百度搜索结果只有十几万条和几万条，搜索“脑白金、褪黑素”的结果数量更多247万个。</p><p>显然，不管是不是低聚糖在脑白金中更重要，消费者显然更关心脑白金和褪黑素的关联。</p><p>根据复旦大学公共卫生学院金锡鹏教授回忆，上世纪80年代中后期，褪黑素(<a href="http://m.so.com/s?q=Melatonin&amp;src=newstranscode" class="qkw">Melatonin</a>)就已经进入中国。他认识的一个熟人晚上睡觉不好，就去药店买回来服用。</p><p>金锡鹏教授对记者表示，褪黑素(melatonin)，又名松果体素，是人类的松果体在夜间分泌产生的一种激素，松果体在人脑深处，状如豌豆大小，它分泌的褪黑素具有调整<a href="http://m.so.com/s?q=%E6%96%B0%E9%99%88%E4%BB%A3%E8%B0%A2&amp;src=newstranscode" class="qkw">新陈代谢</a>和生物钟的功能。我们人体中分泌的褪黑素很少，目前还没有在血液中检测到过褪黑素。</p><p>金锡鹏教授介绍，褪黑素在美国早期是通过生物体内提取得到的，后来通过人工的化学合成，并且这种合成方法制备褪黑素的工艺目前已经较为成熟，纯度高，是褪黑素的主要来源。做毒理研究的人士普遍认为，人工合成的褪黑素副作用不会很大，但目前医学界并没有相关实验的研究定论。</p><p>针对网上流传的褪黑素对人体有副作用和长期服用容易产生依赖性的说法，金锡鹏教授认为，目前还没有医学上的实验可以证明，褪黑素对人体有害，也没有比较性的试验说明，服用过含褪黑素脑白金的人体对此产生依赖性，“对于保健品不能一棍子打死，需要经过科学的验证”。</p><p>但是金锡鹏教授也指出，在医学上并不存在“脑白金体”这个名词，人体中也不存在脑白金体。</p><p>而脑白金却一直对外宣传称:脑中的脑白金体分泌脑白金，是人体机能的最高主宰，脑白金分泌减少会使人体正常运作受到干扰，随之产生各种病症。这其实是概念上的混淆:让消费者以为服用脑白金产品，就可以补充“脑白金体”分泌减少的脑白金。其实是因为松果体分泌的褪黑素减少，才导致睡眠不好。</p><p>此外，对于脑白金在其官网文章所称的“一般人在35岁以后，体内自身分泌的褪黑素活力明显下降导致睡眠障碍”，也有医学界人士质疑，35岁之说没有科学试验的支撑，听起来就很荒诞。</p><p>史玉柱声称脑白金中所含有的褪黑素原料从未用过国产，一直从美国进口。但是有媒体报道，褪黑素原料大部分是化工厂生产的，没有食品卫生许可证。</p><p>记者想就此及其他问题采访脑白金的生产商上海黄金搭档生物科技有限公司，但是在电话中被拒绝，该公司一位人士明确向记者表示，“今年，‘3·15’期间也有很多媒体想就这个事情采访，但我们都拒绝了，领导告诉我们，目前不接受任何媒体的采访。”</p><p class="header">困境</p><p>本报记者走访了上海式长宁区中山公园附近的四五家药房，海王星辰的导购告诉记者，脑白金已经断货半年以上，华氏大药房等另外几家也都表示早就不卖了、断货好几个月了，但都推荐了褪黑素相关的多种国内外产品:GNC(健安喜)、RichLife(瑞莱)、Nature’s Bounty(自然之宝)、<a href="http://m.so.com/s?q=%E6%B1%A4%E8%87%A3%E5%80%8D%E5%81%A5%E8%A4%AA%E9%BB%91%E7%B4%A0%E7%89%87&amp;src=newstranscode" class="qkw">汤臣倍健褪黑素片</a>、Schiff Melatonin(美乐通宁)等。</p><p>此外，一家药房工作人员告诉记者，以往买脑白金的都是以中老年人为主，年轻人买也主要是送礼。现在购买褪黑素产品的除了老年人，还有很多买来自己服用的年轻人，“工作压力大，很多年轻人也失眠，需要助眠产品，还有一些人是因为跨国差旅需要调整睡眠时差，所以买来服用。”一名商场保健品柜台的女导购表示。</p><p>记者在家乐福也遇到了同样的情况，导购称脑白金断货几个月了，并极力推荐国产品牌的褪黑素产品，称“有同样的效果，吃了睡眠好”。记者拨通了脑白金官网上的热线电话咨询，接线客服表示，上海地区的易买得、世纪联华、卜蜂莲花、大润发等超市可以买到，也可以通过电话下单，直邮到家。</p><p>记者在<a href="http://m.so.com/s?q=%E5%A4%A9%E7%8C%AB&amp;src=newstranscode" class="qkw">天猫</a>医药馆上键入“褪黑素”进行搜索，一共有94个品牌(含脑白金)的638件相关商品弹出。进口的如某美国进口品牌的褪黑素，单片含3mg褪黑素，单片价格最低不到7角钱一片。而价格在100~150元之间的脑白金礼盒中，除了低聚糖口服液之外，仅有20粒<a href="http://m.so.com/s?q=%E8%A4%AA%E9%BB%91%E7%B4%A0%E8%83%B6%E5%9B%8A&amp;src=newstranscode" class="qkw">褪黑素胶囊</a>，单颗含褪黑素也是3mg，但由于低聚糖口服液的功效是改善肠胃道功能，促进新陈代谢，能够起助眠作用的仅是礼盒中的20粒胶囊。市场上可选择的褪黑素产品品类较为丰富，脑白金的广告虽然深入人心，但是消费者面临的选择也不少。</p><p>此外，天猫医药馆上有20多家药房旗舰店和保健品专营店在售卖脑白金，包括黄金搭档官方旗舰店和好药师大药房旗舰店等，月成交记录累计780多笔，黄金搭档官方旗舰店的历史总销量近15000笔，数额并不算特别巨大。</p><p>康复之家CEO柏煜对本报记者表示，由于脑白金在广告上一直走“土豪预算”的路线，导致渠道利润空间被压低，相对其他高毛利的保健品，商店里的导购员更乐于推销提成比较高的商品。“此外，无论是产品本身还是营销方式，脑白金都没有升级，也没有赶上全媒体营销时代的趟儿，给人的印象还是上个世纪的产品。现在看电视的人也少了，影响力也就慢慢下降了。”柏煜说。</p><p>中欧国际工商学院市场营销学的王高教授也认为，电视广告的影响力的确在下滑。脑白金推广之初，铺天盖地的广告教育了观众，受到顾客进店之后点名要脑白金的效应拉动，脑白金卖得很火，但主要市场也还是在广大的乡镇农村地区。</p><p>王高认为，脑白金走下坡路也很正常，靠包装营销概念做出来的商品，本来也是波段性的机会导向的生意。而且互联网在中国普及之后，人们获取信息的渠道更加多元化，脑白金的外衣被剥了下来，产品在人们心目中的价值也在变小。</p><p>与脑白金营销路数相近的<a href="http://m.so.com/s?q=%E5%93%88%E8%8D%AF&amp;src=newstranscode" class="qkw">哈药</a>模式近年来也已逐渐没落。极度倚重营销投入的哈药旗下的三精制药在2013年净利润为646万元，同比大跌98%，营收31亿元，同比下降21%;而到了2014年则更惨不忍睹，年报显示，2014年营业收入17.39亿元，同比降低45.27%。</p><p>事实上，随着中国消费者购买力的提升，对于跨境进口商品的需求量正不断攀升。保健品已经成为许多跨境进口电商中占不小比例的商品之一，并在逐渐上升，社区电商小红书相关人士对记者表示，进口保健品成为小红书平台上占比四分之一的商品，而且销量很好。</p><p>业界人士认为，目前，在广告宣传上主打送礼的脑白金，会更加依赖于中国消费购买力水平较低的地区，但留给它的市场生存空间已经越来越小。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://finance.ifeng.com/a/20150620/13789741_0.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='69f332fce82759fcef520765d5577078'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>褪黑素</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%A4%AA%E9%BB%91%E7%B4%A0&amp;pn=1&amp;pos=7&amp;m=8a8b27058d23bc8136dd19f432658b1d01739c71&amp;u=http%3A%2F%2Funion.china.com.cn%2Fzfgl%2F2015-05%2F28%2Fcontent_7943440.htm" data-pos="1"> 禾健<b>褪黑素</b>软胶囊,放心安睡一整夜 </a>   <li> <a href="/transcode?q=%E8%A4%AA%E9%BB%91%E7%B4%A0&amp;pn=1&amp;pos=8&amp;m=2a68e9f4b8286d4f839e9ca3e4378fe59d5153b7&amp;u=http%3A%2F%2Ffinance.ifeng.com%2Fa%2F20150620%2F13789741_0.shtml" data-pos="2"> <b>褪黑素</b>惹争议 脑白金商业神话难续 </a>   <li> <a href="/transcode?q=%E8%A4%AA%E9%BB%91%E7%B4%A0&amp;pn=1&amp;pos=9&amp;m=1267e68f5d194b0821a4973a56bdf01f4d59327c&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Ffood%2F2014-08%2F12%2Fc_126860387.htm" data-pos="3"> <b>褪黑素</b>!美白祛斑抗衰老 控制生物钟周期 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '褪黑素惹争议 脑白金商业神话难续' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '褪黑素惹争议 脑白金商业神话难续'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";