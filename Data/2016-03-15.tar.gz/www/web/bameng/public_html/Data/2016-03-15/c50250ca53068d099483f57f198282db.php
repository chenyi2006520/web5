s:17019:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>引体向上都有那些?训练背部少不了的王牌动作!- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">引体向上都有那些?训练背部少不了的王牌动作!</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-02-26 20:53:00</time></p> </header>  <div id="news-body"><p>如果你的大脑中只想到了正握、<a href="http://m.so.com/s?q=%E5%8F%8D%E6%8F%A1&amp;src=newstranscode" class="qkw">反握</a>引体向上，这是正常人的想法，但<a href="http://m.so.com/s?q=%E5%BC%95%E4%BD%93%E5%90%91%E4%B8%8A&amp;src=newstranscode" class="qkw">引体向上</a>就和俯卧撑的种类一样多，来尝试不同的引体向上方式试试!</p><p><img src="http://p32.qhimg.com/t0129381a5b196ed634.jpg?size=400x423"></p><p>我们知道引体向上可以有效的训练背部肌群，是一个很好的复合性动作，随手拿起一份健身计划，都可以看到引体向上项目，对于一个健身人而言，对引体向上应该有所了解，并掌握几种常见的引体向上训练方法很有必要。引体向上是最基本的锻炼背部的方法，也是衡量男性体质的重要参考标准和项目之一。引体向上要求男性有一定的握力、上肢力量和肩带力量，这个力量必须能克服自身的体重才能完成一次。引体向上种类多种多样，主要分为静力引体向上和借力引体向上(可以摆动身体)两大类。</p><p>引体向上重点锻炼背阔肌和肱二头肌，对<a href="http://m.so.com/s?q=%E8%82%A9%E8%83%9B%E9%AA%A8&amp;src=newstranscode" class="qkw">肩胛骨</a>周围许多小肌肉群以及小臂肌群也有一定的训练效果。认真练习此动作，可以使人拥有倒三角形的健美体型，在<a href="http://m.so.com/s?q=%E6%94%80%E5%B2%A9&amp;src=newstranscode" class="qkw">攀岩</a>、划船等休闲运动项目中表现得更出色。引体向上可增加背部的宽度，还可以拉伸脊柱，使脊柱尽力伸展，促进脊柱骨的增生。不同握距的正握引体向上能发展大圆肌、小圆肌、冈下肌、斜方肌、肱二头肌、背阔肌，但是侧重点不同。宽握引体向上重点刺激背阔肌中、上部; 中握引体向上重点刺激斜方肌; 窄握引体向上重点刺激背阔肌上部、大圆肌。正握颈后引体向上重点刺激背阔肌中、上部、大圆肌、小圆肌、菱形肌、背部深层肌肉。借力引体向上可以锻炼到全身等等。</p><p><img src="http://p32.qhimg.com/t0103810b6a15929469.gif?size=400x219"></p><p>训练引体向上时，一般每次3-5组，每组8-12次，组间休息1分钟左右。引体向上具体有那些分类，下面是一些常见的引体向上种类。</p><p>1.正手(ordinary <a href="http://m.so.com/s?q=grip&amp;src=newstranscode" class="qkw">grip</a>)引体向上</p><p>正手引体向上是以手心向外的抓握方式做引体向上。这是最“正统”的引体向上握姿，此种姿势对三角肌是个挑战。如果想重点锻炼三角肌，在正手握法的同时，可以让双臂张开的角度增大些，这样难度更大。</p><p><img src="http://p31.qhimg.com/t0197c0b2f6891cfb98.jpg?size=400x470"></p><p>2.反手(underhand grip)引体向上</p><p>反手引体向上是以手心向内的抓握方式做引体向上。它相对于正手握法容易些，因为它可以发挥肱二头肌。如果想让肱二头肌更壮观些，可以尝试反手引体向上。而且，还可以把双臂并拢起来，甚至让两手相碰，这样会给肱二头肌更多的压力。</p><p><img src="http://p31.qhimg.com/t015bcc462bb8038cbc.jpg?size=550x458"></p><p>3.正反手(mixed grip)引体向上</p><p>正反手引体向上同时使用正手握法和反手握法。这样做可以增加引体的难度，当采取这种抓握方式，身体会向反握的一侧偏转，增加反握一侧的受力。练习时需要左右交替使用正反手。</p><p><img src="http://p33.qhimg.com/t01c8064acadec7ee73.jpg?size=443x450"></p><p>4.平行(parallel grip)引体向上(也叫侧握引体向上hammer grip)</p><p>如果有两条横杠，就可以采取这种双手掌心相对的抓握方式，这种姿势可以减轻肩部的受力。</p><p class="header">5.负重引体向上</p><p>不管是哪种姿势的引体向上，一口气可以做上15个，就该考虑提高难度了。增加负重是一种简便的提高难度的方法。具体增加的负重要看个人力量。</p><p>6.胸式引体向上(sternum <a href="http://m.so.com/s?q=pull-up&amp;src=newstranscode" class="qkw">pull-up</a>)</p><p>普通的引体向上，只需把下巴，顶多是锁骨拉过横杠。而胸式还要再进一步，当锁骨碰到杠的时候，努力把身体向后倾，让胸骨贴上横杠。这个姿势的引体向上特别锻炼背阔肌。</p><p>7.颈后引体向上(behind-the-neck pull-up)</p><p>用后颈碰横杠，这种姿势可以充分锻炼背上的肌肉，诸如大圆肌、小圆肌等。</p><p>8.毛巾引体向上(towel pull-up)</p><p>在杠上裹条毛巾，对小臂是个挑战。裹了毛巾的横杠增加了抓握的难度，而握力是由小臂的肌肉发起的。</p><p>9.单手引体向上(one-hand pull-up)</p><p>用一只手抓杠，另一只手握住抓杠手的腕部进行引体向上。</p><p>10.单臂引体向上(one-arm pull-up)</p><p class="header">完全用一只手臂发力做引体向上。</p><p>11.单指引体向上(one-finger pull-up)</p><p>用手指悬挂身体做引体向上。开始的时候可以尝试四根手指，逐渐减少到一根。最有力的是中指，其次是食指。</p><p>参考资料:<a href="http://m.so.com/s?q=%E7%99%BE%E5%BA%A6%E7%99%BE%E7%A7%91&amp;src=newstranscode" class="qkw">百度百科</a>、《肌肉健美训练图解》</p><p>本文属威猛士健身原创，欢迎关注威猛士健身微信公众号:tyyjjs &lt;------长按可复制哦</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://toutiao.com/i6255582054843417089/">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='8769dd5b83de32ffa60eca185c9960f4'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>引体向上</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%BC%95%E4%BD%93%E5%90%91%E4%B8%8A&amp;pn=1&amp;pos=10&amp;m=901c180cbf6b67c4f84ce215b7328c986248bcc0&amp;u=http%3A%2F%2Fwww.qiuxingwang.cn%2Fphoto%2Ftpch%2F82309.html" data-pos="1"> 大肚妈妈健身 举重+<b>引体向上</b>产后迅速恢复 </a>   <li> <a href="/transcode?q=%E5%BC%95%E4%BD%93%E5%90%91%E4%B8%8A&amp;pn=2&amp;pos=1&amp;m=a48df713a13a8adc9350d3a38c83388dbe0f1c65&amp;u=http%3A%2F%2Fnews.chinanews.com%2Fty%2F2016%2F01-27%2F7735118.shtml" data-pos="2"> 鲍春来晒<b>引体向上</b>照片 网友:至少10个以上吧? </a>   <li> <a href="/transcode?q=%E5%BC%95%E4%BD%93%E5%90%91%E4%B8%8A&amp;pn=2&amp;pos=2&amp;m=a722e7aa94ce47707f650052c21c1a0ae609d6ea&amp;u=http%3A%2F%2Fcnews.chinadaily.com.cn%2F2016-02%2F03%2Fcontent_23364592.htm" data-pos="3"> 全靠演技!邓超偷懒做<b>引体向上</b> 网友:我都信了! </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '引体向上都有那些?训练背部少不了的王牌动作!' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '引体向上都有那些?训练背部少不了的王牌动作!'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";