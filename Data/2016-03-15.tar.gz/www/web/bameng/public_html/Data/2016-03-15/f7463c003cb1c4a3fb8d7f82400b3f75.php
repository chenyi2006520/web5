s:17212:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>如何买到放心二手车?3.15日济南车管所教你“两步查询法”- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">如何买到放心二手车?3.15日济南车管所教你“两步查询法”</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-03-14 21:07:34</time></p> </header>  <div id="news-body"><p>有违法分子为获取真实车辆标牌和 发动机号 ，在网上专门回收事故车、报废车。</p><p><img src="http://p35.qhimg.com/t01238ef774900796c9.jpg?size=332x521"></p><p>济南 车管所 民警尚健展示近期查扣的“洗白”<a href="http://m.so.com/s?q=%E4%BA%8C%E6%89%8B%E8%BD%A6&amp;src=newstranscode" class="qkw">二手车</a>伪造标牌。</p><p><a href="http://m.so.com/s?q=%E5%A4%A7%E4%BC%97%E7%BD%91&amp;src=newstranscode" class="qkw">大众网</a>济南3月14日讯 (记者 贺辉)今天上午，大众网记者从<a href="http://m.so.com/s?q=%E6%B5%8E%E5%8D%97%E5%B8%82&amp;src=newstranscode" class="qkw">济南市</a> 车管所 获悉，自2015年以来，济南车管部门共查扣涉嫌盗抢、诈骗、走私、拼装等违法二手车37辆。 车管所 民警介绍，目前二手车的“洗白”手段不断升级，购买二手车时最好到交警部门查询车辆状态和违法记录，并到4S点查询车辆维修、保养、保险记录，避免上当受骗。</p><p>济南人买洗白二手“黑车”被骗频发 去年以来已查扣37辆</p><p>“近年来济南人买二手车被骗的事件频发，2015年至今车管部门已查扣了37辆洗白的‘问题二手车’。”今天上午，济南市 车管所 查验科科长尚健告诉大众网记者，这些车大都涉嫌盗抢、诈骗、走私、拼装，或车辆处于抵押、查封、锁定状态，基本都是车主买了二手车来挂牌时被查出 发动机号 、标牌、手续等涉嫌伪造。</p><p>犯罪分子常用的手段是，在租赁公司租车后更换车架号和 发动机号 ，将车辆“洗白”再低价卖出。去年9月8日，一辆黑色别克凯越由<a href="http://m.so.com/s?q=%E8%8F%8F%E6%B3%BD&amp;src=newstranscode" class="qkw">菏泽</a>转入济南，济南市 车管所 查验科民警发现，该车在玻璃生产时间、产品标牌等存在多处疑点。查验民警通过对车载电脑(ECU)、隐藏标签、配件编号进行反查，证实该车是一辆被诈骗的租赁车辆，此前已在历下公安分局经侦大队立案。</p><p>尚健介绍说，根据法律规定，涉嫌盗抢、诈骗、走私、拼装，或处于抵押、查封、锁定状态的违法车辆应暂时查扣，一旦查实，盗抢、诈骗车辆将归还原车主，而走私、拼装车则要销毁处理。但大部分买到“问题二手车”的车主并不知情，即使是“善意所得”也没办法继续拥有，最后只能车、财两空。</p><p>造假手段越来越高明 专业二手车中介都看不出来</p><p>今年1月26日，一辆白色<a href="http://m.so.com/s?q=%E4%B8%B0%E7%94%B0&amp;src=newstranscode" class="qkw">丰田</a>陆地巡洋舰从呼伦贝尔转入济南，随车手续显示该车是四川<a href="http://m.so.com/s?q=%E4%B8%80%E6%B1%BD%E4%B8%B0%E7%94%B0&amp;src=newstranscode" class="qkw">一汽丰田</a>生产，但济南 车管所 的查验民警却发现该车的备胎、后视镜、发动机等处都显示这是一辆日本产<a href="http://m.so.com/s?q=%E4%B8%AD%E4%B8%9C&amp;src=newstranscode" class="qkw">中东</a>版陆巡，国内未曾进口。随后，民警查出该车的车架号、 发动机号 都是铝片打刻伪造又粘贴在原发动机表面的，车辆合格证、发票也都是伪造的。该车随即被列入走私嫌疑车辆，目前车辆手续由济南 车管所 暂扣，<a href="http://m.so.com/s?q=%E5%91%BC%E4%BC%A6%E8%B4%9D%E5%B0%94&amp;src=newstranscode" class="qkw">呼伦贝尔</a>警方仍在进一步调查中。</p><p>去年9月9日下午，济南市民<a href="http://m.so.com/s?q=%E5%BC%A0%E4%BA%AE&amp;src=newstranscode" class="qkw">张亮</a>(化名)开着刚买的二手雪佛兰 景程 到济南 车管所 挂牌，查验民警发现该车产品标牌、配件标签等存在多处疑点。通过进一步排查，证实该车标牌、 发动机号 都是打刻伪造的，实际车主王某是山东新泰人，车辆处于抵押状态。民警将该车查扣时，受骗的张亮很郁闷的告诉交警,他从事二手车交易中介多年，没想到还是看不出里面的猫腻。</p><p>尚健说，近几年犯罪分子“洗白”黑车的手段不断更新，伪造的标牌、 发动机号 在颜色、材质、字体上仿真度越来越高，而且开始使用残值车标牌和 发动机号 的手段。他们一般先将原有 发动机号 打磨、凿挖，再将伪造打刻的标牌 发动机号 或残值车标牌 发动机号 用玻璃胶粘贴到嫌疑车上，连铆钉都使用原车上的。除了专业的车管查验人员外，一般人根本看不出来。</p><p>记者在网络上搜索发现，市场上有不少专门从事车辆残值黑市交易的，他们只需要花1000-5000元好处费，就能买到一辆残值车、事故车，主要目的是拆卸车辆标牌、 发动机号 等出售给专门洗白“问题车”的犯罪分子。</p><p>车管民警教你鉴别“洗白”二手车:只需两步查询</p><p>问题二手车的洗白手段不断升级，但市民在购买二手车时也并非没法辨别。尚健提醒市民首先要注意查看车辆手续和实际配置是否一致。“比如看看是否有天窗、手动档还是自动档，这些配置和车辆合格证是否吻合”，明显低于市场二手车价格的尤其要警惕。</p><p>济南 车管所 民警提醒，购买二手车时最好进行两步查询。一是和卖家一起拿着车辆手续到交警部门查询车辆状态，看看是否已被查封、抵押、锁定;二是和卖家一起到双方都认可的4S店对车辆进行全面检测，并查询车辆维修、保养、保险记录，一般70%左右的的车辆都有过事故记录。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/2016/kuaixun_0314/4749245.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='0c2c6b34497e5378675b8d16fdf3eea7'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>二手车</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%BA%8C%E6%89%8B%E8%BD%A6&amp;pn=1&amp;pos=10&amp;m=8cadc618016feb6f70a89ae104eef99ea26177ea&amp;u=http%3A%2F%2Fauto.people.com.cn%2Fn1%2F2016%2F0313%2Fc1005-28194544.html" data-pos="1"> <b>二手车</b>报告显示女性偏爱日系车 购车更务实 </a>   <li> <a href="/transcode?q=%E4%BA%8C%E6%89%8B%E8%BD%A6&amp;pn=2&amp;pos=1&amp;m=07345c986f22752420472a7f2f38faf4b75e5e3c&amp;u=http%3A%2F%2Fauto.people.com.cn%2Fn1%2F2016%2F0314%2Fc1005-28196653.html" data-pos="2"> 高清实拍:泡水<b>二手车</b>长啥样? </a>   <li> <a href="/transcode?q=%E4%BA%8C%E6%89%8B%E8%BD%A6&amp;pn=2&amp;pos=2&amp;m=a9ce140d66907b9236241f0b1fa7ef3fb19771f0&amp;u=http%3A%2F%2Fnews.youth.cn%2Fjsxw%2F201603%2Ft20160314_7741546.htm" data-pos="3"> 重庆一4S店<b>二手车</b>当新车卖 被判"退一赔三" </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '如何买到放心二手车?3.15日济南车管所教你“两步查询法”' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '如何买到放心二手车?3.15日济南车管所教你“两步查询法”'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";