s:15833:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>券商热议证监会主席刘士余首秀 进一步明确未来资本市场改革发展总方向- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">券商热议证监会主席刘士余首秀 进一步明确未来资本市场改革发展总方向</h1> <p id="source-and-time"><span id=source>和讯网</span><time id=time>2016-03-15 01:19:51</time></p> </header>  <div id="news-body"><p class="header">■本报记者 侯捷宁</p><p>“刘士余主席答记者问信息量大、解读客观、正面，不回避问题、直面中国国情客观解读给广大投资者传递了积极的信号，提振了资本市场的信心。”中泰证券研究所首席宏观策略分析师罗文波在接受<a href="http://m.so.com/s?q=%E3%80%8A%E8%AF%81%E5%88%B8%E6%97%A5%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《证券日报》</a>记者采访时表示。</p><p>虽然距离<a href="http://m.so.com/s?q=%E8%AF%81%E7%9B%91%E4%BC%9A&amp;src=newstranscode" class="qkw">证监会</a>主席刘士余答记者问已过去了两天，但因为刘士余“首秀”就对市场高度关注的一系列问题进行了坦诚且务实的解答，所以，此次“首秀”内容近几天一直成为业界热议的焦点话题。</p><p>罗文波认为，刘士余答记者问透露出三个重要信息:一是注册制从中长期来看，是国家的重大战略安排，因此未来确定会推出，但出于稳定资本市场及人大授权决策流程的慎重考虑，注册制的推出仍有较长的时间，仍有较多的工作去准备，不能一蹴而就和单兵突进，具体必须等待时机成熟，体现了刘士余主席对中长期资本市场发展的方向性问题和速度问题的理性判断和清晰理解;二是出于稳定金融市场的考量，中证金短期不会退出，而且未来相当长一段时间根本没有考虑退出的可能，以保护中小投资者的正当利益。刘士余主席的这一表态对目前波动中的A股市场来说具有积极正面的引导作用，极大提振了资本市场投资人的信心;三是熔断机制因为不适应散户主导的A股市场，未来几年内根本没有考虑退出的可能。熔断机制短期不适应中国市场，坦率表达了监管层开放的监管理念和客观的执政思维。</p><p>“从刘士余主席此次答记者问的内容来看，<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E8%AF%81%E7%9B%91%E4%BC%9A&amp;src=newstranscode" class="qkw">中国证监会</a>政策制定者愈加成熟，尤其在经历股票市场大幅波动以来，政策水平逐渐提升，对未来股票市场平稳发展积累宝贵经验。”罗文波表示。</p><p><a href="http://m.so.com/s?q=%E6%8B%9B%E5%95%86%E8%AF%81%E5%88%B8&amp;src=newstranscode" class="qkw">招商证券</a>(600999,股吧)有关负责人在接受《证券日报》记者采访时表示，刘士余主席在十二届<a href="http://m.so.com/s?q=%E5%85%A8%E5%9B%BD%E4%BA%BA%E5%A4%A7&amp;src=newstranscode" class="qkw">全国人大</a>四次会议记者会上就当前资本市场改革发展中的一些关键问题予以了明确答复，有利于进一步明确未来改革发展的方向与路径;对中国资本市场的特征与实际进行了深入分析，有利于更加立足国情，推进各项改革发展措施;对当前监管中的一些不足予以了诚恳反思，有利于进一步提升监管水平，促进资本市场健康稳定发展。</p><p>上述负责人认为，刘士余此次“首秀”的发言内容可以概括为“一个坚持、两个正视、三个做好”。</p><p>一个坚持即坚持资本市场市场化、法治化的改革发展方向不动摇。刘士余主席在发言中指出，“中国资本市场的发展必须坚持市场化、法治化这一根本方向，既然是根本方向，就不能动摇。”这一论述，与<a href="http://m.so.com/s?q=%E5%8D%81%E5%85%AB%E5%B1%8A%E4%B8%89%E4%B8%AD%E5%85%A8%E4%BC%9A&amp;src=newstranscode" class="qkw">十八届三中全会</a>以来的相关表述一脉相承，也进一步明确了未来资本市场改革发展的总方向。</p><p>两个正视即正视资本市场中存在的问题，正视政府监管中存在的不足。刘士余主席对资本市场中存在的问题及政府监管中存在的不足的“两个正视”，有助于我们更好地全面、准确了解中国资本市场的特征与实际，也有助于相关监管部门全面提升监管水平，促进资本市场健康快速发展。</p><p>三个做好即做好注册制改革的统筹推进，做好市场失灵时的维护稳定，做好对中小投资者的权益保护。</p><p>此外，对于刘士余主席关于“市场失灵仍会果断出手，中证金退出无时间表”的表态，<a href="http://m.so.com/s?q=%E6%96%B9%E6%AD%A3%E8%AF%81%E5%88%B8&amp;src=newstranscode" class="qkw">方正证券</a>(601901,股吧)有关负责人表示，目前A股市场仍处在修复过程中，全球资本市场及外部经济环境仍存在诸多不确定性，投资者信心仍需呵护，虽然特殊时期的“非常规机制性措施”虽然已经或正在退场，但刘士余主席明确表示“证金退出没有时间表”，这无疑给市场注入了一剂强心针，给广大投资者吃下了一颗定心丸。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://stock.hexun.com/2016-03-15/182752798.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='ec784b5649c51811536ba211d56ce2b5'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>证监会</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%AF%81%E7%9B%91%E4%BC%9A&amp;pn=2&amp;pos=1&amp;m=2412d20389f81f9d6419f060085aa619ecb03a40&amp;u=http%3A%2F%2Fwww.csrc.gov.cn%2F" data-pos="1"> <b>中国证券监督管理委员会</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '券商热议证监会主席刘士余首秀 进一步明确未来资本市场改革发展总方向' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '券商热议证监会主席刘士余首秀 进一步明确未来资本市场改革发展总方向'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";