s:14820:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>《西游降魔篇·动作版》24日不删档开测 抢百万红包- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">《西游降魔篇·动作版》24日不删档开测 抢百万红包</h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2015-06-19 11:24:00</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E3%80%8A%E8%A5%BF%E6%B8%B8%E9%99%8D%E9%AD%94%E7%AF%87%C2%B7%E5%8A%A8%E4%BD%9C%E7%89%88%E3%80%8B&amp;src=newstranscode" class="qkw">《西游降魔篇·动作版》</a>将于6月24日开启双平台不删档测试。《西游降魔篇·动作版》作为<a href="http://m.so.com/s?q=%E8%A5%BF%E5%B1%B1%E5%B1%85&amp;src=newstranscode" class="qkw">西山居</a>金牌游戏制作人倾力打造的S级大电影IP手游，历经两次精英测试终于要正式与广大玩家见面，此次不删档测试将同时登陆IOS及<a href="http://m.so.com/s?q=Android&amp;src=newstranscode" class="qkw">Android</a>两大平台。随测试开启，诸多电影中的经典角色将在游戏中陪诸位玩家征战四方完成来自诸多魔物乃至仙人的重重考验，此外参与此次不删档测试的玩家更可参与各类活动赢取百万红包奖励!</p><p class="header">24日不删档 电影角色陪战斗</p><p>《西游降魔篇·动作版》将大电影中的各路神仙、妖怪以及降妖人等角色悉数还原植入游戏的神将系统中，登陆游戏玩家即可免费随机获得一名神将，陪你走上守护<a href="http://m.so.com/s?q=%E8%8A%B1%E6%9E%9C%E5%B1%B1&amp;src=newstranscode" class="qkw">花果山</a>的降妖除魔之路。获得的神将还原电影角色能力拥有不同的法宝及属性，例如手持<a href="http://m.so.com/s?q=%E7%81%AB%E5%B0%96%E6%9E%AA&amp;src=newstranscode" class="qkw">火尖枪</a>拥有超高法力攻击的<a href="http://m.so.com/s?q=%E5%93%AA%E5%90%92&amp;src=newstranscode" class="qkw">哪吒</a>，一根金箍棒就可惊天动地擅长群攻的孙悟空，玩家将可凭借对<a href="http://m.so.com/s?q=%E8%A7%92%E8%89%B2%E4%BA%BA%E7%89%A9&amp;src=newstranscode" class="qkw">角色人物</a>的认知去部署出战神将，陪你上天入地斩妖除魔。</p><p><img src="http://p32.qhimg.com/t0150e01ccd231d742e.jpg?size=500x282"></p><p class="img-title">玩游戏送红包 百万豪礼等你拿</p><p>为了迎接《西游降魔篇·动作版》不删档测试开启，除了在游戏线上将面向全用户开启免费每日免费抽大奖活动，西山居及旗下游戏官方微博、<a href="http://m.so.com/s?q=%E5%BE%AE%E4%BF%A1&amp;src=newstranscode" class="qkw">微信</a>也均将于近期逐步展开玩游戏送好礼活动。此外，《西游降魔篇·动作版》还联合了“滴滴打车”、“今日头条”及“酷狗音乐”等应用展开跨界活动，百万红包、海量数码实物、充值卡以及<a href="http://m.so.com/s?q=%E9%87%91%E5%B1%B1%E4%B8%80%E5%8D%A1%E9%80%9A&amp;src=newstranscode" class="qkw">金山一卡通</a>等你前来领取。活动多，好礼多，来玩就送!</p><p><img src="http://p34.qhimg.com/t018ff4fa3a085b5978.jpg?size=500x282"></p><p><img src="http://p32.qhimg.com/t013c9dafd5b21ede4a.jpg?size=500x282"></p><p>IOS及Android双平台不删档上线</p><p>此次《西游降魔篇·动作版》不删档测试将同步上线IOS及Android两大平台，无论你是忠实的果粉还是任性的安卓用户，均可登录应用商店及渠道平台搜索下载游戏踏上西游之路加入降魔大军。</p><p><img src="http://p34.qhimg.com/t01f62469a6ee4bfaae.jpg?size=500x282"></p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://game.people.com.cn/n/2015/0619/c40130-27182597.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='48934a2893750c64cadadf6a68f1ed11'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>西游降魔篇</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%A5%BF%E6%B8%B8%E9%99%8D%E9%AD%94%E7%AF%87&amp;pn=1&amp;pos=10&amp;m=0ddb0a101f9c1b3decd6b5f77d18b4789f37d033&amp;u=http%3A%2F%2Fgame.people.com.cn%2Fn%2F2015%2F0619%2Fc40130-27182597.html" data-pos="1"> 《<b>西游降魔篇</b>·动作版》24日不删档开测 抢百万红包 </a>   <li> <a href="/transcode?q=%E8%A5%BF%E6%B8%B8%E9%99%8D%E9%AD%94%E7%AF%87&amp;pn=2&amp;pos=1&amp;m=373453822484fd6e254f657b8b7b08ac365a9ba0&amp;u=http%3A%2F%2Ffinance.eastmoney.com%2Fnews%2F1670%2C20160217595097056.html" data-pos="2"> 从《<b>西游降魔篇</b>》到《美人鱼》谁在陪星爷一路赌下去? </a>   <li> <a href="/transcode?q=%E8%A5%BF%E6%B8%B8%E9%99%8D%E9%AD%94%E7%AF%87&amp;pn=2&amp;pos=2&amp;m=edcfc005b32cb11c0742f2179de44b2dcf6545a8&amp;u=http%3A%2F%2Fgame.people.com.cn%2Fn%2F2015%2F0611%2Fc40130-27140492.html" data-pos="3"> 《<b>西游降魔篇</b>·动作版》不删档测试6月24日来袭 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '《西游降魔篇·动作版》24日不删档开测 抢百万红包' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '《西游降魔篇·动作版》24日不删档开测 抢百万红包'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";