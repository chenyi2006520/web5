s:14892:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>山东宁阳一小学生被校车碾轧身亡 校长停职- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">山东宁阳一小学生被校车碾轧身亡 校长停职</h1> <p id="source-and-time"><span id=source>网易</span><time id=time>2016-02-23 20:11:17</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t01fe20a06c4d4f8851.jpg?size=480x320"></p><p class="img-title">事发现场。图片来自网络</p><p><img src="http://p33.qhimg.com/t01e18a36affc84e56f.jpg?size=480x320"></p><p>新京报快讯(记者程媛媛 实习生王春晓)今天早晨7时许，<a href="http://m.so.com/s?q=%E5%B1%B1%E4%B8%9C%E5%AE%81%E9%98%B3%E5%8E%BF&amp;src=newstranscode" class="qkw">山东宁阳县</a>堽城镇中心小学内发生一起校车事故，目击者称校车在倒车时轧过一名4年级男孩致其当场身亡。目前，肇事司机杜某某已被警方控制，<a href="http://m.so.com/s?q=%E5%AE%81%E8%BF%9C%E5%8E%BF&amp;src=newstranscode" class="qkw">宁远县</a>教育局作出暂停该校校长职务的处理决定。</p><p>“今天是孩子第一天上学，没想到出事了。”同校一学生的家长薛先生告诉新京报(<a href="http://m.so.com/s?q=%E5%BE%AE%E4%BF%A1&amp;src=newstranscode" class="qkw">微信</a>ID:bjnews_xjb)记者，今日早晨7时许，送孩子去上学时，发现一名男孩被校车撞倒身亡。薛先生称，被撞男孩陈某是四年级学生，由家长骑电动车送往学校。“这时候校车刚好下完学生，准备倒车，小孩往前走路司机没看见，就直接压过去了。”薛先生介绍，学校使用的是符合标准的校车，能乘坐40人左右。</p><p>目击者提供的现场图片显示，校车停靠在学校内，其左后车轮下碾压过一名小孩，民警在现场勘查。</p><p>该校老师<a href="http://m.so.com/s?q=%E7%8E%8B%E6%9E%97&amp;src=newstranscode" class="qkw">王林</a>(化名)告诉记者，事故发生后教师们收到学校通知提醒学生交通安全。新京报记者多次联系校方负责人未果。</p><p>今日下午4时，宁阳县第一殡仪馆对新京报(微信ID:<a href="http://m.so.com/s?q=bjnews&amp;src=newstranscode" class="qkw">bjnews</a>_xjb)记者表示，今日收到一名因校车事故身亡的男童遗体，具体身亡原因相关部门还在调查，孩子家长已经到殡仪馆，将其衣服穿好，存放于冰棺内。</p><p>今日晚间，宁阳县委宣传部通告案情称，学生陈某，男，现年10岁，<a href="http://m.so.com/s?q=%E5%AE%81%E9%98%B3%E5%8E%BF&amp;src=newstranscode" class="qkw">宁阳县</a>堽城镇平家庄村人，系<a href="http://m.so.com/s?q=%E5%A0%BD%E5%9F%8E%E9%95%87&amp;src=newstranscode" class="qkw">堽城镇</a>中心小学四年级一班学生。学生陈某在去教室上课途中，被杜某某驾驶的校车在倒车过程中撞倒，发生辗轧。</p><p>事故发生后，司机杜某某第一时间报警，同时，随车陪乘人员徐某立即向学校负责人进行了汇报。经医生现场诊断和抢救，发现陈某已无生命特征，属当场死亡。</p><p>目前肇事司机杜某某已被公安机关控制。县教育局作出决定，暂停堽城镇中心小学校长职务，并立即在全县中小学中开展一次安全隐患大排查和安全专题教育活动。校车法人单位县交运集团负责人承诺全力配合此事的处理。</p><p class="header">【欢迎提供新闻线索】</p><p>手机:18611096717(10:00~22:00)</p><p>24小时热线:010-67106710</p><p class="header">新京报微信:bjnews_xjb</p><p>新京报微博:http://weibo.com/xjb</p><p>邮箱:bjnews_xjbkx@126.com</p><p>编辑:魏佳 <a href="http://m.so.com/s?q=%E5%88%98%E5%96%86&amp;src=newstranscode" class="qkw">刘喆</a></p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.163.com/16/0223/20/BGHLPRCE00014SEH.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='4a976e2563b8426585e65b73f141b55d'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>宁阳县</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%AE%81%E9%98%B3%E5%8E%BF&amp;pn=1&amp;pos=8&amp;m=26412b7c6997b182c22496f57afe3efe7e20a9d2&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4039311.html" data-pos="1"> <b>宁阳县</b>鹤山乡第三届"社区节"活动成功举办 </a>   <li> <a href="/transcode?q=%E5%AE%81%E9%98%B3%E5%8E%BF&amp;pn=1&amp;pos=9&amp;m=5fc9de297263e72a19d799ebc87074fc9c2c3439&amp;u=http%3A%2F%2Fwww.mof.gov.cn%2Fmofhome%2Fmof%2Fxinwenlianbo%2Fshandongcaizhengxinxilianbo%2F201603%2Ft20160310_1900036.html" data-pos="2"> <b>宁阳县</b>四措并举积极支持社会组织发展 </a>   <li> <a href="/transcode?q=%E5%AE%81%E9%98%B3%E5%8E%BF&amp;pn=1&amp;pos=10&amp;m=7fc0df51668aacdcc1f1b54d9860767cdcce8ed4&amp;u=http%3A%2F%2Fsd.ifeng.com%2Fa%2F20160309%2F4350892_0.shtml" data-pos="3"> 农行<b>宁阳</b>支行强化客户基础建设提质产品服务 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '山东宁阳一小学生被校车碾轧身亡 校长停职' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '山东宁阳一小学生被校车碾轧身亡 校长停职'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";