s:23593:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>扬帆起航 文明西安再出发(组图)- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">扬帆起航 文明西安再出发(组图)</h1> <p id="source-and-time"><span id=source>网易</span><time id=time>2016-03-11 03:25:07</time></p> </header>  <div id="news-body"><p><img src="http://p35.qhimg.com/t01855e982c03df9955.jpg?size=400x254"></p><p>一系列群众文化活动不断丰富市民生活 (资料照片)</p><p><img src="http://p31.qhimg.com/t01031b62bf96a4a2a3.jpg?size=400x284"></p><p><a href="http://m.so.com/s?q=%E9%92%9F%E9%BC%93%E6%A5%BC%E5%B9%BF%E5%9C%BA&amp;src=newstranscode" class="qkw">钟鼓楼广场</a>的社会主义核心价值观公益广告 (资料照片)</p><p>2015年2月28日，乍暖还寒，三秦大地已透出春的气息。</p><p>当日，在北京召开的全国精神文明建设工作表彰暨学雷锋志愿服务大会上传来喜讯，西安荣获全国文明城市称号。西安人耕耘着、播种着，让文明之花美丽绽放，让这座城市和生活在这里的每个人，幸福地守望着一片片文明的风景。</p><p>城市文明犹如一个生命体，吐故纳新，生生不息，在传统与现代的融合中获得新生。</p><p>对西安而言，创文不仅是一个超越自我的“蝶变”过程，也是一次“补齐短板”“内外兼修”的主动冲刺。文明提升无止境，创文永远在路上。在步履铿锵的创文行动中，西安不断丰富着文明城市的深刻内涵，一点一滴<a href="http://m.so.com/s?q=%E5%8C%96%E8%9B%B9%E6%88%90%E8%9D%B6&amp;src=newstranscode" class="qkw">化蛹成蝶</a>。沐浴现代文明之风，西安正变得更美丽、更现代、更宜居，也更加充满活力。</p><p class="header">常态创建:持之以恒谋创新</p><p>古人云:骐骥一跃，不能十步;驽马十驾，功在不舍。</p><p>创建文明城市非一日之功，需要持之以恒地努力和坚守。西安不断健全完善工作机制，推动文明城市长效常态创建。<a href="http://m.so.com/s?q=%E8%A5%BF%E5%AE%89%E5%B8%82&amp;src=newstranscode" class="qkw">西安市</a>按照“巩固成果、丰富内涵，探索创新、长效常态”的原则，大胆探索、积极实践，逐步建立健全了一整套适应创建工作新常态的体制机制，实现文明城市创建由“全力争创”到“巩固提升”的转型升级，形成了文明城市创建“抓日常、促平常、重经常”的工作格局。</p><p>市委明确把“文明城市巩固提升工作”纳入全市总体工作思路和奋斗目标，在全市清理各类议事协调机构的大背景下，坚持保留西安市创建全国文明城市工作领导小组及其办公室，统筹协调全市文明城市创建工作。</p><p>在多年的创建实践中，西安逐步建立了一套科学的制度，并坚持制度不松，以制度的“指挥棒”为创文保驾护航。创新建立“种文明”机制，充分发挥文明创建活动的真实效用，让城市文明建设由“疾风骤雨”向“润物无声”转变。</p><p>“电影进社区”“文化下乡”……通过培育基层文化能人、配备城乡社区文化辅导员等形式，把文化种在基层、种在群众中间，有效褪除了基层文化活动“舞台化、表演化”色彩，更加接地气，更能满足群众的精神文化需求。</p><p>“心愿墙”“扶贫帮困的个性化定制”……改变了以往逢年过节给群众送米面油的“我给你受”模式，通过社区调查摸排困难群众的具体需求，建立困难群众需求台账，做到帮扶更精准，群众更满意。</p><p>“在职党员干部到社区报到”“文明单位与社区结对子”……志愿服务方面克服“应景式”“运动式”集中活动模式，让党员干部和文明单位员工在自己家门口的社区注册当志愿者，日常做公益、点滴做奉献。</p><p>一系列制度“组合拳”，外加集中整治、宣传教育、督导推进、创文投入等方面持续不减的力度，各项创建任务得以有序推进。</p><p class="header">环境治理:文明生活更美好</p><p>提升之力带来变化之美。如今，扎实推进的创文行动让市民都有了多样的深切感受。</p><p>市民张瑶庆最大的感受是西安的蓝天多了。“一抬头，看见白云蓝天，呼吸新鲜空气，别提有多舒畅!”</p><p>西安曾戴着“全国空气污染最严重城市之一”的黑帽子。</p><p>创文以来，西安市大力实施治污减霾攻坚行动，提前实现主城区20蒸吨燃烧锅炉、煤场、<a href="http://m.so.com/s?q=%E8%9C%82%E7%AA%9D%E7%85%A4&amp;src=newstranscode" class="qkw">蜂窝煤</a>、机关事业单位黄标车四项全清零，市区空气综合污染指数持续下降，空气质量明显好转，2015年收获优良天数251天，稳定退出全国74个重点监测城市后10位。</p><p>妞妞小朋友的最大感受是家门口的公园越来越好玩了，到处是绿色的树木和清清的池水。</p><p>几年来，我市持续推进“八水润西安”工程，全年新增生态水面2823亩、湿地6357亩，使西安这座西部内陆城市因水而显得更加滋润和灵动。城区的绿地面积不断增加。去年12月，我市<a href="http://m.so.com/s?q=%E6%B5%90%E7%81%9E%E7%94%9F%E6%80%81%E5%8C%BA&amp;src=newstranscode" class="qkw">浐灞生态区</a>荣登由国家发改委等部门论证复核评定的第三批<a href="http://m.so.com/s?q=%E7%94%9F%E6%80%81%E6%96%87%E6%98%8E&amp;src=newstranscode" class="qkw">生态文明</a>先行示范区名单。</p><p class="header">环境治理，是一场永不停止的攻坚战。</p><p>抓住政府机构改革契机，西安进一步健全“大城管”体制，不断完善“纵向到底、横向到边”的网格化管理体系，努力提高城市精细化管理水平。运用信息化智能技术，实施城市管理实时监控，大街小巷出现占道经营，执法人员15分钟抵达现场处置。实施巡查值守制度和“错时工作制”，重点部位设置专人值守，上班时间“前伸后延”(<a href="http://m.so.com/s?q=%E5%8D%B3%E6%97%A9&amp;src=newstranscode" class="qkw">即早</a>8点上班前和晚6点下班后)，严防死守，有效巩固了专项整治效果，促进了城市公共环境管理的长效化、常态化。老旧小区、集贸市场、<a href="http://m.so.com/s?q=%E8%83%8C%E8%A1%97&amp;src=newstranscode" class="qkw">背街</a>小巷以及城乡接合部“脏乱差”不见了，取而代之是城市每个角落都干净整洁、美观亮丽。</p><p class="header">道德建设:引领社会新风尚</p><p>今年初，西安一位收废品老人推车过马路不小心划伤了私家车，借钱赔偿，女车主拒收赔偿金反赠老人1000元，这件暖心事被<a href="http://m.so.com/s?q=%E4%BA%BA%E6%B0%91%E6%97%A5%E6%8A%A5&amp;src=newstranscode" class="qkw">人民日报</a>官方微博微信关注，古朴善良的西安人用诚信和善心温暖了一座城。</p><p class="header">这只是西安文明诚信的一个缩影。</p><p>随着“尚德西安”道德<a href="http://m.so.com/s?q=%E5%BB%BA%E8%AE%BE%E7%B3%BB%E7%BB%9F%E5%B7%A5%E7%A8%8B&amp;src=newstranscode" class="qkw">建设系统工程</a>的开展，全市广泛开展社会公德、职业道德、家庭美德、个人品德教育实践活动;持续开展“图说我们的价值观”“讲文明树新风”公益广告宣传活动，各种形式的公益广告刊播力度不减、声势强大，弘扬了新风正气，传播了社会正能量，荣获全省公益广告刊播制作一等奖。</p><p>欲建文明城，先做文明人。全市扎实开展道德模范评选表彰活动，在网上开展“道德模范·西安点赞”活动，在媒体坚持办好“凡人善举”宣传栏目;充分发挥各级各类道德讲堂的作用，将道德模范请进道德讲堂，用身边人讲身边事，增强了道德宣传活动的感染力、影响力。2015年西安市1人获全国道德模范称号，两人获<a href="http://m.so.com/s?q=%E6%97%B6%E4%BB%A3%E6%A5%B7%E6%A8%A1&amp;src=newstranscode" class="qkw">时代楷模</a>称号，4人获全国道德模范提名奖;11人获全省道德模范称号，11人获全省道德模范提名奖。“我推荐、我评议身边好人”活动全年推出“西安好人”64个、“陕西好人”16个、“中国好人”9个。</p><p>积极开展“诚信示范单位”评选、“百城万店无假货”等活动，实施诚信“红黑榜”集中发布制度，建立部门间联合惩戒机制，加大对失信行为的惩戒力度。广泛开展“节俭养德”主题活动，“文明餐桌”在全市酒店饭馆、餐饮街市、单位食堂基本实现全覆盖。</p><p><a href="http://m.so.com/s?q=%E6%83%A0%E6%B0%91&amp;src=newstranscode" class="qkw">惠民</a>为民:文明硕果共分享</p><p>文明创建是一座城市的不懈追求，更是脚踏实地的民心工程。</p><p>“创文为了人民，创文依靠人民，创文成果让人民共享”，是城市决策者的心声，也是向全体市民作出的庄严承诺。创文成为西安关注民生、为民造福的平台和载体，一项项温暖人心的民生工程相继出炉，一件件实事好事落到实处，广大群众的生活质量和幸福指数越来越高。</p><p>交通畅行全民共享。谈起出行变化，市民<a href="http://m.so.com/s?q=%E7%8E%8B%E6%A3%AE&amp;src=newstranscode" class="qkw">王森</a>用“一天一个样”来形容。他说，地铁贯通、道路扩宽、公共自行车随借随用、整治机动车乱停放……随着缓堵保畅措施一项项推进深入，城市交通管理水平明显提高，市区交通秩序极大改善。</p><p>公共服务全民共享。“进一个门、跑一次路，办妥一揽子事”，完善的市、区两级政务服务大厅系统遍布全市;进一步深化<a href="http://m.so.com/s?q=%E8%A1%8C%E6%94%BF%E5%AE%A1%E6%89%B9%E5%88%B6%E5%BA%A6%E6%94%B9%E9%9D%A9&amp;src=newstranscode" class="qkw">行政审批制度改革</a>，建立权力清单、负面清单和责任清单，加快政府职能转变，强化服务意识，方便群众办事创业;建立重大事项决策责任制和决策过错责任追究制，完善民生问题听证咨询制度、重大事项公示制度和新闻发布制度。加大行风评议力度，不断提高政府行政效能和公共服务能力。</p><p>文化发展全民共享。全民阅读、红五月音乐会、夏日广场文化、社区文化节、广场舞大赛……一系列群众文化活动不断丰富市民文化生活。制定<a href="http://m.so.com/s?q=%E3%80%8A%E5%8A%A0%E5%BF%AB%E6%9E%84%E5%BB%BA%E7%8E%B0%E4%BB%A3%E5%85%AC%E5%85%B1%E6%96%87%E5%8C%96%E6%9C%8D%E5%8A%A1%E4%BD%93%E7%B3%BB%E7%9A%84%E5%AE%9E%E6%96%BD%E6%84%8F%E8%A7%81%E3%80%8B&amp;src=newstranscode" class="qkw">《加快构建现代公共文化服务体系的实施意见》</a>和《西安市基本公共文化服务保障标准》，完善全市公共文化服务制度体系建设，推动文化惠民与群众需求的有效对接。全市所有区县均建有综合性文化活动中心，所有街镇、社区(村)都建有文化站、文化室，为市民群众开展文化活动提供了坚实基础。</p><p><a href="http://m.so.com/s?q=%E5%B8%8C%E6%9C%9B%E5%B7%A5%E7%A8%8B&amp;src=newstranscode" class="qkw">希望工程</a>全民关注。制定出台<a href="http://m.so.com/s?q=%E3%80%8A%E8%A5%BF%E5%AE%89%E5%B8%82%E6%9C%AA%E6%88%90%E5%B9%B4%E4%BA%BA%E6%80%9D%E6%83%B3%E9%81%93%E5%BE%B7%E5%BB%BA%E8%AE%BE%E7%B3%BB%E7%BB%9F%E5%B7%A5%E7%A8%8B%E5%AE%9E%E6%96%BD%E6%96%B9%E6%A1%88%E3%80%8B&amp;src=newstranscode" class="qkw">《西安市未成年人思想道德建设系统工程实施方案》</a>，实施未成年人理想信念、道德实践、素质教育、成长环境“四大工程”，全面推进未成年人思想道德建设。广泛开展“我的中国梦”主题实践活动，教育孩子们从小立志向、有梦想，爱学习、爱劳动、爱祖国。</p><p>城乡发展协调统一。全力推进农村精神文明“十个一”建设，努力推进<a href="http://m.so.com/s?q=%E7%A4%BE%E4%BC%9A%E4%B8%BB%E4%B9%89%E6%A0%B8%E5%BF%83%E4%BB%B7%E5%80%BC%E8%A7%82&amp;src=newstranscode" class="qkw">社会主义核心价值观</a>在农村落实落地，全市农村精神文明建设再上新台阶。市文明委动员组织辖区内各级文明单位，采取一对一、多对一等形式，与农村结成帮扶对子，在道德教育、文化阵地、道路交通、饮水安全、环境卫生等方面进行帮扶，为农村和农民办实事、办好事。</p><p>在创建全国文明城市的进程中，我市筑起一个又一个“民生工程”的新高度。</p><p>2016年，西安文明城市创建即将迎来一个新的节点。文明城市的创建不是短期的功利行为，而是需要不断传承的幸福接力。全国文明城市，一个西安人矢志追求的目标，一场永不停歇的幸福接力，一个永无止境的提升之旅。</p><p class="header">创文，我们永远在路上。</p><p>记者 张端/文 <a href="http://m.so.com/s?q=%E7%8E%8B%E6%97%AD%E4%B8%9C&amp;src=newstranscode" class="qkw">王旭东</a>/图</p><p>作者:张端 王旭东 图</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.163.com/16/0311/03/BHRK6RUS00014AED.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='7d30376ea6c6bd55ecb6d37b5198236f'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>西安日报</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '扬帆起航 文明西安再出发(组图)' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '扬帆起航 文明西安再出发(组图)'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";