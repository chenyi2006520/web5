s:17555:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>《烈日灼心》22、23日全国点映生猛大片决胜口碑- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">《烈日灼心》22、23日全国点映生猛大片决胜口碑</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-13 17:17:44</time></p> </header>  <div id="news-body"><p><img src="http://p35.qhimg.com/t01fc8d132016bc1698.jpg?size=600x257"></p><p><img src="http://p33.qhimg.com/t0167aab0dfa857fc00.jpg?size=600x900"></p><p><img src="http://p34.qhimg.com/t01a4a5ea1be0db9d9f.jpg?size=600x269"></p><p><img src="http://p35.qhimg.com/t019e922905cb6d5e49.jpg?size=600x269"></p><p><img src="http://p33.qhimg.com/t01e67543838425a9dc.jpg?size=600x269"></p><p><img src="http://p35.qhimg.com/t0174f57215c71aebd5.jpg?size=600x269"></p><p>由蓝色星空影业和博纳影业联合出品，<a href="http://m.so.com/s?q=%E6%9B%B9%E4%BF%9D%E5%B9%B3&amp;src=newstranscode" class="qkw">曹保平</a>导演，邓超、段奕宏、<a href="http://m.so.com/s?q=%E9%83%AD%E6%B6%9B&amp;src=newstranscode" class="qkw">郭涛</a>、王珞丹主演的暑期犯罪悬疑大片<a href="http://m.so.com/s?q=%E3%80%8A%E7%83%88%E6%97%A5%E7%81%BC%E5%BF%83%E3%80%8B&amp;src=newstranscode" class="qkw">《烈日灼心》</a>近日在万达电影网、<a href="http://m.so.com/s?q=%E6%A0%BC%E7%93%A6%E6%8B%89&amp;src=newstranscode" class="qkw">格瓦拉</a>、时光网等平台启动点映预售，将在8月22日、23日连续两天的下午15:00开启全国规模的盛大点映，覆盖全国50个城市、600家影院，可以自信预期:这部自上影节荣膺殊荣以来，一路收获奖杯口碑无数的热门影片，伴随点映规模扩容而来的将是口碑的进一步催化和翻腾，诚意之作，破格之旅，将为暑期档奉上尖叫、恐惧、感动、爆笑……满满当当不一样的极致观影体验。</p><p>自来水名单华丽 跨界精英与普通观众齐赞</p><p>《烈日灼心》自6月在上影节大胜以来，在后续的多场点映中均收获不俗口碑，其中有毒舌专家如<a href="http://m.so.com/s?q=%E6%88%B4%E9%94%A6%E5%8D%8E&amp;src=newstranscode" class="qkw">戴锦华</a>、史航的当场夸奖，“保平导演蔚然成大家，电影好看不媚俗!”“曹保平导演是真正值得关注的导演，前作<a href="http://m.so.com/s?q=%E3%80%8A%E6%9D%8E%E7%B1%B3%E7%9A%84%E7%8C%9C%E6%83%B3%E3%80%8B&amp;src=newstranscode" class="qkw">《李米的猜想》</a>《光荣的愤怒》一痴一狂，都是标杆电影!”一向以挑剔眼光和公信力闻名的影评人“桃桃淘电影”对本片也打出四星高分:“华语犯罪题材能做到这个程度真的很难得，非主旋律，有案件做驱动。角色的深度，人物关系的<a href="http://m.so.com/s?q=%E5%BC%A0%E5%8A%9B&amp;src=newstranscode" class="qkw">张力</a>都很吸引人。最后高楼追逐一场绝对够紧张，满场尖叫。”<a href="http://m.so.com/s?q=%E5%A7%9C%E6%96%87&amp;src=newstranscode" class="qkw">姜文</a>、黄渤作为“演员中的演员”，也对电影中几位影帝的表演赞赏有加:“演员演得真好!这戏怎么没找我呀!我有那么老吗?”“后悔当时没时间接，现在能重拍一遍吗?”著名社会学家<a href="http://m.so.com/s?q=%E6%9D%8E%E9%93%B6%E6%B2%B3&amp;src=newstranscode" class="qkw">李银河</a>女士也称赏《烈日灼心》“是难得的一部找不出破绽的国产电影，我认为它达到了<a href="http://m.so.com/s?q=%E5%A5%BD%E8%8E%B1%E5%9D%9E&amp;src=newstranscode" class="qkw">好莱坞</a>警匪片的标准，片中的兄弟情谊很动人。”大量的普通观众也从电影中看到自己关心的情感、故事、风格、表演和尺度突破，从不同维度品味烈日下发生的<a href="http://m.so.com/s?q=%E7%BD%AA%E4%B8%8E%E7%88%B1&amp;src=newstranscode" class="qkw">罪与爱</a>:“灭门!同性!猫鼠游戏!法理人性!死刑直播!《烈日灼心》造就了现行审查体制下本不可能出现的奇迹。论尺度、论深度，均属华语片里程碑之作。”“<a href="http://m.so.com/s?q=%E9%82%93%E8%B6%85&amp;src=newstranscode" class="qkw">邓超</a>一直是'表演准确'的好演员。”“<a href="http://m.so.com/s?q=%E6%83%85%E8%8A%82%E7%82%B9&amp;src=newstranscode" class="qkw">情节点</a>密集、叙事顺畅、摄影讲究、角色塑造入心。”可以自信预期: 伴随点映规模扩容而来的将是口碑的进一步催化和翻腾，诚意之作，破格之旅，将为暑期档奉上尖叫、恐惧、感动、爆笑……满满当当不一样的极致观影体验。据悉，《烈日灼心》在全国50各个城市600家影院选择真正的“点映”，不追求点映票房数字的好看，更在乎观众评价电影好看、走心，用口碑和实力去扩线充面，带动这部风格之作真正打进观众心里。</p><p class="header">重拳出击一烈到底类型生猛暑期必看</p><p>作为轰轰烈烈的暑期档最后一道烈性大餐，《烈日灼心》将在十天之后全国公映，并将为观众带来耳目一新的观影体验。沉底七年的水库灭门凶案，三个懵懂青年因一念之差成为背负罪孽的<a href="http://m.so.com/s?q=%E4%BA%A1%E5%91%BD%E7%8B%82%E5%BE%92&amp;src=newstranscode" class="qkw">亡命狂徒</a>--故事从一开篇就紧抓观众，接续而来的拔枪制暴、绝地追车、尖针缝伤、高楼追凶、死刑直播等场面更令人汗手惊心，而<a href="http://m.so.com/s?q=%E8%81%8C%E4%B8%9A%E8%AD%A6%E5%AF%9F&amp;src=newstranscode" class="qkw">职业警察</a>和不法之徒之间复杂的情谊、三个“坏”爸爸对孤女的善念深情亦令观者痛惜。焦灼的人物内心，对演员表演的要求极高，导演曹保平说:“我想找到一个不同的临界点--强大的充满张力的喜剧故事和最朴实的表演之间的衔接，这和大家对他们熟知的那种状态是背道而驰，有很多不一样的地方。比如邓超，我和他是第三次合作，通过《烈日灼心》的合作，我觉得他和很多年前不一样了，不完全是经验、技术和能力的问题，是对表演本质的理解不一样了。他能找到表演最根上的东西。我对他的要求是比较苛刻的，也很残酷无情，但在最后呈现出来的质感和状态上，能相对精确地咬合在一起!”不一样的三位影帝，不一样的故事、类型、表演，带来不一样的暑期档最后一击。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/article/4019091.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='cab3e4f22e81fd7fe05fe6152fc5d630'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>烈日灼心</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%83%88%E6%97%A5%E7%81%BC%E5%BF%83&amp;pn=1&amp;pos=10&amp;m=6026ae3a28b0a9a25e365663edf8e16046668685&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4016447.html" data-pos="1"> 《<b>烈日灼心</b>》首周末破亿放送"非正片画面" </a>   <li> <a href="/transcode?q=%E7%83%88%E6%97%A5%E7%81%BC%E5%BF%83&amp;pn=2&amp;pos=1&amp;m=e42d716bebf24f8a54846da627743015625abbfd&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4016408.html" data-pos="2"> 《<b>烈日灼心</b>》集齐烈性造梦者神经质剧组炼成神作 </a>   <li> <a href="/transcode?q=%E7%83%88%E6%97%A5%E7%81%BC%E5%BF%83&amp;pn=2&amp;pos=2&amp;m=98c22978554f610079a7572b91913df87371b1a8&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4016513.html" data-pos="3"> 段奕宏携《<b>烈日灼心</b>》现身笑称自己帅出新高度 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '《烈日灼心》22、23日全国点映生猛大片决胜口碑' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '《烈日灼心》22、23日全国点映生猛大片决胜口碑'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";