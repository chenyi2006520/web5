s:18843:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>极限挑战六兄弟狂风奔跑 陪伴是最好的礼物- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">极限挑战六兄弟狂风奔跑 陪伴是最好的礼物</h1> <p id="source-and-time"><span id=source>九游网</span><time id=time>2016-03-11 14:54:00</time></p> </header>  <div id="news-body"><p>导 读 极限<a href="http://m.so.com/s?q=%E5%85%AD%E5%85%84%E5%BC%9F&amp;src=newstranscode" class="qkw">六兄弟</a>不但狂风里奔跑录制了最新一期节目，更在昨日中午一同来到位于上海<a href="http://m.so.com/s?q=%E5%B7%9D%E6%B2%99%E6%96%B0%E9%95%87&amp;src=newstranscode" class="qkw">川沙新镇</a>的民办豫息农民工子弟学校，陪伴那里的孩子们度过了一段难忘的时光。<a href="http://m.so.com/s?q=%E4%B9%9D%E6%B8%B8&amp;src=newstranscode" class="qkw">九游</a>玉米为大家带来极限挑战第二季的最新录制情况吧。 ​...</p><p>极限六兄弟不但狂风里奔跑录制了最新一期节目，更在昨日中午一同来到位于上海川沙新镇的民办豫息农民工子弟学校，陪伴那里的孩子们度过了一段难忘的时光。九游玉米为大家带来极限挑战第二季的最新录制情况吧。</p><p><img src="http://p35.qhimg.com/t014c0815534d8dea31.jpg?size=556x283"></p><p class="img-title">陪伴是最好的礼物</p><p>昨日，六位“暖宝宝”一现身小学校园，就自带热力给这里来了一个大升温。<a href="http://m.so.com/s?q=%E9%BB%84%E6%B8%A4&amp;src=newstranscode" class="qkw">黄渤</a>[微博]、孙红雷[微博]、<a href="http://m.so.com/s?q=%E9%BB%84%E7%A3%8A&amp;src=newstranscode" class="qkw">黄磊</a>[微博]、罗志祥[微博]、<a href="http://m.so.com/s?q=%E7%8E%8B%E8%BF%85&amp;src=newstranscode" class="qkw">王迅</a>，张艺兴一起，不但为孩子们分发饭菜，陪孩子们共进午餐，更和大家在操场上一起大玩游戏互动，还把亲自准备的“成长大礼包”分发给小朋友们，最后还和孩子们一起合照，为他们<a href="http://m.so.com/s?q=%E7%95%99%E4%B8%8B%E7%BE%8E%E5%A5%BD%E7%9A%84%E8%AE%B0%E5%BF%86&amp;src=newstranscode" class="qkw">留下美好的记忆</a>。</p><p>中午12点钟，刚刚学习了一上午的小朋友们正在等待着自己的美味午餐，完全没注意到六位哥哥已在此时如约而至，低调的“潜入”到了他们身边。而许久没有<a href="http://m.so.com/s?q=%E5%9B%9E%E5%88%B0%E6%A0%A1%E5%9B%AD&amp;src=newstranscode" class="qkw">回到校园</a>的哥哥们看到小朋友们也显得相当的兴奋。细心的<a href="http://m.so.com/s?q=%E5%BC%A0%E8%89%BA%E5%85%B4&amp;src=newstranscode" class="qkw">张艺兴</a>在为孩子们夹鸡腿时，总是不忘在米饭上多浇一勺汤汁，真是美味又营养，让小朋友们忍不住比平日里多吃上一碗。但在做游戏时，这位呆萌哥哥就变得没那么果断，看着一圈举着手的要跟他一起玩的小朋友，张艺兴因为不知道该选择哪一个和自己做搭档而一度陷入纠结。这样的哥哥自然最受小朋友们的欢迎。当问及最喜欢那位哥哥时，大家异口同声的报上“张艺兴”的名字。究其原因，竟然又异口同声到:“因为他最帅!”</p><p>而对此，“颜王”<a href="http://m.so.com/s?q=%E5%AD%99%E7%BA%A2%E9%9B%B7&amp;src=newstranscode" class="qkw">孙红雷</a>自然表示不服，无奈的却是他在荧幕上演过太多严肃角色，让小朋友们看到这位孙哥哥时总是表现的有点“怕怕的”不敢去亲近。不过大哥就是大哥，总是自有办法。在为大家分发礼物时，孙红雷就一度不顾自己正在发烧身体不适，直接蹲到地上亲手用打气管给小朋友们的皮球充气，然后再把皮球分发了大家。随后就听到一个小朋友在人群中大喊:“孙红雷刚刚亲了我一下。”引得周围其他的小伙伴们一阵羡慕之声。</p><p>但要说最懂小朋友的人，自然还得是黄磊黄老师莫属。作为电影学院的老师，黄磊早已桃李天下，在家庭教育上更是自有一套。昨天黄老师就深入小学图书室内为小朋友们选书讲故事，更拉着<a href="http://m.so.com/s?q=%E7%BD%97%E5%BF%97%E7%A5%A5&amp;src=newstranscode" class="qkw">罗志祥</a>、王迅，教他们该如何给小孩讲童书，也是让还没做爸爸的小猪“受益匪浅”。不过好动的小猪显然对给孩子们上体育课更感兴趣，操场上一见到篮球筐，就喊着要篮球，拍球、上篮就是一技<a href="http://m.so.com/s?q=%E5%A4%A7%E7%81%8C%E7%AF%AE&amp;src=newstranscode" class="qkw">大灌篮</a>，引得小朋友们一阵热烈欢呼，也让几位哥哥十分技痒一起上前“切磋”一番。</p><p>随后，几位哥哥和小朋友们玩起了“两人三只脚”<a href="http://m.so.com/s?q=%E6%8E%A5%E5%8A%9B%E8%B7%91&amp;src=newstranscode" class="qkw">接力跑</a>，王迅和小同伴配合最为默契，<a href="http://m.so.com/s?q=%E7%AC%AC%E4%B8%80%E4%B8%AA%E5%9B%9E%E5%90%88&amp;src=newstranscode" class="qkw">第一个回合</a>就把对手小猪团队甩下了半程。而第二轮，黄磊和自己的小伙伴则状况频出将比分落下更多，这让接下来的黄渤一组不管怎样连蹦带跳也“回天无力”，引得围观的小朋友们乐不可支。看着这场面，该校陈校长禁不住向记者表示;“真的非常欢迎<a href="http://m.so.com/s?q=%E3%80%8A%E6%9E%81%E9%99%90%E6%8C%91%E6%88%98%E3%80%8B&amp;src=newstranscode" class="qkw">《极限挑战》</a>六兄弟常来学校看望孩子们。因为这档节目除了传递一种积极进取的能量，更传达着拼搏与友爱。”</p><p>“<a href="http://m.so.com/s?q=%E6%9E%81%E9%99%90%E7%94%B7%E4%BA%BA%E5%B8%AE&amp;src=newstranscode" class="qkw">极限男人帮</a>”提议“成长计划”</p><p class="header">第二季更关注社会人文</p><p>据了解，此次“极限公益成长计划”由<a href="http://m.so.com/s?q=%E4%B8%9C%E6%96%B9%E5%8D%AB%E8%A7%86&amp;src=newstranscode" class="qkw">东方卫视</a>《极限挑战》、中国扶贫基金会、<a href="http://m.so.com/s?q=%E4%BC%98%E9%85%B7%E5%9C%9F%E8%B1%86&amp;src=newstranscode" class="qkw">优酷土豆</a>联合发起的，旨在通过节目的影响力和“极限男人帮”的暖心公益行动来呼吁社会各界关注城市外来务工子弟的成长。该公益计划将每期《极限挑战》获胜方的奖励转贴成现，加上优酷土豆的公益众筹，每期为一所外来务工子弟学校提供“成长礼包”，礼包包含体育、音乐、文学等各种根据每所学校孩子们的需求不同所采购的物资。</p><p>对此，《极限挑战》的总导演<a href="http://m.so.com/s?q=%E4%BB%BB%E9%9D%99&amp;src=newstranscode" class="qkw">任静</a>、严敏就向记者介绍说，其实早在去年《极限挑战》第一季节目过半时，节目组就已经开始计划做这样的“成长计划”，“这首先是六位哥哥们一直非常想做的事情。《极限挑战》这档节目除了在激发大家去突破自我的局限，向自己发起挑战，更多的则是在鼓励大家乐于将温暖传递给他人，而将温暖传递给孩子们则不光是在温暖一个当下，更是在温暖整个未来。从这一点出发，在第二季节目中，我们则将会更多的去关注社会人文。我们要做的不光是一档好看的节目，更是一档温暖人心的节目。”</p><p>以上就是今天为大家带来的极限挑战第二季2016嘉宾名单大全，更多精彩，尽在九游!最后为大家推荐几款几款好玩的游戏，广告时间必玩的手游喔:</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.9game.cn/news/732797.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='bfd4d9b30b2a489f7094f8b44e560232'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>最好的陪伴</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9C%80%E5%A5%BD%E7%9A%84%E9%99%AA%E4%BC%B4&amp;pn=1&amp;pos=5&amp;m=f44a019bd696f419d68273594bc5b8bccbc7de94&amp;u=http%3A%2F%2Fwww.9game.cn%2Fnews%2F732797.html" data-pos="1"> 极限挑战六兄弟狂风奔跑 <b>陪伴</b>是<b>最好的</b>礼物 </a>   <li> <a href="/transcode?q=%E6%9C%80%E5%A5%BD%E7%9A%84%E9%99%AA%E4%BC%B4&amp;pn=1&amp;pos=6&amp;m=59491d33aac7f17e019d55215b29e31c63709992&amp;u=http%3A%2F%2Fnews.southcn.com%2Fchina%2Fcontent%2F2016-03%2F03%2Fcontent_143415499.htm" data-pos="2"> <b>最好的陪伴</b> 男子带患癌父亲南半球"重生"之旅 </a>   <li> <a href="/transcode?q=%E6%9C%80%E5%A5%BD%E7%9A%84%E9%99%AA%E4%BC%B4&amp;pn=1&amp;pos=7&amp;m=42f066813e4194eb6f1bd0d65ea2144175a65aba&amp;u=http%3A%2F%2Fculture.gmw.cn%2Fnewspaper%2F2016-01%2F29%2Fcontent_110938564.htm" data-pos="3"> 《年兽大作战》 <b>陪伴</b>是<b>最好的</b>爱" </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '极限挑战六兄弟狂风奔跑 陪伴是最好的礼物' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '极限挑战六兄弟狂风奔跑 陪伴是最好的礼物'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";