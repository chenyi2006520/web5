s:17881:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>火影忍者十大奇葩观后感:鸣人佐助才是真爱? - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">火影忍者十大奇葩观后感:鸣人佐助才是真爱? </h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-03-12 20:32:05</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E7%81%AB%E5%BD%B1%E5%BF%8D%E8%80%85&amp;src=newstranscode" class="qkw">火影忍者</a>十大奇葩观后感<a href="http://m.so.com/s?q=%E9%B8%A3%E4%BA%BA&amp;src=newstranscode" class="qkw">鸣人</a>佐助才是真爱?<a href="http://m.so.com/s?q=%E3%80%8A%E7%81%AB%E5%BD%B1%E5%BF%8D%E8%80%85%E3%80%8B&amp;src=newstranscode" class="qkw">《火影忍者》</a>随着博人传的开播，似乎已经走到了这部动漫的尽头，在很多网友一遍遍的看过《火影忍者》之后总结出了许多奇怪的观后感，最先是鸣人追小樱，小樱追佐助，最后却变成了鸣人追<a href="http://m.so.com/s?q=%E4%BD%90%E5%8A%A9&amp;src=newstranscode" class="qkw">佐助</a>.....复杂的师生关系</p><p><img src="http://p33.qhimg.com/t01dc74f2a4fa0e5e75.png?size=550x213"></p><p>三忍是三代的徒弟，四代是自来也的徒弟，<a href="http://m.so.com/s?q=%E5%8D%A1%E5%8D%A1%E8%A5%BF&amp;src=newstranscode" class="qkw">卡卡西</a>是四代的徒弟，鸣人佐助小樱是卡卡西的徒弟，本来这是很纯洁很美好的递进关系，但是由于三忍分别抢走了卡卡西的三个徒弟，结果鸣人和老爸变成了师兄弟，卡卡西的三个徒弟都变成了他的师叔……</p><p class="header">作者貌似很讨厌蛇</p><p><img src="http://p31.qhimg.com/t015a516b4217991810.jpg?size=550x235"></p><p>岸本同学一定很讨厌蛇，从第一部开始就不断的虐待<a href="http://m.so.com/s?q=%E5%A4%A7%E8%9B%87%E4%B8%B8&amp;src=newstranscode" class="qkw">大蛇丸</a>蜀黍，成功的让他加入了残联，第二部更过分，先让心高气傲的蛇叔屡次栽在自来也的师徒弟手里，最后连宠物万蛇都不放过，一个火球将其烤糊，岸本啊，你小时候被蛇咬过吧?</p><p><a href="http://m.so.com/s?q=%E6%9C%80%E5%BC%BA%E9%98%B2%E5%BE%A1&amp;src=newstranscode" class="qkw">最强防御</a>装备——晓队服</p><p><img src="http://p31.qhimg.com/t01b340e3339e687482.png?size=550x361"></p><p>据统计，所有晓成员的死亡都是在脱了晓袍之后发生的，这让我们不禁怀疑晓队服的材质和三防属性，该不会是防御力99%附带反弹所有物理攻击和<a href="http://m.so.com/s?q=%E9%AD%94%E6%B3%95%E6%94%BB%E5%87%BB&amp;src=newstranscode" class="qkw">魔法攻击</a>的暗金装备吧!</p><p>鸣人到底<a href="http://m.so.com/s?q=%E7%88%B1%E7%9A%84%E6%98%AF%E8%B0%81&amp;src=newstranscode" class="qkw">爱的是谁</a>?</p><p>7班的关系本来是很单纯的递进追逐关系:鸣人追小樱，小樱追佐助，但是看着看着就有那么一点异样了，本来佐助出走后鸣人为了小樱才去追佐助的，但是追啊追啊就演变成了单纯的鸣人追佐助了，你看<a href="http://m.so.com/s?q=%E5%A4%A9%E5%9C%B0%E6%A1%A5&amp;src=newstranscode" class="qkw">天地桥</a>一战，鸣人根本没管小樱的死活嘛。是这三年鸣人移情别恋，不要小樱了，还是3年前与佐助的一吻发生了化学变化就不得而知了。</p><p class="header">杀师成功率100%</p><p><img src="http://p32.qhimg.com/t01c22e0539d837c309.jpg?size=550x392"></p><p>目前为止，<a href="http://m.so.com/s?q=%E7%81%AB%E5%BD%B1%E4%B8%AD&amp;src=newstranscode" class="qkw">火影中</a>徒弟杀师傅的成功率达到了百分之百的境界，从大蛇杀害三代，到佐助反推大蛇，再到自来也被徒弟群殴致死，照这么推算下去的话，鸣人很有可能会死在<a href="http://m.so.com/s?q=%E6%9C%A8%E5%8F%B6%E4%B8%B8&amp;src=newstranscode" class="qkw">木叶丸</a>手里。</p><p class="header">索命石像和98天定律</p><p><img src="http://p34.qhimg.com/t01e993cc519207d1a4.jpg?size=550x338"></p><p>据名为patrik的铁杆粉丝统计，最先受此定律诅咒的是<a href="http://m.so.com/s?q=%E9%98%BF%E6%96%AF%E7%8E%9B&amp;src=newstranscode" class="qkw">阿斯玛</a>，313话中，阿斯玛首次给我们心头蒙上一丝不安的阴影，其间还无缘无故的仰望了三代石像，最后阿斯玛在328话里<a href="http://m.so.com/s?q=%E6%AD%A3%E5%BC%8F%E6%AD%BB%E4%BA%A1&amp;src=newstranscode" class="qkw">正式死亡</a>，其间相隔15话，也即98天;而后，自来也也重复了这个定律，在367话中，自来也首次给我们心头蒙上一丝不安的阴影(对手的强大，此次任务的危险)，其间也无缘无故的仰望了三代石像，最后自来也在382里正式死亡，也是相隔15话。</p><p><a href="http://m.so.com/s?q=fans&amp;src=newstranscode" class="qkw">fans</a>逢人叫大叔</p><p><img src="http://p33.qhimg.com/t01190698a80e9885aa.jpg?size=550x607"></p><p>最初叔字辈的只有自来也和大蛇丸这两位，结果叔这个词像传染病一样传遍了火影整个男性群体，上至年龄过百的角都，下至年龄比卡卡西还小的大和，我说叔这个词用得太泛了吧，而且蝎也老大不小的了，咋没人叫他叔捏?你们这是在歧视成熟稳重的男人!</p><p class="header">回忆必死定律</p><p><img src="http://p31.qhimg.com/t017455246d935496f3.jpg?size=550x375"></p><p>海贼王中回忆是人物上船的征兆，而在火影中，回忆则是角色死亡的征兆，无论是三代还是大蛇，<a href="http://m.so.com/s?q=%E8%BF%AA%E8%BE%BE%E6%8B%89&amp;src=newstranscode" class="qkw">迪达拉</a>还是自来也，都逃不过这个定律，不知道这是因为岸本要集中发挥角色余热还是别的什么原因，不过想想也难怪，打架时间你们非得走神，想些乱七八糟的东西，会输很正常。</p><p class="header">主角你在哪里?</p><p><img src="http://p33.qhimg.com/t013dfe20ea414e6234.png?size=550x408"></p><p>火影第二部已经无视鸣小强很久了，从上周的彩页来看，岸本已经明确了2008年是佐助年，这暗示着鸣小强在新的一年里还是不得出头，这样下去的话，我们真的搞不懂到底<a href="http://m.so.com/s?q=%E8%B0%81%E6%98%AF%E4%B8%BB%E8%A7%92&amp;src=newstranscode" class="qkw">谁是主角</a>了</p><p class="header">假情报比真情报好玩</p><p><img src="http://p35.qhimg.com/t01c8c492899335ca0a.png?size=550x393"></p><p>火影每周的情报都伴随着众多的假情报，这些假情报或曲折离奇，或绝妙爆笑，有的甚至发展成规模创建了品牌。最近又有强人开始向情报图下手，做出了乱真度超高的假情报图，fans的力量果然强大啊!</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/2016/kuaixun_0312/4707843.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='f50868424aa96586413e545a2e939a63'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>佐助</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%BD%90%E5%8A%A9&amp;pn=1&amp;pos=4&amp;m=130e63acd4e3d3a150fbd5248844a39e683ad08a&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Finfo%2F2016-03%2F09%2Fc_135169847.htm" data-pos="1"> 火影忍者中10大公认的天才忍者 鸣人<b>佐助</b>未进前三? </a>   <li> <a href="/transcode?q=%E4%BD%90%E5%8A%A9&amp;pn=1&amp;pos=5&amp;m=e937ab0c9897f417e27c84422afde917e9e5711f&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fent%2Fhot%2F4638373_1.html" data-pos="2"> 宇智波<b>佐助</b>春野樱 盘点二次元里那些虐虐更健康的cp </a>   <li> <a href="/transcode?q=%E4%BD%90%E5%8A%A9&amp;pn=1&amp;pos=6&amp;m=d4c2e9a40ebf79998fabb2fc66e277cf7c453928&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fent%2Fhot%2F4638259_1.html" data-pos="3"> 深度挖掘火影忍者七大倾城帅哥 鸣人<b>佐助</b>弱爆了 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '火影忍者十大奇葩观后感:鸣人佐助才是真爱? ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '火影忍者十大奇葩观后感:鸣人佐助才是真爱? '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";