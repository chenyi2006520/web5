s:14978:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>暖春福利! 在易到用车免费体验一汽-大众奥迪A6L- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">暖春福利! 在易到用车免费体验一汽-大众奥迪A6L</h1> <p id="source-and-time"><span id=source>飞象网</span><time id=time>2016-03-14 17:06:00</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E7%99%BD%E8%89%B2%E6%83%85%E4%BA%BA%E8%8A%82&amp;src=newstranscode" class="qkw">白色情人节</a>，去易到约一辆免费的<a href="http://m.so.com/s?q=%E5%A5%A5%E8%BF%AA&amp;src=newstranscode" class="qkw">奥迪</a>A6L载着你爱的人去享受这个<a href="http://m.so.com/s?q=%E6%9A%96%E6%9A%96%E7%9A%84%E6%98%A5%E5%A4%A9&amp;src=newstranscode" class="qkw">暖暖的春天</a>吧!3月11日-5月26日期间，上海、杭州、成都、广州四城的易到用户，打开<a href="http://m.so.com/s?q=%E6%98%93%E5%88%B0%E7%94%A8%E8%BD%A6&amp;src=newstranscode" class="qkw">易到用车</a>App填写信息后，即可获得奥迪A6L体验券一张;之后选择奥迪A6L专车，即有机会免费试乘体验全新奥迪A6L车型，这个春天易到免费送你回家!</p><p><img src="http://p33.qhimg.com/t01aede92e34d2d0642.jpg?size=320x519"></p><p>据了解，本次活动由上海启程，3月11日-24日车辆体验范围为上海<a href="http://m.so.com/s?q=%E4%B8%AD%E7%8E%AF&amp;src=newstranscode" class="qkw">中环</a>以内、4月1日-4月14日为杭州武林商圈和城西、4月22日-5 月5日为成都二环内、5月13日-5月26日为广州<a href="http://m.so.com/s?q=%E5%A4%A9%E6%B2%B3%E5%8C%BA&amp;src=newstranscode" class="qkw">天河区</a>、越秀区，只要在此范围内，易到用户均可免费体验一汽-大众奥迪A6L带来的舒适出行体验。</p><p>本次全新上市的一汽-大众奥迪A6L其搭载的第三代1.8TFSI®发动机以更低能耗，释放更多能量，将革命性的驱动技术融为一体;至臻至美的外观设计，为用户带来跨级别的奢华舒适，彻底点燃你的驾乘欲望。</p><p>作为互联网专车行业的开创者，易到用车始终与各大汽车厂商保持着极为紧密的合作关系。从早先的<a href="http://m.so.com/s?q=%E7%89%B9%E6%96%AF%E6%8B%89&amp;src=newstranscode" class="qkw">特斯拉</a>到一汽丰田普锐斯再到现如今的奥迪A6L，易到已经将这种体验式营销方式玩的炉火纯青。用户可以在易到平台上以低廉甚至免费的价格，体验到各大品牌最新款的车型。</p><p>反之来看，易到高收入高素质的用户群体，则为各大汽车厂商带去了数量庞大的潜在客户资源。这种双赢的合作方式，为互联网专车平台与汽车品牌的合作树立了良好的范本。</p><p>此外对于用户来说，到各大品牌4S店去体验车辆这种传统的方式，不管从时间还是经济角度来看都很不划算，动辄半天的时间让不少消费者望而却步。但是在易到平台，消费者则完全不受时间和地域的限制，打破了传统模式的局限性省去了舟车劳顿之苦，只需打开易到App在上下班路上，即可体验到从经济型到奢华型的各大品牌主流车型。专业的易到司机则从车主的角度，充当了义务讲解员的角色，可以为用户深入的讲解车辆的优势。由此来看，这种易到加汽车品牌的体验式营销可谓<a href="http://m.so.com/s?q=%E4%B8%80%E4%B8%BE%E4%B8%89%E5%BE%97&amp;src=newstranscode" class="qkw">一举三得</a>。</p><p>未来，易到将进一步加深与各大汽车品牌的合作，将易到的<a href="http://m.so.com/s?q=%E7%A7%BB%E5%8A%A8%E4%BA%92%E8%81%94%E7%BD%91&amp;src=newstranscode" class="qkw">移动互联网</a>基因与传统汽车品牌的技术实力进行有效的集合，彻底颠覆现有的营销模式，让易到用户拥有更加简便、快捷的车辆体验及出行过程。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.cctime.com/html/2016-3-14/1147956.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='8c9dfef579eba37d01444af02197d693'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>易到用车</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%98%93%E5%88%B0%E7%94%A8%E8%BD%A6&amp;pn=1&amp;pos=5&amp;m=24e51dd0a99b79ed0ceb9c52dcc8a0f27a9cc315&amp;u=http%3A%2F%2Fwww.cctime.com%2Fhtml%2F2016-3-14%2F1147956.htm" data-pos="1"> 暖春福利! 在<b>易到用车</b>免费体验一汽-大众奥迪A6L </a>   <li> <a href="/transcode?q=%E6%98%93%E5%88%B0%E7%94%A8%E8%BD%A6&amp;pn=1&amp;pos=6&amp;m=33c74201c7fba9d7b1d23f5a83e13aa587337867&amp;u=http%3A%2F%2Fnews.ctocio.com.cn%2F20%2F13720020.shtml" data-pos="2"> 暖春福利! 在<b>易到用车</b>免费体验一汽大众奥迪A6L </a>   <li> <a href="/transcode?q=%E6%98%93%E5%88%B0%E7%94%A8%E8%BD%A6&amp;pn=1&amp;pos=7&amp;m=2cd1abfdb69122083930c33aa247c4f33896b778&amp;u=http%3A%2F%2Fwww.cctime.com%2Fhtml%2F2016-3-14%2F1147579.htm" data-pos="3"> <b>易到用车</b>司机王浩:用温暖传递正能量 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '暖春福利! 在易到用车免费体验一汽-大众奥迪A6L' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '暖春福利! 在易到用车免费体验一汽-大众奥迪A6L'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";