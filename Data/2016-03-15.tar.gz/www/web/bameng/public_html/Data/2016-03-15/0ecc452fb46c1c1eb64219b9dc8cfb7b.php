s:18290:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>从一本书开始，谈谈关于山本耀司的一切- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">从一本书开始，谈谈关于山本耀司的一切</h1> <p id="source-and-time"><span id=source>阅读时间</span><time id=time>2016-03-09 17:53:58</time></p> </header>  <div id="news-body"><p>将他在二十年前谈及日本状况的话“年轻人愈发轻浮、<a href="http://m.so.com/s?q=%E4%B8%AD%E4%BA%A7%E9%98%B6%E7%BA%A7&amp;src=newstranscode" class="qkw">中产阶级</a>变得无趣、所有人都用国际大品牌武装自己，并嘲笑穷人和长者”盲目地拿来比附当下中国的情形，进而在文中将其塑造成类似<a href="http://m.so.com/s?q=%E7%94%98%E5%9C%B0&amp;src=newstranscode" class="qkw">甘地</a>般恬淡守静的先知与<a href="http://m.so.com/s?q=%E8%A7%89%E6%82%9F%E8%80%85&amp;src=newstranscode" class="qkw">觉悟者</a>。这，并不是真正了解了<a href="http://m.so.com/s?q=%E5%B1%B1%E6%9C%AC%E8%80%80%E5%8F%B8&amp;src=newstranscode" class="qkw">山本耀司</a>。</p><p>今年一月，由<a href="http://m.so.com/s?q=%E5%B9%BF%E8%A5%BF%E5%B8%88%E5%A4%A7&amp;src=newstranscode" class="qkw">广西师大</a>出版社引进并出版了新书<a href="http://m.so.com/s?q=%E3%80%8A%E5%85%B3%E4%BA%8E%E5%B1%B1%E6%9C%AC%E8%80%80%E5%8F%B8%E7%9A%84%E4%B8%80%E5%88%87%E3%80%8B&amp;src=newstranscode" class="qkw">《关于山本耀司的一切》</a>。</p><p>跟圈内的朋友聊天，2008年的<a href="http://m.so.com/s?q=%E5%A4%AA%E5%BA%99&amp;src=newstranscode" class="qkw">太庙</a>首秀，大抵是山本耀司第一次出现在中国媒体以及时装爱好者面前。之所以在这个人物前面没有冠以任何称谓，实在是他作为世界时装日本<a href="http://m.so.com/s?q=%E6%B5%AA%E6%BD%AE&amp;src=newstranscode" class="qkw">浪潮</a>的设计师和新掌门人的名头太过响亮。</p><p><img src="http://p32.qhimg.com/t013d849538c9180fc4.jpg?size=500x410"></p><p>同时，在进入新世纪后，“知日”风在整个<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E6%97%B6%E5%B0%9A&amp;src=newstranscode" class="qkw">中国时尚</a>媒体界劲吹至今--与卡尔大帝、西太后、<a href="http://m.so.com/s?q=%E4%B9%94%E6%B2%BB%C2%B7%E9%98%BF%E7%8E%9B%E5%B0%BC&amp;src=newstranscode" class="qkw">乔治·阿玛尼</a>、亚历山大·麦昆等人相较，地缘空间与文化圈层的接近性，无疑让中国媒体人对日本设计师更为关注，在形而上的层面也更为体认与推崇。而这其中，与<a href="http://m.so.com/s?q=%E9%AB%98%E7%94%B0%E8%B4%A4%E4%B8%89&amp;src=newstranscode" class="qkw">高田贤三</a>、川久保玲、三宅一生等日本设计师相比，山本耀司无疑更为知名，这种知名度得缘于他的作品的高度辨识性，特别是女装，稍有些时尚常识的人几乎都能一眼辨别。</p><p>但这种崇尚带来的问题是我们的观察要么流于肤浅的崇拜，这位圈内朋友说他就见过多次还没等参访结束，中国记者就迫不及待地拿出山本的著述请求签名或合影;而问题的另一面则是不想真正去了解这个人，却将他在二十年前谈及日本状况的话“年轻人愈发轻浮、中产阶级变得无趣、所有人都用国际大品牌武装自己，并嘲笑穷人和长者”盲目地拿来比附当下中国的情形，进而在文中将其塑造成类似甘地般恬淡守静的先知与觉悟者。</p><p>想了解这位古稀之年的时尚教父，也许该读读今年一月由广西师大出版社引进的新书《关于山本耀司的一切》。作者是<a href="http://m.so.com/s?q=%E7%94%B0%E5%8F%A3%E6%B7%91%E5%AD%90&amp;src=newstranscode" class="qkw">田口淑子</a>，任职于日本文化出版局。曾从事时尚行业的采编与报道20多年，是日本德高望重的时尚意见领袖。</p><p>该书呈现了山本耀司四十年设计生涯的轨迹，精选了不同时期对山本耀司的深度访谈，其中不仅涉及其对服装和设计的激进思考也包括其对时尚和社会潮流的深刻洞见。对<a href="http://m.so.com/s?q=%E7%9A%AE%E5%A8%9C%C2%B7%E9%B2%8D%E4%BB%80&amp;src=newstranscode" class="qkw">皮娜·鲍什</a>、维姆·文德斯等挚友的采访，更从另一个维度展现出一个独特坚定且富有创造力的山本，他对音乐的热爱以及和女儿之间微妙的父女之情都让我们看到这个潇洒男人内心深处的细腻情感。文中还通过多样化的方式记录了多场震撼人心的时装发布现场，看山本耀司如何用时装向这个世界重重的挥拳。所以与其从当下的媒体上获取关于山本碎片化的形象，真不如从头到尾读一遍这本书。</p><p>安排在卷首的文章是<a href="http://m.so.com/s?q=%E3%80%8A%E5%B1%B1%E6%9C%AC%E8%80%80%E5%8F%B8%E7%9A%84%E6%97%B6%E5%B0%9A%E8%BF%9B%E5%8C%96%E8%AE%BA%E3%80%8B&amp;src=newstranscode" class="qkw">《山本耀司的时尚进化论》</a>，大抵成文于三十年前。随便翻翻，你就会被其间的满目珠玉所吸引，你会发现这位设计师的“禅”抑或说“设计哲学”其实都依傍于设计、剪裁等非常具体而微的工作细节，比如:“衣服不是由设计图来制作完成的。把衣服放在身体上试试，布料的流向和重量会自己呈现出来。”“将布料放在某个部位瞬间爆发出的气魄，还有保留褶皱和垂顺的喜悦之情，如果无法传达这些内容的话，那也不会是好的打版师。”“看领子的版式就知道它有<a href="http://m.so.com/s?q=%E5%9B%9E%E6%97%8B%E9%95%96&amp;src=newstranscode" class="qkw">回旋镖</a>的弧度，这也和日本刀的刀背很像。将翻出来的衣料弯曲起来，就会吸附在颈部。这个弯曲就是领子的关键。是否需要用力折起?</p><p>这几毫米的微妙差别就决定了领子的魅力和趣味。”“可以说轮廓的生命，就在穿上袖子那一刻。”“轮廓是气场、是意志，所以才这么一路走来。”类似这样的讲述串连在一起，无疑才擘画了山本耀司的设计执念。山本曾说“在充分掌握基本的技巧之前是没有话语权的”。了解了这些再去看大师的不满与愤怒，就会知道他<a href="http://m.so.com/s?q=%E4%BC%8A%E4%BA%8E%E8%83%A1%E5%BA%95&amp;src=newstranscode" class="qkw">伊于胡底</a>了。</p><p>对于日本年轻的时装设计师，山本直言指出他们“不过是将我和川久保玲做过的80年代的前卫方式再重新思考一番罢了。尝试将服装弄坏，涂抹甚至剥离”。而针对高级定制，山本淡淡地将其定义为“法国国策产业”，而想要反思这一“古老价值观”的年轻人，那些曾经的叛逆青年，被称为“可怕的孩子”的设计师，为什么会被改造得想要去做高级定制了呢?山本给出的答案是“现在，整个世界都是保守的，华丽的服装最好卖”。很显然，山本基本同意巴黎时尚记者对意大利风尚的判断。(来源/<a href="http://m.so.com/s?q=%E5%8C%97%E4%BA%AC%E9%9D%92%E5%B9%B4%E5%91%A8%E5%88%8A&amp;src=newstranscode" class="qkw">北京青年周刊</a>)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.timetimetime.net/zasui/66027.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='a5fbac3994632d58f137f27d559516e2'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>山本耀司</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%B1%B1%E6%9C%AC%E8%80%80%E5%8F%B8&amp;pn=1&amp;pos=5&amp;m=370c68cecf0cb0cd63ba41061450515c44fcef0c&amp;u=http%3A%2F%2Fwww.fengsung.com%2Fn-160308104400142.html" data-pos="1"> <b>山本耀司</b>Yohji Yamamoto于巴黎时装周发布2016秋冬系列 </a>   <li> <a href="/transcode?q=%E5%B1%B1%E6%9C%AC%E8%80%80%E5%8F%B8&amp;pn=1&amp;pos=6&amp;m=2d4dbcf3122e25fca5362dbdfa25014e1e853a98&amp;u=http%3A%2F%2Fcollection.sina.com.cn%2Fcqyw%2F2016-03-10%2Fdoc-ifxqhmve9018840.shtml" data-pos="2"> <b>山本耀司</b>:社会浮躁 年轻女孩一副娼妓面孔 </a>   <li> <a href="/transcode?q=%E5%B1%B1%E6%9C%AC%E8%80%80%E5%8F%B8&amp;pn=1&amp;pos=7&amp;m=9854ffec5dfe5c44cf6386f28f74119d130b5ed2&amp;u=http%3A%2F%2Ffashion.qq.com%2Fa%2F20160305%2F037153.htm" data-pos="3"> Yohji Yamamoto <b>山本耀司</b>的无声"暗黑游行" </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '从一本书开始，谈谈关于山本耀司的一切' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '从一本书开始，谈谈关于山本耀司的一切'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";