s:17832:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>独家评论:火箭毁于魔登组合的水火难容- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">独家评论:火箭毁于魔登组合的水火难容</h1> <p id="source-and-time"><span id=source>凤凰网</span><time id=time>2016-02-19 10:50:00</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E5%87%A4%E5%87%B0&amp;src=newstranscode" class="qkw">凤凰</a>体育特约评论员洪申</p><p>新闻背景:NBA2015-16赛季交易截止时间已过，<a href="http://m.so.com/s?q=%E9%9C%8D%E5%8D%8E%E5%BE%B7&amp;src=newstranscode" class="qkw">霍华德</a>留在休斯敦火箭队。在此之前，黄蜂、老鹰以及<a href="http://m.so.com/s?q=%E5%87%AF%E5%B0%94%E7%89%B9%E4%BA%BA&amp;src=newstranscode" class="qkw">凯尔特人</a>等球队都曾和火箭商讨过交易霍华德，但最终均未达成协议。这预示着火箭两大核心的矛盾将继续下去。</p><p><img src="http://p33.qhimg.com/t01572c487db048f62d.jpg?size=850x539"></p><p>优秀的中锋与得分后卫之间，好像有着天然的隔阂，无法长久。</p><p><a href="http://m.so.com/s?q=%E5%A5%A5%E5%B0%BC%E5%B0%94&amp;src=newstranscode" class="qkw">奥尼尔</a>与科比的OK组合如此，哈登与霍华德也步其后尘——NBA官网记者、前<a href="http://m.so.com/s?q=%E3%80%8A%E4%BC%91%E6%96%AF%E6%95%A6%E7%BA%AA%E4%BA%8B%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《休斯敦纪事报》</a>资深记者弗兰·比林伯利撰文，“哈登与霍华德在2013年开始合作，关系就一直不融洽，2014年季后赛首轮被(<a href="http://m.so.com/s?q=%E5%BC%80%E6%8B%93%E8%80%85&amp;src=newstranscode" class="qkw">开拓者</a>)利拉德绝杀后，双方都向管理层提出送走对方的要求”。</p><p>三年前，霍华德也许并没有想到，甩掉前任的他，并没有与现任过上只羡鸳鸯不羡仙的美好生活，而是走上<a href="http://m.so.com/s?q=%E8%BD%AE%E5%9B%9E%E5%A4%A7%E9%81%93&amp;src=newstranscode" class="qkw">轮回大道</a>。</p><p>如果他能读懂历史，也许不会惊讶。在OK时代，相似的新闻屡见不鲜，不是奥尼尔建议总裁<a href="http://m.so.com/s?q=%E6%9D%B0%E9%87%8C%C2%B7%E9%9F%A6%E6%96%AF%E7%89%B9&amp;src=newstranscode" class="qkw">杰里·韦斯特</a>送走科比，就是<a href="http://m.so.com/s?q=%E7%A7%91%E6%AF%94&amp;src=newstranscode" class="qkw">科比</a>暗示他不需要奥尼尔。往前翻，奥尼尔与“便士”<a href="http://m.so.com/s?q=%E5%93%88%E8%BE%BE%E5%A8%81&amp;src=newstranscode" class="qkw">哈达威</a>的关系也很冷漠;往后翻，奥尼尔与韦德在2006年夺冠时看似其乐融融，分手之后也多次讽刺闪电侠。</p><p>当霍华德与科比公开撕逼，毅然决然地少拿钱也要离开<a href="http://m.so.com/s?q=%E6%B4%9B%E6%9D%89%E7%9F%B6&amp;src=newstranscode" class="qkw">洛杉矶</a>，不惜成为科蜜攻击的靶子，不过是走上了另一段“拉郎配”，与哈登过上貌合神离的生活。在NBA历史上，只有火箭曾存在一对关系极佳的超级中锋+<a href="http://m.so.com/s?q=%E5%BE%97%E5%88%86%E5%90%8E%E5%8D%AB&amp;src=newstranscode" class="qkw">得分后卫</a>组合，那就是“大梦”<a href="http://m.so.com/s?q=%E5%A5%A5%E6%8B%89%E6%9C%B1%E6%97%BA&amp;src=newstranscode" class="qkw">奥拉朱旺</a>与“滑翔机”德雷克斯勒，但霍华德与哈登能有前辈们的共同点吗?</p><p>奥拉朱旺与<a href="http://m.so.com/s?q=%E5%BE%B7%E9%9B%B7%E5%85%8B%E6%96%AF%E5%8B%92&amp;src=newstranscode" class="qkw">德雷克斯勒</a>是大学校友，到了NBA之后又各自跌摸滚打超过十个赛季才携手，彼此都磨去了棱角，而且，两人性格又有些相似，都很内敛，算是NBA难得一见的天作之合。但哈登与霍华德的脑电波完全不在同一频率，魔兽大大咧咧性格外向爱开玩笑，哈登沉默不语性格内敛不玩幽默。就算两人拥有相同的泡妞爱好，也从未一块儿去夜店。</p><p>而且，就算是泡妞，双方也泡出了不同境界。霍华德私生子一大堆，眼瞅着退役后要坐吃山空;哈登靠着<a href="http://m.so.com/s?q=%E5%8D%A1%E6%88%B4%E7%8F%8A&amp;src=newstranscode" class="qkw">卡戴珊</a>拿到了阿迪达斯的亿元赞助合同，摇身一变成了阿迪在篮球界的一哥，更刺激的是，他取代的正是霍华德在阿迪的位置。</p><p>人生四大铁，这两位一项都不粘，彼此还矛盾重重，能勉强将他们拉在一起的，也就只有总冠军这个大杀器了。</p><p>偏偏魔登又都不是无私的人，哈登当初离开雷霆，既有薪金的因素，也有在2012年西部决赛因出手次数太多且过于随意遭批判的原因，而霍华德同样也舍不得出手权。可笑的是，与泡妞相同，他们在比赛时也有一个共同点，那就是一旦输球就要责怪队友，扔锅的速度比谁都快。</p><p>所以，一旦火箭走势不佳，两人之间的矛盾瞬间爆发。</p><p>其实，早在<a href="http://m.so.com/s?q=%E9%BA%A6%E5%85%8B%E6%B5%B7%E5%B0%94&amp;src=newstranscode" class="qkw">麦克海尔</a>下课之时，哈登与霍华德的不合已经浮出水面，哈登是坚定的反麦派，霍华德试图保麦，但失败了。他们的这一区别反应了总经理莫雷对他们的处理——希望交易魔兽，留下哈登。</p><p>同样，历史也证明在得分后卫与中锋的PK中，球队往往会保住得分后卫——魔术为了哈达威交易奥尼尔，<a href="http://m.so.com/s?q=%E6%B9%96%E4%BA%BA&amp;src=newstranscode" class="qkw">湖人</a>为了科比送走奥尼尔，而到了<a href="http://m.so.com/s?q=%E7%83%AD%E7%81%AB&amp;src=newstranscode" class="qkw">热火</a>，奥尼尔仍然是被交易的那个人。霍华德在2013年选择离开湖人也很清楚一点，如果他非要湖人在他与科比之间二选一，湖人仍然会选择科比而不是他。</p><p>所以我们有必要质疑霍华德的智商与情商，如果2014年，火箭真的要在哈登与霍华德之间做出一个选择，必然会选择哈登而不是陷入伤病困扰、已非当年第一中锋的霍华德。火箭与哈登能忍到2016年，算是为了球队未来做出了一点牺牲。</p><p>但这牺牲不是无限度的，无论火箭还是哈登，都需要霍华德认清现实，甘心担任老二，但如果霍华德真的甘心蛰伏，三年前选择在湖人岂不是更好?于是就有了霍华德与他的经纪人一心推动交易的消息。</p><p>要是真的有<a href="http://m.so.com/s?q=%E5%90%8E%E6%82%94%E8%8D%AF&amp;src=newstranscode" class="qkw">后悔药</a>可吃，你猜霍华德会不会买上一打?</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://sports.ifeng.com/a/20160219/47493009_0.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='f89ad507ed8ee0d6755aa2f2ec4b911b'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>水火难容</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%B0%B4%E7%81%AB%E9%9A%BE%E5%AE%B9&amp;pn=1&amp;pos=3&amp;m=5368c7e9e009b1dc9b84df1106c040752da8a178&amp;u=http%3A%2F%2Fmoney.163.com%2F14%2F1227%2F01%2FAEEE594600253B0H.html" data-pos="1"> 高端餐饮与资本市场并非"<b>水火难容</b>" </a>   <li> <a href="/transcode?q=%E6%B0%B4%E7%81%AB%E9%9A%BE%E5%AE%B9&amp;pn=1&amp;pos=4&amp;m=ad0da5f4961c3e96e5a24375e85738240a9fec2e&amp;u=http%3A%2F%2Fent.sina.com.cn%2Fv%2Fm%2F2014-06-12%2F14264157484.shtml" data-pos="2"> 《金战》张博黄觉演<b>水火难容</b>的兄弟情谊 </a>   <li> <a href="/transcode?q=%E6%B0%B4%E7%81%AB%E9%9A%BE%E5%AE%B9&amp;pn=1&amp;pos=5&amp;m=b92ae0f27fddb53b33b108edf2cd70eaf880568c&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0902%2F15%2FA5570DTR00014AEE.html" data-pos="3"> 《节俭中国人》内容曝光 小组成员<b>水火难容</b>(组图) </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '独家评论:火箭毁于魔登组合的水火难容' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '独家评论:火箭毁于魔登组合的水火难容'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";