s:16870:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>百世汇通:阿里撑腰仍压力大 上市黑马?- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">百世汇通:阿里撑腰仍压力大 上市黑马?</h1> <p id="source-and-time"><span id=source>亿邦动力</span><time id=time>2015-08-18 10:09:25</time></p> </header>  <div id="news-body"><p>百世物流正在酝酿一场弯道超车计划。最近，不少收到<a href="http://m.so.com/s?q=%E7%99%BE%E4%B8%96%E6%B1%87%E9%80%9A&amp;src=newstranscode" class="qkw">百世汇通</a>快递的消费者，都发现包裹上多了一个“优乐洗”的广告，并注明推广范围是全国。对此，百世汇通方面确认，优乐洗是百世推出的自营洗衣业务。不同于“通达系”等传统快递企业，互联网基因十足的百世物流正在阿里的支持下，走一条“资本唱戏”的上市之路。</p><p class="header">谋多元发展</p><p>一则优乐洗的广告开始随着百世汇通的包裹走向全国。根据百世<a href="http://m.so.com/s?q=%E6%B1%87%E9%80%9A&amp;src=newstranscode" class="qkw">汇通</a>市场部负责人介绍，优乐洗是百世旗下的O2O上门洗衣品牌，目前已在上海地区上线，正在向全国范围推广。北京商报记者查询发现，优乐洗注册信息为浙江百世物流科技有限公司，于今年4月1日上线，目前服务范围是上海<a href="http://m.so.com/s?q=%E9%99%A4%E9%87%91%E5%B1%B1&amp;src=newstranscode" class="qkw">除金山</a>、崇明外所有区域。与e袋洗、多洗等新兴上门洗衣O2O服务类似，优乐洗通过信息公众号和手机App提供服务。App显示，忧乐洗提供短薄、长厚、羊绒三项服务，价格分别为8元、18元、28元。</p><p>百世物流近来在多元化方面可谓动作频频。据北京商报记者了解，百世汇通日前推出了“<a href="http://m.so.com/s?q=%E7%99%BE%E4%B8%96%E9%82%BB%E9%87%8C&amp;src=newstranscode" class="qkw">百世邻里</a>”业务，该业务通过与便利店、花店等社区小店合作，提供包裹代保管服务，不过这些企业需要使用百世授权的“百世邻里”品牌。目前，百世邻里已覆盖全国31个省/直辖市，共3万余家。</p><p>此外，7月29日，百世旗下专注物流领域的P2P平台--百微网上线。该借贷平台将为百世快运、快递网点提供贷款服务。</p><p>百世官网信息显示，百世已推出了包括快递业务(百世汇通)、快运业务(百世快运)、社区服务(优乐洗)、金融业务(百微网)、国际业务(360hitao海淘)、仓配物流业务(百世供应链)、软件服务(百世云)等业务，而有信息透露，百世正在筹备一项名为“百世店加”的神秘业务。</p><p class="header">互联网化物流</p><p>自2010年11月，杭州百世网络技术有限公司收购“汇通快运”，并更名“百世汇通”后，快递业便播下了一颗 “互联网化”的种子。分析认为，百世多元化道路与互联网化的经营理念密不可分。</p><p><a href="http://m.so.com/s?q=%E7%99%BE%E4%BA%8B&amp;src=newstranscode" class="qkw">百事</a>物流董事长周韶宁曾在UT斯达康担任九年总裁，并于2005年加入Google，负责中国销售和渠道业务。2007年，<a href="http://m.so.com/s?q=%E5%91%A8%E9%9F%B6%E5%AE%81&amp;src=newstranscode" class="qkw">周韶宁</a>创办物流外包公司--百世物流科技。在2009年前，百世物流首批获得了阿里巴巴和富士康1500万美元融资，从此与<a href="http://m.so.com/s?q=%E9%98%BF%E9%87%8C&amp;src=newstranscode" class="qkw">阿里</a>同行。</p><p>与<a href="http://m.so.com/s?q=%E9%A1%BA%E4%B8%B0&amp;src=newstranscode" class="qkw">顺丰</a>、“三通一达”不同，百世想要打造的是一家互联网化物流企业。周韶宁曾多次公开表示，百世正尝试以信息技术和物流模式创新的方式，再造一个类苹果平台的<a href="http://m.so.com/s?q=%E7%89%A9%E6%B5%81%E7%A4%BE%E5%8C%BA&amp;src=newstranscode" class="qkw">物流社区</a>，继而颠覆传统的物流服务模式，并立誓要做“中国的UPS”。</p><p>据知情人士透露，百世每年在网络方面的投入为5亿-8亿元，不过企业一直处于微利或亏损状态。该人士表示，百世一直与风投接触密切。</p><p class="header">上市黑马?</p><p>今年开始，民营快递上市消息不断传出。其中，中通上市计划获得官方证实，<a href="http://m.so.com/s?q=%E5%BE%B7%E9%82%A6%E7%89%A9%E6%B5%81&amp;src=newstranscode" class="qkw">德邦物流</a>也借“牛市”之风提交IPO申请。不过，在快递专家<a href="http://m.so.com/s?q=%E8%B5%B5%E5%B0%8F%E6%95%8F&amp;src=newstranscode" class="qkw">赵小敏</a>看来，百世或是那匹快递业上市黑马。</p><p>赵小敏表示，百世早已启动上市模式，股份制改造已经完成。“百世极有可能在三年内完成上市，上市后借资本力量冲入快递业第一梯队。”赵小敏认为，百世欲打造成一个平台化物流企业，核心优势在IT技术方面。“这些方面更为资本市场所青睐，资本市场也成为百世上市的有力推手。”</p><p>不过，百世互联网化的运作模式仍待市场检验。此前，顺丰作为民营快递龙头老大，先后试水<a href="http://m.so.com/s?q=%E9%A1%BA%E4%B8%B0%E4%BC%98%E9%80%89&amp;src=newstranscode" class="qkw">顺丰优选</a>、嘿客、海淘等多项业务，不过目前仍处于探索阶段。在赵小敏看来，虽然有阿里等免费“广告”为百世上市铺路，但百世也同样压力不小。“最终话语权能否掌握在自己手中也是个未知数。”</p><p><img src="http://p31.qhimg.com/t011d91ef98365550b9.jpg?size=500x200"></p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.ebrun.com/20150818/145218.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='5d04499954f32243bd00b64037aea0d0'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>百世汇通</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%99%BE%E4%B8%96%E6%B1%87%E9%80%9A&amp;pn=1&amp;pos=9&amp;m=3960896a5785840e9ba5995d5f1378b857dc0942&amp;u=http%3A%2F%2Fcq.cqwb.com.cn%2F2016-02%2F23%2Fcontent_428650.htm" data-pos="1"> <b>百世汇通</b>渝中一部暴力卸货 </a>   <li> <a href="/transcode?q=%E7%99%BE%E4%B8%96%E6%B1%87%E9%80%9A&amp;pn=1&amp;pos=10&amp;m=25eb306fca84b5f5b915dd7d2c6d561631b60bd8&amp;u=http%3A%2F%2Ffinance.sina.com.cn%2Fstock%2Fusstock%2Fmtszx%2F20140814%2F092920008899.shtml" data-pos="2"> <b>百世汇通</b>快递小哥黄伟婉拒2.5万元捐助转赠云南鲁甸 </a>   <li> <a href="/transcode?q=%E7%99%BE%E4%B8%96%E6%B1%87%E9%80%9A&amp;pn=2&amp;pos=1&amp;m=5913fed1c970307fd10dcafe0a573c0b5d3311c6&amp;u=http%3A%2F%2Ffinance.sina.com.cn%2Fconsume%2Fpuguangtai%2F20140703%2F104219596715.shtml" data-pos="3"> <b>百世汇通</b>弄丢客户快件 拖了20多天还没赔 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '百世汇通:阿里撑腰仍压力大 上市黑马?' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '百世汇通:阿里撑腰仍压力大 上市黑马?'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";