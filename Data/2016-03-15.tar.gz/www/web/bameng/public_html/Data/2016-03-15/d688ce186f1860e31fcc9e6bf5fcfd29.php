s:16109:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>104年,她一直住在同一间屋子里,守护着回忆- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">104年,她一直住在同一间屋子里,守护着回忆</h1> <p id="source-and-time"><span id=source>网易</span><time id=time>2016-03-11 15:10:00</time></p> </header>  <div id="news-body"><p>在英国一个叫Hambledon的小村庄里，住着一个叫Ena的老奶奶</p><p>老奶奶今年104岁，她也在这里住了104年。</p><p>她的一生都住在同一个房子里，即使被<a href="http://m.so.com/s?q=%E6%B4%AA%E6%B0%B4%E5%8C%85%E5%9B%B4&amp;src=newstranscode" class="qkw">洪水包围</a>，她也不曾动过离开的念头</p><p><img src="http://p31.qhimg.com/t0113d41568d814031f.jpg?size=550x442"></p><p>老奶奶出生于1912年，那个时候<a href="http://m.so.com/s?q=%E6%B3%B0%E5%9D%A6%E5%B0%BC%E5%85%8B%E5%8F%B7&amp;src=newstranscode" class="qkw">泰坦尼克号</a>还未起航，一战也还没打响</p><p><img src="http://p33.qhimg.com/t01504017b9392236c1.jpg?size=470x802"></p><p>她的家族自1850年开始就住在这里，所以她从出生起就生活在这栋房子里</p><p><img src="http://p35.qhimg.com/t0178b2a5be4ea983d5.jpg?size=550x364"></p><p>她8岁那年，她老爹把房子旁边的棚屋改造成了一个店铺</p><p><img src="http://p32.qhimg.com/t012cca998c79af1bb7.jpg?size=550x424"></p><p class="img-title">这家店一直到今天还开着</p><p><img src="http://p32.qhimg.com/t01adf02886e9e48ab8.jpg?size=550x411"></p><p>她就在这里一天天长大，不幸的是她的两个哥哥都在幼年的时候就去世了，她成了家里唯一一个孩子</p><p><img src="http://p33.qhimg.com/t012a6848d8021c23bf.jpg?size=550x713"></p><p>她还记得一战的时候，士兵们离开村子前往战场，也记得<a href="http://m.so.com/s?q=%E8%AF%BA%E6%9B%BC%E5%BA%95%E7%99%BB%E9%99%86&amp;src=newstranscode" class="qkw">诺曼底登陆</a>的时候，英国和<a href="http://m.so.com/s?q=%E5%8A%A0%E6%8B%BF%E5%A4%A7&amp;src=newstranscode" class="qkw">加拿大</a>军队在附近扎营</p><p>她这<a href="http://m.so.com/s?q=%E4%B8%80%E7%94%9F%E5%94%AF%E4%B8%80&amp;src=newstranscode" class="qkw">一生唯一</a>短暂离开过家的时候，是在二战去帮忙制作防毒面具</p><p><img src="http://p32.qhimg.com/t01f2dc0709a460d186.jpg?size=550x717"></p><p>27岁那年，她和第一任丈夫迈入婚姻殿堂，生下两个女儿</p><p>她生下女儿的房间，也正是她和她父亲出生的同一间屋子，同一个房间</p><p><img src="http://p33.qhimg.com/t0162d57550b3c5b1e3.jpg?size=550x383"></p><p>然而他们的婚姻没能走远，Ena后来又有了第二次婚姻</p><p>她和第二任丈夫一起生活了34年，直到1982丈夫离开了人世</p><p><img src="http://p34.qhimg.com/t01cdb5b15d811f0a29.jpg?size=550x399"></p><p>那之后，老奶奶仍然住在那栋房子里，即使两年前发洪水房子面临被淹的时候，她也拒绝离开</p><p class="header">“我出生在这里，我永远不会离开”</p><p>“我在这里拥有很多<a href="http://m.so.com/s?q=%E5%BF%AB%E4%B9%90%E7%9A%84%E5%9B%9E%E5%BF%86&amp;src=newstranscode" class="qkw">快乐的回忆</a>，我几乎认识村里的每一个人”</p><p>“人们之所以会离开，是因为他们不喜欢一个地方，而我喜欢这里”</p><p><img src="http://p33.qhimg.com/t0142c185c3f7a09e4c.jpg?size=550x409"></p><p>就这样，她在这里住了104年，一直到上周四，她在这里安详的离世</p><p><img src="http://p33.qhimg.com/t01448dc1fb070c9cd7.jpg?size=550x356"></p><p class="img-title">从出生在离去，她一直在同一个地方</p><p><img src="http://p34.qhimg.com/t01bbc1f639ca0e57fe.jpg?size=550x804"></p><p class="img-title">见证了时光，守护着回忆</p><p><img src="http://p35.qhimg.com/t010b8eb6945f42eed7.jpg?size=550x847"></p><p>-----------------------</p><p>诚然俊逸:原来除了女王，英国还有很多超长待机的老奶奶，这份坚持挺暖的</p><p class="header">shoei书易:房屋建筑质量很好啊</p><p>花草日志:之前拜访一对英国老夫妇，他们住的房子看起来像新盖的一样。问过才知道房子已经七十多年了，像新的是因为英国政府会定期组织维护。</p><p><a href="http://m.so.com/s?q=%E8%88%92%E5%85%8B&amp;src=newstranscode" class="qkw">舒克</a>舒克舒克0:只有我一个人觉得老奶奶小时候可爱到爆么</p><p>--------------------</p><p>版权声明:本文系“<a href="http://m.so.com/s?q=%E8%8B%B1%E5%9B%BD%E9%82%A3%E4%BA%9B%E4%BA%8B%E5%84%BF&amp;src=newstranscode" class="qkw">英国那些事儿</a>”(公众号:hereinuk)授权哒哒发表，如需转载请联系“英国那些事儿”获取授权，严禁私自进行二次转载，违者必究。</p><p>本文来源:英国那些事儿 。哒哒-<a href="http://m.so.com/s?q=%E8%87%AA%E5%AA%92%E4%BD%93&amp;src=newstranscode" class="qkw">自媒体</a>  责任编辑:宋欣蔚_NX2107</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.163.com/16/0311/15/BHSSHP8A000155K8.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='bce587b3670fbf150dfa0e66582d2a7a'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>因为守护</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%9B%A0%E4%B8%BA%E5%AE%88%E6%8A%A4&amp;pn=1&amp;pos=8&amp;m=2f440e7ab4cfdf171fff8326ea30cdd8ec6b1df1&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fedu%2Finfo%2F4739091_1.html" data-pos="1"> 校园安全应该由谁来<b>守护</b>?谁为学生安全撑起保护伞? </a>   <li> <a href="/transcode?q=%E5%9B%A0%E4%B8%BA%E5%AE%88%E6%8A%A4&amp;pn=1&amp;pos=9&amp;m=6e5aba6906a0936b3881e4809c2276737ecd915e&amp;u=http%3A%2F%2Fnews.youth.cn%2Fjk%2F201603%2Ft20160314_7741826.htm" data-pos="2"> 几元一斤的韭菜轻松<b>守护</b>全家健康 不吃亏大了 </a>   <li> <a href="/transcode?q=%E5%9B%A0%E4%B8%BA%E5%AE%88%E6%8A%A4&amp;pn=1&amp;pos=10&amp;m=133e1dae798785b4e326a7ca0d27716d02742ddd&amp;u=http%3A%2F%2Fwww.taiwan.cn%2Fxwzx%2Fla%2F201603%2Ft20160314_11408292.htm" data-pos="3"> 孙中山逝世九十一周年 岛内蓝营誓言<b>守护</b>孙中山精神 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '104年,她一直住在同一间屋子里,守护着回忆' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '104年,她一直住在同一间屋子里,守护着回忆'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";