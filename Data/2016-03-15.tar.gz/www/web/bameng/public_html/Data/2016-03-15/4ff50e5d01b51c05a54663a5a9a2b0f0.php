s:15966:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>遭遇婚外情想自杀 跨省联动成功解救- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">遭遇婚外情想自杀 跨省联动成功解救</h1> <p id="source-and-time"><span id=source>中国经济网</span><time id=time>2015-05-07 09:36:00</time></p> </header>  <div id="news-body"><p>17172个电话送来<a href="http://m.so.com/s?q=%E6%96%B0%E5%B8%8C%E6%9C%9B&amp;src=newstranscode" class="qkw">新希望</a></p><p class="header">遭遇婚外情想自杀</p><p class="header">跨省联动成功解救</p><p class="header">长春晚报记者 于慧</p><p>遇到烦心事儿担心自己的秘密被身边人知道，宁愿憋在心里不说一句话，时间长了，小疙瘩变成大问题，不仅让自己更加烦躁，心理也变得迷惘。5年前，长春市心理医院为帮助市民解决心理问题，开通了<a href="http://m.so.com/s?q=%E9%95%BF%E6%98%A5%E5%B8%82&amp;src=newstranscode" class="qkw">长春市</a>心理危机干预热线。如今，这条热线已接听电话17172个，为上万个家庭送去帮助，帮助他们打开“心结”。6日，记者倾听发生在这条热线两端的一个个故事。</p><p class="header">近90分钟通话给绝望者送去新生</p><p>“我们这个热线虽然靠电话连接，可它却能在关键时刻发挥大作用。”当日上午，记者走进长春市心理医院<a href="http://m.so.com/s?q=%E5%BF%83%E7%90%86%E5%8D%B1%E6%9C%BA%E5%B9%B2%E9%A2%84&amp;src=newstranscode" class="qkw">心理危机干预</a>中心热线办公室，看着收获的一面面锦旗，该中心主任<a href="http://m.so.com/s?q=%E9%83%91%E6%99%93%E5%8D%8E&amp;src=newstranscode" class="qkw">郑晓华</a>高兴地说。5年接听热线，无数个案例令人难忘。</p><p>记得一年前的一天，2时许，来自南方某城市的女子丁某把电话拨进长春市心理危机干预热线。丁某刚<a href="http://m.so.com/s?q=%E6%80%80%E5%AD%95&amp;src=newstranscode" class="qkw">怀孕</a>不久，在电话中，她一直哭诉自己心烦、不想活了，并说她的丈夫有婚外情，被她当场发现。丁某觉得不公平，在电话那端哭诉个不停。</p><p>说着说着，丁某想打开煤气自杀，了结自己和胎儿的生命。当她去厨房开煤气时，却发现煤气停了，她又来到阳台想轻生。在电话中，丁某说自己曾多次与丈夫沟通，但没用。当时，接听热线电话的心理咨询专家<a href="http://m.so.com/s?q=%E4%BB%98%E4%B8%BD%E8%90%8D&amp;src=newstranscode" class="qkw">付丽萍</a>感到事态紧急，一边倾听一边耐心劝说，希望她珍惜生命和自己肚子里的孩子。就在近90分钟的通话过程中，该中心的另一组人员马上行动，按照来电显示的电话号码查询电话归属地，然后拨打当地派出所的电话，警方迅速介入，成功将丁某解救。</p><p>70岁以上老人心理问题比年轻人高30%</p><p>王女士68岁，今年春节前，她和老伴要去南方的女儿家过年，因为不放心，就把自家房门钥匙交给邻居，让邻居帮忙照看房子。可老人始终无法安心地在女儿家待着，总觉得自己家里丢了东西。等到春节过后回到家，第一件事就是把家中的柜子、抽屉全部翻遍，查看是否失窃。如今，老人即便白天出门，仍旧提心吊胆，她的家人将电话打到长春市心理医院心理危机干预中心。针对老人的情况，长春市心理危机干预中心主任郑晓华说:“老人有被窃<a href="http://m.so.com/s?q=%E5%A6%84%E6%83%B3%E7%97%87&amp;src=newstranscode" class="qkw">妄想症</a>，总担心自己丢东西，这是因为老人归属感缺失。”采访中，记者了解到，除了像这位老人的表现外，有的老人喜欢攒东西，把没用的东西收集到家里。对此，郑晓华说:“出现这种情况，家属就应该注意了，因为人老了，<a href="http://m.so.com/s?q=%E4%B8%AD%E6%9E%A2%E7%A5%9E%E7%BB%8F%E7%B3%BB%E7%BB%9F&amp;src=newstranscode" class="qkw">中枢神经系统</a>不平衡，靠心理疏导很难起作用，可以服用一些精神类的药物缓解。”</p><p>“有的人可能质疑‘我没病，为什么用精神类药物?’”郑晓华说，“这是人们缺乏常识，其实，70岁以上老人出现心理问题的比率比年轻人高30%，老人对健康的需求不仅是身体方面，还有心理、精神方面。老年人随着年龄增长认知功能变差，记忆力随之下降，可能表现为偏执，老人自己无法调整，需要家人关心并求助医生。”</p><p>记者从长春市心理医院了解到，从2010年5月7日心理危机干预热线开通至今已有5年时间，接听了17172个求助电话，用电波帮助上万市民从心理危机中解脱出来。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://baby.ce.cn/qt/201505/07/t20150507_2494334.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='3735d6f6814181d4e30a21001478db12'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>遭遇婚外情</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%81%AD%E9%81%87%E5%A9%9A%E5%A4%96%E6%83%85&amp;pn=1&amp;pos=6&amp;m=4d89e611f90329466eca377485392ca47fd5ec3b&amp;u=http%3A%2F%2Fwww.sq1996.com%2Fnews%2Fminsheng%2F2014%2F1029%2F128517.shtml" data-pos="1"> 宿迁男子因一条诈骗短信<b>遭遇</b>一场"<b>外遇</b>"风波 </a>   <li> <a href="/transcode?q=%E9%81%AD%E9%81%87%E5%A9%9A%E5%A4%96%E6%83%85&amp;pn=1&amp;pos=7&amp;m=d3c6a2f253462dd4ac0d58f20250c4b54d1a0ddb&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fjsnews%2Fgnxw%2F4515791_1.html" data-pos="2"> 妻子不堪丈夫<b>外遇</b>家暴将其毒杀 反家暴法实施后怎样维权 </a>   <li> <a href="/transcode?q=%E9%81%AD%E9%81%87%E5%A9%9A%E5%A4%96%E6%83%85&amp;pn=1&amp;pos=8&amp;m=7894f53fd35c3337732230b771f65c3fc1ea4aa4&amp;u=http%3A%2F%2Fhealth.china.com%2Fxinli%2Fjiatingxinli%2F201603%2F10-324957.html" data-pos="3"> 伴侣有<b>外遇</b>该如何处理 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '遭遇婚外情想自杀 跨省联动成功解救' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '遭遇婚外情想自杀 跨省联动成功解救'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";