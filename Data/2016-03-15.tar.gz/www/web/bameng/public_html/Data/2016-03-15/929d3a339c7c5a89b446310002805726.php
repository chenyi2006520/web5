s:17786:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>总决赛对位大比拼:郭少遇狠角色 韩德君迎挑战- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">总决赛对位大比拼:郭少遇狠角色 韩德君迎挑战</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-03-11 09:33:34</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E5%8C%97%E4%BA%AC%E6%97%B6%E9%97%B4&amp;src=newstranscode" class="qkw">北京时间</a>3月10日，CBA总决赛第一场将于11日开战，四川队与 辽宁队 也是各自紧张备战之中，接下来就让我们来关注一下两支球队五位先发和替补球员的PK情况。</p><p>【控球后卫:<a href="http://m.so.com/s?q=%E9%83%AD%E8%89%BE%E4%BC%A6&amp;src=newstranscode" class="qkw">郭艾伦</a> VS 邓特蒙】</p><p>郭艾伦是目前中国乃至亚洲最好的控球后卫，今年 季后赛 ，“大侄子”先后3场砍下20分，可见他的状态非常好。不过，郭艾伦的出色表现也有客观因素，这就是他的对手实在太弱。首轮浙江队，队中没有能与郭艾伦对抗的球员，而半决赛广东队的<a href="http://m.so.com/s?q=%E6%8B%9C%E7%BA%B3%E5%A7%86&amp;src=newstranscode" class="qkw">拜纳姆</a>又因伤缺阵，尽管<a href="http://m.so.com/s?q=%E5%8D%A1%E7%89%B9&amp;src=newstranscode" class="qkw">卡特</a>临时顶替，但是卡特显然是人生地不熟。</p><p>如今总决赛面对四川队的<a href="http://m.so.com/s?q=%E9%82%93%E7%89%B9&amp;src=newstranscode" class="qkw">邓特</a>蒙，这可是一位狠角色，他本赛季场均砍下25.1分，攻击力相当火爆，而且 季后赛 6场比赛他4场砍下30+。除了得分能力犀利之外，邓特蒙场均还有4.2次助攻。由此可见，郭艾伦不但要设法降低邓特蒙的攻击力，同时还要避免他频繁助攻队友。</p><p>【<a href="http://m.so.com/s?q=%E5%BE%97%E5%88%86%E5%90%8E%E5%8D%AB&amp;src=newstranscode" class="qkw">得分后卫</a>:哈德森 VS <a href="http://m.so.com/s?q=%E5%AD%9F%E8%BE%BE&amp;src=newstranscode" class="qkw">孟达</a>】</p><p>哈德森绝对是 辽宁队 的第一得分点，同时也是 辽宁队 的核心球员，他的手感直接决定着 辽宁队 的总冠军归属。本赛季，<a href="http://m.so.com/s?q=%E5%93%88%E5%BE%B7%E6%A3%AE&amp;src=newstranscode" class="qkw">哈德森</a>场均贡献28.6分，7场 季后赛 他4场得分30+，尽管攻击力相比上赛季有所下降，但是哈德森明显打得更加团队。当然，哈德森也有隐患，这就是他的左脚踝伤势。与广东队的系列赛中，哈德森扭伤了左脚踝，如果总决赛再次老伤复发，这一定会成为 辽宁队 夺冠的七寸。</p><p>与哈德森相比，孟达场均13.3分的攻击力明显处于下风，不过孟达不用背负过多的压力，他只需要在防守贡献自己的力量，同时在进攻端将到手的机会把握住就足够了，至于其他的，全部交给“<a href="http://m.so.com/s?q=%E9%82%93%E5%93%88%E5%93%88&amp;src=newstranscode" class="qkw">邓哈哈</a>”组合就够了。</p><p>【中锋: <a href="http://m.so.com/s?q=%E9%9F%A9%E5%BE%B7%E5%90%9B&amp;src=newstranscode" class="qkw">韩德君</a> VS 哈达迪】</p><p>韩德君 与<a href="http://m.so.com/s?q=%E5%93%88%E8%BE%BE%E8%BF%AA&amp;src=newstranscode" class="qkw">哈达迪</a>就像是金庸笔下的“胖瘦头陀”，两人一胖一瘦，体重与身高分别是两人的绝对优势，而且两人都具备非常出色的策应能力，因此仅从数据方面很难判断出两人谁更胜一筹。</p><p>由于 韩德君 擅长力量，而哈达迪优势在于身高，因此两人谁能克制住对方的强项，发挥自己的优势，这也成为本次总决赛的胜负关键。</p><p>【小前锋:<a href="http://m.so.com/s?q=%E8%B4%BA%E5%A4%A9%E4%B8%BE&amp;src=newstranscode" class="qkw">贺天举</a> VS 张春军】</p><p>贺天举被认为 辽宁队 夺冠的奇兵型球员，他的状态决定了 辽宁队 的夺冠之路是否一帆风顺。本赛季，贺天举场均贡献12.5分， 季后赛 既有单场26分的出色发挥，也有7投0中，全场0分的尴尬。毕竟贺天举的三分球压力，可以为郭艾伦突破内线和 韩德君 内线单打拉扯开足够的空间，如果他手感冰凉，那么四川队肯定会全力包夹其他 辽宁队 球员。</p><p>与贺天举相比，<a href="http://m.so.com/s?q=%E5%BC%A0%E6%98%A5%E5%86%9B&amp;src=newstranscode" class="qkw">张春军</a>绝对是一位蓝领球员。本赛季，他场均只有6.5分入账， 季后赛 6场比赛只有1次得分突破10分大关，由此可见，张春军就是“邓哈哈”组合的陪衬，除了在进攻端发挥如热之外，他的主要任务就是防守。</p><p>【大前锋:<a href="http://m.so.com/s?q=%E6%9D%8E%E6%99%93%E6%97%AD&amp;src=newstranscode" class="qkw">李晓旭</a> VS 贾诚】</p><p>相比之前两个赛季，李晓旭的投篮能力明显有所提升，本赛季他场均贡献11.1分，这是生涯第二高得分。同时，李晓旭还有8.6个篮板，尽管这位内线蓝领不是 辽宁队 摧城拔寨的首选，但是他在攻守两端的平衡表现可以让 辽宁队 更加放心。</p><p>进入 季后赛 ，四川队突然调整了阵容，将此前很少首发的<a href="http://m.so.com/s?q=%E8%B4%BE%E8%AF%9A&amp;src=newstranscode" class="qkw">贾诚</a>放进首发名单，取代了外援<a href="http://m.so.com/s?q=%E6%B5%B7%E5%B0%94%E6%96%AF&amp;src=newstranscode" class="qkw">海尔斯</a>的位置。当然，四川队的这种变阵无疑是为了平衡“邓哈哈”组合的上场时间，毕竟 季后赛 需要足够的<a href="http://m.so.com/s?q=%E4%BD%93%E8%83%BD%E5%82%A8%E5%A4%87&amp;src=newstranscode" class="qkw">体能储备</a>。贾诚的场均得分相比上赛季下降了4分，再加上邓哈哈在进攻端大包大揽，因此90后的贾诚也很难有露脸的机会。</p><p>【替补:<a href="http://m.so.com/s?q=%E5%85%B0%E5%A4%9A%E5%A4%AB&amp;src=newstranscode" class="qkw">兰多夫</a> VS 海尔斯】</p><p>如果仅从得分来看，场均贡献31分的海尔斯显然强于场均只有22.6分的兰多夫，而且在篮板对比上，海尔斯的11.5个篮板也压制住了兰多夫的10.7个。</p><p>可是从上场时间来看，明显是兰多夫的效率更高。兰多夫场均只有29分钟的上场时间，但是他却贡献了22+10的数据，而海尔斯上场近38分钟，贡献31分11篮板。另外，兰多夫具备背身单打能力，如果兰多夫能联手 韩德君 联手消耗哈达迪，这势必会成为四川队最头痛的问题。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/sport/tyxw/4674545_1.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='2b95b5c0d3f58232a38735a0ef4c4d83'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>韩德君</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%9F%A9%E5%BE%B7%E5%90%9B&amp;pn=1&amp;pos=4&amp;m=e42529f822e9ad365746440102d0e21676ed80e2&amp;u=http%3A%2F%2Fsports.163.com%2F16%2F0314%2F09%2FBI41EN1000052UUC.html" data-pos="1"> 辽媒:仅<b>韩德君</b>能抗衡哈达迪 郭少怒吼未叫醒队友 </a>   <li> <a href="/transcode?q=%E9%9F%A9%E5%BE%B7%E5%90%9B&amp;pn=1&amp;pos=5&amp;m=b899acb3bdfbfce22b2dfb30f7e3814f2bebb228&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fsport%2Ftyxw%2F4619419_1.html" data-pos="2"> 郭艾伦与<b>韩德君</b>网吧打CS 网友:减压好方法(图) </a>   <li> <a href="/transcode?q=%E9%9F%A9%E5%BE%B7%E5%90%9B&amp;pn=1&amp;pos=6&amp;m=c88e1430ddb93f2ba0e0987843592c5009f4125b&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4057623.html" data-pos="3"> 哈达迪一人完爆辽宁内线,连虐周琦<b>韩德君</b>,亚洲第一中锋级表现体育(图) </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '总决赛对位大比拼:郭少遇狠角色 韩德君迎挑战' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '总决赛对位大比拼:郭少遇狠角色 韩德君迎挑战'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";