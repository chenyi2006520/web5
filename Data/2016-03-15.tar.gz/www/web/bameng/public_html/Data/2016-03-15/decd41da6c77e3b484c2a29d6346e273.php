s:18281:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>《中韩时尚王》上演妇仇者联盟 张亮重返T台 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">《中韩时尚王》上演妇仇者联盟 张亮重返T台 </h1> <p id="source-and-time"><span id=source>新华网</span><time id=time>2015-06-05 12:04:30</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t01af38250e45981de4.jpg?size=667x1000"></p><p>&nbsp;由<a href="http://m.so.com/s?q=%E4%BC%98%E9%85%B7%E5%9C%9F%E8%B1%86%E9%9B%86%E5%9B%A2&amp;src=newstranscode" class="qkw">优酷土豆集团</a>跨国联合韩国SBS Plus共同制作、“明星衣橱”首席冠名的首档时尚<a href="http://m.so.com/s?q=%E7%9C%9F%E4%BA%BA%E7%A7%80%E8%8A%82%E7%9B%AE&amp;src=newstranscode" class="qkw">真人秀节目</a>《中韩时尚王: 箱子的秘密》(以下简称<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E9%9F%A9%E6%97%B6%E5%B0%9A%E7%8E%8B%E3%80%8B&amp;src=newstranscode" class="qkw">《中韩时尚王》</a>)第七期比赛在即，随着赛程接近尾声，赢得团体赛的积分对于每组明星设计师都显得极为重要，上周的“沙滩风”可谓是男士的福利，而本期的主题“绅士风”则称得上是“妇女之友”了。本周也是中韩团体赛的第三场，韩国队誓要在团队赛中“雪耻”，而<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E9%98%9F&amp;src=newstranscode" class="qkw">中国队</a>则全面吹响“复仇”的号角，不仅有女神<a href="http://m.so.com/s?q=%E6%9F%B3%E5%B2%A9&amp;src=newstranscode" class="qkw">柳岩</a>上演“妇仇者联盟”，一雪第一期的“扳手腕之耻”，还有韩国队长<a href="http://m.so.com/s?q=%E9%87%91%E9%92%9F%E5%9B%BD&amp;src=newstranscode" class="qkw">金钟国</a>为中国队站台走秀，中国队长<a href="http://m.so.com/s?q=%E5%BC%A0%E4%BA%AE&amp;src=newstranscode" class="qkw">张亮</a>更是亲自上阵再现超模T台秀难掩光芒，韩国女粉丝们会不会拜倒在中国欧巴的大长腿之下呢?更多精彩，尽在本周《中韩时尚王》。</p><p>&nbsp;“恶战”升级:从“推手掌”到“<a href="http://m.so.com/s?q=%E6%AF%94%E5%A4%A7%E8%85%BF&amp;src=newstranscode" class="qkw">比大腿</a>”</p><p>&nbsp;还记得《中韩时尚王》第一期节目中柳岩与<a href="http://m.so.com/s?q=%E5%88%98%E4%BB%81%E5%A8%9C&amp;src=newstranscode" class="qkw">刘仁娜</a>的扳手腕比赛，柳岩不幸落败。而在本期节目中，柳岩与刘仁娜再次进行游戏比拼“推手掌”，为求公平，两人不顾形象脱鞋进行比赛，在一番激烈的撕扯后，迸发出“女汉子”气质的柳岩把刘仁娜一把推倒在地，可谓是一雪前耻，报了第一期扳手腕之仇。柳岩的气势震惊四座，也极大地鼓舞了中国队的士气。在随后的正式比赛中，柳岩也是表现非常积极，除了邀请主持人<a href="http://m.so.com/s?q=Linda&amp;src=newstranscode" class="qkw">Linda</a>穿上自己与王玉涛设计的西装展现西装的两面性以及绅士风度，更是说服理了韩国队队长金钟国亲自穿上自己设计的服装，结果西装的上身效果效果出奇的好，引起现场观众一阵欢呼。穿完衣服后，金钟国才回过<a href="http://m.so.com/s?q=%E7%A5%9E%E7%AC%91&amp;src=newstranscode" class="qkw">神笑</a>称自己怎么在为中国队拉票。柳岩如此卖力的拉票，究竟能否获得中韩评委的认可?</p><p>&nbsp;女神都那么拼，男神更是不甘示弱。上周的比赛<a href="http://m.so.com/s?q=%E5%90%B4%E5%85%8B%E7%BE%A4&amp;src=newstranscode" class="qkw">吴克群</a>、兰玉一分之差输给了<a href="http://m.so.com/s?q=%E6%9D%8E%E6%AD%A3%E4%BF%A1&amp;src=newstranscode" class="qkw">李正信</a>，本周挟带着“复仇”心思的吴克群，刚发了新专辑的他一上来就放大招---在节目伊始就给每位嘉宾现场送上了自己的签名专辑，赚尽现场嘉宾和女主持的印象分。见对手“放花边”，作为CNBLUE成员的李正信毫不示弱，赶紧也为现场的每位嘉宾送上了自己的签名专辑。两人这番暗掐还不过瘾，还要拿着对方的专辑玩比赛大腿力量的游戏，没想到吴克群实力超强，李正信狼狈地输掉了游戏，还直呼大腿内侧撕裂疼!从“扳手腕”到“比大腿”，本期《中韩时尚王》的“楼”歪得很彻底!尽管“比大腿”游戏吴克群完胜，但在之后的主秀对决中，李正信亮出了自己的秘密武器--邀请到了前阵子因<a href="http://m.so.com/s?q=%E3%80%8A%E6%88%91%E4%BB%AC%E7%BB%93%E5%A9%9A%E5%90%A7%E3%80%8B&amp;src=newstranscode" class="qkw">《我们结婚吧》</a>大热的男艺人洪宗玄作为模特出场。究竟吴克群能否延续游戏中的胜利，最终“复仇”成功，为中国队夺得一分呢?</p><p>&nbsp;瑜亮之争:“王牌特工”PK“雨衣西装”</p><p>&nbsp;吴克群和李正信引发的这场“比大腿”大战延续到了两位队长身上，金钟国与张亮在正式比赛前也进行了大腿力量比拼，结果并没有什么悬念，一条大腿有张亮两个粗的金钟国，就算张亮憋红了耳朵也没能撼动一分。虽然力气方面是金钟国的强项，但在时尚方面张亮的优势就完全体现了。正式比赛中，金钟国以超炫的夜光秀开场，模特身穿斗篷西装让人顿时有了中世纪欧洲的即视感，帅气与古典的结合，这不是前段时间热映的英伦范儿十足的<a href="http://m.so.com/s?q=%E3%80%8A%E7%8E%8B%E7%89%8C%E7%89%B9%E5%B7%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《王牌特工》</a>吗?双排扣的设计，长裤可以变成短裤，英国古典绅士风一览无遗。然而与之对决的张亮毫不怯场，拿出最大的杀手锏--作为中国招牌大长腿的自己!只见他身穿别出心裁的雨衣西装亲自走秀，超模范十足，迷倒一众女评委。两国队长的PK用Linda的话来说简直就是有“既生瑜何生亮”的感觉,本场队长之战究竟最终花落谁家?</p><p>&nbsp;此外，节目还将邀请到VIXX作为匿名走秀的表演嘉宾，MISS A成员也将出现在节目中为明星与设计师的服装提出意见。由于团体战胜利与失败的积分差距非常大，本期节目结束后中韩两国的积分排序又将怎样变换，答案就在即将于6月6日晚10点在<a href="http://m.so.com/s?q=%E4%BC%98%E9%85%B7%E5%9C%9F%E8%B1%86&amp;src=newstranscode" class="qkw">优酷土豆</a>双平台以及韩国SBS Plus频道同步播出的<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E9%9F%A9%E6%97%B6%E5%B0%9A%E7%8E%8B%3A%E7%AE%B1%E5%AD%90%E7%9A%84%E7%A7%98%E5%AF%86%E3%80%8B&amp;src=newstranscode" class="qkw">《中韩时尚王:箱子的秘密》</a>。</p><p><img src="http://p31.qhimg.com/t010e3189dad6970275.jpg?size=950x633"></p><p><img src="http://p33.qhimg.com/t01f7a55e1a48d188e8.jpg?size=950x633"></p><p><img src="http://p34.qhimg.com/t019c8a36872e85d265.jpg?size=950x633"></p><p><img src="http://p31.qhimg.com/t018eb1e513c83283b8.jpg?size=950x633"></p><p><img src="http://p33.qhimg.com/t01049930389639631d.jpg?size=950x633"></p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.xinhuanet.com/ent/2015-06/05/c_127882676.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='24eae4dab58064002ed48a9f60ad260d'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>时尚王</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%97%B6%E5%B0%9A%E7%8E%8B&amp;pn=1&amp;pos=8&amp;m=c674bcefe72b5b9b095eb2830f0d18e6a14f2525&amp;u=http%3A%2F%2Fent.people.com.cn%2Fn%2F2015%2F0511%2Fc1012-26982845.html" data-pos="1"> 《中韩<b>时尚王</b>》取景 最美设计师兰玉献篮球体验 </a>   <li> <a href="/transcode?q=%E6%97%B6%E5%B0%9A%E7%8E%8B&amp;pn=1&amp;pos=9&amp;m=cf683855f90be9dded60c6ac6a038533be5548ce&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Fent%2F2015-05%2F04%2Fc_127762621.htm" data-pos="2"> 《中韩<b>时尚王</b>》金钟国惊人大逆袭"解冻" </a>   <li> <a href="/transcode?q=%E6%97%B6%E5%B0%9A%E7%8E%8B&amp;pn=1&amp;pos=10&amp;m=39d035eadb9d13b1f16c5fc6e6cd0173027e86a5&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Fent%2F2015-04%2F28%2Fc_127743088.htm" data-pos="3"> 《中韩<b>时尚王</b>》柳岩引争议 金钟国"遭讽" </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '《中韩时尚王》上演妇仇者联盟 张亮重返T台 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '《中韩时尚王》上演妇仇者联盟 张亮重返T台 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";