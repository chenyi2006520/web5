s:22823:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>江苏无锡发布2015年度侵害消费者权益典型案例- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">江苏无锡发布2015年度侵害消费者权益典型案例</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-03-15 10:08:33</time></p> </header>  <div id="news-body"><p>谭晓明以不合格计量器具欺骗消费者案 2015年9月，市质监局根据举报称在无锡市<a href="http://m.so.com/s?q=%E6%BB%A8%E6%B9%96%E5%8C%BA&amp;src=newstranscode" class="qkw">滨湖区</a>稻香菜市场有人销售“鬼称”。质监执法人员检查发现，</p><p class="header">谭晓明以不合格计量器具欺骗消费者案</p><p>2015年9月，市质监局根据举报称在无锡市滨湖区稻香菜市场有人销售“鬼称”。质监执法人员检查发现，谭晓明销售的电子秤的铅封处有拆动的痕迹。经<a href="http://m.so.com/s?q=%E6%97%A0%E9%94%A1%E5%B8%82&amp;src=newstranscode" class="qkw">无锡市</a>计量检定测试中心<a href="http://m.so.com/s?q=%E6%A3%80%E5%AE%9A&amp;src=newstranscode" class="qkw">检定</a>，谭晓明制造并销售的电子秤带有改变秤量功能的遥控装置。遥控器有ABCD四档，A档为正常档位，该档位称重结果与标准值之差符合规定;B档的称重结果比标准值多20%;C档的称重结果比标准值多10%;D档的称重结果比标准值多30%。谭晓明的行为违反了<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E5%8D%8E%E4%BA%BA%E6%B0%91%E5%85%B1%E5%92%8C%E5%9B%BD%E8%AE%A1%E9%87%8F%E6%B3%95%E3%80%8B&amp;src=newstranscode" class="qkw">《中华人民共和国计量法》</a>等有关法律法规的规定，无锡市质监局依法对当事人处以没收其制造的以欺骗消费者为目的的电子计价秤，并处以1500元罚款。</p><p><a href="http://m.so.com/s?q=1881%E5%8D%8A%E5%B2%9B%E9%85%92%E5%BA%97&amp;src=newstranscode" class="qkw">1881半岛酒店</a>有限公司销售“土豪”话梅案</p><p>2015年10月，市物价局接到一位网民通过微博反映在<a href="http://m.so.com/s?q=%E6%97%A0%E9%94%A1&amp;src=newstranscode" class="qkw">无锡</a>1881半岛酒店有限公司消费10颗话梅被收取88元的情况。经查，消费者在无锡1881半岛酒店喝下午茶，提出想要一盘话梅，但是酒店菜单中并无话梅单品供应。在顾客的再三要求下，当班服务员将酒店干果拼盘里的话梅给了顾客。结帐时，因电脑系统内没有话梅价格，收银台服务员便录入杏干代替话梅(单价88元)。无锡市物价局认定1881半岛酒店销售商品(话梅)时，未按有关规定进行明码标价，违反了<a href="http://m.so.com/s?q=%E3%80%8A%E4%BB%B7%E6%A0%BC%E6%B3%95%E3%80%8B&amp;src=newstranscode" class="qkw">《价格法》</a>、《关于商品和服务实行明码标价的规定》等规定，属于违反明码标价规定的价格违法行为。依法对1881半岛酒店作出了罚款3000元的行政处罚。</p><p class="header">邓鸿伟销售手机冒用入网认证标志案</p><p>2015年9月，消费者向江阴市青阳市场监督管理分局投诉，反映其购买的手机有冒用入网认证标志问题，要求退机并赔偿。据调查，被投诉人无法提供所售的该款手机取得入网认证的证明材料及进货凭证，且在工业和信息化部电信设备认证中心也未调取到该款手机取得入网许可的证明材料。经调解协商，被投诉人同意为消费者办理退货，并赔偿消费者20000元。江阴市市场监管部门根据<a href="http://m.so.com/s?q=%E3%80%8A%E4%BA%A7%E5%93%81%E8%B4%A8%E9%87%8F%E6%B3%95%E3%80%8B&amp;src=newstranscode" class="qkw">《产品质量法》</a> “销售者不得伪造或者冒用认证标志等质量标志”的规定，责令当事人改正，并没收该品牌手机5台，罚款3000元。</p><p class="header">霍会丽无医疗机构执业许可证行医案</p><p>2015年3月，市卫生局接群众举报，在无锡市新区<a href="http://m.so.com/s?q=%E6%A2%85%E6%9D%91&amp;src=newstranscode" class="qkw">梅村</a>泰伯花园三区523号201室查获霍会丽(河南省<a href="http://m.so.com/s?q=%E6%B1%9D%E5%B7%9E%E5%B8%82&amp;src=newstranscode" class="qkw">汝州市</a>人)未取得医师执业证书和医师资格证书，为非卫生技术专业人员，从事诊疗活动。霍会丽的行为违反了<a href="http://m.so.com/s?q=%E3%80%8A%E5%8C%BB%E7%96%97%E6%9C%BA%E6%9E%84%E7%AE%A1%E7%90%86%E6%9D%A1%E4%BE%8B%E3%80%8B&amp;src=newstranscode" class="qkw">《医疗机构管理条例》</a>的规定。市卫生局当即予以取缔(停止违法行为)，没收药品器械，并给予霍会丽罚款人民币5100元的行政处罚。</p><p class="header">张某经营网店发布虚假化妆品广告案</p><p>2015年8月，山东商先生向无锡市工商局12315中心投诉，称其在天猫官网张某经营的网店购买了化妆品“日霜晚霜”20盒，总价900元。购买后发现该化妆品在网页上宣称有美白祛黄褐斑<a href="http://m.so.com/s?q=%E9%9B%80%E6%96%91&amp;src=newstranscode" class="qkw">雀斑</a>功能，其成分芦荟“可以治疗皮肤炎症，对粉刺，雀斑以及虫咬等有很好的疗效.甘草能修复损伤皮肤，毛发!临床治疗有斑皮肤等功效”。消费者商先生要求退货并赔偿。 <a href="http://m.so.com/s?q=%E5%8D%97%E9%95%BF%E5%8C%BA&amp;src=newstranscode" class="qkw">南长区</a>市场监督管理局金匮分局工作人员调查后发现，商先生反映问题属实，该化妆品属于普通化妆品，不能宣传药效和治疗效果。取得相关证据后，经多次电话调解，双方达成一致，商家退货，并赔偿1500元。南长区市场监管部门对该网店违法发布了虚假化妆品广告的行为，依据<a href="http://m.so.com/s?q=%E3%80%8A%E5%8C%96%E5%A6%86%E5%93%81%E5%B9%BF%E5%91%8A%E7%AE%A1%E7%90%86%E5%8A%9E%E6%B3%95%E3%80%8B&amp;src=newstranscode" class="qkw">《化妆品广告管理办法》</a>的相关规定，作出了没收违法所得4628元，并处罚款5000元的处罚。</p><p>北京三民<a href="http://m.so.com/s?q=%E5%A4%AA%E5%A5%87&amp;src=newstranscode" class="qkw">太奇</a>教育科技有限公司无锡分公司发行盗版教材案</p><p>2014年6月，无锡市文化行政综合执法支队执法人员根据群众举报，对北京三民太奇教育科技有限公司无锡分公司依法进行检查，现场查获涉嫌盗版该出版社的教材621册。市文化行政综合执法支队依据<a href="http://m.so.com/s?q=%E3%80%8A%E8%91%97%E4%BD%9C%E6%9D%83%E6%B3%95%E5%AE%9E%E6%96%BD%E6%9D%A1%E4%BE%8B%E3%80%8B&amp;src=newstranscode" class="qkw">《著作权法实施条例》</a>规定，决定对北京三民太奇教育科技有限公司无锡分公司罚没非法教材621册，并罚款人民币18000整的行政处罚。</p><p>商家更改车辆技术履历欺诈消费者 消委会介入获退款</p><p>2015年9月，无锡市消费者委员会接到消费者刘先生投诉，2015年9月5日消费者与无锡大全二手车经纪公司签订了<a href="http://m.so.com/s?q=%E4%BA%8C%E6%89%8B%E8%BD%A6&amp;src=newstranscode" class="qkw">二手车</a>买卖合同，购买一辆进口(德国大众)迈腾汽车，价格13万元，该公司提供的信息为2009年2月2日上牌，行驶总公里数为8.55万公里。消费者认可车况及信息，于2015年9月9日下午支付了全款并签订了过户等手续，随即将车开走，当晚消费者在车内发现该车的维修保养手册，随即查看了记录，该车2012年6月行驶公里数为10.3万公里。第二天，消费者就到无锡进口大众4S店调看维修保养记录，数据显示，该车止2014年6月7日已行驶了17.5万公里，与商家提供的信息相差很大，消费者认为该公司有欺诈嫌疑，并且发现该车变速箱也有问题。消费者多次到该公司交涉，提出要求退车，该公司不肯退，遂投诉到消委会。经消委会多次交涉调解，最终商家承认事实，愿意退车还款。</p><p>无锡市消委会提醒广大消费者在购买二手车时首先要到正规的二手车交易市场购买，其次要和二手车经纪公司签订较为详细的正规合同约定，第三要请有经验的懂车人协同详细查看、了解车辆的真实车况和维修保养记录，第四成交后发现商家有故意隐瞒车况欺骗消费者的行为可向当地的相关部门进行投诉、举报。及时维护好自身的权益。</p><p>存款时被忽悠买成保险导致本金拿不到，消委会介入保险公司连本带息退还消费者</p><p>2015年12月，无锡市消费者委员会受理了消费者张女士的投诉，消费者反映2010年1月3日在中国建设银行江苏省无锡市永丰分理处存款时，银行业务员告知消费者有新业务，每年存一万，连续五年，存满五年第六年可支取六万元，如果六万元不取，第十年可取八万。于是消费者按照银行的约定每年向银行存了一万元。2015年12月2日消费者到银行取钱时被告知是买的华夏人寿的十年期保险，于是消费者就到<a href="http://m.so.com/s?q=%E5%8D%8E%E5%A4%8F%E4%BA%BA%E5%AF%BF%E4%BF%9D%E9%99%A9%E8%82%A1%E4%BB%BD%E6%9C%89%E9%99%90%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">华夏人寿保险股份有限公司</a>江苏分公司无锡中心支公司银行保险部取款，却被告知如果现在取款属于退保，连本金都拿不全。消费者认为银行存在欺骗行为，与华夏<a href="http://m.so.com/s?q=%E4%BA%BA%E5%AF%BF%E4%BF%9D%E9%99%A9%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">人寿保险公司</a>客服部和银行部多次交涉未果。于是消费者诉至无锡市消委会，要求华夏人寿保险公司退还本金及相应的利息。接到投诉后，消委会立即协调处理，帮助消费者追回了本金五万元及利息四千元。</p><p>无锡消委会提醒广大消费者到银行接受服务时，一定要问清楚是需要的何种银行服务，切勿被业务员推荐的产品所误导。同时也提醒所有商业银行，在为消费者提供服务时一定要如实介绍自身产品，让消费者有充分的选择权。</p><p class="header">皮衣购买近两年 超过三包难退货</p><p>2015年11月，任女士向宜兴市市场监督管理局<a href="http://m.so.com/s?q=%E5%AE%9C%E5%9F%8E&amp;src=newstranscode" class="qkw">宜城</a>分局投诉称:2014年初其在某商场购买了一件男士皮衣，将近两年后发现皮衣的袖口发白，认为该商场所销售的皮衣质量存在问题，要求退货。</p><p>办理经过:接到投诉后，宜城分局工作人员联系投诉人，投诉人发票已经遗失;联系商场负责人，该商场负责人称投诉人任女士已多次找到商场，要求商场作退货处理，但商场认为该皮衣已购买近两年，早已超过三包期限，故未做出处理。随后宜城分局组织当事人双方至分局进行了调解。</p><p>办理结果:经调解，商场作出让步，给投诉人1500元的购物卡，可在该商场用于购物，或给投诉人500元现金，投诉人均不认可。双方无法达成一致意见，调解终止，宜城分局工作人员告知投诉人可选择通过司法途径解决争议。</p><p>消费提示:根据服装类商品三包规定，西装、大衣、裘皮服装等三包期限为六个月。三包期内，消费者一定要注意保存好发票等购物凭证，以方便维权;要仔细检查商品是否存在质量问题，以便及时维权。此外，消费者对皮衣等商品还要做好日常保管和保养。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/jsnews/around/4759775_1.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='2943c27e05d05718666fedcffc3e7586'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>无锡市</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%97%A0%E9%94%A1%E5%B8%82&amp;pn=1&amp;pos=2&amp;m=a54ec2d10a342c1fb2a1f01c78d41651b8ac8c2c&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fjsnews%2Faround%2F4759845_1.html" data-pos="1"> 维权者"独具心思"过度维权行为在<b>无锡</b>遭"冷遇" </a>   <li> <a href="/transcode?q=%E6%97%A0%E9%94%A1%E5%B8%82&amp;pn=1&amp;pos=3&amp;m=dff60355fa5117aa7b934a3f18a1b6ae14ae7f59&amp;u=http%3A%2F%2Fhouse.china.com.cn%2Fwuxi%2Fview%2F824227.htm" data-pos="2"> <b>无锡</b>重点商圈年内先行赔付率逾90% </a>   <li> <a href="/transcode?q=%E6%97%A0%E9%94%A1%E5%B8%82&amp;pn=1&amp;pos=4&amp;m=0f4b663430c257fea5abcd05fd9e038bd1e89344&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fjsnews%2Faround%2F4759851_1.html" data-pos="3"> 维护消费者合法权益 <b>无锡</b>警方在行动 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '江苏无锡发布2015年度侵害消费者权益典型案例' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '江苏无锡发布2015年度侵害消费者权益典型案例'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";