s:17358:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>供应北京禄林波斯菊混色种子矮杆 出芽率高- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">供应北京禄林波斯菊混色种子矮杆 出芽率高</h1> <p id="source-and-time"><span id=source>中国农业网</span><time id=time>2015-05-19 09:48:42</time></p> </header>  <div id="news-body"><p class="header">,波斯菊,北京禄林等</p><p><a href="http://m.so.com/s?q=%E6%B3%A2%E6%96%AF%E8%8F%8A&amp;src=newstranscode" class="qkw">波斯菊</a>又名秋英、格桑花、张大人花。秋英属，为一年生草本植物，植株高度30~120cm，细茎直立，分枝较多，光滑茎或具微毛。单叶对生，长约10cm，二回羽状<a href="http://m.so.com/s?q=%E5%85%A8%E8%A3%82&amp;src=newstranscode" class="qkw">全裂</a>，裂片狭线形，全缘无齿。草本植物，细茎直立，单叶对生，头状花序着生在细长的花梗上，顶生或腋生。头状花序着生在细长的花梗上，顶生或腋生，<a href="http://m.so.com/s?q=%E8%8A%B1%E5%BE%84&amp;src=newstranscode" class="qkw">花径</a>5~8cm。总包片2层，内层边缘膜质。舌状花l轮，花瓣尖端呈齿状，花瓣8枚，有白、粉、深红色。筒状花占据花盘申央部分均为黄色。瘦果有椽，种子寿命3~4年，<a href="http://m.so.com/s?q=%E5%8D%83%E7%B2%92%E9%87%8D&amp;src=newstranscode" class="qkw">千粒重</a>约6克。花期夏、秋季。</p><p>别称:秋英，张大人花，大波斯菊，<a href="http://m.so.com/s?q=%E7%A7%8B%E6%A8%B1&amp;src=newstranscode" class="qkw">秋樱</a>，格桑花，八瓣梅，扫帚梅</p><p>此价格为混色高杆儿波斯菊，矮杆儿波斯菊的价格目前为120-140。</p><p class="header">形态特征</p><p>一年生或多年生草本，高1-2米。根纺锤状，多须根，或近茎基部有不定根。茎无毛或稍被柔毛。叶二次羽状深裂，裂片线形或丝状线形。头状花序单生，径3-6厘米;花序梗长6-18厘米。总苞片外层披针形或线状披针形，近革质，淡绿色，具深紫色条纹，上端<a href="http://m.so.com/s?q=%E9%95%BF%E7%8B%AD&amp;src=newstranscode" class="qkw">长狭</a>尖，较内层与内层等长，长10-15毫米，内层椭圆状卵形，膜质。</p><p><img src="http://p31.qhimg.com/t01238f74baac751be8.jpg?size=550x420"></p><p class="img-title">波斯菊</p><p><img src="http://p33.qhimg.com/t01171abab668ac02bf.jpg?size=550x420"></p><p><img src="http://p35.qhimg.com/t0197ff3467d2de7049.jpg?size=550x420"></p><p class="img-title">生长习性</p><p>喜温暖，不耐寒，忌酷热。喜光，耐干旱瘠薄，喜排水良好的沙质土壤。忌大风，宜种背风处。</p><p class="header">品种分类</p><p>园艺变种有白花波斯菊、大花波斯菊、紫红花波斯菊，园艺品种分早花型和晚花型两大系统，还有单、重瓣之分。</p><p class="header">园艺价值</p><p>波斯菊株形高大，<a href="http://m.so.com/s?q=%E5%8F%B6%E5%BD%A2&amp;src=newstranscode" class="qkw">叶形</a>雅致，花色丰富，有粉、白、深红等色，适于布置花镜，在草地边缘，树丛周围及路旁成片栽植美化绿化，颇有野趣。重瓣品种可作切花材料。适合作花境背景材料，也可植于篱边、山石、崖坡、树坛或宅旁。</p><p class="header">药用价值</p><p class="header">波斯菊 别名:痢疾草</p><p class="header">生境分布:各地引种栽培。</p><p><a href="http://m.so.com/s?q=%E6%80%A7%E5%91%B3&amp;src=newstranscode" class="qkw">性味</a>:甘，平。</p><p>功能主治:<a href="http://m.so.com/s?q=%E6%B8%85%E7%83%AD%E8%A7%A3%E6%AF%92&amp;src=newstranscode" class="qkw">清热解毒</a>，化湿。主治急、慢性痢疾，目赤肿痛;外用治痈疮肿毒。</p><p class="header">植物文化</p><p class="header">花言花语</p><p>花语:<a href="http://m.so.com/s?q=%E6%80%9C%E5%8F%96%E7%9C%BC%E5%89%8D%E4%BA%BA&amp;src=newstranscode" class="qkw">怜取眼前人</a></p><p>大波斯菊的花语是少女的真心、<a href="http://m.so.com/s?q=%E5%B0%91%E5%A5%B3%E7%9A%84%E7%BA%AF%E6%83%85&amp;src=newstranscode" class="qkw">少女的纯情</a>、清净、高洁、自由、爽朗、永远快乐。</p><p class="header">赠花礼仪</p><p>在玻璃制作的色拉盘中放入各色的波斯菊，摆上几种葡萄。盘上系扎白色和粉红色缎带。 波斯菊的学名有美好、和谐之意。原为秋花的<a href="http://m.so.com/s?q=%E7%9F%AD%E6%97%A5%E7%85%A7%E6%A4%8D%E7%89%A9&amp;src=newstranscode" class="qkw">短日照植物</a>，但也有了许多早花品种，花色也有红、黄、粉、白和复色，多姿多彩。</p><p class="header">欢迎来电咨询:</p><p class="header">北京禄林园艺有限公司</p><p class="header">东北地区负责人:刘女士</p><p>联系电话:139-4044-4463</p><p>本公司专业从事纯正东北野生植物资源，花卉种子、林木种子、草坪种子、特菜种子、山野菜种子、中药材种子、园林<a href="http://m.so.com/s?q=%E8%A7%84%E5%88%92%E8%AE%BE%E8%AE%A1&amp;src=newstranscode" class="qkw">规划设计</a>、园林绿化施工、<a href="http://m.so.com/s?q=%E5%9B%AD%E6%9E%97%E7%BB%BF%E5%8C%96%E5%85%BB%E6%8A%A4&amp;src=newstranscode" class="qkw">园林绿化养护</a>及用品等销售业务。所经营的种子质量稳定，出芽率高，抗病性强，且价格合理，一直以来深得广大客户的信赖。</p><p>公司培育及研发基地位于东北辽宁，是北方草种、花种、中药材及野菜销售量最大的储备库，业务范围覆盖全国，并出口韩国、日本及多个欧美国家。公司本着“一手抓开发、一手抓保护”的理念，坚持保证质量、追求高产、保护环境的原则，对国标中规定的各项指标有着近乎苛刻的内控标准，出口手续齐全，芽率和净度经过严格的检验检疫，全部合格通过。</p><p>公司拥有独立的培育基地，设立在辽宁省抚顺清源县，秉着对客户、对社会负责任的态度，设立了样品田及濒危植物保护园。库房<a href="http://m.so.com/s?q=%E5%9F%BA%E5%9C%B0%E4%BF%9D%E6%8A%A4&amp;src=newstranscode" class="qkw">基地保护</a>着濒临灭绝的种子，以备必要时能够扩大繁殖，竭力避免物种灭绝的悲剧发生。保护生态，保护资源，为可持续发展做出我们的一份贡献。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.zgny.com.cn/eproduct/2015-05-19/31289930.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='6ed3a6cd38286b050e6d3d44814dffc9'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>长狭</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%95%BF%E7%8B%AD&amp;pn=1&amp;pos=9&amp;m=134c6b1b012172f3c5cdfc58e8007415346ad901&amp;u=http%3A%2F%2Fwww.gd.xinhuanet.com%2Fnewscenter%2F2015-06%2F11%2Fc_1115588787.htm" data-pos="1"> 穗北京路清代古船移送博物馆 </a>   <li> <a href="/transcode?q=%E9%95%BF%E7%8B%AD&amp;pn=1&amp;pos=10&amp;m=54538ecb23dfc9292b6f5a628b86b1440dcbf6a4&amp;u=http%3A%2F%2Fnews.163.com%2F15%2F0611%2F05%2FARQB5JNU00014AED.html" data-pos="2"> 北京路挖出清代木船(组图) </a>   <li> <a href="/transcode?q=%E9%95%BF%E7%8B%AD&amp;pn=2&amp;pos=1&amp;m=2abfd373fd1ea8fec5cbee4d0746dda650e46b4f&amp;u=http%3A%2F%2Fbaobao.sohu.com%2F20150309%2Fn409530874.shtml" data-pos="3"> 以尊祖、父、圣贤的命名方法 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '供应北京禄林波斯菊混色种子矮杆 出芽率高' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '供应北京禄林波斯菊混色种子矮杆 出芽率高'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";