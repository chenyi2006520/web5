s:15249:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>阿法狗战斗中表现完美 李世石神之一手未获成效- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">阿法狗战斗中表现完美 李世石神之一手未获成效</h1> <p id="source-and-time"><span id=source>搜狐</span><time id=time>2016-03-12 14:41:06</time></p> </header>  <div id="news-body"><p>随着左边战斗的深入，黑棋一条大龙被推上被告席，观战高手们都认为小李前景艰难。不过赵守洵表示<a href="http://m.so.com/s?q=%E6%9D%8E%E4%B8%96%E7%9F%B3&amp;src=newstranscode" class="qkw">李世石</a>开始自己擅长的“僵尸流”，也许是一种策略。<a href="http://m.so.com/s?q=%E6%9D%8E%E5%96%86&amp;src=newstranscode" class="qkw">李喆</a>也认为李世石彻底放开了，几局棋的不同谋略非常用心，令人感动。</p><p><a href="http://m.so.com/s?q=%E5%AE%8B%E6%B3%B0%E5%9D%A4&amp;src=newstranscode" class="qkw">宋泰坤</a>认为小李如果布局不便宜后面就没机会了，但当此局面，中华台北棋王<a href="http://m.so.com/s?q=%E5%91%A8%E4%BF%8A%E5%8B%8B&amp;src=newstranscode" class="qkw">周俊勋</a>认为黑棋很辛苦。</p><p>对于阿法狗的精彩表现，<a href="http://m.so.com/s?q=%E8%81%8C%E4%B8%9A%E9%AB%98%E6%89%8B&amp;src=newstranscode" class="qkw">职业高手</a>们也开始反思，赵守洵说也许我们的年轻棋手之前过于傲慢了，人工智能的高度超出想象。</p><p>左边黑棋逶迤逃出，与上方白棋形成<a href="http://m.so.com/s?q=%E5%AF%B9%E6%94%BB&amp;src=newstranscode" class="qkw">对攻</a>之势，可是即使双活也是黑棋不利。</p><p>黑57三路拐，棋形要点。阿法狗白58脱先跳一手，与下方联络。黑棋只得从二路和一路渡过，白棋则走厚中腹。<a href="http://m.so.com/s?q=%E5%8F%A4%E5%8A%9B&amp;src=newstranscode" class="qkw">古力</a>判断白棋如此选择是因为觉得自己已经优势，它的目标是安全取胜。作为李世石的老对手，古力承认阿法狗的水平远超出自己之前的想象。而<a href="http://m.so.com/s?q=%E6%9F%AF%E6%B4%81&amp;src=newstranscode" class="qkw">柯洁</a>更为直接，宣称现在已经基本可以判李世石死刑了，这棋换自己上去下，黑棋也没什么机会了。这是柯少侠的说话风格，下意识中，也表明他认可了阿法狗的实力。聂卫平棋圣也对阿法狗的表现大加赞赏，认为目前电脑零失误，小李一胜难求。</p><p>李世石强行在中腹出头，力求搅乱局势。局面落后下，他展现出优秀的<a href="http://m.so.com/s?q=%E8%83%9C%E8%B4%9F%E5%B8%88&amp;src=newstranscode" class="qkw">胜负师</a>气质，在左下角留下打劫味道后，黑77从四路碰在白棋右下<a href="http://m.so.com/s?q=%E5%A4%A7%E9%A3%9E&amp;src=newstranscode" class="qkw">大飞</a>守角一子，超越常规的一手!乍看以为是阿法狗下出的手段，这几乎是对计算机<a href="http://m.so.com/s?q=%E6%9C%80%E5%90%8E%E7%9A%84%E8%80%83%E9%AA%8C&amp;src=newstranscode" class="qkw">最后的考验</a>!</p><p>面对李世石的“神之一手”，阿法狗直接迎战，李世石酝酿大型弃子计划，欲图谋白棋左上<a href="http://m.so.com/s?q=%E5%B7%A8%E9%BE%99&amp;src=newstranscode" class="qkw">巨龙</a>。但阿法狗不入圈套，白90挡在上边补棋，李世石只得回到右下活角。这一<a href="http://m.so.com/s?q=%E6%88%98%E5%BD%B9%E4%B9%8B%E5%90%8E&amp;src=newstranscode" class="qkw">战役之后</a>，刘星认为李世石已经没机会了，前面落后太多，还是第二盘机会更多些。<a href="http://m.so.com/s?q=%E8%8A%88%E6%98%B1%E5%BB%B7&amp;src=newstranscode" class="qkw">芈昱廷</a>、周俊勋等都认为李世石本局一开始就在拼命，但还是不行。</p><p>一片悲观声中，李世石在坚持着“一个人的战斗”，他瘦削的身影显得如此苍凉……</p><p><a href="http://m.so.com/s?q=%E5%BC%88%E7%A7%8B&amp;src=newstranscode" class="qkw">弈秋</a></p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://sports.sohu.com/20160312/n440205915.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='62037df60b45290585bc8b2deaec2a91'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>一个人的战斗</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%B8%80%E4%B8%AA%E4%BA%BA%E7%9A%84%E6%88%98%E6%96%97&amp;pn=1&amp;pos=3&amp;m=127891245c0f98c942e59b9a50c6fc362e8941fa&amp;u=http%3A%2F%2Fworld.chinaso.com%2F326924%2Fdetail%2F20160304%2F1000200032709021457054362039916635_1.html" data-pos="1"> 美军<b>1个</b>航母<b>战斗</b>群已驶入南海 发巡航召集令无人买账 </a>   <li> <a href="/transcode?q=%E4%B8%80%E4%B8%AA%E4%BA%BA%E7%9A%84%E6%88%98%E6%96%97&amp;pn=1&amp;pos=4&amp;m=80e9e40082d4c91879d4b74f36fbed905eda2020&amp;u=http%3A%2F%2Fmt.sohu.com%2F20160312%2Fn440219836.shtml" data-pos="2"> 想要养<b>一个</b>健康的孩子,那么,先做<b>一个</b>精致的妈妈 </a>   <li> <a href="/transcode?q=%E4%B8%80%E4%B8%AA%E4%BA%BA%E7%9A%84%E6%88%98%E6%96%97&amp;pn=1&amp;pos=5&amp;m=5f455a1070a30fa6a1ed5ef3ac8e888f3dfad096&amp;u=http%3A%2F%2Fcul.qq.com%2Fa%2F20160307%2F044994.htm" data-pos="3"> <b>一个</b>以色列<b>人的</b>探索:我们做错了什么?将走向何方? </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '阿法狗战斗中表现完美 李世石神之一手未获成效' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '阿法狗战斗中表现完美 李世石神之一手未获成效'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";