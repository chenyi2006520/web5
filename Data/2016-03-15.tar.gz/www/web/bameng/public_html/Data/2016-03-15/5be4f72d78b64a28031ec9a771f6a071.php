s:14744:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>菏泽将规划建设曹州木瓜公园 选址在牡丹办事处- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">菏泽将规划建设曹州木瓜公园 选址在牡丹办事处</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-02-21 11:19:25</time></p> </header>  <div id="news-body"><p>在去年的“两会”上,市政协委员、市花木协会会长孙文起向大会提交一份提案,建议我市推进市树<a href="http://m.so.com/s?q=%E6%9C%A8%E7%93%9C&amp;src=newstranscode" class="qkw">木瓜</a>主题公园建设。市政府将该提案批转到市城市管理局进行办理落实。近一年过去了,看到1950棵“市树”木瓜栽植在<a href="http://m.so.com/s?q=%E8%A5%BF%E5%AE%89%E8%B7%AF&amp;src=newstranscode" class="qkw">西安路</a>上,孙文起有着说不出的兴奋。而根据市城管局总体工作规划和<a href="http://m.so.com/s?q=%E7%89%A1%E4%B8%B9%E5%8C%BA&amp;src=newstranscode" class="qkw">牡丹区</a>的实际,市树木瓜公园正在做立项前的准备工作,木瓜主题公园也将呼之欲出。</p><p>据孙文起介绍,2013年7月,市人大常委会正式表决通过木瓜树作为<a href="http://m.so.com/s?q=%E8%8F%8F%E6%B3%BD&amp;src=newstranscode" class="qkw">菏泽</a>“市树”的决定后,菏泽也有了自己的市树。作为是苗木协会的一员,如何推广好市树,普及好“市树”木瓜则成了他的一块“心病”。当年,他便向牡丹区政协提出了<a href="http://m.so.com/s?q=%E3%80%8A%E5%85%B3%E4%BA%8E%E5%8A%A0%E5%BC%BA%E6%98%8E%E4%BB%A3%E6%9C%A8%E7%93%9C%E6%A0%91%E4%BF%9D%E6%8A%A4%E5%8F%91%E5%B1%95%E7%9A%84%E5%BB%BA%E8%AE%AE%E6%A1%88%E3%80%8B&amp;src=newstranscode" class="qkw">《关于加强明代木瓜树保护发展的建议案》</a>,牡丹区政府也将木瓜树保护列入到牡丹区重点发展项目,并适时开展了对明代木瓜树普查挂牌保护活动。2014年的市“两会”上,孙文起再次提交<a href="http://m.so.com/s?q=%E3%80%8A%E5%85%B3%E4%BA%8E%E6%8E%A8%E8%BF%9B%E5%B8%82%E6%A0%91%E6%9C%A8%E7%93%9C%E4%B8%BB%E9%A2%98%E5%85%AC%E5%9B%AD%E7%9A%84%E5%BB%BA%E8%AE%AE%E3%80%8B&amp;src=newstranscode" class="qkw">《关于推进市树木瓜主题公园的建议》</a>,建议我市建设曹州木瓜主题公园,保护好明代木瓜古树,与市花<a href="http://m.so.com/s?q=%E7%89%A1%E4%B8%B9&amp;src=newstranscode" class="qkw">牡丹</a>主题公园曹州牡丹园相呼应,打造<a href="http://m.so.com/s?q=%E4%B8%80%E8%8A%B1%E4%B8%80%E6%9C%A8&amp;src=newstranscode" class="qkw">一花一木</a>特色城市品牌。</p><p>对此,市城管局在办理答复该提案时认为,木瓜树是我市成熟乡土树种,同时也是园林绿化中常用的春季观花夏秋赏果的观赏树种。针对去年牡丹区政协向区政府提出的 《关于加强明代木瓜树保护发展的建议案》,牡丹区高度重视,已将木瓜树保护列入牡丹区重点发展项目,并提出筹备建立菏泽“市树”公园的意见。</p><p>该局有关负责人表示,木瓜树作为我市“市树”,也是一张代表菏泽的名片。为此,2015年下半年,市政府和城管部门多次磋商,决定在西安路改造中首次引入市树木瓜,在两旁绿化带内种植了1950棵木瓜树,效果整体不错。同时,针对我市花木及绿化建设的实际,当前市树公园建设时机成熟,他们已经向市政府提交了建设市树公园的汇报。如项目立项后,牡丹区将以牡丹办事处某社区明代木瓜园为中心,规划建设曹州木瓜公园。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/2016/sdnews_0221/4205089.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='46f399285c4af5d2d8e3dc1a76249670'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>牡丹公园</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%89%A1%E4%B8%B9%E5%85%AC%E5%9B%AD&amp;pn=1&amp;pos=4&amp;m=2203e40f9adcc09d40bcd7a1cc08a74ff0364603&amp;u=http%3A%2F%2Ftravel.people.com.cn%2Fn%2F2015%2F0503%2Fc41570-26939139.html" data-pos="1"> 北京景山<b>公园</b>:<b>牡丹</b>花开醉游人 </a>   <li> <a href="/transcode?q=%E7%89%A1%E4%B8%B9%E5%85%AC%E5%9B%AD&amp;pn=1&amp;pos=5&amp;m=30778223a7320301be5546156758dc6e18fca4cb&amp;u=http%3A%2F%2Fnews.lyd.com.cn%2Fsystem%2F2016%2F03%2F03%2F010587124.shtml" data-pos="2"> 王城<b>公园</b>动物园提升改造工程将于<b>牡丹</b>文化节前完工 </a>   <li> <a href="/transcode?q=%E7%89%A1%E4%B8%B9%E5%85%AC%E5%9B%AD&amp;pn=1&amp;pos=6&amp;m=5be24854e258676c8b3142e97e697603da5c834d&amp;u=http%3A%2F%2Fwww.chinanews.com%2Fm%2Fcul%2F2015%2F05-10%2F7264958.shtml" data-pos="3"> 叶剑英为景山<b>公园牡丹</b>命名 万里特批<b>牡丹</b>肥料麻渣 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '菏泽将规划建设曹州木瓜公园 选址在牡丹办事处' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '菏泽将规划建设曹州木瓜公园 选址在牡丹办事处'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";