s:17446:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>西汉景帝陵墓发现中国最早茶叶距今至少2150年- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">西汉景帝陵墓发现中国最早茶叶距今至少2150年</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-12 23:57:05</time></p> </header>  <div id="news-body"><p><img src="http://p34.qhimg.com/t017afbaa0d0d686c2d.jpg?size=421x258"></p><p>华商报讯(记者 周艳涛)昨日，一则来自英国的消息风靡全国，而且与咱老陕有关。原来在英国科学杂志上发表的文章说，<a href="http://m.so.com/s?q=%E6%B1%89%E6%99%AF%E5%B8%9D&amp;src=newstranscode" class="qkw">汉景帝</a>的汉阳陵发现了中国最早的茶叶。</p><p>华商报记者采访省考古研究院专家后确认，该发现是由该院委托<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E7%A7%91%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">中国科学院</a>进行出土物分析鉴定得出的，<a href="http://m.so.com/s?q=%E6%B1%89%E9%98%B3%E9%99%B5&amp;src=newstranscode" class="qkw">汉阳陵</a>发现的是中国最早的茶叶，距今起码有2150多年。</p><p>省考古研究院专家、曾担任汉阳陵考古队副队长的<a href="http://m.so.com/s?q=%E6%9D%A8%E6%AD%A6&amp;src=newstranscode" class="qkw">杨武</a>站说，早在1998年，考古专家就对汉阳陵进行了详细钻探，在陵墓封土四周发现了86座外藏坑，考古人员先后试掘了封土东侧11座外藏坑。在外藏坑出土了木车马、漆盒、粮食、动物骨架等大量有机质遗存。网上译文说茶叶是在一个木盒子里被发现的，杨武站说，他看了英文原文，这种翻译是误译，其实是在一个陪葬坑里。</p><p>考古专家在这个陪葬坑发现一些树叶状的东西，2008年底送到中国科学院。经检测，专家发现这些叶子竟然是茶叶，这些茶叶看起来是顶级品质，完全由茶芽制成。茶芽通常被认为比普通茶叶品质高。汉景帝死于公元前141年，由此推断，该茶叶至少距今2150多年了，也是目前发现的最早的茶叶。</p><p><a href="http://m.so.com/s?q=%E4%BC%A6%E6%95%A6%E5%A4%A7%E5%AD%A6%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">伦敦大学学院</a>中国文物和考古学国际中心主任多里安·富勒教授说:“这项发现表明，现代科学能够揭示以前不知道的中国古代文化的重要细节。在这位皇帝的墓葬群中发现茶叶一事，让我们难得一窥非常古老的传统，使我们对世界上最受欢迎的饮料之一--茶叶的起源有了新的认识。”对<a href="http://m.so.com/s?q=%E6%B1%89%E6%99%AF%E5%B8%9D%E5%88%98%E5%90%AF&amp;src=newstranscode" class="qkw">汉景帝刘启</a>墓葬群中的食物和其他祭品的科学分析结果显示，除了茶叶，他还带着谷子、大米和藜科植物去另一个世界。这项研究结果新近发表在英国<a href="http://m.so.com/s?q=%E3%80%8A%E8%87%AA%E7%84%B6%E3%80%8B&amp;src=newstranscode" class="qkw">《自然》</a>周刊下属的开放网络科学杂志<a href="http://m.so.com/s?q=%E3%80%8A%E7%A7%91%E5%AD%A6%E6%8A%A5%E5%91%8A%E3%80%8B&amp;src=newstranscode" class="qkw">《科学报告》</a>上。</p><p>据茶文化专家、<a href="http://m.so.com/s?q=%E9%99%95%E8%A5%BF%E5%8E%86%E5%8F%B2%E5%8D%9A%E7%89%A9%E9%A6%86&amp;src=newstranscode" class="qkw">陕西历史博物馆</a>研究员梁子介绍，我国是世界上最早发现、栽培、利用茶叶的国家。据历史资料考证，茶树起源于中国，早在5000多年前，我们的祖先就发现了茶有解毒的功效。</p><p class="header">北宋墓葬也曾发现茶叶实物</p><p>科学家发现茶叶至少在1800年前就已输送到西藏<a href="http://m.so.com/s?q=%E9%98%BF%E9%87%8C%E5%9C%B0%E5%8C%BA&amp;src=newstranscode" class="qkw">阿里地区</a>。由此推测，当时<a href="http://m.so.com/s?q=%E4%B8%9D%E7%BB%B8%E4%B9%8B%E8%B7%AF&amp;src=newstranscode" class="qkw">丝绸之路</a>有一个分支穿越了<a href="http://m.so.com/s?q=%E9%9D%92%E8%97%8F%E9%AB%98%E5%8E%9F&amp;src=newstranscode" class="qkw">青藏高原</a>。相关成果近日在线发表于《科学报告》上。</p><p>茶起源于中国。此前最早的茶叶实物发现于我国北宋时期的墓葬中。长期以来，人们推测茶叶、丝绸和瓷器沿着丝绸之路，从<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E5%8F%A4%E9%83%BD&amp;src=newstranscode" class="qkw">中国古都</a>长安传送到中亚及更远地区。但迄今在丝绸之路上，没有茶叶在<a href="http://m.so.com/s?q=%E5%94%90%E6%9C%9D&amp;src=newstranscode" class="qkw">唐朝</a>以前进入新疆或青藏高原的任何证据。一般认为由于古代茶叶多已腐烂或碳化，难保存难发现，即使发现了也难鉴定。</p><p>中科院地质与地球所研究员<a href="http://m.so.com/s?q=%E5%90%95%E5%8E%9A%E8%BF%9C&amp;src=newstranscode" class="qkw">吕厚远</a>与国内外同行合作，针对西藏阿里地区故如甲木寺遗址和西安汉阳陵陪葬坑出土的疑似茶叶食物残体，开展了植物鉴定和年代学分析工作。他们发现茶叶具有4类植钙体形态和组合特征，又通过对现代茶叶标准样品的色谱-质谱分析，明确了鉴定茶叶的两个生物标志物:<a href="http://m.so.com/s?q=%E5%92%96%E5%95%A1%E5%9B%A0&amp;src=newstranscode" class="qkw">咖啡因</a>和茶氨酸。他们通过碳14测年，证明故如甲木寺遗址出土植物的年龄距今约1800年左右，属西藏古象雄王国时期;汉阳陵出土植物年龄约为2100多年，与历史文献吻合。这也是目前<a href="http://m.so.com/s?q=%E5%B7%B2%E7%9F%A5%E7%9A%84%E4%B8%96%E7%95%8C&amp;src=newstranscode" class="qkw">已知的世界</a>上最早的茶叶实物。据<a href="http://m.so.com/s?q=%E3%80%8A%E7%A7%91%E6%8A%80%E6%97%A5%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《科技日报》</a></p><p class="header">责任编辑:倪子牮</p><p>北京再增两名两院院士 市属单位院士已增至13人</p><p>司机撞死人逃回老家 交警上门规劝其自首</p><p>患者病危没钱做手术 医生求助<a href="http://m.so.com/s?q=%E6%9C%8B%E5%8F%8B%E5%9C%88&amp;src=newstranscode" class="qkw">朋友圈</a>1小时凑齐</p><p>动车15元盒饭&quot;难买&quot; 记者多次询问乘务员端出(图)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/article/3997726.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='ff5bdb4d4c06c415f1f4260ec8570bce'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>最早的中国</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9C%80%E6%97%A9%E7%9A%84%E4%B8%AD%E5%9B%BD&amp;pn=1&amp;pos=9&amp;m=967df2417aa9df3983bc0ead111a680f669225f1&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4021714.html" data-pos="1"> <b>中国最早</b>论坛聚合门户:大旗网突然关门 </a>   <li> <a href="/transcode?q=%E6%9C%80%E6%97%A9%E7%9A%84%E4%B8%AD%E5%9B%BD&amp;pn=1&amp;pos=10&amp;m=2ac1aa81917eed3c649cad191a06c2a76151e98e&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F4011581.html" data-pos="2"> 旧照忆新<b>中国最早</b>警花 </a>   <li> <a href="/transcode?q=%E6%9C%80%E6%97%A9%E7%9A%84%E4%B8%AD%E5%9B%BD&amp;pn=2&amp;pos=1&amp;m=2644d9132ca5a0da05ee7debca77c3799f129cc5&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F3997726.html" data-pos="3"> 西汉景帝陵墓发现<b>中国最早</b>茶叶距今至少2150年 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '西汉景帝陵墓发现中国最早茶叶距今至少2150年' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '西汉景帝陵墓发现中国最早茶叶距今至少2150年'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";