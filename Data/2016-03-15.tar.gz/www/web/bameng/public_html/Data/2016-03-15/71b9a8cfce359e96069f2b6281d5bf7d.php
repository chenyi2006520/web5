s:22155:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>李海鹰音乐会广州举行 再现流行与古典的完美结合- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">李海鹰音乐会广州举行 再现流行与古典的完美结合</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-14 15:16:08</time></p> </header>  <div id="news-body"><p><img src="http://p32.qhimg.com/t01fa691226f80b5758.jpg?size=300x203"></p><p><a href="http://m.so.com/s?q=%E6%9D%8E%E5%81%A5&amp;src=newstranscode" class="qkw">李健</a>的很多作品都有古典音乐的元素。(CFP供)</p><p><img src="http://p31.qhimg.com/t01afaee018d07321ff.jpg?size=300x386"></p><p><a href="http://m.so.com/s?q=%E9%87%91%E5%BF%97%E6%96%87&amp;src=newstranscode" class="qkw">金志文</a>演唱经典歌曲《往事只能回味》，融合流行与古典的编曲让人眼前一亮。</p><p><img src="http://p35.qhimg.com/t01e383ebea1f5f84ac.jpg?size=300x200"></p><p><a href="http://m.so.com/s?q=%E8%B0%AD%E5%92%8F%E9%BA%9F&amp;src=newstranscode" class="qkw">谭咏麟</a>演唱会由专业交响乐团伴奏。</p><p><img src="http://p33.qhimg.com/t01a4c0aa598897f13a.jpg?size=300x242"></p><p><a href="http://m.so.com/s?q=%E6%9D%8E%E4%BA%91%E8%BF%AA&amp;src=newstranscode" class="qkw">李云迪</a>和张杰合作演出。</p><p>广州日报3月14日报道 昨日下午，<a href="http://m.so.com/s?q=%E6%9D%8E%E6%B5%B7%E9%B9%B0&amp;src=newstranscode" class="qkw">李海鹰</a>指挥的“跨界异彩--流行好经典”音乐会在广州举行。近几年，作为知名流行音乐作曲家，李海鹰开始尝试将自己的流行音乐作品进行交响化再造。而在前晚播出的新一季<a href="http://m.so.com/s?q=%E3%80%8A%E6%88%91%E6%98%AF%E6%AD%8C%E6%89%8B%E3%80%8B&amp;src=newstranscode" class="qkw">《我是歌手》</a>中，金志文前来踢馆，演唱的作品以融合流行与古典的编曲让人眼前一亮。在不久前结束的谭咏麟银河岁月40载中国巡回演唱会广州站上，也采用了管弦乐队伴奏。如今流行音乐与古典音乐的跨界、融合越来越频繁，产生了许多奇妙的听觉体验。</p><p class="header">撰文:广州日报记者李渊航</p><p class="header">流行作品交响化</p><p class="header">让流行音乐像艺术品般雅致</p><p>昨日下午，李海鹰指挥的“跨界异彩--流行好经典”音乐会举行，这几年他已多次进行此类尝试。2012年~2014年连续三年，在<a href="http://m.so.com/s?q=%E5%B9%BF%E5%B7%9E%E4%BA%A4%E5%93%8D%E4%B9%90%E5%9B%A2&amp;src=newstranscode" class="qkw">广州交响乐团</a>音乐季上都曾推出不同曲目的“鹰交响--李海鹰流行经典交响乐”音乐会。</p><p>李海鹰曾告诉记者，他尝试把流行音乐上升到交响乐层面，是为了让流行音乐不仅仅只有“流行”的一面:“就像广东牙雕一样，镂空有50多层，流行音乐交响化就是要像牙雕一样，层面很多，像艺术品一样雅致，但同时不曲高和寡，会有很多人喜欢。”李海鹰也坦然表示，从流行到古典，跨越难度较大，“写一首流行歌曲可能也就三到五个点睛之笔，但一首交响乐，最少要有100个点睛的地方”。</p><p>广州交响乐团团长<a href="http://m.so.com/s?q=%E9%99%88%E6%93%8E&amp;src=newstranscode" class="qkw">陈擎</a>也表示，观众对古典乐最大的误解就是离自己生活远，而李海鹰的这种尝试就是以流行乐视角看古典乐，“不要说起古典乐就板着脸，而是用各自好玩有趣的方式让观众亲近古典乐”。</p><p class="header">演唱会大阵仗</p><p class="header">交响乐团伴奏提升格调</p><p>古典音乐与流行音乐相融合，以“接地气”的方式去普及，而流行音乐也借助古典音乐来提升格调和品质。</p><p>谭咏麟银河岁月40载中国巡回演唱会刚刚在广州落下帷幕，演唱会由专业交响乐团伴奏。演唱会主办方首席运营官<a href="http://m.so.com/s?q=%E9%99%88%E5%B9%B3&amp;src=newstranscode" class="qkw">陈平</a>表示，此前谭咏麟听到很多人评论他的歌用弦乐来搭配效果最好，于是决定演唱会邀请<a href="http://m.so.com/s?q=%E9%A6%99%E6%B8%AF%E7%AE%A1%E5%BC%A6%E4%B9%90%E5%9B%A2&amp;src=newstranscode" class="qkw">香港管弦乐团</a>担任伴奏。陈平表示，广州的这场演出观众普遍认为效果非常好，乐团的伴奏配合春夏秋冬的主题，整个音域、音场都扩充了不少，在表现歌曲的细腻程度方面，有了更出色的发挥。他认为<a href="http://m.so.com/s?q=%E4%B9%90%E5%9B%A2&amp;src=newstranscode" class="qkw">乐团</a>伴奏可以将现场的收听效果提升三成左右，“不过乐团伴奏势必造成演出人员增加，成本相应也会增加，但是为了力求效果好，这次可以说是不计成本地投入”。</p><p>陈平还称:“乐团是表演中的重要一环，能够体现出歌手与乐队的融合，每一次表演、每一首歌，都是不一样的，这是最激动人心的部分，毕竟表演不是卡拉OK，乐团的加入能够增加更多互动，提升整体档次。专业乐团伴奏的好处首先是比较稀缺，现在音乐主要都使用电脑合成的方式，减少使用管弦乐。管弦乐配合情歌，配合抒情类的歌曲，往往有意想不到的效果。其次是品牌，之前香港管弦乐团曾配合过张学友、陈慧娴、<a href="http://m.so.com/s?q=%E6%9D%8E%E5%85%8B%E5%8B%A4&amp;src=newstranscode" class="qkw">李克勤</a>等演唱会，已经变成了一个品牌，票房都不错。”</p><p>钢琴家李云迪也一直喜欢和<a href="http://m.so.com/s?q=%E6%B5%81%E8%A1%8C%E6%AD%8C%E6%89%8B&amp;src=newstranscode" class="qkw">流行歌手</a>合作，他曾在音乐会上邀请<a href="http://m.so.com/s?q=%E5%BC%A0%E6%9D%B0&amp;src=newstranscode" class="qkw">张杰</a>合作，他称:“人们印象中古典音乐一般很严肃，但我与张杰的跨界合作很放松，不管古典音乐还是流行音乐，都是美的音乐。”</p><p class="header">歌唱节目吸睛招数</p><p class="header">再现流行与古典的完美融合</p><p>在前晚结束的新一季《我是歌手》的最新一期节目中，金志文前来踢馆，演唱了经典歌曲<a href="http://m.so.com/s?q=%E3%80%8A%E5%BE%80%E4%BA%8B%E5%8F%AA%E8%83%BD%E5%9B%9E%E5%91%B3%E3%80%8B&amp;src=newstranscode" class="qkw">《往事只能回味》</a>，融合流行与古典的编曲让人眼前一亮。乐评人称赞说:“精心设计过的中国风转音行云流水，平添一层古韵在其中。此外，特别助阵的美声合唱团更是烘托出年代感，使得整首歌曲既华丽又唯美。”</p><p>流行与古典融合一向是《我是歌手》的一大传统，此前的音乐诗人李健更将这一传统发扬光大，他演唱的多首作品中都有古典音乐的元素。李健钟爱古典音乐广为人知，他说过“古典音乐可以很严肃，也可以很活泼，流行音乐能表现的一切，古典音乐也都能表现”。在《我是歌手》的舞台上，他娴熟地将两者融合。他选择的《贝加尔湖畔》、《在水一方》等歌曲，都给人很强的文艺气息。他自称喜欢肖邦的抒情、舒曼的唯美、<a href="http://m.so.com/s?q=%E6%9F%B4%E5%8F%AF%E5%A4%AB%E6%96%AF%E5%9F%BA&amp;src=newstranscode" class="qkw">柴可夫斯基</a>的忧郁，李健现场改编和演绎也恰如其分，感情充沛。</p><p>李健在十年音乐大碟《拾光》中和顶级交响乐团合作，全部用古典音乐进行重新编曲，让流行音乐有了更多的想象力和生命力。他表示:“随着年纪越来越大，我发现现在自己听古典乐的时间越来越多，那才是真正历久弥新的经典，是能够触动心灵的音乐。”</p><p>在历届《我是歌手》的竞演台上，张靓颖曾请来小提琴家<a href="http://m.so.com/s?q=%E6%96%87%E8%96%87&amp;src=newstranscode" class="qkw">文薇</a>合作。韩红采用过西方古典歌剧编制和唱法。林志炫挑战无词的<a href="http://m.so.com/s?q=%E3%80%8AOpera%E3%80%8B&amp;src=newstranscode" class="qkw">《Opera》</a>，也曾和伦敦交响乐团一起让流行和古典交响相得益彰。韩磊也是个古典音乐迷，他称“古典跟流行并不冲突，你看获格莱美奖的那些西方歌手，哪一个不有着深厚的古典音乐功底?”李克勤也和古典音乐有着不解之缘，他曾和郎朗等古典乐名家合作，也曾和知名乐团跨界合作过。新一季《我是歌手》节目的观众，很期待看到李克勤的“流行+古典”跨界之作。</p><p class="header">愿流行与古典的握手越来越多</p><p class="header">李渊航</p><p>古典乐和流行乐之间的“握手”广泛存在，许多流行歌直接向古典乐学习。李健曾表示:“今天流行音乐所有的技法都来源于古典音乐，我的创作就非常得益于古典音乐。”周杰伦也曾说过，先有古典音乐的基础，创作流行音乐就比较容易。S.H.E的<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%8D%E6%83%B3%E9%95%BF%E5%A4%A7%E3%80%8B&amp;src=newstranscode" class="qkw">《不想长大》</a>中有《莫扎特40交响曲》的曲调。刘若英和黄立行合唱的<a href="http://m.so.com/s?q=%E3%80%8A%E5%88%86%E5%BC%80%E6%97%85%E8%A1%8C%E3%80%8B&amp;src=newstranscode" class="qkw">《分开旅行》</a>，一开头就采用了法国作曲家德利布的歌剧《拉克美》中的“花之二重唱”旋律。周杰伦的《琴伤》改编了两首著名的钢琴曲，乐曲开始引用柴可夫斯基的《六月船歌》，中间插曲又加入了莫扎特的《土耳其进行曲》。</p><p>钢琴家李云迪称“我们现在所说的古典音乐，在它当时的年代也是流行音乐;肖邦、李斯特在当年也是炙手可热的 流行偶像 ，古典其实就是经历过时间检验，大浪淘沙保留到今天的文化精华。而到了20世纪、21世纪，所谓古典和流行的界限就更加模糊了，许多非常杰出的古典演奏家，也常参与流行作品的演出甚至创作。从形制上说， 古典 有它的定义界限，我也严格去遵守它的规范;但在音乐的视野里则是无边无际的。音符构成旋律，就像流动的水一样，不能去控制，也没有办法控制。”</p><p>而不少交响乐团如德国汉堡交响乐团等，都是流行演唱会伴奏的“常客”。效果往往也令人惊喜，因为流行歌手通过与交响乐团的深度合作，拥有了录音棚所没有的、由上百人营造的丰富层次，音乐更具张力，将人声甚至情绪的细微变化都烘托到了极致。在越来越强调听觉体验的年代，这样的用心更能赢得乐迷青睐。</p><p>同样，音乐不应只局限在流行与古典之间，其他类型音乐之间的对话、融合也应多起来，给乐迷碰撞出更多的惊喜。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://huaxunwang.com.cn/yy/2016-03-14/86541.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='444da40df93744110a8b6e106bf10adc'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>流行歌手</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%B5%81%E8%A1%8C%E6%AD%8C%E6%89%8B&amp;pn=1&amp;pos=9&amp;m=1fe6036e2bc5fc6e8f254e140c2bd9b646118799&amp;u=http%3A%2F%2Ffinance.huanqiu.com%2Fssgs%2F2015-12%2F8152728.html" data-pos="1"> 瑞吉酒店任命爵士<b>流行</b>乐<b>歌手</b>JAMIE CULLUM为"瑞吉鉴赏家" </a>   <li> <a href="/transcode?q=%E6%B5%81%E8%A1%8C%E6%AD%8C%E6%89%8B&amp;pn=1&amp;pos=10&amp;m=c2f64d687dfe0738fec074d832c1ec5c34680302&amp;u=http%3A%2F%2Fnews.163.com%2F16%2F0130%2F19%2FBEJQDB0E00014JB6.html" data-pos="2"> 人气<b>歌手</b>魏晨空降福州 为全球<b>流行</b>音乐榜站台 </a>   <li> <a href="/transcode?q=%E6%B5%81%E8%A1%8C%E6%AD%8C%E6%89%8B&amp;pn=2&amp;pos=1&amp;m=2f0f0b5288b73dde3f7eaf7973d14f741b1e4f9a&amp;u=http%3A%2F%2Fhuaxunwang.com.cn%2Fyy%2F2016-03-14%2F86541.html" data-pos="3"> 李海鹰音乐会广州举行 再现<b>流行</b>与古典的完美结合 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '李海鹰音乐会广州举行 再现流行与古典的完美结合' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '李海鹰音乐会广州举行 再现流行与古典的完美结合'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";