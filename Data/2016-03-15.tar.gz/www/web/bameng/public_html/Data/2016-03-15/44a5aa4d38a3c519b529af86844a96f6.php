s:16831:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>增兵爱琴海 北约出大招阻非法移民偷渡欧洲- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">增兵爱琴海 北约出大招阻非法移民偷渡欧洲</h1> <p id="source-and-time"><span id=source>中国青年网</span><time id=time>2016-03-08 06:35:32</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E5%8C%97%E5%A4%A7%E8%A5%BF%E6%B4%8B%E5%85%AC%E7%BA%A6%E7%BB%84%E7%BB%87&amp;src=newstranscode" class="qkw">北大西洋公约组织</a>6日宣布扩大在<a href="http://m.so.com/s?q=%E7%88%B1%E7%90%B4%E6%B5%B7&amp;src=newstranscode" class="qkw">爱琴海</a>的军事行动，向<a href="http://m.so.com/s?q=%E5%B8%8C%E8%85%8A%E5%92%8C%E5%9C%9F%E8%80%B3%E5%85%B6&amp;src=newstranscode" class="qkw">希腊和土耳其</a>领海派遣更多舰船，以协助打击<a href="http://m.so.com/s?q=%E9%9D%9E%E6%B3%95%E5%81%B7%E6%B8%A1&amp;src=newstranscode" class="qkw">非法偷渡</a>和难民贩运。</p><p>英国首相<a href="http://m.so.com/s?q=%E6%88%B4%E7%BB%B4%C2%B7%E5%8D%A1%E6%A2%85%E4%BC%A6&amp;src=newstranscode" class="qkw">戴维·卡梅伦</a>7日凌晨发表声明，称难民危机是欧洲眼下面临的“最严峻挑战”，英国海军将派出一艘<a href="http://m.so.com/s?q=%E4%B8%A4%E6%A0%96&amp;src=newstranscode" class="qkw">两栖</a>登陆舰和“野猫”直升机加入北约行动。</p><p class="header">【明确信号】</p><p>北约秘书长<a href="http://m.so.com/s?q=%E5%BB%B6%E6%96%AF%C2%B7%E6%96%AF%E6%89%98%E5%B0%94%E6%BB%95%E8%B4%9D%E6%A0%BC&amp;src=newstranscode" class="qkw">延斯·斯托尔滕贝格</a>6日说，北约军舰将在爱琴海海域进行侦察和监视，与希腊和土耳其的<a href="http://m.so.com/s?q=%E6%B5%B7%E5%B2%B8%E8%AD%A6%E5%8D%AB%E9%98%9F&amp;src=newstranscode" class="qkw">海岸警卫队</a>以及欧洲边境管理局“实时共享信息”，帮助欧盟更有效应对非法偷渡和难民贩运网络。</p><p>希腊与<a href="http://m.so.com/s?q=%E5%9C%9F%E8%80%B3%E5%85%B6&amp;src=newstranscode" class="qkw">土耳其</a>存在领土纠纷，但相关方面已就北约舰队进入这两国领海“达成一致安排”，他说，北约还将向地中海东部派遣军事力量。</p><p><a href="http://m.so.com/s?q=%E6%96%AF%E6%89%98%E5%B0%94%E6%BB%95%E8%B4%9D%E6%A0%BC&amp;src=newstranscode" class="qkw">斯托尔滕贝格</a>强调，北约舰队所做的只是“支持和协助土耳其、希腊政府以及欧盟”，不会直接参与遣返那些搭载非法偷渡者和难民的船只。</p><p><a href="http://m.so.com/s?q=%E5%8D%A1%E6%A2%85%E4%BC%A6&amp;src=newstranscode" class="qkw">卡梅伦</a>在声明中说:“我们必须击破犯罪人员的商业模式，阻止绝望的民众涌入简易船只，继而开始徒劳而险恶的旅程。”</p><p>国际移民署4日估算，今年以来，超过12.5万难民抵达<a href="http://m.so.com/s?q=%E5%B8%8C%E8%85%8A&amp;src=newstranscode" class="qkw">希腊</a>，至少410人在途中溺亡或失踪。</p><p>卡梅伦说，北约扩大在爱琴海的军事行动规模和覆盖面，向考虑前往欧洲的难民释放了明确信号，即“他们会被遣返”。</p><p>北约在上月的成员国国防部长会议上决定，派出海上军事力量协助应对欧洲难民危机，北约第二海上常备部队3艘军舰随后开赴爱琴海。</p><p><img src="http://p32.qhimg.com/t01e86f9f48c3ea3ff0.jpg?size=400x300"></p><p class="img-title">【绝对要务】</p><p>北约宣布增兵爱琴海之时，正值欧盟-土耳其难民特别峰会召开之际。</p><p>希腊总理亚历克西斯·齐<a href="http://m.so.com/s?q=%E6%99%AE%E6%8B%89%E6%96%AF&amp;src=newstranscode" class="qkw">普拉斯</a>6日说，“立即启动”重新安置滞留希腊的难民是欧盟眼下“绝对要务”。</p><p>法新社报道，欧盟去年9月通过一项“摊派”希腊和<a href="http://m.so.com/s?q=%E6%84%8F%E5%A4%A7%E5%88%A9&amp;src=newstranscode" class="qkw">意大利</a>境内16万难民申请人的方案，而实际上不到700人真正得到转移。</p><p>希腊邻国<a href="http://m.so.com/s?q=%E9%A9%AC%E5%85%B6%E9%A1%BF&amp;src=newstranscode" class="qkw">马其顿</a>不是欧盟成员国，今年以来不断收紧边境管控，限制难民从希腊入境，6日当天仅对大约160人放行。</p><p>欧洲理事会主席<a href="http://m.so.com/s?q=%E5%94%90%E7%BA%B3%E5%BE%B7%C2%B7%E5%9B%BE%E6%96%AF%E5%85%8B&amp;src=newstranscode" class="qkw">唐纳德·图斯克</a>在峰会邀请函中说，7日举行的特别峰会成功与否，很大程度上取决于能否让土耳其政府重新从希腊接回“大量”经济移民，后者没有资格成为难民。</p><p>土耳其方面，总理艾哈迈德·达武特<a href="http://m.so.com/s?q=%E5%A5%A5%E5%8D%A2&amp;src=newstranscode" class="qkw">奥卢</a>前往布鲁塞尔出席峰会前告诉媒体记者，根据欧盟-土耳其去年11月达成的协议，土政府已经采取了一系列“重要措施”，但叙利亚动乱持续，导致难民人数“并没有显著减少”。</p><p>欧盟-土耳其协议规定，欧盟向土耳其提供32亿美元援助，用于改善在土耳其境内的难民生活状况;欧盟承诺向土耳其公民提供免签证入境待遇;重启土耳其加入欧盟的谈判等。</p><p>只是，<a href="http://m.so.com/s?q=%E6%8D%B7%E5%85%8B&amp;src=newstranscode" class="qkw">捷克</a>总统米洛什·泽曼对土耳其政府并不满意，认为“金钱换难民”政策纯属浪费，因为土方“既不准备、也没能力”帮助难民。(<a href="http://m.so.com/s?q=%E5%88%98%E7%BA%A2%E9%9C%9E&amp;src=newstranscode" class="qkw">刘红霞</a> 新华社专特稿)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.youth.cn/gj/201603/t20160308_7715965.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='730c206cd242aeb7209abfd0b698b413'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>爱琴海</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%88%B1%E7%90%B4%E6%B5%B7&amp;pn=1&amp;pos=6&amp;m=db8f8e1c5518f2a2464b6469a7609da8f851c6f6&amp;u=http%3A%2F%2Fcul.china.com.cn%2Fcswh%2F2016-03%2F07%2Fcontent_8618311.htm" data-pos="1"> <b>爱琴海</b>难民船倾覆18人死 去年超3000难民在海域中丧生 </a>   <li> <a href="/transcode?q=%E7%88%B1%E7%90%B4%E6%B5%B7&amp;pn=1&amp;pos=7&amp;m=5b309f2df50dc1c00bda3a2bc48fc249a58118a1&amp;u=http%3A%2F%2Fsichuan.scol.com.cn%2Fzyxw%2F201603%2F54389938.html" data-pos="2"> 资阳物业服务测评报告出炉:空间<b>爱琴海</b>物业公司倒数第一 </a>   <li> <a href="/transcode?q=%E7%88%B1%E7%90%B4%E6%B5%B7&amp;pn=1&amp;pos=8&amp;m=6c3d3b63c6c45c97adbbf781c78690d75357ac55&amp;u=http%3A%2F%2Fnews.gmw.cn%2F2016-03%2F10%2Fcontent_19235951.htm" data-pos="3"> 土希表示坚决阻止非法移民偷渡<b>爱琴海</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '增兵爱琴海 北约出大招阻非法移民偷渡欧洲' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '增兵爱琴海 北约出大招阻非法移民偷渡欧洲'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";