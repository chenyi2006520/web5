s:16989:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>深灰色的庭院(组诗) - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">深灰色的庭院(组诗) </h1> <p id="source-and-time"><span id=source>光明网</span><time id=time>2015-06-18 08:23:00</time></p> </header>  <div id="news-body"><p class="header">思绪回流</p><p class="header">那一片草地</p><p class="header">高楼林立之中的喘息</p><p class="header">停顿的一个节拍</p><p class="header">天空有些许牵挂</p><p class="header">纸鸢比着高低</p><p class="header">宁静端坐</p><p>清苦地依傍着<a href="http://m.so.com/s?q=%E6%B5%B7%E6%B2%B3&amp;src=newstranscode" class="qkw">海河</a></p><p class="header">注视着以往的不同</p><p class="header">院落与街衢由此诞生</p><p class="header">很响亮的三个汉字</p><p>在记忆里划了一道<a href="http://m.so.com/s?q=%E6%B7%B1%E7%97%95&amp;src=newstranscode" class="qkw">深痕</a></p><p class="header">一座城池</p><p class="header">斩断了与城外的联络</p><p class="header">跳动的心音听不到了</p><p class="header">却一直跳个不停</p><p class="header">城池的深处</p><p class="header">总有思绪与推理</p><p class="header">出出进进的</p><p class="header">那草地间的距离</p><p class="header">空白</p><p class="header">拒绝承载排斥担负</p><p class="header">讨人欢喜或是生厌</p><p class="header">让熟悉彼此陌生</p><p class="header">春寒</p><p class="header">早春二月</p><p class="header">深深庭院</p><p>跨过第二道<a href="http://m.so.com/s?q=%E6%9C%B1%E9%97%A8%E4%B9%8B%E5%90%8E&amp;src=newstranscode" class="qkw">朱门之后</a></p><p class="header">雪已经把来时的足迹覆盖了</p><p class="header">了无人烟</p><p class="header">苍凉旷日持久</p><p class="header">雕花的窗棂之外</p><p class="header">它只为一人舞</p><p class="header">一朵朵洁白</p><p class="header">投怀送抱</p><p class="header">天边一抹亮色</p><p class="header">修成正果之后</p><p class="header">温暖与浪漫接踵而来</p><p class="header">连海风的味道都是甜美的</p><p class="header">那一片天和这深宅大院</p><p class="header">距离不可以丈量</p><p class="header">境遇不可同日而语</p><p class="header">狮子守候的桥下</p><p class="header">河刚刚脱去冬衣</p><p class="header">冷得呻吟</p><p class="header">灰色院落如此</p><p class="header">二月倒春寒</p><p class="header">冷风穿透暗色的披肩</p><p><a href="http://m.so.com/s?q=%E8%B7%B3%E5%8A%A8%E7%9A%84%E6%80%9D%E7%BB%AA&amp;src=newstranscode" class="qkw">跳动的思绪</a>暗暗在抖</p><p class="header">深灰色的庭院</p><p class="header">危险是太湖石堆砌的</p><p class="header">恐慌来自掘地三尺</p><p class="header">淡定的眼神</p><p class="header">飘香院落的每个角落</p><p class="header">抚慰大人物不经意间的过失</p><p class="header">绽出富有禅机的紫色碎花</p><p class="header">三月突围</p><p class="header">嫩草醒后伸个懒腰</p><p class="header">纯朴的一群</p><p class="header">知端坐在院中的大师</p><p class="header">他们为你来了</p><p class="header">为你的一生感动</p><p class="header">为纪念你的一生操劳</p><p class="header">伸出双手或是翅膀</p><p class="header">阳光走在风雨后</p><p class="header">给一些爱意融融的情怀</p><p class="header">积累了几十年以后</p><p class="header">人们忘不了你这不同凡俗之人</p><p class="header">天赐予的空旷感觉</p><p class="header">这一片空旷</p><p class="header">充满来来往往间的欣赏</p><p class="header">脚步踏踏</p><p>他日的<a href="http://m.so.com/s?q=%E6%9E%AF%E8%8D%89&amp;src=newstranscode" class="qkw">枯草</a>和今春的返青</p><p class="header">都痛得低吟</p><p class="header">在鸽子丢失之前</p><p class="header">不多的心爱和情趣悄然隐退</p><p class="header">夕阳的两鬓夹着银丝</p><p class="header">倦怠是一定的</p><p class="header">没有考证的必要</p><p class="header">纸鹞收回高傲的心性</p><p class="header">用曾经俯视的眼神</p><p class="header">告别天空</p><p>岁荣<a href="http://m.so.com/s?q=%E5%B2%81%E6%9E%AF&amp;src=newstranscode" class="qkw">岁枯</a></p><p class="header">都是这一片空旷的财富</p><p class="header">供以后的日子饱览眼福</p><p class="header">不再穿行其间</p><p class="header">放飞什么了</p><p class="header">站在白色栏杆之外</p><p class="header">高高灰墙之上</p><p class="header">回首</p><p class="header">流水让谁也没有话说</p><p class="header">留守</p><p class="header">那个城市是一盏灯</p><p class="header">聚集着散淡的目光</p><p class="header">缘分两次擦肩而过</p><p><a href="http://m.so.com/s?q=%E5%A4%A7%E6%A7%90%E6%A0%91&amp;src=newstranscode" class="qkw">大槐树</a>的后代多如牛毛</p><p class="header">这个世界里</p><p class="header">缺一不可只是一条理论</p><p>向往的<a href="http://m.so.com/s?q=%E4%B8%80%E6%9C%B5%E4%BA%91&amp;src=newstranscode" class="qkw">一朵云</a></p><p class="header">漂浮着诱惑不可言喻</p><p class="header">手举得很矜持很无奈</p><p class="header">一座深深庭院的主人</p><p class="header">呵护着亭台楼榭中的一座雕像</p><p class="header">是孙辈为你付出</p><p><a href="http://m.so.com/s?q=%E7%94%B2%E5%A3%B3%E8%99%AB&amp;src=newstranscode" class="qkw">甲壳虫</a>在高速上赛跑</p><p class="header">叶子的位置上会是谁</p><p class="header">谈论着你的名字</p><p class="header">一车人都会感觉到温暖</p><p class="header">还有隐隐的愧疚与感激</p><p class="header">陪着一尊塑像</p><p class="header">让秋风吹开皱着的心情</p><p class="header">心无旁骛地修行</p><p>到天黑吧别到天荒</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.gmw.cn/newspaper/2015-06/18/content_107372764.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='64b2b0f4c624ebeab1226143a83c7ed0'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>灰色记忆</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%81%B0%E8%89%B2%E8%AE%B0%E5%BF%86&amp;pn=1&amp;pos=10&amp;m=038fb8456715bef9faeda220a0a83a1fe01b2026&amp;u=http%3A%2F%2Fxj.people.com.cn%2Fn%2F2015%2F0112%2Fc219077-23524898.html" data-pos="1"> 复兴之路上,无须流连"大国<b>记忆</b>" </a>   <li> <a href="/transcode?q=%E7%81%B0%E8%89%B2%E8%AE%B0%E5%BF%86&amp;pn=2&amp;pos=1&amp;m=9330baf8d99ee1b32e58c6430d69fc366dd7375e&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fgxnews_0217%2F4109711.html" data-pos="2"> 桂林不少女子求美失败 美容<b>灰色</b>产业链浮出水面 </a>   <li> <a href="/transcode?q=%E7%81%B0%E8%89%B2%E8%AE%B0%E5%BF%86&amp;pn=2&amp;pos=2&amp;m=1deb3ff2e2485eaa4f1eca6487929717e3202b83&amp;u=http%3A%2F%2Ffun.youth.cn%2F2015%2F1024%2F2482293.shtml" data-pos="3"> 代理仁新曲《谢谢你离开我》 道出埋藏<b>记忆</b>的伤疤 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '深灰色的庭院(组诗) ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '深灰色的庭院(组诗) '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";