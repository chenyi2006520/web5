s:14346:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>档案馆微信公众号“青岛记忆”将开通- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">档案馆微信公众号“青岛记忆”将开通</h1> <p id="source-and-time"><span id=source>大众网</span><time id=time>2016-02-28 17:16:25</time></p> </header>  <div id="news-body"><p>“<a href="http://m.so.com/s?q=%E9%9D%92%E5%B2%9B%E8%AE%B0%E5%BF%86&amp;src=newstranscode" class="qkw">青岛记忆</a>”微信公众号由青岛市档案馆主办。致力于通过分享历史档案、照片及视频,解密青岛历史上的人物与事件,展现青岛民俗与风貌。该公众号将于下月初开通,其开通将为岛城广大文史爱好者搭建一个青岛历史文化学习与交流的平台。本报记者</p><p>记者从山东省引进国外智力工作视频会议上获悉，“十三五”时期，山东将引进外国专家总量15万人次，实施重点引智项目800项，出国、出境培训人员7500 人。据山东人民广播电台<a href="http://m.so.com/s?q=%E3%80%8A%E5%B1%B1%E4%B8%9C%E6%96%B0%E9%97%BB%E3%80%8B&amp;src=newstranscode" class="qkw">《山东新闻》</a>报道，2016年，山东将突出“高精尖缺”导向，以人才项目为抓手，精准引进高端急...[详细]</p><p>山东省质监局与省住建厅日前对全省78家建设工程质量检测机构进行了专项监督检查，占全部检测机构的26.2%。其中，对<a href="http://m.so.com/s?q=%E6%B5%8E%E5%AE%81&amp;src=newstranscode" class="qkw">济宁</a>鸿启建设工程检测有限公司等7家机构进行行政处罚，对济南<a href="http://m.so.com/s?q=%E4%B8%9C%E5%8D%87&amp;src=newstranscode" class="qkw">东升</a>建设工程检测有限公司等7家进行全省通报批评。[详细]</p><p>独自给病床上的母亲喂水、喂饭、端尿盆……最近，临沂市兰陵县3岁女童<a href="http://m.so.com/s?q=%E8%96%87%E8%96%87&amp;src=newstranscode" class="qkw">薇薇</a>照顾重病母亲的事感动了全<a href="http://m.so.com/s?q=%E4%B8%B4%E6%B2%82&amp;src=newstranscode" class="qkw">临沂</a>。王洪英生病以来，张保立将更多的精力放到妻子身上，女儿薇薇每晚都跟着奶奶，第二天一早再回到自己家。[详细]</p><p>记者26日从<a href="http://m.so.com/s?q=%E6%B0%91%E6%94%BF%E9%83%A8&amp;src=newstranscode" class="qkw">民政部</a>获悉，为加强未成年人保护工作，民政部近日成立未成年人(留守儿童)保护处，将建立完善未成年人保护工作机制和服务体系，全面摸底排查、完善农村留守儿童信息管理。[详细]</p><p>2月26日，全自主化、世界上自动化等级最高的全自动<a href="http://m.so.com/s?q=%E6%97%A0%E4%BA%BA%E9%A9%BE%E9%A9%B6&amp;src=newstranscode" class="qkw">无人驾驶</a>地铁列车在中车青岛<a href="http://m.so.com/s?q=%E5%9B%9B%E6%96%B9%E6%9C%BA%E8%BD%A6%E8%BD%A6%E8%BE%86%E8%82%A1%E4%BB%BD%E6%9C%89%E9%99%90%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">四方机车车辆股份有限公司</a>下线。据悉，列车在中车四方股份公司完成相关试验后，年内将开赴国内首条自主化全自动无人驾驶地铁线路-- 北京燕房线投入试运营。[详细]</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://sd.dzwww.com/sdnews/201602/t20160228_13898140.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='be830b7d2a3b1126131664acbec49ceb'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>青岛记忆</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%9D%92%E5%B2%9B%E8%AE%B0%E5%BF%86&amp;pn=1&amp;pos=4&amp;m=976ac577da2eb10c15924aedb4464079af42af10&amp;u=http%3A%2F%2Fwww.sd.xinhuanet.com%2Fwhsd%2Fwhsd%2F2016-02%2F29%2Fc_1118184758.htm" data-pos="1"> 【城市<b>记忆</b>】百年<b>青岛</b>火车站老照片 </a>   <li> <a href="/transcode?q=%E9%9D%92%E5%B2%9B%E8%AE%B0%E5%BF%86&amp;pn=1&amp;pos=5&amp;m=b8951aabb65bf4e23b8536bc69a9ddd6acd51405&amp;u=http%3A%2F%2Fqingdao.iqilu.com%2Fjiaoyu%2Fjyzx%2F2016%2F0229%2F2704084.shtml" data-pos="2"> <b>青岛</b>一场不寻常的升旗仪式 帮你寻找童年<b>记忆</b> </a>   <li> <a href="/transcode?q=%E9%9D%92%E5%B2%9B%E8%AE%B0%E5%BF%86&amp;pn=1&amp;pos=6&amp;m=a2bb9a0744c5a1cd18cdd57af2db956349b8d661&amp;u=http%3A%2F%2Fqd.ifeng.com%2Fqingdaoyinxiang%2Fdetail_2015_08%2F25%2F4275503_0.shtml" data-pos="3"> 【抗战<b>青岛记忆</b>】血肉谱成英雄史诗 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '档案馆微信公众号“青岛记忆”将开通' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '档案馆微信公众号“青岛记忆”将开通'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";