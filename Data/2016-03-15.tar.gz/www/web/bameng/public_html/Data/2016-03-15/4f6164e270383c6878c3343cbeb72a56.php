s:18008:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>兰州打掉磁铁遥控“猜瓜子”骗抢团伙- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">兰州打掉磁铁遥控“猜瓜子”骗抢团伙</h1> <p id="source-and-time"><span id=source>每日甘肃网</span><time id=time>2016-03-14 08:33:00</time></p> </header>  <div id="news-body"><p>兰州打掉磁铁遥控“<a href="http://m.so.com/s?q=%E7%8C%9C%E7%93%9C%E5%AD%90&amp;src=newstranscode" class="qkw">猜瓜子</a>”骗抢团伙</p><p>查证落实案件33起呼吁受骗抢群众尽快与警方联系</p><p><img src="http://p32.qhimg.com/t012e185aefed470fe2.jpg?size=300x199"></p><p><img src="http://p35.qhimg.com/t01af7125aa94005f04.jpg?size=300x224"></p><p class="img-title">◇记者金振华文/图</p><p><a href="http://m.so.com/s?q=%E6%AF%8F%E6%97%A5%E7%94%98%E8%82%83%E7%BD%91&amp;src=newstranscode" class="qkw">每日甘肃网</a>-科技鑫报讯通过信息研判和串并案侦查，兰州市公安局便衣侦查支队一大队近日打掉一个长期盘踞在<a href="http://m.so.com/s?q=%E5%85%B0%E5%B7%9E%E5%B8%82&amp;src=newstranscode" class="qkw">兰州市</a>部分医院、火车站、五泉下广场、<a href="http://m.so.com/s?q=%E5%85%B0%E5%B7%9E%E8%A5%BF%E7%AB%99&amp;src=newstranscode" class="qkw">兰州西站</a>、安宁等地的诈骗抢劫团伙。据办案民警介绍，该团伙以老乡、家庭关系为纽带，利用“猜瓜子”赌博方式，诱骗来兰看病人员、过路乘客和不明真相的中老年人，先骗后抢。目前便衣民警已抓获团伙成员6人，上网追逃2人，破获诈骗、抢夺案件100余起，查证落实案件33起。警方呼吁近年来有类似被骗抢经历的市民或知情人尽快和办案民警联系或反映线索。谢警官:13399311705;刘警官:13399311978</p><p class="header">五旬妇女被骗</p><p class="header">民警接报锁定嫌犯行踪</p><p>便衣民警接报的首起“猜瓜子”诈骗案件发生在2015年12月9日，受害人刘某从外地来兰看病，上午9时许，等待化验结果的刘某从<a href="http://m.so.com/s?q=%E7%9C%81%E4%BA%BA%E6%B0%91%E5%8C%BB%E9%99%A2&amp;src=newstranscode" class="qkw">省人民医院</a>出来，打算到附近吃点东西。</p><p>在途经医院西侧的人行通道时，刘某看到一名中年男子蹲在路边，面前摆着毯子，上面放着白色小瓷盘。男子向碗内扔几个瓜子后用木片盖上，周围人猜碗内瓜子数量。猜对了，男子向猜对的人返还200元。猜错了，摊主就把押的100元收走。看到有两名中年女子连赢几把，抱着试试看、赢点钱的心理，刘某也押了100元。第一把输了，赢钱的两名中年女子怂恿她再次下注，结果赢了。就这样，输多赢少，刘某很快就输了2100元。看到刘某犹豫不决是否继续下注时，身边一名中年男子突然抢过刘某装钱的背包转身就跑。刘某跟着追了几步，回头发现摆摊的男子和两名中年女子也四散离去。</p><p>面对突如其来的遭遇，刘某整个人都傻了，沮丧着回到医院，便瘫坐在椅子上。拿到化验结果后，刘某回到亲戚家里，到晚上在再三追问下，才述说了白天的遭遇。</p><p>12月10日上午，接到刘某报案后，便衣侦查支队一大队立即介入调查。调取案发周边地段的监控视频时民警发现，这伙人有很强的反侦查意识，将行骗地点特意选在地铁施工场地附近，这里道路狭窄，治安监控探头很难全方位覆盖。随后，民警扩大调查范围，通过对附近商铺及沿街视频监控画面逐段拼接，完整地还原了这伙人骗抢后的行踪。原来，这伙人骗抢后沿着地铁施工现场档板四散离开，在省中医学院附近的公交车站汇合，然后上公交车离去。</p><p>民警<a href="http://m.so.com/s?q=%E5%AE%88%E6%A0%AA%E5%BE%85%E5%85%94&amp;src=newstranscode" class="qkw">守株待兔</a></p><p class="header">布控抓获6名团伙成员</p><p>“这是典型团伙作案，团伙成员分工明确，犯罪手法熟练，有预谋的结伙作案。”便衣侦查一大队卢大队长告诉记者，市公安局及便衣侦查支队相关领导听取汇报后明确要求，这类团伙作案对社会危害大，影响恶劣，必须尽快结案，肃清社会影响。</p><p>随后，大队立即安排警力在<a href="http://m.so.com/s?q=%E4%BA%94%E9%87%8C%E9%93%BA&amp;src=newstranscode" class="qkw">五里铺</a>、西站、火车站等地蹲坑守候，并在市公安局相关部门的配合下，在红山根一带查找到了几名嫌疑人的落脚点。通过十几天的跟踪守候后民警发现，这伙人是五男三女，间隔一两天就三三两两地汇合在一起，在城区部分医院、火车站、五泉下广场、兰州西站、安宁等地摆摊行骗。团伙中有人专门望风，有人当托“摇车”，有人装扮成过<a href="http://m.so.com/s?q=%E8%B7%AF%E8%A1%8C%E4%BA%BA&amp;src=newstranscode" class="qkw">路行人</a>，在受害人反应过来是骗局时，言语中劝其要“认赌服输”，还负责在摆摊男子“撤离现场”时拦阻受害人，并跟踪受害人，看其是否报警。</p><p>今年1月初，在初步摸清该团伙情况后便衣民警开始收网，包括主要成员陈某、袁某在内的6名嫌疑人先后落网，其余两人在逃。办案民警告诉记者，8名团伙成员都是河南籍人，其中<a href="http://m.so.com/s?q=%E4%B8%89%E7%94%B7%E4%B8%89%E5%A5%B3&amp;src=newstranscode" class="qkw">三男三女</a>是夫妻关系。自2013年9月开始，形成固定团伙关系，在兰州市“猜瓜子”行骗抢夺，在甲地得手后立即转移至乙地继续行骗，每次骗抢来的钱款团伙成员均分。其中负责摆摊“摇碗子”的袁某特征非常明显，身高只有1.5米左右。他事先“特制”了一粒瓜子，这粒瓜子里面装有铁粒，然后用<a href="http://m.so.com/s?q=%E5%88%9B%E5%8F%AF%E8%B4%B4&amp;src=newstranscode" class="qkw">创可贴</a>裹上磁铁缠绕在手指上。这样只要通过操纵，每次开碗时就会少、或多1粒瓜子，投注的人永远不可能猜对。“行骗人在瓜子上做了手脚，摆摊的人手中有磁铁，可改变碟内瓜子的个数。围观者下注时，看起来是压100元赔200元，但不法分子会用极快的手法改变碟内瓜子数目，让你赢就赢，让你输就输，看到钱多就抢。”办案民警对记者说。</p><p class="header">警方接警数量多</p><p class="header">破案后查证落实难</p><p>办案民警告诉记者，接到刘某报案后，他们到市公安局110指挥中心查询类似报警，发现在两年多时间里，兰州市接到“猜瓜子”行骗报警电话500余次，但打掉该团伙后，团伙成员交待了100余起案件，警方目前只查证落实了33起案件。由于作案时间跨度大，很多案件嫌疑人只是大概记得在何地，骗子所抢金额大概是多少。目前警方查证落实的最大一起案件，被骗抢金额7100元。</p><p>“受害人基本上都是五六十岁的中老年人，这些人抱着谋利心理，看见有人赢钱，心想‘三个瓜子你怎么能变成两个?’于是受骗上当。”民警告诉记者，目前，该团伙已交代100余起案件，警方已查证落实33起。“在查证落实案件时，很多受害人都在外地，电话要么是空号，要么号码已经易主。还有部分受害人不配合，张嘴先问钱能不能要回来。”民警告诉记者，多数案件不能查证落实，对不法人员打击处理就有难度，呼吁近年来有类似被骗抢经历的市民或知情人尽快和办案民警联系或反映线索。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://gansu.gansudaily.com.cn/system/2016/03/14/015943441.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='1e6f16606f468694875dc895b92c45dd'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>吸铁石</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '兰州打掉磁铁遥控“猜瓜子”骗抢团伙' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '兰州打掉磁铁遥控“猜瓜子”骗抢团伙'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";