s:13765:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>全球最大欧泊原石现身上海- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">全球最大欧泊原石现身上海</h1> <p id="source-and-time"><span id=source>解放网</span><time id=time>2016-02-25 17:58:00</time></p> </header>  <div id="news-body"><p><img src="http://p35.qhimg.com/t0160c09f0a6e1a426e.jpg?size=600x475"></p><p>上周，在<a href="http://m.so.com/s?q=%E9%9D%9E%E6%B4%B2&amp;src=newstranscode" class="qkw">非洲</a>做宝石生意的刘先生带着一块重达6公斤的<a href="http://m.so.com/s?q=%E6%AC%A7%E6%B3%8A&amp;src=newstranscode" class="qkw">欧泊</a>原石回到上海，“这是我在非洲经商多年最大的收获!”</p><p>在刘先生家，记者看到了这块宝石的真身，个头比足球还大，阳光下，变幻出<a href="http://m.so.com/s?q=%E7%BA%A2%E6%A9%99%E9%BB%84%E7%BB%BF%E9%9D%92%E8%93%9D%E7%B4%AB&amp;src=newstranscode" class="qkw">红橙黄绿青蓝紫</a>七色光彩。</p><p>这块宝石来自<a href="http://m.so.com/s?q=%E5%9F%83%E5%A1%9E%E4%BF%84%E6%AF%94%E4%BA%9A&amp;src=newstranscode" class="qkw">埃塞俄比亚</a>WELO地区的火山岩欧泊矿区，是截至目前为止非洲大陆开采出的最大一块欧泊原石，被<a href="http://m.so.com/s?q=WELO&amp;src=newstranscode" class="qkw">WELO</a>当地部落供奉为“神物”。凭着与当地部落长老多年的交情，以及不菲的代价，刘先生终于在猴年春节期间，将这块神物请回了中国。</p><p>记者查询<a href="http://m.so.com/s?q=%E5%90%89%E5%B0%BC%E6%96%AF%E4%B8%96%E7%95%8C%E7%BA%AA%E5%BD%95&amp;src=newstranscode" class="qkw">吉尼斯世界纪录</a>后发现，此前全球最大一块欧泊原石，是<a href="http://m.so.com/s?q=%E6%BE%B3%E5%A4%A7%E5%88%A9%E4%BA%9A&amp;src=newstranscode" class="qkw">澳大利亚</a>欧泊收藏家凯恩拥有的2.268公斤的欧泊石，2012年，沙特王室方面曾出价2500万人民币，凯恩也没舍得将宝贝转让，但刘先生的想法和凯恩不同，“有合适的买家，我就会出手，这样的稀世珍宝是属于全人类的，不同的收藏者将赋予它不同的经历，收藏的人越多，越能体现出它的价值。”</p><p><img src="http://p31.qhimg.com/t017f64ec5979073a33.jpg?size=600x450"></p><p><img src="http://p34.qhimg.com/t01bd9d60998f51dc3d.jpg?size=600x483"></p><p class="img-title">背景资料:</p><p>欧泊是世上最<a href="http://m.so.com/s?q=%E7%8F%8D%E8%B4%B5%E7%9A%84%E5%AE%9D%E7%9F%B3&amp;src=newstranscode" class="qkw">珍贵的宝石</a>之一，它以绚丽多彩的光焰，被公认为世界上最奇丽的宝石，誉为“集宝石之美于一身”。西方市场中上品黑欧泊的价格直逼钻石，有报道称:重5克拉的上品黑欧泊，每克拉售价高达3万美元。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.jfdaily.com/life/new/201602/t20160225_2142475.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='2afe1b5a04968d22b0b51f152e93e075'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>欧泊</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%AC%A7%E6%B3%8A&amp;pn=1&amp;pos=5&amp;m=b31d0d36756a9a64eb16cfe8da5bcac0044ec7a7&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0611%2F07%2F9UELJK5Q00014Q4P.html" data-pos="1"> 万科<b>欧泊</b>配套小学确定非省一级 </a>   <li> <a href="/transcode?q=%E6%AC%A7%E6%B3%8A&amp;pn=1&amp;pos=6&amp;m=beabfc46ed01caefc1f91d57cd74901f79233a09&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0606%2F10%2F9U23NCHH00014AED.html" data-pos="2"> 万科<b>欧泊</b>陷"学位欺诈门"?(图) </a>   <li> <a href="/transcode?q=%E6%AC%A7%E6%B3%8A&amp;pn=1&amp;pos=7&amp;m=3b2ed3e2ae8f7d5cad633a219d8b66b97a0d4c8a&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0428%2F09%2F9QTKDEQ100014AED.html" data-pos="3"> 万科·<b>欧泊</b> 首付54万拥万博商圈三房(组图) </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '全球最大欧泊原石现身上海' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '全球最大欧泊原石现身上海'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";