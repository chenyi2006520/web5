s:23895:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>2016年卫视竞争加剧，我们不得错过的六大IP- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">2016年卫视竞争加剧，我们不得错过的六大IP</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-08 23:45:00</time></p> </header>  <div id="news-body"><p>2015年“一剧两星”新政之下，电视荧屏所播放的电视剧不再过于集中，呈现出相对“百花齐放”的格局，到了2016年这样的状况会愈加明显，形成一线卫视打独播战，二三线卫视打拼播战，越来越多种类的电视剧将出现在观众面前。从一线卫视在电视剧购剧资源的投入上看，“大投入”几乎成为竞争的标配。“圈地”、“囤剧”、“资本竞争”成为了明年卫视电视剧的一大打法，<a href="http://m.so.com/s?q=%E4%BC%98%E8%B4%A8%E5%89%A7&amp;src=newstranscode" class="qkw">优质剧</a>也越来越多。所以可以预想的是，2016年的电视剧市场将会是改朝换代最为厉害的一年，其中最典型的便是一大批具有网络气质，配搭高颜值演员的大制作电视剧将霸屏2016。</p><p class="header">◆◆◆</p><p class="header">架空类</p><p>1、响应号召，用传统文化重新建构一个全新的世界体系</p><p>在刚结束的全国电视剧行业年会上，<a href="http://m.so.com/s?q=%E6%9D%8E%E4%BA%AC%E7%9B%9B&amp;src=newstranscode" class="qkw">李京盛</a>司长在谈到玄幻类题材时表示，“内容导向不要有偏差，惩恶扬善、抱打不平，符合中国人传统，用神魔形式表达人间冷暖，不要有封建迷信、不要有过度暴利和情色。”由九州梦工厂国际文化传播有限公司出品，知名导演曹盾执导，<a href="http://m.so.com/s?q=%E9%BB%84%E8%BD%A9&amp;src=newstranscode" class="qkw">黄轩</a>、窦骁、周一围等人主演，改编自今何在同名小说的东方魔幻剧<a href="http://m.so.com/s?q=%E3%80%8A%E4%B9%9D%E5%B7%9E%C2%B7%E6%B5%B7%E4%B8%8A%E7%89%A7%E4%BA%91%E8%AE%B0%E3%80%8B&amp;src=newstranscode" class="qkw">《九州·海上牧云记》</a>正是这样一部响应主旋律的大剧。</p><p>该剧讲述了以人族皇族牧云家为核心，几大部族之间的爱恨纠葛与权力纷争。作为史上最难改编的IP之一，小说《九州·海上牧云记》有着庞大世界观架构，六族八部众多人物贯穿于九州纪元，期间交织部族纷争、朝代更迭，以及不同部落和种族间相异的信仰、图腾、武器……其魔幻史诗题材对故事架构、服化道、特效要求极高。因此，剧组在制作方面一切从细节出发，丝毫不敢马虎。据悉，该剧投资超三亿，全电影制作班底，仅拍摄就将长达9个月。因叙事之宏大、参演演员之多、制作周期之长，可谓登顶国内电视剧制作之最。</p><p class="header">古装类</p><p>1、立足女性权谋 成就史上最高能女主</p><p>一部《甄嬛传》将宫斗剧推上巅峰，一部《琅琊榜》将男性权谋演绎的淋漓尽致，如若将两者优点汇集，会变成什么样?由上海克顿影视、丰璟传媒联合制作，金牌导演李慧珠执导，<a href="http://m.so.com/s?q=%E5%94%90%E5%AB%A3&amp;src=newstranscode" class="qkw">唐嫣</a>等主演的古装大剧<a href="http://m.so.com/s?q=%E3%80%8A%E9%94%A6%E7%BB%A3%E6%9C%AA%E5%A4%AE%E3%80%8B&amp;src=newstranscode" class="qkw">《锦绣未央》</a>会给你一个答案。</p><p>该剧讲述的是南北朝期间，出身北凉王族的少女心儿，因朝廷政变，被迫流落异乡，化身救命恩人李未央，回朝与仇敌斗智斗勇，尔虞我诈。她凭借无上的智慧与心胸，历尽艰险磨难，终为父正名，同时也收获了曲折感人的美好爱情。《锦绣未央》改编自同名出版小说，书中紧凑的剧情，精彩的人设，尔虞我诈的宫斗，使之在网络上连载以来，蝉联潇湘书院月票榜、钻石榜、订阅榜TOP1。为了更好地呈现这部小说，幕后团队认真打磨剧本两年多，不仅加重剧中男性观众爱看的朝堂之上的恩怨宫斗戏份，更是为了满足女性观众，做足小说中薄弱的感情戏部分，给观众一段唯美大气的<a href="http://m.so.com/s?q=%E5%80%BE%E4%B8%96%E4%B9%8B%E6%81%8B&amp;src=newstranscode" class="qkw">倾世之恋</a>。《锦绣未央》是一部绝对以女性为主视角的作品，刻画女主波澜壮阔、充满悬念的一生;它将以精致的服装造型与美术设计强化观众的视觉冲击力，呈现出古装历史正剧的视觉效果;而“收视女王”唐嫣和罗晋的四度携手，也将是一大看点。这部将正剧的魂和核附着于偶像的皮和形上的大剧将如何打动人心，值得期待。</p><p>2、无IP定义时代里的大IP，打造新概念轻玄幻武侠偶像剧</p><p>如若按照现在的定义，多次被翻拍的金庸、<a href="http://m.so.com/s?q=%E5%8F%A4%E9%BE%99&amp;src=newstranscode" class="qkw">古龙</a>等大师的作品，算是没有 IP 定义时代里的大 IP，<a href="http://m.so.com/s?q=%E3%80%8A%E9%A3%9E%E5%88%80%E5%8F%88%E8%A7%81%E9%A3%9E%E5%88%80%E3%80%8B&amp;src=newstranscode" class="qkw">《飞刀又见飞刀》</a>便是其中之一。由鑫盛影视携手和力辰光、国奥影业、东阳春秋联合出品，<a href="http://m.so.com/s?q=%E9%98%BF%E8%AF%BA%E5%B7%A5%E4%BD%9C%E5%AE%A4&amp;src=newstranscode" class="qkw">阿诺工作室</a>承制，林国华金牌制作团队全力打造，<a href="http://m.so.com/s?q=%E5%88%98%E6%81%BA%E5%A8%81&amp;src=newstranscode" class="qkw">刘恺威</a>、杨蓉、吴映洁、黄明、关智斌等人主演的玄幻武侠古装电视剧《飞刀又见飞刀》已于去年年底杀青，并预计将在今年登陆电视荧屏。</p><p><img src="http://p32.qhimg.com/t0179e444062c45aa90.jpg?size=626x955"></p><p>这部剧改编自古龙晚期代表作之一《飞刀又见飞刀》。原著的故事线路简洁，讲述了小李飞刀传人李坏与仇家之女薛采月夹在家族仇恨与情爱纠葛中的传奇人生。原著本身就有多种解读方式，而这次新版电视剧《飞刀又见飞刀》不仅在内容上添加玄幻色彩，增加了更贴近现代观众喜好的改编，并利用高科技特效来补充说明小李飞刀的神奇之处。此外，该剧在服化道上同样精心设置，制作团队使用唯美又贴近潮流的服装造型，配上演员们干净清透的妆容，使角色造型更符合现代观众审美。</p><p>而从演员阵容上看，这是刘恺威2016年自《寂寞空庭春欲晚》之后的第二部古装剧，更是他的第一部武侠剧，由此可见这部剧对刘恺威的重要性。而对于广大的刘恺威粉丝来说，这部剧绝对也是一个巨大的惊喜。</p><p>3、大神级作品改编，金牌阵容重新定义新古装</p><p>影视市场IP风行的当下，华策克顿集团旗下上海剧芯文化联合乐视网拿到重要筹码，将目标瞄准了起点中文网大神级网络作家月关的大热小说<a href="http://m.so.com/s?q=%E3%80%8A%E9%94%A6%E8%A1%A3%E5%A4%9C%E8%A1%8C%E3%80%8B&amp;src=newstranscode" class="qkw">《锦衣夜行》</a>。</p><p><img src="http://p31.qhimg.com/t014c8ef555db363f0a.jpg?size=372x602"></p><p>原著小说《锦衣夜行》作为起点网点击量排名前10的历史类小说，以明朝靖难之役及<a href="http://m.so.com/s?q=%E6%B0%B8%E4%B9%90%E7%9B%9B%E4%B8%96&amp;src=newstranscode" class="qkw">永乐盛世</a>为背景，讲述了以<a href="http://m.so.com/s?q=%E5%A4%8F%E6%B5%94&amp;src=newstranscode" class="qkw">夏浔</a>为首的三兄弟在政权斗争、国家复兴、爱恨情仇上的选择和争夺的故事，是网络小说中难得的以真实历史背景为基础的小说。基于“网络历史小说第一人”月关的高人气IP，《锦衣夜行》有着优良的“史学基因”和“文学基因”，其中紧凑丰实的故事情节，深厚扎实的文化底蕴，丰满多样的人物角色也为该剧打下坚实基础。除此之外，本剧更另辟蹊径，开创古装版谍战元素，带来豪情热血又刺激紧张的精彩看点。</p><p>电视剧《锦衣夜行》团队更可谓是顶级阵容:金牌制片人<a href="http://m.so.com/s?q=%E6%9E%97%E5%9B%BD%E5%8D%8E&amp;src=newstranscode" class="qkw">林国华</a>、著名古装剧导演钟澍佳、<a href="http://m.so.com/s?q=%E6%A2%81%E8%83%9C%E6%9D%83&amp;src=newstranscode" class="qkw">梁胜权</a>，制作新秀林晋诺，鬼才编剧<a href="http://m.so.com/s?q=%E7%99%BD%E4%B8%80%E9%AA%A2&amp;src=newstranscode" class="qkw">白一骢</a>，大中华地区最顶尖的服装指导钟佳妮以及美术大师钟志鹏等大咖组成，使得该剧的品质得到保障。而霸道塘主张翰饰演的夏浔据说集合了古装剧所有男主的优良血统于一身，小人物逆袭锦衣卫，覆雨翻云，操控乾坤，他和韩国艺人朴敏英CP感十足。徐正曦、魏千翔、吴倩、宋妍霏等【鲜肉+小花】高颜值属性令整部剧的观赏体验整体提升了好几个档次。这样一个金牌阵容与SIP的组合，相信对得起观众的期待。</p><p class="header">当代剧</p><p>1、正能量国际范儿，首部聚焦法语翻译领域电视剧</p><p>电视剧<a href="http://m.so.com/s?q=%E3%80%8A%E7%BF%BB%E8%AF%91%E5%AE%98%E3%80%8B&amp;src=newstranscode" class="qkw">《翻译官》</a>是根据缪娟同名小说改编的IP大剧，讲述了从小励志当翻译的法语系女硕士生乔菲，在翻译天才程家阳指导下，成长为一名优秀的高级翻译，并与程家阳从彼此看不顺眼的欢喜冤家，逐渐互相了解吸引，成为困境中互相扶持的亲密爱人的故事。该剧是首部首部聚焦法语翻译领域的电视剧，为了完美的诠释中国人与西方文化碰撞的火花，剧组远赴法国、瑞士进行实地拍摄，做足“国际范儿”。剧中这样的碰撞将伴随着语言的延伸从工作到职业，从职业到事业，再从事业上升到人生的高度。在这样的高度中，全剧无时无刻都在散发着男女主角在感情与人生的抉择中交织的情愫。他们对翻译官职业的信仰，促使着他们追求更美好的生活，侧面激发了年轻人以及社会精英对自己人生更多探讨与思考。</p><p><img src="http://p33.qhimg.com/t01c5f0d16156b363e9.jpg?size=533x800"></p><p>两大主演由杨幂和黄轩搭档出演，经过他们各自多部叫好叫座的作品累积，该阵容一经推出便受到原著粉和网友们的关注，大家都期待两大实力主演碰撞出的火花。另外，《翻译官》的制作班底也让人信心十足:擅长青春剧的资深导演全力加持;电影《小时代》造型师黄薇倾力加盟;原著小说自带粉丝;如此优良的基因让《翻译官》必然成为年度最受关注的电视剧之一。该剧将在湖南卫视强势上线，到时一起领略“国际范儿”。</p><p>2、网络小说鼻祖，全新改编赋予新能量</p><p>网络文学创世纪时期最受瞩目的作者、文风十分独特的<a href="http://m.so.com/s?q=%E5%AE%89%E5%A6%AE%E5%AE%9D%E8%B4%9D&amp;src=newstranscode" class="qkw">安妮宝贝</a>，曾经在“榕树下”陪伴了很多人的青春的记忆，后来发书，也受到读者热烈追捧，成为网络文学界最先被正统文学出版界接纳、并随着时间经典化的作家。所以其作品的IP估值，不容小觑，其中，<a href="http://m.so.com/s?q=%E3%80%8A%E5%85%AB%E6%9C%88%E6%9C%AA%E5%A4%AE%E3%80%8B&amp;src=newstranscode" class="qkw">《八月未央》</a>和《彼岸花》的电视剧版权花落康曦影业。王小康导演曾执导过《钱多多嫁人记》、《中国家庭》、《新女婿时代》、《老公的春天》等剧，擅长都市情感表达。《八月未央》作为安妮宝贝小说改编的首部电视剧，由专业的强大的制作班底完成，是一切的前提。</p><p><img src="http://p33.qhimg.com/t01216ee663884be7b6.jpg?size=447x252"></p><p>《八月未央》是散文体小说，缺乏贯穿性的故事线索，在改编过程中，制作团队力求用讲故事的形式将它们串连起来，把小说里没有写出来的因果关系呈现出来。为了一改观众对安妮宝贝作品中，黑暗颓废的东西，也为剧情的饱满性，剧中将出现全新的人物。他们在尽量不影响原著人物性格、气质的基础上，充当了阳光、正能量的角色，更适应电视剧这种表现形式的特殊性。</p><p class="header">公众号: Vlinkage</p><p>合作/投稿请加微信:aiming_2787</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://toutiao.com/i6259708426037756417/">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='104f03f90ddc059561256f8ccc805918'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>鬼才编剧第一人</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%AC%BC%E6%89%8D%E7%BC%96%E5%89%A7%E7%AC%AC%E4%B8%80%E4%BA%BA&amp;pn=1&amp;pos=5&amp;m=0f527ef1a7d8f3767840099bc90250ece6d4cf76&amp;u=http%3A%2F%2Fgb.cri.cn%2F27224%2F2015%2F08%2F13%2F8351s5065433.htm" data-pos="1"> 电影《泡沫之夏》启动 梁咏琪首任制片人(组图) </a>   <li> <a href="/transcode?q=%E9%AC%BC%E6%89%8D%E7%BC%96%E5%89%A7%E7%AC%AC%E4%B8%80%E4%BA%BA&amp;pn=1&amp;pos=6&amp;m=d7720e99a377b85198b2e7301e0da3ac37bae12d&amp;u=http%3A%2F%2Fent.ifeng.com%2Fa%2F20150813%2F42473311_0.shtml" data-pos="2"> 电影《泡沫之夏》梁咏琪首任制片人 铁三角打造IP之王 </a>   <li> <a href="/transcode?q=%E9%AC%BC%E6%89%8D%E7%BC%96%E5%89%A7%E7%AC%AC%E4%B8%80%E4%BA%BA&amp;pn=1&amp;pos=7&amp;m=0a39fdcfd5d512d4e271299ca594b36d2473af2d&amp;u=http%3A%2F%2Ffun.youth.cn%2F2015%2F0921%2F2152355.shtml" data-pos="3"> 《泡沫之夏》制造童话爱情 梁咏琪帮女生圆梦 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '2016年卫视竞争加剧，我们不得错过的六大IP' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '2016年卫视竞争加剧，我们不得错过的六大IP'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";