s:24770:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>在阳光中尽情奔跑吧,激情马德里- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">在阳光中尽情奔跑吧,激情马德里</h1> <p id="source-and-time"><span id=source>大庆网</span><time id=time>2015-05-03 11:46:27</time></p> </header>  <div id="news-body"><p class="header">活得太慢</p><p><a href="http://m.so.com/s?q=%E9%A9%AC%E5%BE%B7%E9%87%8C&amp;src=newstranscode" class="qkw">马德里</a>的白天真长啊，长得你几乎不知道怎么打发这些时间。刚刚4月，马德里的日落已经是晚上10点了。说实话，白天太久让我很不适应，当我走到出酒店的门口，发现街上行人寥寥，一片寂静。这到底是怎么回事?难道热情的马德里就这样迎接一位来自<a href="http://m.so.com/s?q=%E9%81%A5%E8%BF%9C%E4%B8%9C%E6%96%B9&amp;src=newstranscode" class="qkw">遥远东方</a>的游客吗?我询问了下旅店的门童这里究竟是马德里还是巴格达，听了半天才弄明白他嘴里翻过来倒过去说的那个词--SIESTA，翻译过来叫做<a href="http://m.so.com/s?q=%E8%A5%BF%E7%8F%AD%E7%89%99&amp;src=newstranscode" class="qkw">西班牙</a>午睡。</p><p>在西班牙终年热烈的阳光下，安逸的西班牙人民想出了一个打发时间的好办法--睡觉。整个城市的商店、饭店下午两点全部关门，一直到傍晚近6点的时候才重新开业。好吧好吧，你们睡，我先撤了。</p><p>热情是件好事情，尤其是当你连嘴都没张就会有好几个晒太阳的兄弟围上来给你指路的时候。强烈的主人翁意识和对于雷峰精神的崇拜让马德里人根本就不好意思说出“不知道”这三个字。所以你会看到一个大叔用力地拍着我的肩膀，絮絮叨叨地说着中国人民和功夫李万岁，他一个劲地在我手里塞水果，和我大力地拥抱吻别，然后给我指了一条错路。我并没有责怪他的意思，要知道几乎你在路上遇到的马德里人有一半是不认路的，但是他们的热情足以像三伏天的阳光把这些你这些外国雪糕迅速融化，所以往他们指的反方向走好了。愿主保佑你。</p><p>托他们的福，我在原地转了两个180度之后找到了方向。从太阳门出发，一路前往西班牙广场。这里除了是狂欢的场所，还是文学爱好者顶礼膜拜之地。广场正中央竖立着《堂?吉诃德》作者塞万提斯的<a href="http://m.so.com/s?q=%E7%BA%AA%E5%BF%B5%E7%A2%91&amp;src=newstranscode" class="qkw">纪念碑</a>，纪念碑之下，骑着马的<a href="http://m.so.com/s?q=%E5%A0%82%E5%90%89%E8%AF%83%E5%BE%B7&amp;src=newstranscode" class="qkw">堂吉诃德</a>和仆人桑丘的塑象伫立在面前。“您再看看，”我听见<a href="http://m.so.com/s?q=%E6%A1%91%E4%B8%98&amp;src=newstranscode" class="qkw">桑丘</a>说，“那些不是巨人，是风车。那些像长臂的东西是风车翼，靠风转动，能够带动石磨。”而自信满满的堂吉诃德则吹胡子瞪眼睛:“在闯荡征战方面你是外行。他们就是巨人，如果你恐惧了，就和那边站着的小子靠边呆着，且看我去怎样同他们展开殊死的搏斗。”“是在说我吗?”我问，但是没有回答。这个食古不化的家伙即使变成了雕塑也绝不放弃自己的骑士梦想，不管是世界变成什么样子，他都会按照自己的准则来理解和生存，这也是他被西班牙人铸在这里的原因。让他面对着广场旁边宏伟的马德里塔吧，那塔是现代世界的风车，也是堂?吉诃德的下一个对手。</p><p>将近8点了，太阳仍旧热力逼人。我买了一杯啤酒，慢慢喝着，看着马德里的孩子们在中心广场踢足球。环顾四周发现和我一样清闲的家伙也不少。要是在自己的国家里这个时段可正是堵车高峰，所有人都在路上焦急地等着自己的头发变白，而马德里运营良好的交通管理和独特的天气因素决定了他们永远不会有那种忙着活、赶着死的状态，所有人整日里看上去就好象没什么工作似的。这些游荡的家伙现在关心的惟一问题是去哪个酒馆吃点火腿，然后点上一杯冰冰的啤酒。</p><p>咝，哎，痛快!在任何一个西班牙小酒馆里，都有切得薄如纸的生<a href="http://m.so.com/s?q=%E7%81%AB%E8%85%BF&amp;src=newstranscode" class="qkw">火腿</a>用来下酒。它的特别之处在于:用来腌制火腿的猪是在长满榛子树的山上度过催肥阶段的，它们惟一的食物是满山遍野的<a href="http://m.so.com/s?q=%E6%A6%9B%E5%AD%90&amp;src=newstranscode" class="qkw">榛子</a>，所以肉质肥瘦相间，腌好的火腿吃起来还有榛子的香味。如果你遇到这道菜，一定要试着把<a href="http://m.so.com/s?q=%E8%9C%9C%E7%93%9C&amp;src=newstranscode" class="qkw">蜜瓜</a>切成小段，用火腿片把蜜瓜卷起来吃。</p><p>但是并没有人告诉我这些窍门，我还是中规中矩地找了一家看上去比较历史悠久又不会太黑的餐厅。里面客人不多。老板热情地接待了我，“看啊!又来了一个贵客。”他说:“苦你妻娃。”我很有礼貌地纠正他:“我是中国人，不是日本人。我家人都很好，谢谢。”“都一样都一样，哈哈。”他顺了下自己嘴唇上的两撇小胡子，看了看我的肚子，表示非常满意。我点了一个<a href="http://m.so.com/s?q=%E4%BB%80%E9%94%A6%E6%8B%BC%E7%9B%98&amp;src=newstranscode" class="qkw">什锦拼盘</a>，一个血肠，一个黄油鸡块。老板吩咐后厨去做了，还殷勤地问我要不要参观一下这个很有西班牙氛围的小饭馆。再好也没有了，吃饭前听说一些当地的历史故事，会起到很好的开胃作用。“看见这个家伙了吗?”老板指着一张照片，神情立刻肃然起敬，“这个是西班牙历史上著名的疯子朗贝罗，他21岁就死在<a href="http://m.so.com/s?q=%E6%96%97%E7%89%9B%E5%9C%BA&amp;src=newstranscode" class="qkw">斗牛场</a>上。当时他的肚子被公牛的尖角挑破，我的天，他的肠子流了一地，那血啊喷得……”我突然觉得还是在餐桌上等我点的<a href="http://m.so.com/s?q=%E8%A1%80%E8%82%A0&amp;src=newstranscode" class="qkw">血肠</a>比较好，您说呢。</p><p>从饭馆出来，我打听了下最近的<a href="http://m.so.com/s?q=Flamenco&amp;src=newstranscode" class="qkw">Flamenco</a>舞厅。白天的话，你会觉得马德里整个大街上都是晃荡着的男人，抽烟卷的女人，还有就是吉普塞小偷的和“苦你妻娃”的日本人。但是入了夜，这些男人女人换上了黑色皮靴、白色绣花衬衣和翻褶的红色大裙，跳起弗拉明戈舞，你就认不出他们了。推开小剧场的门，高昂嘹亮的音乐伴随着酒味和烟味扑面而来。一个长发盖住眼睛的男人正在跳舞，他忽地把手放在胸前，接着用脚的各个部位踏击地板，伴随着吉他的节奏蹋着小碎步，一个骤停，然后跃起。旁边一个女舞者在不停地拍手、打响指，并在节奏的间隙喊上那么一两下。一曲终了，女舞者上场，她双手拿着Flamenco的独特乐器--响板。在舞蹈中，除了吉他，响板是必备道具。左右手响板所发出来的声音并不相同，左手边的声音低沉，代表男性;右边的较为高亢，代表女性。两个声音交织到一起，性感地如同缠绕在一起的花蔓。随着节奏的渐快，她扔掉了响板，双手把那殷红的荷叶缀边鱼尾裙甩地漫天飞舞，整个过程中，她的眼睛从来不往台下看，完全把整个舞台的空气凝结在自己的身上。下面口哨声、叫好声不绝于耳。这时候又上来了好几个女人，分成两个队伍，一对人踩着节奏向另一队人进攻，在逼到墙角的时候对方也开始返攻，两对人在对方的缝隙中擦肩而过，然后再度逼近，这次是两两相对，好似两个超现实主义的蝴蝶在煽动着翅膀，这是Flamenco中的群舞，也有人叫斗舞。在一阵你来我往之后，出现了几十秒的沉静，音乐响起，一个女舞者开始用高亢的声音演唱，沙哑的嗓音里蕴涵着无尽的悲凉和凄苦。她在诉说吉普塞的历史，他们的祖先如何饱受磨难，万里奔波，却始终没有找到属于他们的乐土。那声音直上云霄，也深深镌刻在了我的耳朵里。</p><p>凌晨四点，我和另一个刚认识的中国游客走出这家舞厅，天已经发亮。我们的肚子饿的要命，正在这时你猜我发现了什么?一个<a href="http://m.so.com/s?q=%E6%B2%B9%E6%9D%A1&amp;src=newstranscode" class="qkw">油条</a>店!走进才发现这里人吃油条是用油条沾巧克力吃的，等到我们要的东西端上来，我已经被那巧克力味道熏得昏昏欲睡了。在把油条扎进碗里前，我已经趴到桌子上睡着了。</p><p class="header">死得太早</p><p>当<a href="http://m.so.com/s?q=%E7%AA%97%E5%A4%96%E7%9A%84%E5%A3%B0%E9%9F%B3&amp;src=newstranscode" class="qkw">窗外的声音</a>把我从酒店那可爱的小床上吵醒的时候，应该已经是下午了。反正在这里我已经放弃了想确定时间的任何努力，彻底和自己的生物钟说了再见。和往常不同的是，今天街上熙熙攘攘，人们神色兴奋，渐渐汇聚成一股庞大的人潮，他们的方向只有一个--文塔斯斗牛场。</p><p>海明威说过，生活与斗牛差不多。不是你战胜牛，就是牛挑死你。西班牙的斗牛是由古代的狩猎演变而成，中世纪每当国王加冕、结婚、王太子出生或凯旋等庆祝活动，王宫贵族以驾马刺牛助兴。</p><p>两个身穿中古时代黑绒官服的前导，骑着高头大马走在前面，后面跟着一正一副两名各穿金绣和银绣紧身斗牛服的斗牛士和数名旗手。再后是六名刺牛手，他们头戴宽边软帽，身穿紧身衣裤，手执长矛，骑在身披红色铁甲的马背上。接着走进八个投镖手，他们上穿<a href="http://m.so.com/s?q=%E7%BA%A2%E8%89%B2%E7%B4%A7%E8%BA%AB%E8%A1%A3&amp;src=newstranscode" class="qkw">红色紧身衣</a>，下着齐膝短裤，腰扎金光闪烁的宽条丝带，脚蹬鲜艳的五彩长靴，手执亮晶晶的短小梭镖，梭镖上七十公分长的镖柄被五光十色的彩色丝绸包缠着。最后出场的是专为拖死尸用的装饰华丽的四匹骏马和数名掩埋血迹的清扫工。这一行人徐徐穿过斗牛场同观众见面，由先导向裁判官领取牛圈钥匙，随即散去。大喇叭里开始介绍牛的名字、年龄和体重。斗牛场的牛都是经过严格挑选和特殊训练的，它们全身毛色乌黑、双角犀利，是纯非洲种公牛，体重往往达千斤以上。</p><p>一头好像重型坦克似的公牛冲进斗牛场。几个斗牛士的助手，分别从几个护门后，拿着粉红色的斗篷，不断地出去挑逗牛。在比赛中他们的目的是引诱牛在场中央疲于奔命。它一会儿冲向这边，一会儿冲向另一边。助手则躲到掩护后面，引起全场大笑。几经挑逗和刺激，<a href="http://m.so.com/s?q=%E5%85%AC%E7%89%9B&amp;src=newstranscode" class="qkw">公牛</a>更加怒不可遏。这时乐队奏起了激昂的乐曲。两名刺牛手上场了。他们手持长矛，跨一匹骏马，飞驰进场。公牛正在寻找目标，看到有人进场便翘起双角，凭借全身的千斤重量猛冲过去。由于每匹马都有厚重的护甲，公牛并不能给马造成什么危害，刺牛手等的也是这一刻，在牛冲到身边的一刹那，刺牛手用长矛在牛的背部狠狠刺了两下。被刺伤的牛已经有些晕头转向了。两名镖师从场地深处跳了出来。他们没有马，手里拿着花镖。暴跳的公牛奔驰而来，镖师迎面而上，在即将顶撞的瞬间，顺势一闪身，将对儿花镖嗖地插在满身溅血的牛背上。</p><p>经过三次投镖后，牛背上已有六支梭镖在血泊中科动着。这时，在乐队的伴奏下，真正的<a href="http://m.so.com/s?q=%E6%96%97%E7%89%9B%E5%A3%AB&amp;src=newstranscode" class="qkw">斗牛士</a>手持利剑和红旗，健步登场。他脱帽向裁判官和观众致意后，不断地摆动<a href="http://m.so.com/s?q=%E7%BA%A2%E6%97%97&amp;src=newstranscode" class="qkw">红旗</a>，挑逗公牛冲刺。每次公牛冲来的时候，他都轻闪一步让开攻击。公牛卷着红布旋风一样从他身边刮过。在一次进攻中，公牛失血过多，重心不稳，差点跌倒。观众也随着发出嗨的声音，表示对斗牛士的赞扬。受到刺激的牛兽性大发，眼珠变得通红，眼睛瞪得如同铜铃一般，裁判官发出刺死了公牛的号令，斗牛士将红斗篷夹在腋下，再一次迈着优雅的脚步贴到离牛只有几米远的地方。</p><p>面对公牛，斗牛士双臂展开，好像要和牛拥抱。牛仿佛意识到了这是它最后一次冲击，它稳住身体，用蹄子刨了刨地，用布满血丝的眼睛寻找着这个最后对手的破绽，直到斗牛士挺身发出一声“嗨”的声音，这个信号刺激了它，公牛奔腾而至，沉重的蹄子踏在黄色的沙地上，随后洒下斑斑的血迹，斗牛士利剑出鞘，随后一个漂亮的起跃，把剑直直地送入对方的身体，利刃穿过牛的肩胛，直插入心脏，它死了。</p><p>如同《死在午后》这书里所说的，马德里人玩的就是这种命悬一线的优雅感觉。这倒很好的解释了马德里名字的由来。传说在古代，马德里只是一个</p><p class="header">马德里五星酒店的两个选择</p><p>1.WestinPalace<a href="http://m.so.com/s?q=Madrid&amp;src=newstranscode" class="qkw">Madrid</a></p><p>WestinPalace为旅客提供具古典美态的色彩，酒店外观壮丽，在这幢极具路易斯16世情调的建筑物内，有各式休闲及娱乐设施，住宿服务甚具水平。加上友善体贴的服务员，令人乐而忘返。</p><p>2.ACSantoMauroHotelMadrid</p><p>酒店属5星级，位处Madrid的Chamberi心脏地带，临近PaseodelaCastellana。区内满是19世纪的历史建筑，当年曾是西班牙贵族的住宅及宫殿大楼，气派非凡。其中一座皇宫正好是今日的AcSantoMauro酒店，她于1994年度过了100周年纪念，在1999年重新粉饰，糅合了古典风格及当代建筑元素。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.dqdaily.com/hyxw/lsdz/20150503/1198431.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='c369691187b8beb90783d666eb6dc675'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>在阳光下奔跑</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '在阳光中尽情奔跑吧,激情马德里' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '在阳光中尽情奔跑吧,激情马德里'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";