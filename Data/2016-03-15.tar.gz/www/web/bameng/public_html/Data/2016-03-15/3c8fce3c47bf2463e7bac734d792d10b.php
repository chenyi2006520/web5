s:15950:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>娃哈哈C驱动携明星团 “享跑”，挑战百公里- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">娃哈哈C驱动携明星团 “享跑”，挑战百公里</h1> <p id="source-and-time"><span id=source></span><time id=time>2015-05-14 11:36:47</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E5%A8%83%E5%93%88%E5%93%88&amp;src=newstranscode" class="qkw">娃哈哈</a>C驱动绝对是今年最热门的饮料新品之一。继携手<a href="http://m.so.com/s?q=%E6%9B%BC%E8%81%94&amp;src=newstranscode" class="qkw">曼联</a>高调北京发布后，娃哈哈又与<a href="http://m.so.com/s?q=%E6%90%9C%E7%8B%90&amp;src=newstranscode" class="qkw">搜狐</a>强强合作，开启“享跑C驱动，健康C生活”C驱动2015挑战百公里活动。5月13日，在被誉为北京“城市之肺”的国家<a href="http://m.so.com/s?q=%E5%A5%A5%E6%9E%97%E5%8C%B9%E5%85%8B%E6%A3%AE%E6%9E%97%E5%85%AC%E5%9B%AD&amp;src=newstranscode" class="qkw">奥林匹克森林公园</a>内，由近20位商业、体育、演艺、电视、互联网等领域的明星、名人组成的明星跑团格外抢眼，甚至连搜狐CEO<a href="http://m.so.com/s?q=%E5%BC%A0%E6%9C%9D%E9%98%B3&amp;src=newstranscode" class="qkw">张朝阳</a>也亲自出马，领跑本次 “享跑”活动。</p><p><img src="http://p34.qhimg.com/t011f95831242c0f218.jpg?size=600x400"></p><p class="img-title">明星带头，开启百公里挑战</p><p><img src="http://p34.qhimg.com/t01f693d005ccaf5b18.jpg?size=600x383"></p><p>当天上午，张朝阳、<a href="http://m.so.com/s?q=%E6%BD%98%E7%9F%B3%E5%B1%B9&amp;src=newstranscode" class="qkw">潘石屹</a>、马布里、郎永淳、<a href="http://m.so.com/s?q=%E5%91%A8%E9%9F%A6%E5%BD%A4&amp;src=newstranscode" class="qkw">周韦彤</a>、大鹏、李炜等近20位名人准时出现在了国家奥林匹克森林公园内跃跃欲试，主持人、著名体育评论员<a href="http://m.so.com/s?q=%E9%BB%84%E5%81%A5%E7%BF%94&amp;src=newstranscode" class="qkw">黄健翔</a>正式宣布，享跑2015挑战百公里活动揭幕跑启动。总计近千人的庞大跑步队伍从<a href="http://m.so.com/s?q=%E8%B5%B7%E8%B7%91%E7%BA%BF&amp;src=newstranscode" class="qkw">起跑线</a>出发，声势浩大，而跑在最前面的就是搜狐CEO张朝阳带队的<a href="http://m.so.com/s?q=%E6%98%8E%E6%98%9F%E5%9B%A2&amp;src=newstranscode" class="qkw">明星团</a>。参与本次活动的明星们都围绕奥林匹克森林公园完成了5公里、10公里的路程，而这仅仅是一个开始。因为他们将在接下来的两个月里，持续参与 “享跑”活动，直到完成最终的挑战--100公里!</p><p><img src="http://p31.qhimg.com/t0105fcc83d5866e98d.jpg?size=497x569"></p><p>跑步现场，沿途还设有三个娃哈哈C驱动补给站，作为今年最闪亮的新品，娃哈哈C驱动专为年轻人研发，原料选用了进口的优质<a href="http://m.so.com/s?q=%E6%9F%A0%E6%AA%AC%E6%B1%81&amp;src=newstranscode" class="qkw">柠檬汁</a>，富含柠檬精华和<a href="http://m.so.com/s?q=%E6%B0%B4%E6%BA%B6%E6%80%A7%E7%BB%B4%E7%94%9F%E7%B4%A0&amp;src=newstranscode" class="qkw">水溶性维生素</a>C，享受清新柠檬鲜汁的同时补充身体每日所需的维生素C。C驱动的来到，使得本次“享跑”活动变得格外时尚、靓丽。</p><p><img src="http://p32.qhimg.com/t01534671b1dadd299d.jpg?size=600x399"></p><p>活动主办方称，这次C驱动2015挑战百公里活动，旨在通过这种形式，号召所有人告别电脑、放下手机、脱下西装和高跟鞋，一起来参与健康、时尚的跑步活动，提倡树立健康的生活理念。</p><p><img src="http://p32.qhimg.com/t01862fa3bbf7445221.jpg?size=380x507"></p><p class="img-title">80场彩虹跑全国同步开跑</p><p><img src="http://p32.qhimg.com/t011df3371db444a543.jpg?size=600x400"></p><p>据悉，同一天，北京、上海、江苏、江西、山东等地的80所余高校的近万名学生还同步参加了色彩斑斓、年轻活力的C驱动彩虹跑活动。各地的参与者统一穿着C驱动白色T恤并且领了C驱动彩虹跑“通行证”，沿途在每个补给站接受彩色的洗礼，并且盖上纪念章。全程5公里的路程，伴随着欢乐与笑声，参与者完全感觉不到运动的疲惫。完成挑战后，身上已被覆盖了<a href="http://m.so.com/s?q=%E5%BD%A9%E8%99%B9%E8%88%AC%E7%BB%9A%E4%B8%BD&amp;src=newstranscode" class="qkw">彩虹般绚丽</a>颜色的参与者们还纷纷在活动背板上写下自己的C驱动“享跑”宣言。更有不少参与者表示，将与搜狐CEO张朝阳带领的“明星队”进行PK，看谁先完成百公里挑战。</p><p><img src="http://p34.qhimg.com/t01257357c1797d4c5d.jpg?size=600x400"></p><p>也想加入挑战队伍?扫描二维码，就可立即参与!来挑战明星吧!</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://mt.sohu.com/20150514/n413034188.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='abc4dfb7d1fbd2f6fe5a011c99e00cee'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>明星团</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%98%8E%E6%98%9F%E5%9B%A2&amp;pn=1&amp;pos=8&amp;m=bb6fc8b466522ade9eb943a1cb08c52ba3eb4c43&amp;u=http%3A%2F%2Fyule.sohu.com%2F20140627%2Fn401453496.shtml" data-pos="1"> 《中国梦想秀》今收官 "<b>明星团</b>"助阵大显身手 </a>   <li> <a href="/transcode?q=%E6%98%8E%E6%98%9F%E5%9B%A2&amp;pn=1&amp;pos=9&amp;m=6eae22c614304d111bbf006e5a160c928380866f&amp;u=http%3A%2F%2Fstyle.youth.cn%2F2015%2F0126%2F922906.shtml" data-pos="2"> 一不留神把大牌穿成淘宝款的<b>明星团</b> </a>   <li> <a href="/transcode?q=%E6%98%8E%E6%98%9F%E5%9B%A2&amp;pn=1&amp;pos=10&amp;m=e748ad0538cfd4285dd7a9a9b820fb2100604f91&amp;u=http%3A%2F%2Fqh.people.com.cn%2Fn%2F2014%2F1227%2Fc182762-23363791.html" data-pos="3"> "冬花"携<b>明星团</b>惊喜回归 《一年级》分享成长感悟 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '娃哈哈C驱动携明星团 “享跑”，挑战百公里' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '娃哈哈C驱动携明星团 “享跑”，挑战百公里'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";