s:17163:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>LOL虚空之眼维克兹:大魔王faker的黑科技 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">LOL虚空之眼维克兹:大魔王faker的黑科技 </h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-03-15 10:07:26</time></p> </header>  <div id="news-body"><p>在3月7日结束的IEM总决赛中，<a href="http://m.so.com/s?q=faker&amp;src=newstranscode" class="qkw">faker</a>大魔王掏出的“黑科技”中单维克兹完美地展现出了这位来自虚空的超远程法师蕴藏的威力。</p><p><a href="http://m.so.com/s?q=%E8%99%9A%E7%A9%BA%E4%B9%8B%E7%9C%BC&amp;src=newstranscode" class="qkw">虚空之眼</a>维克兹在降临召唤师<a href="http://m.so.com/s?q=%E5%B3%A1%E8%B0%B7&amp;src=newstranscode" class="qkw">峡谷</a>时最初的定位就是中路法师，但由于缺乏位移、控制不稳定和后期伤害乏力的原因逐渐成为了一个冷门英雄，甚至在更多时候大家把他用作辅助位。</p><p class="header">符文天赋推荐</p><p class="header">符文:</p><p><img src="http://p32.qhimg.com/t01e77ff6c6a74c4f6c.jpg?size=500x264"></p><p>章鱼哥的技能的基础伤害是非常高的，所以在符文中红色点出法术穿透的性价比是最高的，因为大眼睛虽然技能基础伤害非常高，但是AP加成就显得并不是很高了，对于这种特点的英雄我们可以通过叠加法术穿透来增加其的伤害。</p><p class="header">天赋:</p><p><img src="http://p33.qhimg.com/t01123bf0a833fad707.jpg?size=500x288"></p><p>在天赋中有必要提一点的就是，雷霆领主的法令对于大眼睛来说是非常重要的，因为大眼睛在对线的时候经常使用的三段就是QWE的组合连招，这三段在前期对线的时候一旦全部打中对手，对手的血量将会大大降低，再加上雷霆领主的法令的伤害，可以让大眼睛在三级的时候拥有三个小技能的情况下就有机会轻松完成一次漂亮的单杀。其次就是凶猛系的第二层，由于揭示弱点的存在让其他两点天赋都变得黯淡无光。</p><p class="header">出装</p><p><img src="http://p34.qhimg.com/t01df4fdf9ea538df24.jpg?size=500x295"></p><p class="img-title">出门装:</p><p>对于大眼睛来说最好的出门装就是多兰戒了，也是一套常规的AP法师出门的装备。</p><p class="header">中期核心:</p><p>对于现在的中单英雄来说，如果出全输出的装备会导致自身非常非常的脆皮，如果<a href="http://m.so.com/s?q=%E8%B5%B0%E4%BD%8D&amp;src=newstranscode" class="qkw">走位</a>一失误，很容易被对手集火一套击杀。所以像大眼睛这种没有位移英雄的法师在前期的AP装备的选择上还是要让自己更肉一些。在上文笔者也给大家提到过，大眼睛技能的基础伤害是非常高的，所以不用担心会不会因为出了这些肉的AP装而导致伤害的缺失，大可不必担心这点，这些装备对于大眼睛来说既能够提供伤害，又能够提供控制。</p><p class="header">后期神装:</p><p>这套是比较常见的一套法师的出装，这套出装的有点在于不仅能够提供大量的伤害，对于大眼睛来说让其也不会变得非常的脆皮，在团战中能够找到更合适的位置在后排使用R技能去对对手造成大量的伤害。</p><p class="header">连招技巧</p><p><img src="http://p32.qhimg.com/t01ba02d48df520aee9.jpg?size=500x295"></p><p>大眼睛虽然有着中路和辅助的两种截然不同的打法，不过从技能加点思路的角度上来说区别并不是太大。因为技能多少对于一些技能效果的影响时间产生不了太大的影响。</p><p>主W副Q，E一级，有大点大。这种加点思路似乎是目前最为常见的加点思路了，无论是中单的大眼睛还是辅助的大眼睛都基本上是这样加点，主W来增加W的伤害，因为W的伤害足且相对CD短(可以积攒两次)，Q虽然点多了可以增加它的减速效果，不过考虑到命中率的因素还是不值当我们主学Q的，当然你是高手Q谁谁中的话还是建议你主Q效果好，E技能一级和满级的击飞时间是一样的，所以我们学一级就可以了。</p><p class="header">玩法教学</p><p><img src="http://p31.qhimg.com/t011086610d89bf1f66.jpg?size=500x295"></p><p>我们先来分析一下大眼睛在前期的综合情况——其实大眼睛的前期能力还可以。首先，大眼睛在一级的时候就有两层W技能的充能，可以让你快速的清掉第一波兵领先对手到达二级。这让对手没有办法先到二级来打你一波，并且不得不和你同时推线，而没有任何英雄在一级的时候推线能力像大眼睛这么好。而当等级提升了以后，大眼睛在对线的时候尽可能的要跟对手“装”一下。你可以通过W技能推线的同时用Q技能不停地消耗对手，把Q技能往各个方向扔让你的对手无从躲避，笔者把这个套路叫做“声东击西”，并且我们还要一直找机会利用EWQ的连招来消耗对方的血量。这样对手可能基本上都在躲你的技能没时间想怎么攻击你了，所以让对手在对线的时候对你的技能变得应接不暇。当然小心打野的Gank已经是老生常谈的事了一定要小心对方的打野。</p><p>大眼睛的团战技巧其实很简单也很单一——主要看他施放大招的时机。我们应该一直在队伍后排等待团战的开启，理想情况下你的EWQR连招至少应该命中两个敌人，不管你打到谁，只要把伤害打出去就可以。大招过后你可以用Q和W来继续造成伤害，能多触发被动伤害是再好不过的了。如果有人突脸我们，留着E技能控制他是比较安全的办法。需要注意的是我们的大招并不需要任何的连招作为前置，如果你觉得有机会，比如队友先手使用了大招，那么别犹豫马上使用大招来攻击对手。</p><p>总结使用得当，你也能像faker一样carry。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/tech/yx/4759503_1.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='56efb8909340e0f015fed33c1fad2353'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>英雄联盟</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%8B%B1%E9%9B%84%E8%81%94%E7%9B%9F&amp;pn=1&amp;pos=3&amp;m=a8ec8e6b85feab494d29ef73ae98fd0bca85a0da&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Ftech%2Fyx%2F4757207_1.html" data-pos="1"> <b>英雄联盟</b>3月16日凌晨5点停机版本更新公告 加入战团系统 </a>   <li> <a href="/transcode?q=%E8%8B%B1%E9%9B%84%E8%81%94%E7%9B%9F&amp;pn=1&amp;pos=4&amp;m=88c8fee71916e283d0a0ef96671bfe38ff3ad544&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Ftech%2Fyx%2F4755057_1.html" data-pos="2"> <b>LOL</b>十大辅助英雄排行榜 前十竟无奶妈 </a>   <li> <a href="/transcode?q=%E8%8B%B1%E9%9B%84%E8%81%94%E7%9B%9F&amp;pn=1&amp;pos=5&amp;m=83fcfc761f5dff89436e5402906a80495b9b56f3&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Ftech%2Frdzx%2F4753381_1.html" data-pos="3"> <b>LOL</b>十大辅助英雄排行榜,奶妈无缘上榜 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + 'LOL虚空之眼维克兹:大魔王faker的黑科技 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + 'LOL虚空之眼维克兹:大魔王faker的黑科技 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";