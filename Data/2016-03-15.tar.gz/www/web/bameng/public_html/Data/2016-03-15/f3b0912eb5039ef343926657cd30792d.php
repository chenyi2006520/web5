s:18512:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>新《甜心战士》西内玛利亚饰人工智能 首触银幕- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">新《甜心战士》西内玛利亚饰人工智能 首触银幕</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-09 14:14:48</time></p> </header>  <div id="news-body"><p>新<a href="http://m.so.com/s?q=%E3%80%8A%E7%94%9C%E5%BF%83%E6%88%98%E5%A3%AB%E3%80%8B&amp;src=newstranscode" class="qkw">《甜心战士》</a>西内玛利亚饰人工智能 首触银幕_明星八卦_台海网新《甜心战士》<a href="http://m.so.com/s?q=%E8%A5%BF%E5%86%85%E7%8E%9B%E5%88%A9%E4%BA%9A&amp;src=newstranscode" class="qkw">西内玛利亚</a>饰人工智能 首触银幕 西内玛利亚新片演<a href="http://m.so.com/s?q=%E4%BA%BA%E5%B7%A5%E6%99%BA%E8%83%BD&amp;src=newstranscode" class="qkw">人工智能</a> 1905电影网讯 歌手兼女演员的西内玛利亚将首次主演电影作品<a href="http://m.so.com/s?q=%E3%80%8A%E7%94%9C%E5%BF%83%E6%88%98%E5%A3%AB+Tears%E3%80%8B&amp;src=newstranscode" class="qkw">《甜心战士 Tears》</a>,...</p><p>西内玛利亚首触银幕 新《甜心战士》饰人工智能_日本_电影网_1905....西内玛利亚新片演人工智能 1905电影网讯 歌手兼女演员的西内玛利亚将首次主演电影作品《甜心战士 Tears》,该片是根据永井豪创作的国民人气作品《甜心战士》...</p><p>西内玛利亚首触银幕 新《甜心战士》饰人工智能_娱乐推荐新闻_大众网西内玛利亚新片演人工智能。 <a href="http://m.so.com/s?q=m1905&amp;src=newstranscode" class="qkw">m1905</a>电影网授权刊载3月5日报道歌手兼女演员的西内玛利亚将首次主演电影作品《甜心战士 Tears》,该片是根据永井豪创作的国民...</p><p>西内玛利亚首触银幕 新《甜心战士》饰人工智能-中国网.江西西内玛利亚新片演人工智能。 歌手兼女演员的西内玛利亚将首次主演电影作品《甜心战士 Tears》,该片是根据永井豪创作的国民人气作品《甜心战士》而改编的新真</p><p><a href="http://m.so.com/s?q=%E7%94%9C%E5%BF%83%E6%88%98%E5%A3%AB&amp;src=newstranscode" class="qkw">甜心战士</a>花絮:西内玛利亚首触银幕 新《甜心战士》饰人工智能_<a href="http://m.so.com/s?q=%E7%94%B5%E8%A7%86%E7%8C%AB&amp;src=newstranscode" class="qkw">电视猫</a>西内玛利亚首触银幕 新《甜心战士》饰人工智能2016年03月05日 09:27 m1905电影网授权刊载3月5日报道歌手兼女演员的西内玛利亚将首次主演电影作品《...</p><p>西内玛利亚主演《甜心战士》饰美女<a href="http://m.so.com/s?q=%E4%BB%BF%E7%94%9F%E4%BA%BA&amp;src=newstranscode" class="qkw">仿生人</a>-中国娱乐网-西内玛利亚-...导读: 电影<a href="http://m.so.com/s?q=%E3%80%8A%E7%94%9C%E5%BF%83%E6%88%98%E5%A3%AB+-TEARS-%E3%80%8B&amp;src=newstranscode" class="qkw">《甜心战士 -TEARS-》</a>故事设定在21世纪末,世界各地气象怪异病毒横行,西内玛利亚饰演的人形机器人外号“甜心战士”,由<a href="http://m.so.com/s?q=%E5%A4%A9%E6%89%8D%E7%A7%91%E5%AD%A6%E5%AE%B6&amp;src=newstranscode" class="qkw">天才科学家</a>制造,与邪恶...</p><p>日本-电影网_1905.com西内玛利亚首触银幕 新《甜心战士》饰人工智能 歌手兼女演员的西内玛利亚将首次主演电影作品<a href="http://m.so.com/s?q=%E3%80%8A%E7%94%9C%E5%BF%83%E6%88%98%E5%A3%ABTears%E3%80%8B&amp;src=newstranscode" class="qkw">《甜心战士Tears》</a>,该片是根据永井豪创作的国民人气作品《甜心战士》而改编...</p><p><a href="http://m.so.com/s?q=%E3%80%8A%E5%AD%A3%E6%98%A5%E5%A5%B6%E5%A5%B6%E3%80%8B&amp;src=newstranscode" class="qkw">《季春奶奶》</a>曝光剧照 尹汝贞、<a href="http://m.so.com/s?q=%E9%87%91%E9%AB%98%E6%81%A9&amp;src=newstranscode" class="qkw">金高恩</a>饰演祖孙_韩国西内玛利亚首触银幕 新《甜心战士》饰人工智能_日本两会发言人傅莹:电影...摘要:创导演执导的韩国新片《季春奶奶》曝光剧照,<a href="http://m.so.com/s?q=%E5%B0%B9%E6%B1%9D%E8%B4%9E&amp;src=newstranscode" class="qkw">尹汝贞</a>、金高恩饰演的...</p><p>...実写『<a href="http://m.so.com/s?q=%E3%82%AD%E3%83%A5%E3%83%BC%E3%83%86%E3%82%A3%E3%83%BC%E3%83%8F%E3%83%8B%E3%83%BC&amp;src=newstranscode" class="qkw">キューティーハニー</a>』で映画初主演_西内玛利亚吧_百度贴吧今回の映画ではいい意味で<a href="http://m.so.com/s?q=%E9%87%8C%E5%88%87%E3%82%8A&amp;src=newstranscode" class="qkw">里切り</a>たいです。新しいハニーが生まれたと感じ...西内玛利亚说:“这次因为《甜心战士》这部作品首次主演电影,真的很开心,也希望...</p><p><img src="http://p31.qhimg.com/t01f27f9fda0288c1d8.jpg?size=640x440"></p><p class="img-title">西内玛利亚新片演人工智能</p><p>1905电影网讯 歌手兼女演员的西内玛利亚将首次主演电影作品《甜心战士 Tears》，该片是根据永井豪创作的国民人气作品《甜心战士》而改编的新真人版电影。</p><p>原作《甜心战士》曾于1973年在<a href="http://m.so.com/s?q=%E3%80%8A%E5%91%A8%E5%88%8A%E5%B0%91%E5%B9%B4Champion%E3%80%8B&amp;src=newstranscode" class="qkw">《周刊少年Champion》</a>上连载，东映动画曾将其制作成TV动画在<a href="http://m.so.com/s?q=%E6%9C%9D%E6%97%A5%E7%94%B5%E8%A7%86%E5%8F%B0&amp;src=newstranscode" class="qkw">朝日电视台</a>播出了25集。在2004年，<a href="http://m.so.com/s?q=%E5%BA%B5%E9%87%8E%E7%A7%80%E6%98%8E&amp;src=newstranscode" class="qkw">庵野秀明</a>曾经将该漫画拍成真人版首次搬上银幕，由佐藤江梨子主演并引起了巨大话题。</p><p>此次的新作将把背景设定在近未来，世界各地气候异常、未知病毒蔓延导致人口急剧下降，根据某位博士的愿望诞生了一名有着人类感情的人工智能甜心战士。在该作中，运动神经超群的西内玛利亚将首次挑战动作戏份。</p><p>回忆拍摄西内玛利亚称:“在这部新作中，将会颠覆大家喜爱的甜心形象，当然是好的方面。感觉是诞生了一个新的甜心。”对于动作戏份，西内玛利亚也称:“有大量的回旋踢和吊威亚的戏份，身上有多处淤青，可以说拍出来的戏份可以说相当有冲击力。这是一部注入了工作人员浑身技术和心血的作品。”</p><p>原作<a href="http://m.so.com/s?q=%E6%B0%B8%E4%BA%95%E8%B1%AA&amp;src=newstranscode" class="qkw">永井豪</a>对于西内玛利亚的出演也表示赞赏，“西内玛利亚代表了当代美女演员，诞生了新生的甜心战士并有着最新的影像技术，让甜心在‘空想的未来’大展身手，这就是美少女所复合的舞台!作为原作者也相当高兴，甜心战士将会如何在银幕上展现，请观众们敬请期待。”</p><p>据悉，《甜心战士Tears》将于今年秋季上映。</p><p class="header">原文来自:1905电影网</p><p>西内玛利亚首触银幕 新《甜心战士》饰人工智能_网易娱乐授权刊载3月5日报道 歌手兼女演员的西内玛利亚将首次主演电影作品《甜心战士 Tears》,该片是根据永井豪创作的国民人气作品《甜心战士》而改编的新真人版...</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.rmkb.com.cn/content/2016/03-09/14575040887345.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='78081864ade694c8d3480b927fd008b1'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>西内玛利亚</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%A5%BF%E5%86%85%E7%8E%9B%E5%88%A9%E4%BA%9A&amp;pn=1&amp;pos=6&amp;m=af76f61caea29bbb872be79950de1dced444f182&amp;u=http%3A%2F%2Fmt.sohu.com%2F20160308%2Fn439705423.shtml" data-pos="1"> <b>西内玛利亚</b>在首演电影《CUTIE HONEY》中挑战动作戏 </a>   <li> <a href="/transcode?q=%E8%A5%BF%E5%86%85%E7%8E%9B%E5%88%A9%E4%BA%9A&amp;pn=1&amp;pos=7&amp;m=686b4f59388823281a586eee341db91a136924d0&amp;u=http%3A%2F%2Fwww.rmkb.com.cn%2Fcontent%2F2016%2F03-09%2F14575040887345.html" data-pos="2"> 新《甜心战士》<b>西内玛利亚</b>饰人工智能 首触银幕 </a>   <li> <a href="/transcode?q=%E8%A5%BF%E5%86%85%E7%8E%9B%E5%88%A9%E4%BA%9A&amp;pn=1&amp;pos=8&amp;m=30fcba46cb15d6fe3c94314139e5e4a8529547f8&amp;u=http%3A%2F%2Fcomic.qq.com%2Fa%2F20160304%2F065367.htm" data-pos="3"> <b>西内玛利亚</b>主演漫改电影《甜心战士》 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '新《甜心战士》西内玛利亚饰人工智能 首触银幕' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '新《甜心战士》西内玛利亚饰人工智能 首触银幕'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";