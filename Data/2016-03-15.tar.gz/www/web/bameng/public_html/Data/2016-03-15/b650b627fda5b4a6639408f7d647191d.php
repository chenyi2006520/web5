s:17699:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>东京种第三季禁播?东京食尸鬼第二季第12集未解之谜 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">东京种第三季禁播?东京食尸鬼第二季第12集未解之谜 </h1> <p id="source-and-time"><span id=source>大宁网</span><time id=time>2016-03-14 09:55:58</time></p> </header>  <div id="news-body"><p>CCG在讨论金木的制裁问题上，有马若有所思的望着天空，看着地上英的遗体，以及金木的身份，还有以往的报告什么的，有马到底在想些什么呢?</p><p><img src="http://p31.qhimg.com/t01238d2ceaf7dc1b38.jpg?size=500x276"></p><p>东京 种最强<a href="http://m.so.com/s?q=%E5%9C%A3%E5%9C%B0%E5%B7%A1%E7%A4%BC&amp;src=newstranscode" class="qkw">圣地巡礼</a></p><p><img src="http://p33.qhimg.com/t014e9f1007190bc098.jpg?size=500x251"></p><p>糟了是因为他知道自己受伤情况，可以看到英良放下咖啡后靠在墙上，再一次暗示受伤严重。靠在墙上后因疼痛叫出声为不引起金木注意说咖啡难喝。</p><p><img src="http://p32.qhimg.com/t0168f63bf6fa8c85d7.jpg?size=500x251"></p><p>见到金木仍捂着眼睛，英良不由得走近，手按桌子支撑自己，血滴速更快。</p><p class="header">英良不是用自己的血救金木。</p><p class="header">他的伤不是金木造成的。</p><p class="header">1、 金木的伤未恢复</p><p>2、 用自己的肉救金木非要让自己受重伤?</p><p><img src="http://p31.qhimg.com/t0152d3031d400dc911.jpg?size=500x277"></p><p>1月续作<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%9C%E4%BA%AC%E9%A3%9F%E5%B0%B8%E9%AC%BC%E2%88%9AA%E3%80%8B&amp;src=newstranscode" class="qkw">《东京食尸鬼√A》</a>完结。早在去年7月第一季播出时该作就积攒了相当高的人气，BD销量也是非常可观，第二季也就自然而然得播出了，不过与漫画走不同路线的剧情也遭到了不少网友们的吐槽，可在最终结局还是和漫画差异不太大，留下的伏笔也是相当多，或许制作组真的已经在为第三季做准备了。</p><p><img src="http://p32.qhimg.com/t013abbf5d97803123e.jpg?size=419x485"></p><p>提到学长事件中装死不仅是向金木说明自己早知道他是 种，也与碰到野吕装死对应，11集中英良遇到野吕，看漫画的同好应该知道政道是半边身子被咬，英站的位置远些，所以被伤害面积不大，然后英良装死，对于一个小兵，是不值得注意的，多多良要找法寺，又不是专门来虐杀小兵，难道还一个个看看死没死然后补刀?英说:“犯蠢出了点错。”犯蠢?对啊，看到 种还喊出声?不就是犯蠢吗?因为犯蠢所以受伤，出错指的就是受伤这件事。</p><p><img src="http://p32.qhimg.com/t011fdd662ee0c27488.jpg?size=500x273"></p><p><img src="http://p31.qhimg.com/t013b72c10910d41185.jpg?size=500x274"></p><p><img src="http://p34.qhimg.com/t0182c3237dcdc97a86.jpg?size=500x274"></p><p><img src="http://p35.qhimg.com/t015a1e9cd8bdbb9b55.jpg?size=500x274"></p><p><img src="http://p31.qhimg.com/t015ef17e6ec78a9150.jpg?size=500x274"></p><p><img src="http://p35.qhimg.com/t01f2466ec8efcf28d1.jpg?size=500x275"></p><p><img src="http://p33.qhimg.com/t01ae92277fbc4ee687.jpg?size=500x278"></p><p><img src="http://p35.qhimg.com/t01f58061b380aef645.jpg?size=500x272"></p><p><img src="http://p33.qhimg.com/t018de5d057728a4de9.jpg?size=500x278"></p><p><img src="http://p32.qhimg.com/t01d77b631e98e96a92.jpg?size=500x282"></p><p><img src="http://p31.qhimg.com/t015fdfb32755dcc89e.jpg?size=500x273"></p><p><img src="http://p33.qhimg.com/t013e95e239df150c29.jpg?size=500x258"></p><p>《东京食尸鬼√A》迎来最终回，在放送最后官方公布了<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%9C%E4%BA%AC%E9%A3%9F%E5%B0%B8%E9%AC%BC+JACK%E3%80%8B&amp;src=newstranscode" class="qkw">《东京食尸鬼 JACK》</a>OVA的制作决定。《东京食尸鬼 JACK》是只限<a href="http://m.so.com/s?q=%E3%80%8Ajump+live%E3%80%8B&amp;src=newstranscode" class="qkw">《jump live》</a>收录的番外作品，主要描述了 种搜查官有<a href="http://m.so.com/s?q=%E9%A9%AC%E8%B4%B5&amp;src=newstranscode" class="qkw">马贵</a>将和7区上等搜查官富良太志相遇的故事。</p><p>既然主线剧情不会大改，那么结合以上，基友所说想做的事，应该是基于保护金木和他的那群小伙伴的，那么作为人类想站在 种和人类之间，确实势单力薄，况且还是一个什么地位都没有的CCG助理，那么我可以猜测他想在两个物种之间建立一种平衡(说实话比较难，所以才说一个人很难做到)，而金木，作为一个人类和 种边缘的“人”，他的经历，他的内心，以及实力，会不会成为这个<a href="http://m.so.com/s?q=%E5%BB%BA%E7%AB%8B%E5%B9%B3%E8%A1%A1&amp;src=newstranscode" class="qkw">建立平衡</a>的“人”的呢。</p><p><img src="http://p32.qhimg.com/t01755ca508c89fc876.jpg?size=500x270"></p><p>有马是一个谜一样的人，报表的战斗力和一段未知头发黑(漫画中年少时为黑色)变白的经历，漫画和动画都可以看出，有马和金木有些隐隐约约的相似，身世和经历我不敢乱猜，因为毕竟漫画也没有提到，但是，如果说有马因为自己曾经的某些经历(有马16岁就杀了那么多 种，而且凭他的实力，秒金木理所应当)而对金木产生了恻隐之心呢?</p><p><img src="http://p32.qhimg.com/t010519098c8ced0642.jpg?size=500x246"></p><p>金木抱着英的遗体去CCG那里，我想应该不是为了开战(实际还不是干不过啊喂!)，而是希望继承英的遗愿作为一个边缘人物，希望能成为建立这种平衡的人，结合漫画的剧情就是类似“自首”了(但也不应该是完全去送死一样，因为CCG也知道金木的身份了，他的经历，他的想法，还有他做过的事，以及有马若有所思，应该是起到一定的作用了，毕竟亚门也说过，很想和他多聊聊以及你只想当个普通的 种吗之类的话)，也就是大家都知道的退去记忆，加入CCG。</p><p>但是跟漫画不同的是，这是自愿的，我可以理解为失去了太多的金木，就像之前改动加入青铜树一样，自愿的加入ccg(当然，加入可能说的不准确，应该是一种交流吧)，然后自愿退去记忆，化身为<a href="http://m.so.com/s?q=%E4%BD%90%E4%BD%90%E6%9C%A8&amp;src=newstranscode" class="qkw">佐佐木</a>，为建立两个物种之间的平衡而努力。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.fjndwb.com/ningde/2016/0314/49048.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='72d19aebac0da243fc455ad2dbe745e8'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>东京食尸鬼</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%B8%9C%E4%BA%AC%E9%A3%9F%E5%B0%B8%E9%AC%BC&amp;pn=1&amp;pos=5&amp;m=cb862c1f800aeab56d406e2c8d95de3891c1ee58&amp;u=http%3A%2F%2Fwww.fjndwb.com%2Fningde%2F2016%2F0314%2F49048.html" data-pos="1"> <b>东京</b>种第三季禁播?<b>东京食尸鬼</b>第二季第12集未解之谜 </a>   <li> <a href="/transcode?q=%E4%B8%9C%E4%BA%AC%E9%A3%9F%E5%B0%B8%E9%AC%BC&amp;pn=1&amp;pos=6&amp;m=388743834a4863795fa8b43aa455982959467f2a&amp;u=http%3A%2F%2Fwww.kejixun.com%2Farticle%2F201603%2F161375.html" data-pos="2"> <b>东京食尸鬼</b>第三季十大看点分析 金木加入CCG </a>   <li> <a href="/transcode?q=%E4%B8%9C%E4%BA%AC%E9%A3%9F%E5%B0%B8%E9%AC%BC&amp;pn=1&amp;pos=7&amp;m=79f35d3598f107cc240c70a75ec8ec57f83c60ea&amp;u=http%3A%2F%2Fwww.9game.cn%2Fdjssgol%2F736520.html" data-pos="3"> 《<b>东京食尸鬼</b>OL》开测签到千元话费随便拿 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '东京种第三季禁播?东京食尸鬼第二季第12集未解之谜 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '东京种第三季禁播?东京食尸鬼第二季第12集未解之谜 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";