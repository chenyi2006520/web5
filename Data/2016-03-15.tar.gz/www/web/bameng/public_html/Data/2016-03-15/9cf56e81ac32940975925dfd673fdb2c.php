s:23385:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>数十年前广东女子竟成今日网传民国女神 长得像周璇“姆妈”- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">数十年前广东女子竟成今日网传民国女神 长得像周璇“姆妈”</h1> <p id="source-and-time"><span id=source>千龙网</span><time id=time>2016-02-17 15:46:00</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t0116d2356f706fc499.jpg?size=462x646"></p><p><img src="http://p32.qhimg.com/t0186e342fb264c727c.jpg?size=550x544"></p><p><img src="http://p31.qhimg.com/t013c3058091f41c3c7.jpg?size=534x685"></p><p>近两日，《一本文庙老相册，竟记录了民国无名“女神”的一生》的网文在互联网上传播甚广。知名演员<a href="http://m.so.com/s?q=%E5%A7%9A%E6%99%A8&amp;src=newstranscode" class="qkw">姚晨</a>在微博转发美文美图后，无数网友被民国无名“女神”超凡脱俗的气质所吸引，也对她由疑似上海千金小姐到一家<a href="http://m.so.com/s?q=%E5%9B%BD%E8%90%A5%E9%A5%AD%E5%BA%97&amp;src=newstranscode" class="qkw">国营饭店</a>普通员工的人生转变之路充满好奇。人们都在追问，这位女子到底是谁?她的一生是如何度过的?果真一生美丽并未养育后代，直至暮年去世?</p><p>昨日，羊城晚报记者辗转多人，核实到了这位“网红女神”的身份:她叫<a href="http://m.so.com/s?q=%E6%9D%8E%E4%BC%9F%E5%8D%8E&amp;src=newstranscode" class="qkw">李伟华</a>，生于1926年，是广东中山人，后举家迁居上海。2008年她因<a href="http://m.so.com/s?q=%E5%BF%83%E8%84%8F%E7%97%85&amp;src=newstranscode" class="qkw">心脏病</a>去世，享年79岁。与其相熟的多名同事向记者回忆:李伟华一生爱美低调，会说一口流利的粤语。她跟回族丈夫育有两子一女，真诚开朗乐于助人。最后在离开人世之前，思想开放的夫妻双双立下遗嘱，将遗体捐献给医学界做研究。</p><p class="header">因相册被封“女神”</p><p>2月13日，一篇名为《一本文庙老相册，竟记录了民国无名“女神”的一生》的微信文章在网上热传。因文章集中展示了相册里一名清新女子各个年龄段的照片，时间跨度从民国时代一直到解放后，年龄跨度从小女孩到<a href="http://m.so.com/s?q=%E5%9E%82%E6%9A%AE%E4%B9%8B%E5%B9%B4&amp;src=newstranscode" class="qkw">垂暮之年</a>，该内容引发的网络点击量迅速超过10万。而后文章被转载至新浪微博，知名演员姚晨转发后，再次引发网民关注，并封照片中清新明媚的女子为民国无名“女神”。</p><p>许多人看完了长贴得知，网文作者在钱塘江畔的铁崧斋里，无意翻开了一本装帧考究的绣花册子。该作者一下被相册吸引住，因为海量的照片记录了一个清丽女子的一生。热传文章里，作者因一时无法判断女子身份，根据展示的照片做了相应配文。其称，相册女主角是一个出生于民国的<a href="http://m.so.com/s?q=%E4%B8%8A%E6%B5%B7%E5%A5%B3%E5%AD%90&amp;src=newstranscode" class="qkw">上海女子</a>，“少女时代，是‘资产阶级’家的千金;中青年时代，是红色中国的一名普通工人。”</p><p>有网友甚至从老照片认出，相册中的女子年轻时去的游泳池，正是当年的上海工部局游泳池。相册中的照片，均为黑白照，下方还写有拍摄时间，包括个人照、集体照、夫妻照，年龄跨越其一生。作者用抒情温暖的文字，串联起一张张老照片，称“令人久久不能掩卷的，是她身上那种非凡的气质，如美玉、如清流。当然，她是如此的美。”根据相册主人在照片上写下的拍摄年月，及她55岁的退休纪念照，知悉她生于1926年12月。</p><p>从其小时的照片看，父母给了她富裕的成长环境，父母还育有一名帅气的弟弟。记者留意到，当时上海时髦的运动骑马、游泳，她都有参与，其中泳装照看起来甚至有些惊艳。热传的网文称，那个时候穿泳装，虽有点羞涩但敢于上镜，实属新潮。而从后面的照片可以看到，女子于1950年结婚，丈夫也是相貌堂堂，婚后她就职于上海西餐馆<a href="http://m.so.com/s?q=%E9%9B%B7%E8%8C%9C&amp;src=newstranscode" class="qkw">雷茜</a>饭店直至退休。照片背后，她和她的家庭都经历了些什么?被网民封为女神的她，照片背后的故事牵动人心。</p><p class="header">籍贯广东迁居上海</p><p>昨日记者经核实得知，《一本文庙老相册，记录了民国无名“女神”的一生》一文，出自上海媒体人沈月明的微信公众号。该帖发出后，阅读数一路飙升至50余万，后又被转载至微博传播。几经周转，记者昨日找到了这名女子曾经工作过的雷茜饭店。如今72岁的<a href="http://m.so.com/s?q=%E5%BC%A0%E7%BB%B4%E8%81%AA&amp;src=newstranscode" class="qkw">张维聪</a>，正是这名女子的徒弟兼后来的同事，其称女子叫李伟华，“她是我的师傅”。</p><p>据张维聪回忆，1962年，高中毕业的他进入蕾茜饭店工作，李伟华是他的带教老师，同时也担任蕾茜饭店的财务主管。他说他这一届，是上海第一批进入商业单位的高中毕业生。“说实在的，当时餐饮行业社会地位并不高，比起进入蕾茜饭店，我更想去类似仪表局、化工厂这样的单位工作。”很快，张维聪的心思便被师傅李伟华看了出来，随之而来的就是一场“思想交流”。</p><p>“当时心里面其实挺害怕的，想着一顿训话是逃不掉了。”然而，令张维聪始料未及的是李伟华非但没有骂他，还与他聊起了自己的人生经历。原来李伟华是广东中山人，会说一口流利的粤语。她父母解放前从广东迁居上海，在<a href="http://m.so.com/s?q=%E5%BB%B6%E5%AE%89%E8%B7%AF&amp;src=newstranscode" class="qkw">延安路</a>开了一家广东小吃店。张维聪称其家曾掩护过中共地下党员<a href="http://m.so.com/s?q=%E6%9C%B1%E6%B1%9F&amp;src=newstranscode" class="qkw">朱江</a>。当时外面风声紧朱江为掩护自己身份，在她父母的小食店当过一段时间服务生，最后躲过敌人的追缉。后来，朱江担任过上海工商行政管理局局长。</p><p>张维聪告诉记者，李伟华在进入蕾茜饭店工作前，曾在<a href="http://m.so.com/s?q=%E5%BE%90%E6%B1%87&amp;src=newstranscode" class="qkw">徐汇</a>饮食店(旧址就是如今的徐家汇太平洋)做过一段时间的服务员，还是“业务标兵”。“她在当服务员时，有很多顾客都曾向她抛出橄榄枝，请她去企业里担任文职，然而，师傅都一一回绝了，她一直在蕾茜饭店兢兢业业地工作，直到退休。‘干一行就要爱一行’，当时师傅说的这句话对我今后工作生涯有很大影响。每当面临选择，我耳边总会回响起这句话，因此，我的工作始终<a href="http://m.so.com/s?q=%E6%9C%AA%E6%9B%BE%E7%A6%BB%E5%BC%80&amp;src=newstranscode" class="qkw">未曾离开</a>过餐饮系统。”</p><p class="header">长得像周璇的“姆妈”</p><p>如今70多岁的朱慧芳，是<a href="http://m.so.com/s?q=%E4%B8%8A%E6%B5%B7%E5%B8%82&amp;src=newstranscode" class="qkw">上海市</a>原乔家栅工会主席，现退休在家。网文热传后，她也认出了照片中的女子就是“老熟人”李伟华。原来，李伟华曾工作的蕾茜饭店后来与乔家栅饮食集团合并，她们因此成为同事。谈起李伟华的为人，朱慧芳的评价是工作严谨、开朗真诚、乐于助人。她称李伟华和回族丈夫撒先生都有文化，为人不张扬、低调恬适。</p><p>据朱慧芳回忆，上世纪八十年代大家经济条件都不好，但李伟华把钱看得很开，经常帮助有困难的同事。也正是因为她心存善良与热心，朱慧芳记得后来年轻的同事都直接称李伟华“姆妈”(上海话妈妈之意)。而爱美，是她留给大家的另一个印象，据李伟华的另一位同事今年77岁的尤道珍称，大家都觉得李伟华长得像老上海的歌星<a href="http://m.so.com/s?q=%E5%91%A8%E7%92%87&amp;src=newstranscode" class="qkw">周璇</a>。当时她拍摄的照片都紧跟时代潮流，且会把照片压在玻璃台板下面。</p><p>尤道珍记得，2005年前后她做了一次手术，当时已经快80岁的李伟华还来医院看望了她。2008年，李伟华因心脏病去世，病来得很突然。而在朱慧芳印象中，老人以前就有心脏病和<a href="http://m.so.com/s?q=%E9%AB%98%E8%A1%80%E5%8E%8B&amp;src=newstranscode" class="qkw">高血压</a>。李伟华离世，朱慧芳、张维聪和尤道珍这三位昔日同事都去送了她最后一程。当时，李伟华的丈夫撒先生因为中风已经瘫痪在轮椅上，但还能认出妻子的同事。</p><p>与此前猜测不同的是，相册里没有出现李伟华的子女，并不是因为她没有孩子，而是她自己整理了好几本相册，子女的照片收录在其他册子里。朱慧芳介绍，李伟华生育了两个儿子，一个女儿，如今大儿子在上海已经退休;二儿子前些年因病去世;女儿早前曾在大丰农场当过“赤脚医生”，如今定居<a href="http://m.so.com/s?q=%E6%BE%B3%E5%A4%A7%E5%88%A9%E4%BA%9A&amp;src=newstranscode" class="qkw">澳大利亚</a>。当时李伟华去世，他们夫妇原先聪慧的小儿子却出现精神障碍，而女儿因为在国外没能赶来奔丧。</p><p class="header">夫妻双双捐献遗体</p><p>昨日，记者试图找到李伟华的儿子了解相关情况，未能如愿。徒弟张维聪称，她退休的大儿子此前在上海一家滑稽剧场工作。张维聪对师傅的一生甚为敬仰，尤其在为人和工作业务方面。“师傅的业务相当精湛，当时还为蕾茜饭店设计了一张‘一日营业报表’。这张东西看一眼，一天的经营全都晓得了。”张维聪介绍，李伟华做事效率极高，待人又十分真诚，自己从她那里学到了很多实践经验。</p><p>回忆其师傅当时离世的情形，张维聪表示“痛心又震惊”。“2007年我还与师傅见过一面，当时她说过一句话:‘即使老了，我也要为社会做点贡献。’其实我还挺纳闷，想着都近八旬的老人了，你还怎么为社会做贡献呢?现在回想起来，师傅可能早就已经下定决心走遗体捐献这条路了。”</p><p>李伟华离世，张维聪去送了她最后一程。由于决定遗体捐赠，李伟华的告别仪式并没有在殡仪馆举行，而是在当时位于上海市石龙路的一家研究所内。“<a href="http://m.so.com/s?q=%E5%91%8A%E5%88%AB%E5%BC%8F&amp;src=newstranscode" class="qkw">告别式</a>简单而庄重，就如同师傅的一生，平凡但充满价值。”而朱慧芳告诉羊城晚报记者，李伟华丈夫撒先生追随她去后，也将自己的遗体捐献给了医院用作研究。“他们的思想，都是超越同辈人的，很开放、很了不起。”</p><p>记者获悉，昨日李伟华身在澳洲的女儿撒明，通过网络也得知母亲的身世在国内被关注。她讲述了自己的确切家史:1950年母亲和父亲结婚，同年大哥出生，过两年自己出生，弟弟1957年出生。撒明说，因为小儿子生得晚，母亲特别宠爱他。遗憾的是，弟弟不幸于2009年就去世了。</p><p>在撒明眼里，母亲其实是一个职业女性，家务活做得不多，“文革”以前家里请保姆，后来她也学着做饭。撒明一直记得母亲做的“八宝填鸭”简直是绝世美味，到现在还想念。她自己生儿子时，母亲来照顾她，给她做粤式<a href="http://m.so.com/s?q=%E5%A7%9C%E6%B1%A4&amp;src=newstranscode" class="qkw">姜汤</a>猪蹄，整个弄堂都闻得到香味。回顾<a href="http://m.so.com/s?q=%E6%AF%8D%E4%BA%B2%E7%9A%84%E4%B8%80%E7%94%9F&amp;src=newstranscode" class="qkw">母亲的一生</a>，她表示母亲是个一辈子爱美，也一辈子有童心的人。在母亲身上，确实有一些值得她学习的精神和气质。羊城晚报记者 罗坪</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://finance.qianlong.com/2016/0217/371578.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='08e5d11a30bd24f8511d12deded4a137'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>姆妈</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%A7%86%E5%A6%88&amp;pn=1&amp;pos=7&amp;m=0e1e5a4be4f2f240d800a5de36ecab06be12cec3&amp;u=http%3A%2F%2Ftravel.163.com%2F15%2F0513%2F10%2FAPG6PHDH00063KE8.html" data-pos="1"> 猪油糕酒酿油闷笋 这些都是老苏州<b>姆妈</b>的米道 </a>   <li> <a href="/transcode?q=%E5%A7%86%E5%A6%88&amp;pn=1&amp;pos=8&amp;m=16d945f4d96007bbc6f1612642c41c8c61c3ab8f&amp;u=http%3A%2F%2Fnews.hexun.com%2F2015-02-12%2F173327196.html" data-pos="2"> 家乡年味是"<b>姆妈</b>"炒出来的 </a>   <li> <a href="/transcode?q=%E5%A7%86%E5%A6%88&amp;pn=1&amp;pos=9&amp;m=86073ba1cb509b09f1a0ef1e0a74c2e5e1d912de&amp;u=http%3A%2F%2Fnewspaper.jfdaily.com%2Fxwcb%2Fhtml%2F2015-10%2F20%2Fcontent_139877.htm" data-pos="3"> <b>姆妈</b>的"杂物癖" </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '数十年前广东女子竟成今日网传民国女神 长得像周璇“姆妈”' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '数十年前广东女子竟成今日网传民国女神 长得像周璇“姆妈”'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";