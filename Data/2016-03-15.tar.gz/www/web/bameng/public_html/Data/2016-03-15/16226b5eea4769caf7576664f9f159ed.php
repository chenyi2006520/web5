s:20069:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>中甲转会投入半年增9倍 联赛市场开发仍然滞后- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">中甲转会投入半年增9倍 联赛市场开发仍然滞后</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-03-10 13:17:16</time></p> </header>  <div id="news-body"><p>“史上最贵”<a href="http://m.so.com/s?q=%E4%B8%AD%E8%B6%85&amp;src=newstranscode" class="qkw">中超</a>在上周末开赛，“史上最贵”中甲也将于本周六在深圳拉开战幕。中甲追随中超脚步，在冬季转会期投入重金，令世界足坛震惊。但光鲜背后，是贫富和实力分化程度比中超更加严重的阴影。部分“土豪”俱乐部瞄准中超名额的同时，更多球队追求的是继续“活”在中甲。作为中国职业足球第二级<a href="http://m.so.com/s?q=%E8%81%94%E8%B5%9B&amp;src=newstranscode" class="qkw">联赛</a>，中甲是中超的“放大镜”，中超的好与坏都会在这里被放大。只有健康发展的中甲，才能助推中超的进步。对整体水平依然低下的中甲而言，“史上最贵”的背后，机遇和挑战并存。</p><p class="header">转会投入半年增9倍是不是“虚火”?</p><p>2月27日中超、中甲冬季转会窗口关闭时，中超以近3.4亿欧元投入排名全球冬季转会期投入榜第一。令世界足坛大跌眼镜的是，在这份排行榜上，<a href="http://m.so.com/s?q=%E4%B8%AD%E7%94%B2%E8%81%94%E8%B5%9B&amp;src=newstranscode" class="qkw">中甲联赛</a>以5677万欧元力压德甲(5262万欧元)、<a href="http://m.so.com/s?q=%E8%8B%B1%E5%86%A0&amp;src=newstranscode" class="qkw">英冠</a>(4027万欧元)和西甲(3642万欧元)等多个<a href="http://m.so.com/s?q=%E6%AC%A7%E6%B4%B2%E8%81%94%E8%B5%9B&amp;src=newstranscode" class="qkw">欧洲联赛</a>，排名第四，仅次于中超、英超(2.53亿欧元)和意甲(8705万欧元)。</p><p>去年的夏季转会期，中甲在球员转会上的投入其实已高达635万欧元，当时这一数字位列亚洲第2位、全球第17位，中甲也在那时开始超过日韩联赛和向来以“土豪”著称的西亚各国联赛。但去年的635万欧元放在今年来看只能算个“零头”，半年时间里，中甲的转会投入竟然增加了近9倍。中甲能够成功“上位”，很大程度上是因为欧洲球队大多更喜欢在夏季转会期砸钱买人，但更重要的原因是，曾经如同鸡肋一般的中甲联赛也得到了多个“土豪”的青睐。转会投入半年多增长近9倍，已让中甲联赛形成一个巨大的泡沫，是福是祸?还需时间来验证。</p><p>“土豪”复制“恒大模式”能不能成功?</p><p>中甲这5677万欧元的冬季转会期投入，有超过70%来自同一家俱乐部--天津权健。在上赛季与中超球队天津泰达不欢而散之后，权健转而入主当时在中甲苦苦求生的天津松江。天津权健横空出世之后，先后引进了<a href="http://m.so.com/s?q=%E6%B3%95%E6%AF%94%E4%BA%9A%E8%AF%BA&amp;src=newstranscode" class="qkw">法比亚诺</a>、贾德森和格乌瓦尼奥等巴西国脚级球星。权健与号称是“内马尔师弟”的<a href="http://m.so.com/s?q=%E6%A0%BC%E4%B9%8C%E7%93%A6%E5%B0%BC%E5%A5%A5&amp;src=newstranscode" class="qkw">格乌瓦尼奥</a>签约4年，付出超过3000万欧元。现年35岁的法比亚诺则是前巴西国脚，他将成为权健新赛季的队长。内援方面，<a href="http://m.so.com/s?q=%E6%81%92%E5%A4%A7&amp;src=newstranscode" class="qkw">恒大</a>的赵旭日、富力的张烁和中国香港归化球员<a href="http://m.so.com/s?q=%E5%9F%BA%E8%93%9D%E9%A9%AC&amp;src=newstranscode" class="qkw">基蓝马</a>等实力派球员也纷纷来投。此外，权健还引进了晏子豪、张修维和刘奕鸣等小将，为长远发展做准备。加上去年用6000万元人民币购进的国脚孙可，权健被认为已预订了一个中超名额。</p><p>可以说，天津权健几乎是凭一己之力，将中甲推至全球冬季转会期投入第4名的位置，巨大的投入显示这支球队的野心不止于中甲。恒大模式成功之后，近两年出现的“新土豪”球队纷纷效仿，但恒大的成功秘诀不仅在于投入。“新土豪”在大肆花钱之后，能否在球队管理方面有作为，才是球队能否成功的关键。</p><p>中甲也有“<a href="http://m.so.com/s?q=BIG4&amp;src=newstranscode" class="qkw">BIG4</a>”争霸谁是搅局者?</p><p>除了“一枝独秀”的天津权健，排名中甲冬季转会期投入第二名的北京北控花了600万欧元，排名第三的北京人和花费约420万欧元，大连一方则以250万欧元排名第四。天津权健、北京北控、北京人和与大连一方也构成了2016赛季的中甲“BIG4”。</p><p>虽然从投入看，其他12支球队很难与“BIG4”匹敌，但与中超相比，中甲更容易出现“黑马”。上赛季，河北<a href="http://m.so.com/s?q=%E5%8D%8E%E5%A4%8F%E5%B9%B8%E7%A6%8F&amp;src=newstranscode" class="qkw">华夏幸福</a>和北京北控均有大手笔投入，不料<a href="http://m.so.com/s?q=%E5%BB%B6%E8%BE%B9&amp;src=newstranscode" class="qkw">延边</a>富德横空出世，最终力压华夏幸福，以中甲冠军身份晋级中超。要知道，在2014赛季中甲结束时，<a href="http://m.so.com/s?q=%E5%BB%B6%E8%BE%B9%E9%98%9F&amp;src=newstranscode" class="qkw">延边队</a>已降入中乙，只因有球队无法完成注册手续，延边队才得以递补重返中甲。从<a href="http://m.so.com/s?q=%E4%B8%AD%E4%B9%99&amp;src=newstranscode" class="qkw">中乙</a>死里逃生到打上中超，延边<a href="http://m.so.com/s?q=%E5%AF%8C%E5%BE%B7&amp;src=newstranscode" class="qkw">富德</a>只用了一个赛季。</p><p>今年中甲联赛依然可能有“黑马”出现，他们也许无法复制延边队的奇迹，但至少可以成为中甲“BIG4”争霸的搅局者。</p><p>本赛季，广东一共有两支球队参加中甲联赛，分别是梅州客家和深圳佳兆业。梅州客家是历时3年才冲甲成功的中甲新军。在冬季转会期，梅州客家引进了桑科、贾帕和<a href="http://m.so.com/s?q=%E5%9D%A6%E5%90%89%E6%88%88%E6%8B%89&amp;src=newstranscode" class="qkw">坦吉戈拉</a>3名外援以及罗足庆、土耳其裔中华台北队球员朱恩乐、中国香港队球员李志豪等内援。俱乐部总经理曹阳表示，新赛季梅州客家的目标是保十争八，第一年先力求在中甲站稳脚跟。梅州客家是国内第一支县级中甲球队，队中拥有多名广东籍球员，他们有能力成为搅局者。</p><p>深圳佳兆业比梅州客家更高调一些。今年中甲开幕式将在深圳举行，这是深圳继2000赛季举办甲A联赛开幕式之后再次举办职业联赛开幕式。深圳队在近几个赛季历经球员欠薪、俱乐部人事变动等风波，此次举办开幕式意在给外界一个全新形象。对于这支已在中甲徘徊多年的球队来说，新赛季在新赞助商的支持下能否成为“黑马”已不重要，重要的是维持内部稳定，让球队能平稳发展。</p><p class="header">市场开发仍然滞后怎样求发展?</p><p>去年年底，<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E8%B6%B3%E5%8D%8F&amp;src=newstranscode" class="qkw">中国足协</a>曾发文表示，中甲联赛将在2017赛季增加至17队，并引进升降级<a href="http://m.so.com/s?q=%E9%99%84%E5%8A%A0%E8%B5%9B&amp;src=newstranscode" class="qkw">附加赛</a>。但在3月初，中国足协又通知各俱乐部，中甲暂不扩军，理由是每年增加一支球队会导致中甲球队总数是单数，结果就是每轮都会有球队轮空，到了联赛末段，赛程安排容易引起争端。因此，新赛季中甲的球队数量和升降级制度仍维持不变。</p><p>若中甲扩军，将进一步扩大联赛的影响范围，并提高其自身的商业价值。不过，即使维持16支球队不变，中甲的市场潜力同样有待进一步开发。与中超版权卖出80亿元天价相比，中甲的市场开发依然举步维艰。虽然中甲在上赛季告别了“10年裸奔”无冠名商的尴尬局面，现在更有中甲“BIG4”撑门面，但实际上这仍然是一个商业开发程度低、缺乏足够关注度的低水平联赛。</p><p>有知情人士透露，中甲各俱乐部一个赛季的分红不超过40万元。要知道，目前一家中甲俱乐部一年的运营成本少则6000万元，多则上亿元，40万元的分红真是“塞牙缝都不够”。加上中国足协对中甲监管力度不够，各俱乐部在青训方面发展缓慢，中甲联赛整体发展不甚理想。在冬季转会期大撒金钱之后，中甲还需进一步加强市场开发和整顿管理，并鼓励和支持俱乐部进行人才培养。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/sport/tyxw/4654103_1.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='6190fb84afa8dcaf8cd3fda826e2caa1'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>转会市场</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%BD%AC%E4%BC%9A%E5%B8%82%E5%9C%BA&amp;pn=1&amp;pos=4&amp;m=22b341a84223df6ea5791a6d5f9687323845b4c5&amp;u=http%3A%2F%2Fnews.youth.cn%2Fjsxw%2F201602%2Ft20160226_7677486.htm" data-pos="1"> 国内<b>转会市场</b>良品奇缺 中超土豪竞购转至潜力股 </a>   <li> <a href="/transcode?q=%E8%BD%AC%E4%BC%9A%E5%B8%82%E5%9C%BA&amp;pn=1&amp;pos=5&amp;m=25d566aaca2a924afa7b839f289455c12b2cd85c&amp;u=http%3A%2F%2Fhouse.gmw.cn%2Fnewspaper%2F2016-02%2F28%2Fcontent_111208334.htm" data-pos="2"> <b>转会市场</b>上有多少大连人很抢手 </a>   <li> <a href="/transcode?q=%E8%BD%AC%E4%BC%9A%E5%B8%82%E5%9C%BA&amp;pn=1&amp;pos=6&amp;m=725970f1dca0ecddcb060ecbaa6158f2aaebe423&amp;u=http%3A%2F%2Fsports.163.com%2F16%2F0304%2F07%2FBHA0DHNV00051C89.html" data-pos="3"> 华夏中超巡礼:<b>转会市场</b>狂购13人 或成争冠搅局者 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '中甲转会投入半年增9倍 联赛市场开发仍然滞后' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '中甲转会投入半年增9倍 联赛市场开发仍然滞后'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";