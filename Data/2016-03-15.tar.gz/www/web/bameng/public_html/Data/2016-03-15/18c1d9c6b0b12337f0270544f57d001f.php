s:18377:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>【小生活大事件】家长们注意啦!申请学位，这些事情要早做- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">【小生活大事件】家长们注意啦!申请学位，这些事情要早做</h1> <p id="source-and-time"><span id=source>搜狐</span><time id=time>2016-03-04 17:58:45</time></p> </header>  <div id="news-body"><p>我家孩子能报哪所小学?学位申请该准备哪些材料?</p><p>孩子即将入读小学一年级的家长们，是不是感到无从下手?</p><p>市教育局公布了今年学位申请的流程，网上预报名大约会 在3月底、4月初启动。 下面这些事情，各位家长要早做准备哦!</p><p><img src="http://p34.qhimg.com/t0116e6dea016ea5cd2.jpg?size=293x220"></p><p>查询学校目前，不少家长还存在着一种观念上的误区--离自家最近的学校就是划片学校。事实上，各区的教育部门对学校都进行了详细的划片， “地理位置上最近”并不是划片的依据。特别是周边有多所学校的小区，家长更不能想当然地就此判断可以入读某某学校，必须事先做好查询的工作。 自查“家底”深圳市多个区都推行“学位房政策”，也就是说 学区内一套房屋只能供一户家庭(一对夫妇)的孩子申请学位。</p><p>一旦房屋信息已被锁定，学生在读期间(小学6年、初中3年)该房屋不能再次用于申请公办学位。 家长们可以登录家庭所在区的教育部门网站，查询学位锁定情况。特别是租住房屋的家庭，更要对所租房屋的学位使用情况有所掌握。</p><p><img src="http://p35.qhimg.com/t019f6b6f87e969b43f.jpg?size=486x375"></p><p>租房时间有所限定--准备材料根据往年的要求，深圳户籍儿童申请学位的材料很简单，即:户籍证明材料(申请就学儿童及父母的身份证和全家户口簿)和住房证明材料。其中，购房的只要准备好<a href="http://m.so.com/s?q=%E6%88%BF%E4%BA%A7%E8%AF%81&amp;src=newstranscode" class="qkw">房产证</a>即可，而租房的则需要注意租房合同的时间。比如:龙华新区今年最大的变化就是严格执行“父母在学区范围租房时间须连续1年以上”的规定。申请学位时须提交2015年8月31日(以发证日期为准)以前办理的学区有效租赁凭证，租期最短至2016年9月1日(不再使用人口信息单辅助证明在学区内居住的做法)。同时要确保租赁合同在资料核验期间处于未过期的状态。此前，包括<a href="http://m.so.com/s?q=%E7%A6%8F%E7%94%B0%E5%8C%BA&amp;src=newstranscode" class="qkw">福田区</a>在内的多个区也都对<a href="http://m.so.com/s?q=%E7%A7%9F%E8%B5%81%E6%88%BF%E5%B1%8B&amp;src=newstranscode" class="qkw">租赁房屋</a>的时间有所规定。也就是说，“临时抱佛脚”是来不及的。</p><p>今年针对租房户，还有一个变化，就是自2015年9月2日起，市<a href="http://m.so.com/s?q=%E6%88%BF%E5%B1%8B%E7%A7%9F%E8%B5%81&amp;src=newstranscode" class="qkw">房屋租赁</a>管理部门只对持有合法<a href="http://m.so.com/s?q=%E4%BA%A7%E6%9D%83%E8%AF%81&amp;src=newstranscode" class="qkw">产权证</a>房屋出租的租赁当事人发放<a href="http://m.so.com/s?q=%E3%80%8A%E6%88%BF%E5%B1%8B%E7%A7%9F%E8%B5%81%E5%87%AD%E8%AF%81%E3%80%8B&amp;src=newstranscode" class="qkw">《房屋租赁凭证》</a>，不再为租住在无合法权属证明房屋的家庭出具《房屋租赁凭证》。租住在无合法权属证明房屋的家庭，可凭借由市房屋租赁管理部门出具的<a href="http://m.so.com/s?q=%E3%80%8A%E6%88%BF%E5%B1%8B%E7%A7%9F%E8%B5%81%E4%BF%A1%E6%81%AF%E3%80%8B&amp;src=newstranscode" class="qkw">《房屋租赁信息》</a>申请学位。只是该信息不作为当事房屋进入租赁市场、允许租赁交易的法律凭证。</p><p>非深户籍的材料要准备得多一些，除户籍和房屋证明材料外，还要准备计生证明材料(去年起电子化，没有纸质计生证明);监护人在深就业证明材料;居住满一年证明材料等。这一点，各区要求略有不同，可到时上网查询各区公布的具体政策。</p><p><img src="http://p31.qhimg.com/t01130fad342f9c80ea.jpg?size=260x242"></p><p>学位紧张竞争激烈--多手准备虽然学位申请工作还未正式铺开，但各区早在春节前后就陆续公布了学位预警。可以肯定，今年各区的<a href="http://m.so.com/s?q=%E5%85%AC%E5%8A%9E%E5%AD%A6%E6%A0%A1&amp;src=newstranscode" class="qkw">公办学校</a>依然存在学位缺口，这意味着申请学位的适龄儿童，不是每个都能入读心仪的公办学校。在这种情况下，家长必须对自己孩子的积分心中有数。</p><p>记者从<a href="http://m.so.com/s?q=%E9%BE%99%E5%B2%97%E5%8C%BA&amp;src=newstranscode" class="qkw">龙岗区</a>教育局的网站上看到，该区已经公布了去年龙岗区各个学校的入学积分，家长们可以根据实际情况计算一下自己的积分，对于孩子入读的几率做出预判。 福田区教育局去年网上申请学位时有三个志愿:<a href="http://m.so.com/s?q=%E7%AC%AC%E4%B8%80%E5%BF%97%E6%84%BF&amp;src=newstranscode" class="qkw">第一志愿</a>应填报为居住地地段所属学校，为固定志愿，不可随意选择;网上预报名结束后，系统将显示各学校学位紧张程度，家长可在有空余学位的学校中选择第二和第三志愿。</p><p>此外，家长须对是否服从调剂作出选择。选择服从调剂的学生，若未被填报的志愿学校录取，教育部门将统筹安排到相对较近的有空余学位的学校;选择不服从调剂的学生，若未被填报的志愿学校录取，教育部门不再安排公办学校学位。教育部门的工作人员提醒家长:不论积分高低，最好能填报第二、第三志愿，做到有备无患。</p><p>另外，<a href="http://m.so.com/s?q=%E7%BD%97%E6%B9%96&amp;src=newstranscode" class="qkw">罗湖</a>、福田、盐田、南山四个区从去年开始就试行“大学区制”，在试行“大学区”的片区，家长可以给孩子报两到三个志愿，按照志愿次序和积分情况录取。在这些片区的家长，就要对片区内的几所学校都要有所了解。</p><p>民办学校作为公办学校的补充，也不失为一个入学的理想选择。全市对符合“1 5”人口政策的学生，都会有不同数额的补贴。随着政府对民办学校的扶持力度越来越大，民办学校的教学质量也在不断提升。在公办学校“挤破头”的情况下，家长不妨多考虑几条退路，保证孩子顺利入学。</p><p>文章来源:<a href="http://m.so.com/s?q=%E6%B7%B1%E5%9C%B3%E5%95%86%E6%8A%A5&amp;src=newstranscode" class="qkw">深圳商报</a>、深圳新闻网 文章转载于滨海<a href="http://m.so.com/s?q=%E5%AE%9D%E5%AE%89&amp;src=newstranscode" class="qkw">宝安</a>，侵权请联系删除 关注我们:sz3861(宝安妇儿中心)，可了解更多公益活动资讯哦! 点击下方“阅读原文”查看更多</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://baobao.sohu.com/20160304/n439436831.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='50fca93d7643ca38a59934b01aafbd02'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>我这些年的生活</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%88%91%E8%BF%99%E4%BA%9B%E5%B9%B4%E7%9A%84%E7%94%9F%E6%B4%BB&amp;pn=1&amp;pos=7&amp;m=d76364b085b7d1dd72a05b7e78ad7d02e33dbafe&amp;u=http%3A%2F%2Fxj.people.com.cn%2Fn2%2F2016%2F0301%2Fc188514-27834256.html" data-pos="1"> 新疆人请注意!<b>这些</b>新规三月起将影响你的<b>生活</b> </a>   <li> <a href="/transcode?q=%E6%88%91%E8%BF%99%E4%BA%9B%E5%B9%B4%E7%9A%84%E7%94%9F%E6%B4%BB&amp;pn=1&amp;pos=8&amp;m=bdd1939d22e90ef497a63636c8f51da26856a725&amp;u=http%3A%2F%2Flearning.sohu.com%2F20160303%2Fn439309365.shtml" data-pos="2"> 明天起,<b>这些</b>新政与你的房、车、<b>生活</b>密切相关! </a>   <li> <a href="/transcode?q=%E6%88%91%E8%BF%99%E4%BA%9B%E5%B9%B4%E7%9A%84%E7%94%9F%E6%B4%BB&amp;pn=1&amp;pos=9&amp;m=16de2c9c16c685d562d8ca1afd5d35036ca00af3&amp;u=http%3A%2F%2Fbaobao.sohu.com%2F20160304%2Fn439436831.shtml" data-pos="3"> 【小<b>生活</b>大事件】家长们注意啦!申请学位,<b>这些</b>事情要早做 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '【小生活大事件】家长们注意啦!申请学位，这些事情要早做' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '【小生活大事件】家长们注意啦!申请学位，这些事情要早做'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";