s:27438:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>跨境电商的江湖，如何诞生阿里、京东巨头? - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">跨境电商的江湖，如何诞生阿里、京东巨头? </h1> <p id="source-and-time"><span id=source>投资界</span><time id=time>2016-03-15 09:14:00</time></p> </header>  <div id="news-body"><p>摘要为什么内贸出现了淘宝<a href="http://m.so.com/s?q=%E4%BA%AC%E4%B8%9C&amp;src=newstranscode" class="qkw">京东</a>两家独大，而跨境电商发展多年却依旧处于群雄<a href="http://m.so.com/s?q=%E6%B7%B7%E6%88%98%E7%9A%84%E6%97%B6%E4%BB%A3&amp;src=newstranscode" class="qkw">混战的时代</a>?不是因为这里缺少人物，而是因为这个江湖里每个玩家都遇到了共同的行业难题。这同时也意味着如果难题得以解决，跨境贸易领域有产生巨头的空间。</p><p><img src="http://p31.qhimg.com/t017bfbdf6a7e52f9ee.jpg?size=500x314"></p><p class="img-title">中国制造，漂洋过海</p><p>跨境<a href="http://m.so.com/s?q=%E7%BA%A2%E6%B5%B7&amp;src=newstranscode" class="qkw">红海</a>，不见巨头</p><p>援引<a href="http://m.so.com/s?q=%E5%85%B0%E4%BA%AD%E9%9B%86%E5%8A%BF&amp;src=newstranscode" class="qkw">兰亭集势</a>品牌事业部总经理郝学芳的话，“从跨境电商的企业数量来看，这里已经是一片红海，但从增长速度上看，这里的前景还十分广阔。”这个现象其实不太正常。在信息如此透明的互联网时代，任何一个领域只要被关注，通常 2-3 年就会出现一批巨头，比如最近两年的 O2O，前几年的垂直电商。</p><p>然而在跨境领域，早在 2000 年初就有一批广州外贸玩家开始探索，到现在一波一波新的跨境电商公司和概念涌现，该领域依旧起起伏伏。DH、兰亭集势、大龙网，Jollychic 等在各自的领域各有优势，却都无法一统江湖。</p><p>为什么内贸出现了淘宝京东两家独大，而跨境电商发展多年却依旧处于群雄混战的时代?不是因为这里缺少人物，而是因为这个江湖里每个玩家都遇到了共同的行业难题。这同时也意味着如果难题得以解决，跨境贸易领域有产生巨头的空间。</p><p class="header">绕不开的物流</p><p>单从名字就能看出，相较于电商，跨境电商最重要的就在于一个“跨”字。跨代表了路途遥远，同时也催生出了两种不同的物流方式:集中运送和小包直邮。</p><p>集中运送就是客户先在中国集中采购，然后以集装箱的形式发至国外的仓库，当有货卖出，客户直接从国外仓库出货。这种国外建仓的模式能够将发货日期从跨境的几十天缩减到几天，对用户体验来说是优势。但是，这种模式很重，面临巨大的库存风险。因而适合做海外仓的商品并不太多，选品时一定要挑相对标准的、出货稳定的货品。</p><p>换个角度，这类商品不正是 <a href="http://m.so.com/s?q=Walmart&amp;src=newstranscode" class="qkw">Walmart</a>，Bestbuy 等美国商家正在经营的品类吗?这些传统行业巨头的模式也是先在中国集中采购，然后以集装箱的形式发至国外的仓库。它们和海外仓的区别，仅仅是建仓和库存相关费用到底归谁所有。所以，虽然从运营角度讲，海外仓是每个做大的跨境电商的必要优化，但是海外仓并不会成为跨境电商的下一个杀手锏，因为海外仓的商品面临着和众多国外本土品牌及电商的竞争，而在这种竞争中，跨境电商并不占优势。</p><p>究竟什么模式是跨境特有的，什么业务只有跨境才能做?从跨境电商平台的数据来看，排前三的类目是首饰、服装，数码配件。而在这些品类中，绝大多数商品是通过小包直邮的方式到达用户。这种<a href="http://m.so.com/s?q=%E5%95%86%E4%B8%9A%E6%A8%A1%E5%BC%8F&amp;src=newstranscode" class="qkw">商业模式</a>和 Walmart，<a href="http://m.so.com/s?q=Bestbuy&amp;src=newstranscode" class="qkw">Bestbuy</a> 等美国商家所经营的传统外贸模式的成本结构和运营方式完全不同，也是这类国外公司难以复制的。所以，小包直邮的模式才是跨境特有的模式，是跨境电商相较于外国本土电商的<a href="http://m.so.com/s?q=%E6%A0%B8%E5%BF%83%E7%AB%9E%E4%BA%89%E5%8A%9B&amp;src=newstranscode" class="qkw">核心竞争力</a>。</p><p class="header">如何选择吸金品类?</p><p><img src="http://p34.qhimg.com/t01e51a7035da341fe8.jpg?size=760x395"></p><p class="img-title">婚纱是非标品中的战斗机</p><p>既然小包直邮是跨境的特色，找到适合的 SKU 就很容易了:中国能生产的、国外需要的和适合小包直邮的。</p><p>拿服装举例，去<a href="http://m.so.com/s?q=%E4%BA%9A%E9%A9%AC%E9%80%8A&amp;src=newstranscode" class="qkw">亚马逊</a>上查看什么样的商品比较好卖，总结下来就会发现，虽然好卖的品类各有各的特点，但有共通之处。比如:时尚性强、有设计感，对衣服材质要求不高。而中国热卖的商品简单来说就是工艺简单、性价比高。综合考量小包直邮对商品的重量体积、非标程度，以及起订量的要求，我们很容易判断一件商品是否适合跨境电商。</p><p>比如中低端婚纱是非标品中的战斗机。商品重量轻、设计感和时尚感强，而且起订量低等一些因素，使其成为外贸市场一个长久不衰的吸金品类。</p><p>SKU 的非标程度决定了跨境电商的下限</p><p>选到了合适的货品，就意味着可以尝试做电商。但是电商可大可小，究竟是什么决定了跨境电商的规模下限?我认为是 SKU 的非标程度。</p><p>一个行业的利润多少取决于竞争的多少。虽然深耕供应链，提供性价比高的商品，走品牌化路线，是外贸行业正在探索的路，但是因为参与到同国外本土品牌的竞争，这条<a href="http://m.so.com/s?q=%E5%85%89%E8%8D%A3%E4%B9%8B%E8%B7%AF&amp;src=newstranscode" class="qkw">光荣之路</a>必然充满荆棘。</p><p>对跨境电商公司而言，产品越标准，竞争越激烈，产地近的优势越不明显， 必然是<a href="http://m.so.com/s?q=%E8%B5%A2%E5%AE%B6%E9%80%9A%E5%90%83&amp;src=newstranscode" class="qkw">赢家通吃</a>。在当今时代，跨境电商公司会因为亚马逊和几大垂直网站的存在而难以扩张。</p><p>非标品则不一样。它的优势在于当你在一个网站发现了你的心仪之物，却很难在第二个网站找到它，你就有了留在这网站并消费的理由和动力。可以说，当你找到了一款非标爆款，你就有了一个做电商的理由。当然爆款爆的程度和多少决定了你到底能做成 ebay 店还是类 Anthropologie 之类的独立站。</p><p class="header">SKU 的数量决定了跨境电商的上限</p><p><img src="http://p34.qhimg.com/t017ec3858198783022.jpg?size=480x295"></p><p class="img-title">怎么重视都不为过的 SKU</p><p>既然跨境直邮是跨境电商的核心，就不得不接受跨境直邮的缺点:</p><p class="header">慢，邮寄时间超过 20 天。</p><p>贵，运费可能等于或远大于商品本身的价值。</p><p>正因为如此，跨境直邮很难做出好的用户体验。而好的用户体验通常是好的品牌，尤其是渠道品牌所必须拥有的。在这种情况下，数千家跨境电商必然走向一个方向--能够快速起量的杂货铺似的外贸平台。虽然是不得已而为之，但也是一条金光灿灿的<a href="http://m.so.com/s?q=%E9%98%B3%E5%85%B3%E9%81%93&amp;src=newstranscode" class="qkw">阳关道</a>。</p><p>而杂货铺似的平台最重要的就是其所支持的 SKU 的数量，因为品牌的缺失导致用户很难对平台产生足够忠诚度。因而，哪个平台支持的 SKU 多，哪个平台最后能获得的流量也就越大。这也是为什么 Wish，SMT，<a href="http://m.so.com/s?q=lazada&amp;src=newstranscode" class="qkw">lazada</a> 等第三方平台在跨境领域独领风骚。</p><p>我的观点是，跨境电商 2C 平台这个行业的终点，或者说终点之一，必然是 SKU 数量最多的那个平台。</p><p class="header">SKU 数量与供应链质量的矛盾</p><p>然而，SKU 的数量和供应链的质量两者难得兼。估计只要是做过电商的人对此都深有体会。举个例子，我们身边最大的厂能生产 1000 件商品，于是我们很轻易的将这 1000 个商品上架。而第二大的厂只能生产 500 件商品，我们花费了同样的力气，只增加了 500 个 SKU。</p><p>以此类推，我们很容易发现，前一千个 SKU 我们只需要管理一个厂家，而第 1001 到第 2000 个 SKU，虽然同样是一千个 SKU，我们需要管理 2-3 个厂家。这个管理成本将会随着 SKU 数量的上升而呈指数型增长。</p><p class="header">SKU 数量与运营的矛盾</p><p>此外，SKU 数量和运营成本两者难兼得。得益于科技的发展，藉由 ERP，CRM 等产品大幅削减了电商的运营成本，实现规模效应。然而，商品管理却一直没有办法实现规模效应，理由如下:</p><p>一是选品。选前 100 个商品和选第 101-200 个商品，虽然所选的商品数量相同，难度差别却很大。这也是为什么大公司需要很多很厉害的买手。跨境电商的需求方来自世界各地，各地都有不同的民俗和喜好，想要找出大量好卖的货比内贸要难得多。而且跨境电商对于选货数量的要求要远大于内贸。</p><p>二是上下架或缺货管理。在电商中，上架只是一个商品的开始，上好货后，要时刻了解货源的动态，缺货则下架，重复货要删除，信息变更要及时，等等。然而，由于跨境卖家人手相较于其所售卖的 SKU 数量来说少得可怜，货品管理的压力很大。有时，运营专员大量刊登重复的货，导致信息不一致等问题。而且，有些企业为了追求 SKU 数量，上货之后不会去检查是否缺货。等消费者真的开始购买，才发现没货，然后下架。这一切都会极大地降低用户体验。</p><p>然而，即使如此牺牲用户体验，做到几万个 SKU，众多 B2C 独立站的运营能力也到了临界点。</p><p class="header">靠不住的平台</p><p>为了解决 SKU 数量带来的瓶颈，传统的方式是靠平台。这是合理的，说到底规模效应由<a href="http://m.so.com/s?q=%E8%BE%B9%E9%99%85%E6%88%90%E6%9C%AC&amp;src=newstranscode" class="qkw">边际成本</a>和边际效益决定。平台新上一个 SKU 的边际成本要远低于 B2C 独立站，因为平台通过市场这只看不见的手动员了社会各界力量。有些卖家，即使一天只能卖一两单，也可能坚持下去，因为一顿饭钱或许就是他们坚持的动力。这个理论同样适用于外贸。</p><p>目前看来，平台方式在外贸领域中非常成功，比如，速卖通，lazada，wish等无一不有成为下一个超级独角兽的趋势。不过，和内贸不同，平台再猖獗，独立 B2C 站依旧在自己的空间闷声发大财。原因在于平台模式存在缺陷:</p><p>物流不规范:平台很难规定其平台上的卖家采用什么物流。卖家的地区、库存情况，货代提供折扣等因素无法驱动卖家使用相同的物流。而B2C则可以采用相同的物流和包装。</p><p>产品重复刊登:平台的另一个问题是过多的重复刊登。虽然重复刊登促进了平台的比价，能帮助用户选到低价商品，但是重复刊登也严重影响用户体验。B2C 如果运营得当，可以减少重复商品出现的概率，减少产品选择过程中的噪音。</p><p>产品质量不好:鉴于平台上卖家的大部分流量来自平台，而非卖家老客户的自然流量，平台卖家缺乏强烈的意愿去让用户满意。因为即便用户满意了开始频繁地造访平台，并不意味着他下次来平台会继续光顾那个曾经让他买得高兴的店铺。</p><p>这些缺陷淘宝也有，不过因为内贸本身非常简单，这些问题显得不那么严重。对跨境电商而言，服务、回款以及用户反馈的周期长，这些问题发生的几率和严重性被放大了很多。比如，好的物流和差的物流可能相差一个月有余，比如，包装简易的产品寄出后更容易破损。然而这些并不是单靠规则就能解决的。</p><p>外贸的服务即使很用心，也会因为俄罗斯的冰雪、清关人员的马虎等不可预知的因素影响服务体验 。所以，平台的规则必然不能太严，否则好的卖家必然会被逼到其他平台上。而过于松垮的规则，则必然造成劣币驱逐良币。换句话说，如果能够赚钱，卖家为什么不疯狂开店铺抢展位，卖假货次品，发最便宜的包裹呢?毫无疑问，这有损平台的利益。</p><p class="header">破题:得长尾者得天下</p><p><img src="http://p34.qhimg.com/t01b57cc73de143fb9e.jpg?size=760x352"></p><p class="img-title">打造爆款。</p><p class="header">总结一下当下外贸玩家的解题思路:</p><p>海外仓 :一大堆公司在做，死掉的不计其数。如我上文所言，适合做海外仓的商品潜在竞争太激烈。更靠谱的方式是对已有爆品进行海外仓处理。归根结底，海外仓是锦上添花。</p><p>精品化 :比如，JollyChic，Shein 等。既然 SKU 太多运营跟不上，那么就缩减 SKU，走高逼格路线。这么做的问题在于市场规模有限，以致这些店都在经历初期高速增长后走品牌化路线，去线下开店。</p><p>严格要求供应链 :以 Bellabuy，速卖通为代表。这是平台发现自己增长乏力之后的玩法。问题在于，当供应链要求严格起来之后，平台的 SKU 会急剧减少。速卖通自 2016 起开始提高准入门槛之后，平台的 SKU 下降了百分之几十。</p><p>转小 B to 小 B :比如 DHgate，但它的转型已经不在 2C 行业的范畴了，但不失为对跨境供应链的进一步探索。</p><p>不过，当下的这些玩法都局限在外贸的条条框框里跳不出来。如果寄希望于从以上这些解题思路中找到终局，机会不大。</p><p>我认为，真正的机会在于系统性地提升整个跨境电商的效率，也就是对行业基础设施进行投资。在提升行业效率的情况下，看看是否会和原有的商业模式发生<a href="http://m.so.com/s?q=%E5%8C%96%E5%AD%A6%E5%8F%8D%E5%BA%94&amp;src=newstranscode" class="qkw">化学反应</a>。比如，保税区的建立，邮政小包价格的补贴，等等。</p><p>电商的本质很简单:对于标品来讲，质量<a href="http://m.so.com/s?q=%E6%9C%8D%E5%8A%A1%E4%B8%BA%E7%8E%8B&amp;src=newstranscode" class="qkw">服务为王</a>;对于非标品，得长尾者得天下。既然跨境电商的本质是非标品，解决方案就在于如何增加长尾的覆盖。</p><p>爆款易通过对全网数据的采集，在建立庞大厂商数据库的同时完善各地区各品类的需求整理，并用<a href="http://m.so.com/s?q=%E4%BA%BA%E5%B7%A5%E6%99%BA%E8%83%BD&amp;src=newstranscode" class="qkw">人工智能</a>连接供需，从而全面提高<a href="http://m.so.com/s?q=%E4%BE%9B%E5%BA%94%E5%95%86%E7%AE%A1%E7%90%86&amp;src=newstranscode" class="qkw">供应商管理</a>和产品开发的效率，达到在控制好成本和服务质量的前提下大量增加平台 SKU 的目的。这能把现有跨境电商卖家的上限提高几十倍，从而脱离因为 SKU 少而被平台吊打的困境。</p><p>想象一下，当一家像京东一样提供规范化服务的电商平台能够服务包括衣服等非标品在内的全品类，将是一件多么令人兴奋的事情。而爆款易正在帮助一万多个外贸卖家铺平这条路，也希望能为所有的外贸卖家系统性地提升跨境电商的基础设施。</p><p><a href="http://m.so.com/s?q=%E8%BF%99%E6%98%AF%E6%9C%80%E5%A5%BD%E7%9A%84%E6%97%B6%E4%BB%A3&amp;src=newstranscode" class="qkw">这是最好的时代</a>，也是最坏的时代。这是外贸巨头将要诞生的时代。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.pedaily.cn/201603/20160315394444.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='188f8ba665d8a77303e573221a0635f3'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>江湖依旧</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%B1%9F%E6%B9%96%E4%BE%9D%E6%97%A7&amp;pn=1&amp;pos=8&amp;m=992216fd718a5d187ee1cd2a5b7f80df4361fd8f&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Ffinance%2F2016-03%2F11%2Fc_128791735.htm" data-pos="1"> 徐翔部下重出<b>江湖</b>:今年以来收益高达90% 秒杀所有公募 </a>   <li> <a href="/transcode?q=%E6%B1%9F%E6%B9%96%E4%BE%9D%E6%97%A7&amp;pn=1&amp;pos=9&amp;m=b0eb408e8e26df7799571266ed47c1342716ce6c&amp;u=http%3A%2F%2Fnews.pedaily.cn%2F201603%2F20160315394444.shtml" data-pos="2"> 跨境电商的<b>江湖</b>,如何诞生阿里、京东巨头? </a>   <li> <a href="/transcode?q=%E6%B1%9F%E6%B9%96%E4%BE%9D%E6%97%A7&amp;pn=1&amp;pos=10&amp;m=70d489c6642be91e849482848c7055736ed81ed7&amp;u=http%3A%2F%2Fwww.js.chinanews.com%2Fnews%2F2016%2F0314%2F150826.html" data-pos="3"> 江苏楼市"炒号""房托"重出<b>江湖</b> 追高需谨慎 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '跨境电商的江湖，如何诞生阿里、京东巨头? ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '跨境电商的江湖，如何诞生阿里、京东巨头? '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";