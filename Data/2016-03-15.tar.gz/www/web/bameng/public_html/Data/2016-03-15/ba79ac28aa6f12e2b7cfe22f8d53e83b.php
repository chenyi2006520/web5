s:17251:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>河北魏县建设美丽乡村重现田园风光- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">河北魏县建设美丽乡村重现田园风光</h1> <p id="source-and-time"><span id=source>中国青年网</span><time id=time>2016-03-03 15:36:31</time></p> </header>  <div id="news-body"><p>中国经济网邯郸3月3日讯 3月3日，<a href="http://m.so.com/s?q=%E6%98%A5%E5%AF%92%E4%B9%8D%E6%9A%96&amp;src=newstranscode" class="qkw">春寒乍暖</a>，阳光明媚，笔者走进<a href="http://m.so.com/s?q=%E9%AD%8F%E5%8E%BF&amp;src=newstranscode" class="qkw">魏县</a>东代固镇后闫庄村，机器声轰鸣，勾机咚咚咚的开凿街道，挖土机正在开挖地下排水管道土方，工人们有的粉刷墙壁，有的正在整理村内残垣断壁，他们昼夜施工，加班加点有序推进各项建设任务，施工现场一派繁忙景象……魏县全面掀起新一轮美丽乡村建设热潮。</p><p>在后<a href="http://m.so.com/s?q=%E9%97%AB%E5%BA%84%E6%9D%91&amp;src=newstranscode" class="qkw">闫庄村</a>民文化广场上，老人们围在一起聊家常，不时传来阵阵笑声，孩童们在一起嬉戏玩耍……一派安逸祥和的景象。提起美丽乡村建设的好处，杨大妈激动的说:“俺村大小街道全部硬化了，阴天下雨再也不用走‘水泥’路啦，村里的街道每天都有人打扫，街道干干净净，村里有超市、饭店，买东西、吃饭非常方便，这不，俺没事就到这广场上扭扭<a href="http://m.so.com/s?q=%E7%A7%A7%E6%AD%8C&amp;src=newstranscode" class="qkw">秧歌</a>、跳跳舞，生活越过越有劲儿。”魏大爷乐呵呵地大声说:“真没想到农村人的生活和城里人的生活没啥区别。”</p><p>魏县县委书记<a href="http://m.so.com/s?q=%E5%8D%A2%E5%81%A5&amp;src=newstranscode" class="qkw">卢健</a>说:“美丽乡村建设是今年工作的重头戏，作为魏县‘三个主战场’之一，按照环境美、产业美、精神美、生态美‘四美’建设要求，统筹规划、精心设计，分期分批、梯次推进，推进美丽乡村提档升级，打造村美民富、生态宜居的<a href="http://m.so.com/s?q=%E7%BE%8E%E4%B8%BD%E6%9D%91%E5%BA%84&amp;src=newstranscode" class="qkw">美丽村庄</a>，重现田园好风光。”</p><p>今年，为提档升级美丽乡村建设水平，后闫庄村依托村周边梨园、河湖公园、礼贤台<a href="http://m.so.com/s?q=%E6%97%85%E6%B8%B8%E6%99%AF%E7%82%B9&amp;src=newstranscode" class="qkw">旅游景点</a>等特色生态旅游资源，在县美丽乡村办和<a href="http://m.so.com/s?q=%E8%B4%A2%E6%94%BF%E5%B1%80&amp;src=newstranscode" class="qkw">财政局</a>驻村工作队帮助下，对村庄进行硬化、绿化、亮化，<a href="http://m.so.com/s?q=%E5%BB%BA%E8%AE%BE%E6%9D%91&amp;src=newstranscode" class="qkw">建设村</a>内地下排水管网，进一步完善基础设施，充分挖掘魏县及村庄文化内涵，在村口设置建设村庄标识，在村内规划建设鸭梨文化展览馆、<a href="http://m.so.com/s?q=%E6%A0%B9%E9%9B%95%E9%A6%86&amp;src=newstranscode" class="qkw">根雕馆</a>、农耕展览馆、土纺土织展览馆、土特产展览馆等重点节点，绘制<a href="http://m.so.com/s?q=%E6%96%87%E5%8C%96%E5%A2%99&amp;src=newstranscode" class="qkw">文化墙</a>，建设农家餐馆、旅馆，并在村外梨园内铺设观赏休闲道路等。</p><p>据了解，后闫庄村是该县打造的梨乡水城风景片区内的8个美丽乡村重点村之一，他们将依托县城周边20万亩梨园、环城水系、旅游景点等旅游资源，大力发展农家乐、休闲游。目前，该县后闫庄、前闫庄、<a href="http://m.so.com/s?q=%E5%8C%97%E5%BC%A0%E5%BA%84&amp;src=newstranscode" class="qkw">北张庄</a>、东南温等8个村庄正在按照设计规划紧张建设中，预计3月底完工。“三月底、四月初<a href="http://m.so.com/s?q=%E6%A2%A8%E8%8A%B1%E7%9B%9B%E5%BC%80&amp;src=newstranscode" class="qkw">梨花盛开</a>之际，游客来到魏县，可徜徉花海赏梨花，进村品民俗文化，购<a href="http://m.so.com/s?q=%E5%9C%B0%E6%96%B9%E7%89%B9%E4%BA%A7&amp;src=newstranscode" class="qkw">地方特产</a>，吃农家饭、住农家院……让游客到这里回归田园，记住乡愁，流连忘返。”魏县政府县长樊中青说。</p><p>今年，魏县在美丽乡村建设上，按照以点连线、以线带片、以片成面的总体布局，将全县重点打造的145个美丽乡村重点村，划分梨乡水城风景片区村、工业园区片区村、<a href="http://m.so.com/s?q=%E7%8E%B0%E4%BB%A3%E5%86%9C%E4%B8%9A%E5%9B%AD%E5%8C%BA&amp;src=newstranscode" class="qkw">现代农业园区</a>片区村、易地扶贫搬迁项目片区村、交通主干线村、扶贫村、历史文化名村等八个类型村实施建设，因村制宜、精准定位，形成风格迥异、亮点鲜明的样板村。</p><p>魏县县委农工委常务副书记<a href="http://m.so.com/s?q=%E5%BC%A0%E4%BF%8A%E6%9D%B0&amp;src=newstranscode" class="qkw">张俊杰</a>介绍说，围绕“四美”建设目标，魏县大力实施农村环境整治提升工程，推进“环卫保洁公司化、监督管理网格化、垃圾处理一体化、乡镇政府驻地管理常态化”，建立完善公司化卫生保洁机制，推行“一人一月一元钱”模式，形成政府与群众共建共享的有效管护机制，实现农村环境美。按照“村有特色产业、户有致富门路”的思路，因村制宜培育一批<a href="http://m.so.com/s?q=%E4%B9%A1%E6%9D%91%E6%97%85%E6%B8%B8&amp;src=newstranscode" class="qkw">乡村旅游</a>、特色种养和家庭手工业特色专业村，实现农村产业美。实施村庄绿化工程，突出“本地树、栽大树、保成活”的要求，倾力打造绿树成荫、村在林中、人在绿中的乡村环境，实现农村生态美。实施社会治理提升工程，切实改善农村生产生活条件，大力倡导健康文明的社会风尚，提升群众幸福指数，实现农村精神美。(张 佩 郭海民 茜秀臣)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.youth.cn/jsxw/201603/t20160303_7700714.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='32d3cc45aa2c5ca7d92f2eb7439bb9e0'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>田园风光</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%94%B0%E5%9B%AD%E9%A3%8E%E5%85%89&amp;pn=1&amp;pos=4&amp;m=e7340f70cbe5387749fec87de04a5b86b7533881&amp;u=http%3A%2F%2Fdy.qq.com%2Farticle.htm%3Fid%3D20160311A050DI00" data-pos="1"> 杭州自驾1.5h直达的<b>田园</b>牧歌生活,有绝美<b>景致</b>还有家的气息 </a>   <li> <a href="/transcode?q=%E7%94%B0%E5%9B%AD%E9%A3%8E%E5%85%89&amp;pn=1&amp;pos=5&amp;m=6389d5175ca03c0066ec754bb78951bb3a848231&amp;u=http%3A%2F%2Fnd.fjsen.com%2Ff%2F2016-03%2F11%2Fcontent_17481739_all.htm" data-pos="2"> 川石:独具特色的<b>田园风光</b>美丽乡村建设 </a>   <li> <a href="/transcode?q=%E7%94%B0%E5%9B%AD%E9%A3%8E%E5%85%89&amp;pn=1&amp;pos=6&amp;m=34bb05d756d38078379c1443c333a28025aa1b6f&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fahnews_0301%2F4444519.html" data-pos="3"> 如诗如画<b>田园风光</b>渐显 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '河北魏县建设美丽乡村重现田园风光' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '河北魏县建设美丽乡村重现田园风光'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";