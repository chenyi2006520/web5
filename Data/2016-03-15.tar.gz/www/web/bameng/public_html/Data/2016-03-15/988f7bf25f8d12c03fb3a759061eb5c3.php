s:31812:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>三星堆遗址北部城圈露真容 月亮湾小城可能是宫城- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">三星堆遗址北部城圈露真容 月亮湾小城可能是宫城</h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2016-03-02 08:19:00</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t01f37b966be6697170.jpg?size=400x300"></p><p><a href="http://m.so.com/s?q=%E4%B8%89%E6%98%9F%E5%A0%86&amp;src=newstranscode" class="qkw">三星堆</a>遗址各段城墙平面位置图。 (除署名外，均本报资料照片)</p><p><img src="http://p35.qhimg.com/t0181788bc4dd7e3690.jpg?size=400x267"></p><p>李伯谦(前)、林留根(后左)、雷雨(后右)等在讨论北城墙断代等问题。本报记者 付鑫鑫摄</p><p><img src="http://p34.qhimg.com/t019d309b5651fd06f7.jpg?size=400x267"></p><p>参加成果论证会的专家在青<a href="http://m.so.com/s?q=%E5%85%B3%E5%B1%B1&amp;src=newstranscode" class="qkw">关山</a>城墙附近分析、讨论。本报记者 付鑫鑫摄</p><p><img src="http://p33.qhimg.com/t01d1a7acdfbddf4293.jpg?size=399x600"></p><p class="img-title">红烧土建筑F3内发掘象牙时的情景。</p><p><img src="http://p34.qhimg.com/t01e0939a18d6ea95e5.jpg?size=400x177"></p><p><a href="http://m.so.com/s?q=%E9%87%91%E7%AE%94&amp;src=newstranscode" class="qkw">金箔</a>片</p><p><img src="http://p34.qhimg.com/t01e0939a18d6ea95e5.jpg?size=400x177"></p><p class="img-title">玉璋</p><p><img src="http://p34.qhimg.com/t01e0939a18d6ea95e5.jpg?size=400x177"></p><p><a href="http://m.so.com/s?q=%E7%BB%BF%E6%9D%BE%E7%9F%B3&amp;src=newstranscode" class="qkw">绿松石</a></p><p><img src="http://p34.qhimg.com/t01e0939a18d6ea95e5.jpg?size=400x177"></p><p>青关山土台出土的玉锛。本报记者 付鑫鑫</p><p>日前，三星堆遗址201 1~2015年考古勘探、发掘成果专家论证会在四川省<a href="http://m.so.com/s?q=%E5%B9%BF%E6%B1%89%E5%B8%82&amp;src=newstranscode" class="qkw">广汉市</a>举行。会上，四川省文物考古研究院副研究员、三星堆遗址工作站站长雷雨公布了“十二五”期间取得的进展，包括:新发现5道城墙，合围2个小城，城圈结构逐渐清晰;新发现青关山土台及3座大型红烧土建筑，<a href="http://m.so.com/s?q=%E6%9C%88%E4%BA%AE%E6%B9%BE&amp;src=newstranscode" class="qkw">月亮湾</a>小城的性质初步明确;新发现新石器时代晚期夯土台面，明确三星堆遗址是新石器时代晚期又一中心遗址。尤为重要的是，三星堆遗址北城墙的发现，实现了近30年来三星堆考古工作者的夙愿;同时，用实证否定了以前的判断---曾以为<a href="http://m.so.com/s?q=%E9%B8%AD%E5%AD%90%E6%B2%B3&amp;src=newstranscode" class="qkw">鸭子河</a>是三星堆遗址天然北墙。</p><p>三星堆遗址是迄今为止西南地区面积最大、出土文物最为丰富的新石器时代至商周时期遗址。三星堆遗址的发现及三星堆文物的出土，使自古以来<a href="http://m.so.com/s?q=%E7%9C%9F%E4%BC%AA%E8%8E%AB%E8%BE%A8&amp;src=newstranscode" class="qkw">真伪莫辨</a>的古蜀史传说成为信史。古蜀国的中心，也因三星堆得到确认。</p><p>三星堆古蜀国是中国古代中原周边地区颇具典型意义的“古国”之一，填补了中华文化演进序列中的缺环。<a href="http://m.so.com/s?q=%E4%B8%89%E6%98%9F%E5%A0%86%E6%96%87%E6%98%8E&amp;src=newstranscode" class="qkw">三星堆文明</a>作为长江上游古代文明的杰出代表，再次证明中华文明起源的多元化。</p><p>始于1929年的考古工作史，震惊世人，重大发现层出不穷。</p><p><a href="http://m.so.com/s?q=%E5%86%AC%E6%9C%AB%E6%98%A5%E5%88%9D&amp;src=newstranscode" class="qkw">冬末春初</a>，四川盆地夜长昼短，清晨7点，明晃晃的月亮还挂在天上。即使是上午8点，天蒙蒙亮，薄薄的雾气仍旧笼罩在山野<a href="http://m.so.com/s?q=%E6%B2%B3%E6%B6%A7&amp;src=newstranscode" class="qkw">河涧</a>之上，平添了一层朦胧美。鸭子河两岸的芦苇随风摆动，汽车在无人的乡间公路上疾驰，路旁的油菜花身染寒霜却傲然挺立……</p><p>距离成都市区约四五十公里的广汉市三星堆遗址，就隐匿在这片村落里。下车后，翻过一片菜地，爬上一个<a href="http://m.so.com/s?q=%E5%B0%8F%E5%9D%A1&amp;src=newstranscode" class="qkw">小坡</a>，就到了四川省文物考古研究院工作人员冉宏林的工作地---青关山土台。</p><p>2013年，冉宏林从<a href="http://m.so.com/s?q=%E5%8C%97%E4%BA%AC%E5%A4%A7%E5%AD%A6%E8%80%83%E5%8F%A4%E6%96%87%E5%8D%9A%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">北京大学考古文博学院</a>硕士毕业。身为重庆人，他对川渝地区有着独特的情感，总希望能够用己所长、回报故乡。毕业后，他顺利地进入<a href="http://m.so.com/s?q=%E5%9B%9B%E5%B7%9D%E7%9C%81&amp;src=newstranscode" class="qkw">四川省</a>文物考古研究院工作，并入驻三星堆考古工作站。</p><p>5年考古最大成就是啥?北部城圈结构基本清晰</p><p>参加工作后，冉宏林亲眼见证了“十二五”期间三星堆考古陆续取得的突破。在三星堆遗址北部，相继发现5道城墙，分别为真武宫城墙、仓包包城墙、青关山城墙、马屁股城墙和李家院子城墙(见右上图)。</p><p>真武宫城墙，位于三星堆城址北部的真武宫梁子上，北临鸭子河。大致呈西北---东南走向，残长逾200米，顶残宽约15米、底宽逾21米、残高1.7米，始筑于三星堆遗址二期偏晚，即夏代晚期。</p><p>“真武宫城墙呈斜向堆筑，城墙结构与月亮湾城墙相同。真武宫城墙的东端与月亮湾城墙的北段几乎垂直相接，二者可能为同时建造。”在三星堆遗址2011~2015年考古勘探、发掘成果专家论证会上，报告人、四川省文物考古研究院三星堆考古工作站站长雷雨介绍说。</p><p>其次是仓包包城墙，位于三星堆城址东北部的仓包包梁子上，大致呈西北---东南走向，东抵东城墙北段并与之近直角相接，西隔月亮湾城壕与月亮湾城墙垂直相望，南侧并行一条宽约40米的城壕并与月亮湾城壕相通。残长550米、顶宽约20米、底宽近30米、残高2.7米，始筑于三星堆遗址三期，即商代。斜向堆筑，城墙结构堆筑方法与南城墙基本相同。</p><p>而青关山城墙，位于三星堆城址西北部的青关山<a href="http://m.so.com/s?q=%E5%8F%B0%E5%9C%B0&amp;src=newstranscode" class="qkw">台地</a>北缘，城墙走向与真武宫城墙相近，二者位于同一直线上。残长140米、顶部残宽10-15米、残高近3米，始筑于三星堆遗址二期偏晚，即夏代晚期。</p><p>“青关山城墙的筑造方法和结构，与真武宫城墙相同。由于两道城墙基本位于同一直线上，我们可以推断青关山城墙与真武宫城墙都是北城墙的部分所在。”冉宏林在青关山土台实地解释道。</p><p>马屁股城墙，位于三星堆城址东北角，仓包包台地东北边缘，北侧即为鸭子河滩地。目前保存状况较差，现存残高仅0.2米至1.6米。城墙呈拐角状，南接东城墙北段，西延约20米长并可直线对接真武宫城墙(北城墙中段)。经考古发掘和勘探明确，确认该拐角由外廓城“东城墙北段”和“北城墙东段”残留构成，始筑于三星堆遗址三期，即商代，且城墙结构与东城墙南段相近。</p><p>李家院子城墙位于三星堆城址东北部，南端与仓包包城墙西端相接，北边为坐落于鸭子河滩地的李家院子。现存长度约150米，宽约20~25米，西(外)侧壕沟与月亮湾城墙共用，始筑于三星堆遗址三期，即商代。</p><p>“李家院子城墙的筑墙方法，与仓包包城墙基本相同。考古发掘还确认了李家院子城墙和仓包包城墙明确相连，二者应为同时建造。”雷雨说，此外，还发现有城墙修筑时的施工通道，城墙东(内)侧有补筑现象。</p><p>从年代来说，月亮湾城墙、真武宫城墙、青关山城墙和西城墙北段的城墙结构相同，始筑年代均为夏代晚期，因此，这几道城墙极有可能是同时期建造的，它们可以合围成一个小城，即月亮湾小城，面积将近46万平方米。仓包包城墙、李家院子城墙、马屁股城墙和东城墙北段也可合围成一个小城，即仓包包小城，其面积约8.8万平方米。</p><p>雷雨强调说，随着外廓城北城墙(青关山-真武宫-马屁股)等城墙的确认，以及月亮湾小城和仓包包小城的合围，三星堆城址，尤其是北部，城圈结构已基本清晰。这对于认识三星堆城址的聚落结构具有深远意义。</p><p class="header">精美文物有哪些?金箔、玉璋和绿松石</p><p>冉宏林说，以前社会公众只知道祭祀坑出土了青铜面具等精美文物，可对考古工作者来说，光有点上的工作是不够的，最重要的是点、线、面的结合。</p><p>“‘十二五’以来，最大的考古发现就是点、线、面都有取得突破。在勘探和调查方面，我们不仅对遗址本身的遗存分布、堆积状况和保存情况有全面认识，还跳出遗址本身，研究了遗址与其所处区域的关系，即在‘面’上有重要收获。‘线’上则是北边5座城墙的相继发掘。青关山土台和土台上3座红烧土建筑，就是‘点’上的工作。”站在青关山土台上，冉宏林一边接受采访，一边对技工、民工发掘出土的陶片进行审视、判断。</p><p>他告诉记者，每次发掘，出土的陶片数以千、万计，别看陶片很不起眼，但分期、断代全靠它们。出土的碎陶片拼接成完整器形后，可用<a href="http://m.so.com/s?q=%E7%B1%BB%E5%9E%8B%E5%AD%A6&amp;src=newstranscode" class="qkw">类型学</a>来进行分析。“所谓类型学，就是通过一些器物的演变，比如说，陶器从高瘦型变成矮胖型等。我们将器物形制伴随岁月流逝呈现的变化，排成一个新的<a href="http://m.so.com/s?q=%E6%97%B6%E9%97%B4%E8%BD%B4&amp;src=newstranscode" class="qkw">时间轴</a>。遇上新出土的陶器，在时间轴上做比对，判断它更接近于哪个时代，并得出相应的推论。”</p><p>实际上，青关山土台，位于月亮湾小城西北角的青关山台地南半部，北边间隔约20米即为青关山城墙。经过勘探得知，土台面积近5500平方米，厚约4米，由夯土、红烧土和文化层相间叠压堆积形成，其年代从新石器时代晚期一直延续至西周时期。</p><p>土台和青关山之间宽约20米的凹地内，填充的多为西周至春秋时期生活堆积，也有出土大量西周时期完整陶器，乃至玉璋、绿松石和金箔片等高等级文物的灰坑、灰沟和房址等。这表明在西周时期，至少在西周早期，三星堆遗址仍比较繁荣，尚未极速衰落。</p><p>据介绍，在青关山土台的灰坑(即生活垃圾坑)中，出土了2块金箔片，约大拇指指甲盖大小;残留的玉璋长约30厘米、宽约15厘米，还有4粒绿豆般大小的绿松石。</p><p>“每粒绿松石上都有小孔，我们当时还特别遗憾，怎么就剩这么几个了。要是有一整串，该有多好!”冉宏林说，考古就是一门遗憾的艺术。一旦发掘哪里，最好把所有的信息都提取完毕，否则，挖了就是破坏，以后再挖又会构成新的破坏。“况且，文物是不可再生的，挖了一次就不能重来了。”</p><p>在土台上，冉宏林详细讲解了编号为F1-F3的三座大型红烧土建筑。揭露最完整的建筑F1位于土台南部，平面为长方形，纵轴呈东南---西北走向，长逾65米，宽近16米，建筑面积逾1000平方米，是三星堆遗址迄今为止发现的、面积最大的商代单体建筑基址。</p><p>推测F1可能为干栏---楼阁式建筑，由多间“正室”以及相对应的“U”字形“楼梯间”组成，所有房间分为两排，沿中间的“穿堂过道”对称分布，廊道两侧各有3排柱洞，南、北、西墙墙基外侧有一排密集排列的凸字形“檐柱”遗迹，其内侧有一列平行的“柱础”。根据地层叠压关系、墙基内包含物以及建筑形制判断，F1的使用年代大约为三星堆遗址三期(商代)，废弃年代大致与一、二号祭祀坑同时。</p><p>在一些被画了圈的柱洞内，累积着好些卵石。冉宏林告诉记者，这些卵石推测是巩固木柱的根基，功能类似是现代石柱的柱基。“依照当时的生产力水平，建造如此大型的单体建筑，通常非富即贵，不是一般百姓能够负担得起的。普通人家，树篱糊墙，立几根木头柱子，架起篱笆，糊上泥巴，烘烤一下就完事了。”</p><p>F2尚未揭露，形制并不明显，不过，根据F2的夯土面被F1红烧土叠压，推测其年代应早于F1，有可能是F1前身。</p><p>城址发掘有何重大意义?月亮湾小城可能是宫城</p><p>F3的发掘起源于当时寻找F1的东墙。那是2014年下半年，在F1东侧发现了红烧土，起初以为是F1的东墙，顺藤摸瓜才发现是两个建筑遗址。后来，总算摸清楚了F3的北墙和东墙。只是，F3保存也不完整，通过现存部分看，其走向、形制与F1相似，年代也基本相当。</p><p>“F3里面出土了一根口径约15厘米的象牙，我们当时还是很兴奋的。”冉宏林激动地回忆自己第一次发现象牙的情景:当时，听说有象牙，考古工作人员第一反应不是马上取出象牙，而是要给它“安户口”。具体来说，就是象牙出在哪个土层，这个土层大约是哪个年代的，这样才好帮它断代。</p><p>冉宏林推测说，建造F1、F3这样高等级的建筑，首先要平整地面，因此，有可能要从其他的地方运土来夯平地表。为保证建成后的房子屹立不倒，还可能举办祭祀仪式。在填土或建筑过程中埋入象牙、玉璧和石壁等物，很有可能与祭祀有关。这也就是为什么附近的祭祀坑、仁胜墓地以及成都金沙遗址都有出土象牙的重要原因。</p><p>距离象牙发现地几米处，在F3西北角区域还发现有打破F3的南宋墓葬。据说，在考古发掘前，青关山土台曾是一片<a href="http://m.so.com/s?q=%E6%A1%83%E6%9E%97&amp;src=newstranscode" class="qkw">桃林</a>和养鸡场。近年来，随着考古发掘的深入，这里除了遗址，还出土了很多古代墓葬，以汉代和宋代的墓葬居多，甚至还有战国船棺墓葬。</p><p>在F1的北边，记者还发现有6个大小不一、长条形状的坑洞。冉宏林说，至今，考古工作人员也不知道这些究竟是什么，作何用途。“此类未解之谜，只能有待将来揭晓谜底。”</p><p>在雷雨看来，青关山土台和F1、F2、F3三座大型红烧土建筑的发现，表明这一区域属于遗址核心地带，极有可能是当时的高等级人群活动区域。在月亮湾台地，历年也发现有陶瓦等重要遗物，可知该区域也十分重要。“我们目前推断，囊括青关山土台和月亮湾台地在内的月亮湾小城，很有可能是三星堆城址的宫城。”</p><p>距离F1建筑约20米开外，在发掘青关山城墙(约处夏代晚期，距今3600年左右)的过程中，还发现一处新石器时代晚期的夯土台面 (距今逾4100年以上)。该台面表面大致平整光滑，由浅黄色和青灰色粘土夯筑而成，未见夯窝等夯打遗迹，其面积应在500平方米以上。</p><p>在夯土台面的偏北区域发现两排23个柱洞，柱洞直径最大可达40厘米，最小也有20厘米以上，两排柱洞整体长约10米，间距约2米。受发掘面积所限，两排柱洞所属建筑的面积和结构尚不清楚，推测应是一座大型建筑。</p><p>“小的柱洞，有出土过竹子被烧后炭化的痕迹，推测当时的平民建筑可能是竹骨篱墙。”冉宏林说，“这么光滑的夯土台面，台面之上还有大型建筑，据此推断，三星堆遗址的重要性肯定不亚于宝墩文化遗址。在新石器时代晚期，三星堆遗址同样是成都平原的中心遗址之一。”</p><p>青关山城墙的主体发掘工作已于去年6月结束，并在城墙下面发现了3座新石器时代晚期的墓葬，其中一个墓穴的人骨清晰可见，仔细看还能看到人的手指骨。除了大量陶片，尚未发掘出其他随葬品。令人遗憾的是，陶器没有区分主人身份的功能，墓葬应为平民墓穴。</p><p>未来考古方向是在哪儿?水系、墓葬区、手工业</p><p>问及对三星堆过去的考古工作有什么心得体会，冉宏林很谦虚。他说，他学的专业是考古，考古就是每天发掘、再发掘。“我个人不喜欢太复杂的生活，考古嘛，关键是要耐得住寂寞!我一直住在三星堆考古工作站里，每天骑自行车上下班。对我来说，工地每一铲土下都是惊喜。因为我们不是为了发掘特别的文物，而是为了解决学术问题才来干这行的。”</p><p>据悉，过去5年间，四川省文物考古研究院已在三星堆遗址西城墙外、西北角，沿鸭子河上游，做了55平方公里的考古调查;并在遗址保护范围内，做了约9平方公里的考古勘探。这些摸底工作，将为“十三五”期间的三星堆考古打下坚实的基础。</p><p>雷雨说，西城墙在月亮湾小城处有一个拐角，然后南段与其有一段距离是空白的，初步认定，这是三星堆<a href="http://m.so.com/s?q=%E5%8F%A4%E5%9F%8E&amp;src=newstranscode" class="qkw">古城</a>水门所在。除了水门，在对北城墙的考古发掘中，还发现了一条“大沟”，这条<a href="http://m.so.com/s?q=%E5%A4%A7%E6%B2%9F&amp;src=newstranscode" class="qkw">大沟</a>将月亮湾小城和北城墙隔开，而且马牧河穿三星堆古城而过，说明三星堆时期，城内水系很发达。</p><p>为此，陕西省考古研究院院长王炜林指出，既然在西城墙有一处水门，水系与古代聚落联系紧密。“我建议，是否有必要在‘十三五’规划中，重点关注三星堆遗址水系研究。第二点，则是南城墙处遗迹较少，其附近遗址的功能定位也可多留心。”</p><p>南京博物院考古研究所所长林留根说，三星堆遗址的水系十分复杂，如果这个问题不解决好，那么城池的使用功能和平面布局就没法做到清晰可辨。“城墙中间出现水门，城内有水系，这条水系有没有可能不是城墙外的护城河，而是解决百姓生活用水的?另外，三星堆遗址城墙拐角不够明显，是否也与水系有关?”</p><p>据三星堆研究院院长肖先进透露，截至目前，西城墙、月亮湾小城和高等级墓葬区等功能分区并不清楚，或许可以成为“十三五”规划的重点。他还提出，四川早期先民的建筑中，出现过前院有柱子、后院仅为土坯墙的大型建筑，可否作为研究三星堆建筑遗址的参照物。</p><p>北京大学考古文博学院教授李伯谦在总结发言时说，建议三星堆考古把高等级人群的墓葬区(即俗称的“王墓”)寻找作为一个重要内容，因为这类墓葬往往浓缩了一个时期的文化精髓。</p><p>冉宏林解释道，上世纪90年代，在三星堆遗址外围仁胜村曾抢救性地发掘了仁胜墓地20多座墓葬，但仍不是高等级墓葬。而上世纪80年代末，2个祭祀坑出土的精美文物如此之多。“因此，我们有理由认为，2个祭祀坑单独摆在那里不太合理，理论上，周边应该有祭祀用的宫殿等建筑或其他遗迹，甚至高等级墓葬区。”</p><p>一号、二号祭祀坑出土如此多的青铜器、玉器，其制作耗时耗力，相信只有当时的垄断阶层才有权力发号施令、调配众人完成如此浩大、繁复的工程。那么，这些器物是怎么做出来的?手工艺人在哪里?他们是如何被管理的?这些问题都有待进一步研究。</p><p>“根据专家们的建议，我们现在的计划是先做城址和水系，再做墓葬区和手工业。”冉宏林说，希望每天都有新收获。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://culture.people.com.cn/n1/2016/0302/c22219-28163513.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='6f3cef6193cac5764ab2dd03c80017d6'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>月亮湾</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9C%88%E4%BA%AE%E6%B9%BE&amp;pn=1&amp;pos=3&amp;m=7197e4453221a4544ae7f8070203b278a2141d29&amp;u=http%3A%2F%2Fnews.focus.cn%2Fyichang%2F2016-03-08%2F10738310.html" data-pos="1"> 楼盘测评:清能地产卷土再来 <b>月亮湾</b>兼神助攻 </a>   <li> <a href="/transcode?q=%E6%9C%88%E4%BA%AE%E6%B9%BE&amp;pn=1&amp;pos=4&amp;m=6745ebf3038e9e510a0606651f84ad046e61c47c&amp;u=http%3A%2F%2Fwww.eol.cn%2Fzhejiang%2Fzhejiang_news%2F201603%2Ft20160307_1373063.shtml" data-pos="2"> <b>月亮湾</b>幼儿园开展"聚焦G20,寻家乡美景"毅行活动 </a>   <li> <a href="/transcode?q=%E6%9C%88%E4%BA%AE%E6%B9%BE&amp;pn=1&amp;pos=5&amp;m=f0a0aab69e7b64ac0bb996613be95d77145124da&amp;u=http%3A%2F%2Fnb.house.sina.com.cn%2Fscan%2F2016-03-04%2F10126111342410456164425.shtml" data-pos="3"> 恒大山水城<b>月亮湾</b>均价5955元每平米起(图) </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '三星堆遗址北部城圈露真容 月亮湾小城可能是宫城' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '三星堆遗址北部城圈露真容 月亮湾小城可能是宫城'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";