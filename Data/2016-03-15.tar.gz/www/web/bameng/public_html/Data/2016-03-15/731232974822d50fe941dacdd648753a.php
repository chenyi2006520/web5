s:28346:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>2016年广东江门市蓬江区招聘教职员公告- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">2016年广东江门市蓬江区招聘教职员公告</h1> <p id="source-and-time"><span id=source>国家公务员考试网</span><time id=time>2016-03-14 10:22:32</time></p> </header>  <div id="news-body"><p>2016年<a href="http://m.so.com/s?q=%E6%B1%9F%E9%97%A8%E5%B8%82&amp;src=newstranscode" class="qkw">江门市</a>蓬江区教职员招聘公告</p><p><a href="http://m.so.com/s?q=%E8%93%AC%E6%B1%9F%E5%8C%BA&amp;src=newstranscode" class="qkw">蓬江区</a>是享有“中国侨都”美誉的江门市中心城区，是江门市政治、经济、文化中心，是广东省教育强区、广东省推进教育现代化先进区、全国义务教育发展基本均衡区(简介详见附件4)。2016年，蓬江区根据<a href="http://m.so.com/s?q=%E3%80%8A%E5%B9%BF%E4%B8%9C%E7%9C%81%E4%BA%8B%E4%B8%9A%E5%8D%95%E4%BD%8D%E5%85%AC%E5%BC%80%E6%8B%9B%E8%81%98%E4%BA%BA%E5%91%98%E5%8A%9E%E6%B3%95%E3%80%8B&amp;src=newstranscode" class="qkw">《广东省事业单位公开招聘人员办法》</a>(粤府令第139号)和<a href="http://m.so.com/s?q=%E3%80%8A%E6%B1%9F%E9%97%A8%E5%B8%82%E4%BA%8B%E4%B8%9A%E5%8D%95%E4%BD%8D%E5%85%AC%E5%BC%80%E6%8B%9B%E8%81%98%E4%BA%BA%E5%91%98%E5%AE%9E%E6%96%BD%E6%84%8F%E8%A7%81%E3%80%8B&amp;src=newstranscode" class="qkw">《江门市事业单位公开招聘人员实施意见》</a>(江人社发〔2010〕573号)精神，坚持公开、平等、竞争、择优的原则招聘教职员，现将有关事项公告如下:</p><p class="header">一、招聘职位</p><p>招聘教职员90名，其中，小学80名，初中5名，高中4名，教育财务核算中心1名。具体职位参见<a href="http://m.so.com/s?q=%E3%80%8A%E6%B1%9F%E9%97%A8%E5%B8%82%E8%93%AC%E6%B1%9F%E5%8C%BA%E6%8B%9B%E8%81%98%E4%B8%AD%E5%B0%8F%E5%AD%A6%E6%95%99%E8%81%8C%E5%91%98%E8%81%8C%E4%BD%8D%E8%A1%A8%E3%80%8B&amp;src=newstranscode" class="qkw">《江门市蓬江区招聘中小学教职员职位表》</a>(附件1)。</p><p class="header">二、招聘对象和条件</p><p class="header">(一)招聘对象</p><p class="header">1、小学和初中专任教师招聘对象</p><p>(1)2016年全日制师范类应届毕业生(不含暂缓就业毕业生)。</p><p class="header">(2)在编在岗教师</p><p>①具有中学二级(或小学一级)及以上职称并获县(区)级及以上荣誉(专指党委政府或<a href="http://m.so.com/s?q=%E6%95%99%E8%82%B2%E8%A1%8C%E6%94%BF%E9%83%A8%E9%97%A8&amp;src=newstranscode" class="qkw">教育行政部门</a>授予的优秀校长、优秀教师、优秀党员、优秀党务工作者、先进教育工作者、优秀班主任【德育工作者】、教坛新秀、名师、学科带头人、教研积极分子、参加县【区】级及以上教研室组织的课堂教学【含教学基本功】现场比赛获得一等奖)的教师。</p><p>②具有副高(中学高级教师、小学副高)职称的教师。</p><p>(3)2015年12月31日前在蓬江区公办中小学从事教学工作现仍在教学岗位上的人员(以区教育局已备案的名单为准)。</p><p>(4)正在蓬江区辖区服役军人的配偶。</p><p>(5)获得研究生学历或硕士学位的人员。</p><p class="header">2、高中专任教师招聘对象</p><p>(1)获得研究生学历或硕士学位的人员。</p><p>(2)2016年全日制师范类应届毕业生(不含暂缓就业毕业生)。</p><p class="header">3、非专任教师招聘对象</p><p>(1) 校医招聘对象: 临床医学专业，持有<a href="http://m.so.com/s?q=%E3%80%8A%E6%89%A7%E4%B8%9A%E5%8C%BB%E5%B8%88%E8%B5%84%E6%A0%BC%E8%AF%81%E3%80%8B&amp;src=newstranscode" class="qkw">《执业医师资格证》</a>，有两年以上(含两年)医学工作经验的人员。</p><p>(2)实验员招聘对象:所学专业与应聘学科专业对口的人员。</p><p>(3)教育财务核算中心职员招聘对象:财会及相关专业毕业，持有初级及以上会计专业技术资格证书，有两年以上(含两年)财会工作经验的人员。</p><p>备注1:考生被录用后，不按原来职称岗位聘任，而是根据分配所在学校的职称、岗位空缺情况给予聘任。</p><p class="header">(二)基本条件</p><p>1、具有中华人民共和国国籍，享有公民政治权利，遵守<a href="http://m.so.com/s?q=%E4%B8%AD%E5%8D%8E%E4%BA%BA%E6%B0%91%E5%85%B1%E5%92%8C%E5%9B%BD%E5%AE%AA%E6%B3%95&amp;src=newstranscode" class="qkw">中华人民共和国宪法</a>和法律。</p><p>2、具有良好的品行和职业道德，有较强的组织能力，能胜任班主任工作和岗位相关工作。</p><p>3、具有岗位所需的专业或者技能条件，符合招聘的相关规定资格。</p><p class="header">4、报考专业:</p><p>(1)报考学科须与所学专业一致或与<a href="http://m.so.com/s?q=%E3%80%8A%E6%95%99%E5%B8%88%E8%B5%84%E6%A0%BC%E8%AF%81%E4%B9%A6%E3%80%8B&amp;src=newstranscode" class="qkw">《教师资格证书》</a>认定的任教学科一致或与专业技术职称评审认定的学科一致。</p><p class="header">(2)其他事宜:</p><p>报考“英语”学科的须为英语专业毕业生或<a href="http://m.so.com/s?q=%E3%80%8A%E6%95%99%E5%B8%88%E8%B5%84%E6%A0%BC%E8%AF%81%E3%80%8B&amp;src=newstranscode" class="qkw">《教师资格证》</a>认定学科为英语;报考科技学科的须另外具有在中学及以上读书期间或在社会工作期间本人参加或指导学生参加各类型理科类竞赛(创新设计、制作类优先)中获得区级(或大学二级学院院级)及以上奖励证书(含辅导奖)。</p><p>5、年龄:45周岁以下(1970年4月1日以后出生)，其中教育财务核算中心40周岁以下(1975年4月1日以后出生)。</p><p>6、学历:报考高中专任教师的考生须为研究生学历或具有硕士学位;其余的考生为本科及以上学历。</p><p>7、教师资格证:报考专任任教师岗位须取得相应的教师资格证。</p><p>8、适应岗位要求的身体条件，身体状况符合<a href="http://m.so.com/s?q=%E3%80%8A%E5%B9%BF%E4%B8%9C%E7%9C%81%E6%95%99%E5%B8%88%E8%B5%84%E6%A0%BC%E7%94%B3%E8%AF%B7%E4%BA%BA%E5%91%98%E4%BD%93%E6%A0%BC%E6%A3%80%E6%9F%A5%E6%A0%87%E5%87%86%E3%80%8B&amp;src=newstranscode" class="qkw">《广东省教师资格申请人员体格检查标准》</a>，无精神病史。</p><p class="header">9、符合国家计划生育规定。</p><p class="header">10、服从组织分配。</p><p>备注2:尚未解除纪律处分或者正在接受纪律审查的人员，以及刑事处罚期限未满或者涉嫌违法犯罪正在接受调查的人员，不得应聘。</p><p class="header">三、招聘程序及注意事项</p><p class="header">(一)报名</p><p class="header">1、报名方式:网上填表报名。</p><p>2、报名时间: 2016年3月28日至3月30日。</p><p>3、报名地址:http://<a href="http://m.so.com/s?q=pjedu&amp;src=newstranscode" class="qkw">pjedu</a>.jmpj.gov.cn.</p><p>4、报考科目:参见附件3的报考科目或《教师资格证书》认定的任教科目或专业技术职称评审认定的科目。如附件3中没有对应学科则参照相近学科报考，但以现场审核确认为准。</p><p class="header">5、其他事宜:</p><p class="header">(1)每个考生限报1个职位。</p><p>(2)报名上传电子相片要求:本人近期正面免冠证件照，文件类型为JPG格式，尺寸为168像素×240像素，不大于35K.</p><p class="header">(二) 现场确认报名资料</p><p>1、确认时间:2016年4月12日、13日，每天上午9:00-11:30,下午2:30-5:00.每个考生确认资料的具体时间安排，于2016年4月7日在网上公布，请留意。</p><p>2、确认地点:江门市农林小学(江门市<a href="http://m.so.com/s?q=%E5%86%9C%E6%9E%97%E6%A8%AA%E8%B7%AF&amp;src=newstranscode" class="qkw">农林横路</a>21号)。</p><p>3、相关要求:考生本人须到现场确认。每个职位的计划招聘人数与有效报名人数须达到1:3比例才能开考。如达不到上述比例，将视情况合理调整招聘人数。</p><p>4、考生提供资料:考生须按如下要求用A4纸将报名表和报名资料复印件一式一份按顺序排列装订。报名所用相关证件须提供原件用于备验。提供的资料必须真实，如录用后发现提供虚假资料的取消录用资格。</p><p>(1)全部考生:<a href="http://m.so.com/s?q=%E3%80%8A%E6%B1%9F%E9%97%A8%E5%B8%82%E8%93%AC%E6%B1%9F%E5%8C%BA%E6%8B%9B%E8%81%98%E4%B8%AD%E5%B0%8F%E5%AD%A6%E6%95%99%E5%B8%88%E6%8A%A5%E5%90%8D%E8%A1%A8%E3%80%8B&amp;src=newstranscode" class="qkw">《江门市蓬江区招聘中小学教师报名表》</a>(附件2,须从报名系统打印)、身份证、近期一寸正面免冠证件照照片电子版(不大于35K,备用)。</p><p>(2)身份为在编在岗教师的考生:另须提供学历证、教师资格证、职称证以及符合报名资格规定的相关证书。</p><p>(3)身份为在蓬江区辖公办中小学从事教学工作现仍在教学岗位上的考生:另须提供学历证、教师资格证及与公办中小学签订的劳动合同书和学校出具的在职证明。</p><p>(4)身份为正在蓬江区辖区服役军人配偶的考生:另须提供学历证、教师资格证、结婚证、随军随队审批表以及配偶的军官证(或士兵证)、部队所在<a href="http://m.so.com/s?q=%E8%93%AC%E6%B1%9F&amp;src=newstranscode" class="qkw">蓬江</a>辖区地的证明。</p><p>(5)身份为研究生(含硕士学位)的考生:另须提供学历证(或学位证)、教师资格证书。</p><p>(6)身份为应届毕业的考生:另须提供就业推荐表、教育学和教育心理学成绩单(考试成绩要合格以上)、普通话水平测试二乙等级以上证书(如普通话证书已上交学校办理相关手续的，须提供证书复印件和学院证明)、学院或系出具的考生所学专业属于师范类别的证明(须盖公章)以及符合报名资格规定的相关证书。</p><p>(7)报考校医的考生:另须提供学历证、《执业医师资格证》、工作满两年的证明。</p><p>(8)报考实验员的考生:另须提供学历证。</p><p>(9)报考教育财务核算中心职员的考生:另须提供学历证、初级职称证书、工作满两年的证明。</p><p class="header">(三)考试</p><p>1、小学、初中教师和非专任教师人员考试</p><p>招聘教职员的笔试、面试工作由江门市蓬江区人社局、教育局组成的招聘工作领导小组(下同)组织进行。综合成绩由笔试、面试成绩组成。笔试成绩占40%,面试成绩占60%.笔试、面试及综合成绩在蓬江人社局网(网址:http://pjrsj.pjq.gov.cn/index.asp)及蓬江区基础教育信息网(网址:http://pjedu.<a href="http://m.so.com/s?q=jmpj&amp;src=newstranscode" class="qkw">jmpj</a>.gov.cn)公布。</p><p class="header">(1)笔试</p><p>①笔试时间:2016年4月30日(星期六)上午9:30-11:30.</p><p class="header">②笔试地点:具体安排以准考证为准。</p><p class="header">③笔试内容:</p><p>笔试采取100分制，内容是公共知识(含时事政治、教育学、心理学等知识，占40%)和应聘科目教学所需具备的专业知识(占60%)。考试不指定考试参考用书。</p><p>报考<a href="http://m.so.com/s?q=%E5%B0%8F%E5%AD%A6%E7%A7%91%E6%8A%80&amp;src=newstranscode" class="qkw">小学科技</a>职位的参加物理科目笔试;报考高中生物实验员职位的参加生物科目笔试;报考高中化学实验员职位的参加化学科目笔试。</p><p>④成绩公布:笔试结束后10个工作日内在网上公布。</p><p class="header">(2)面试</p><p>笔试完成后，根据招聘工作领导小组划定的合格分数线，分学科按分数从高分到低分排列，按1:3比例确定面试人员。</p><p>①时间:2015年5月下旬开始，具体时间以网上公布为准。</p><p class="header">②地点:具体安排以网上公布为准。</p><p>③内容:面试采取100分制。面试要求在面试公告公布，面试成绩低于60分的不予聘用。</p><p>④面试成绩在面试结束60分钟内现场书面通知考生。</p><p class="header">2、高中教师考试</p><p>考试工作由招聘工作领导小组组织进行。考试采用面试方式(实验员等非专任教师除外)，分初试和复试两个阶段，面试成绩低于60分的不予录取。</p><p class="header">(1)初试</p><p>①时间:5月6日上午8:30开始。每个考生的初试时间为5分钟。</p><p>②地点:江门市蓬江区<a href="http://m.so.com/s?q=%E6%A3%A0%E4%B8%8B%E4%B8%AD%E5%AD%A6&amp;src=newstranscode" class="qkw">棠下中学</a>高中部(江门市棠下镇棠下大道10号)。</p><p>③内容:主要测试考生的基本素质和对教育情况的掌握。</p><p>④其他事宜:初试成绩在初试结束60分钟内现场书面通知考生，当天分学科现场公布考生(考号)初试成绩，初试成绩合格分数线为60分，并根据初试成绩从高分到低分公布进入复试的考生(分学科按1:3比例入选复试)。</p><p class="header">(2)复试</p><p>①时间:5月6日下午2:30开始。考生备课和上课各为20分钟。</p><p>③内容及形式:采用“上课”方式，主要测试考生的专业素质。</p><p>④其他事宜:复试成绩在复试结束60分钟内现场书面通知考生。当天分学科现场公布考生(考号)复试成绩。复试成绩合格分数线为60分，按照复试成绩的高分到低分顺序等额确定体检对象。</p><p>3、面试中如安排有技能测试或实操的学科，其技能测试项目的成绩占面试成绩40%.</p><p class="header">(四)体检</p><p>1、确定体检对象:根据招聘人数和考生考试综合成绩从高分到低分等额确定。</p><p>2、提供资料:参加体检考生须提供如下资料的原件，凡不能全部依时提供的视为自动放弃招录资格。</p><p>(1)计生证明(证明考生本人的婚姻状况，写明是否有违反国家计划生育政策等内容。由户籍所在地村[居]委会提供，镇级计生部门加意见并盖章;应届毕业生的由学院或系出具。不能用<a href="http://m.so.com/s?q=%E3%80%8A%E6%9C%AA%E5%A9%9A%E8%AF%81%E3%80%8B&amp;src=newstranscode" class="qkw">《未婚证》</a>代替)。</p><p>(2)无犯罪证明(由户籍所在地派出所或学院、系提供)。</p><p>(3)同意报考证明(在编公办教师所在学校出具并有上级教育部门同意的方有效)。</p><p>3、其他事宜:由招聘工作领导小组于6月上、中旬统一组织到县级以上综合性医院进行体检(具体时间以网上公布为准)，体检标准参照《广东省教师资格申请人员体格检查标准》执行，体检费用自理。逾期不参加体检的，视为自动放弃。</p><p class="header">(五)考察</p><p>体检结束后，由招聘工作领导小组按照<a href="http://m.so.com/s?q=%E3%80%8A%E5%B9%BF%E4%B8%9C%E7%9C%81%E4%BA%8B%E4%B8%9A%E5%8D%95%E4%BD%8D%E5%85%AC%E5%BC%80%E6%8B%9B%E8%81%98%E4%BA%BA%E5%91%98%E8%80%83%E5%AF%9F%E5%B7%A5%E4%BD%9C%E5%AE%9E%E6%96%BD%E7%BB%86%E5%88%99%28%E8%AF%95%E8%A1%8C%29%E3%80%8B&amp;src=newstranscode" class="qkw">《广东省事业单位公开招聘人员考察工作实施细则(试行)》</a>规定，组织对考察人选进行考察、审核报考资格和审查个人档案。</p><p class="header">(六)递补</p><p>出现以下情形的，由招聘工作领导小组研究同意后，可以在同职位的考生中，按考试综合成绩从高分到低分依次递补人选:</p><p>1、体检人选放弃体检或体检不合格的。</p><p>2、考察人选放弃考察或考察不合格的。</p><p class="header">3、拟录用人员放弃录用机会的。</p><p class="header">(七)聘用</p><p>1、对体检、考察合格的考生确定为拟聘人员，由区人社局发布公示7个工作日。经公示无异后由区人社局办理相关聘用手续，并由用人单位与拟聘人员签订聘用合同。</p><p>2、试用期内或期满考核不合格或发现隐瞒聘前病史且身体条件不符合岗位要求的人员，取消聘用资格。</p><p>备注3:拟录用人员，户口在江门市蓬江区、江海区、新会区三区以外的须迁入江门市蓬江区户口，方能办理报到手续。</p><p class="header">四、联系办法</p><p class="header">单位:江门市蓬江区教育局</p><p class="header">地址:江门市蓬江区胜利路135号</p><p>电话:0750-8220646,3226160(江门市蓬江区教育局人事与师资管理股)</p><p class="header">联系人:吴老师，古老师</p><p>备注4:考生在报名时要留2个手机联系电话，若因填写联系电话有误、考生报名后更改电话号码或其他自身原因不能联系到考生的，责任由考生自负;凡参加笔试、面试、体检及办理聘用相关手续时，须携带准考证和身份证原件。</p><p>本公告未尽事宜，由江门市蓬江区教育局负责解释。</p><p class="header">1:江门市蓬江区教职员招聘岗位表</p><p>2:江门市蓬江区招聘中小学教师报名表</p><p class="header">3:报考学科参照目录(版)</p><p class="header">4:蓬江教育简介</p><p>江门市蓬江区人力资源和社会保障局 江门市蓬江区教育局</p><p>2016年3月11日</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.chinagwy.org/html/gdzk/guangdong/201603/82_144608.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='2ef63673ac990714d257972bf86299e0'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>蓬江</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%93%AC%E6%B1%9F&amp;pn=1&amp;pos=4&amp;m=2020bb3e2e3d429fdec4f63093b63d05a295c60b&amp;u=http%3A%2F%2Fwww.nxing.cn%2Fwap%2Farticle%2F4045703.html" data-pos="1"> <b>蓬江</b>供电走进社区开展安全用电知识宣传 </a>   <li> <a href="/transcode?q=%E8%93%AC%E6%B1%9F&amp;pn=1&amp;pos=5&amp;m=e87d192e3cf0470b4df754e61b12e0df778482c7&amp;u=http%3A%2F%2Fnews.163.com%2F16%2F0304%2F03%2FBH9IBJAA00014Q4P.html" data-pos="2"> <b>蓬江</b>现正公开招募文明城市义务监督员 </a>   <li> <a href="/transcode?q=%E8%93%AC%E6%B1%9F&amp;pn=1&amp;pos=6&amp;m=86b96e30b080e899ca0f796beaf7c54853743e51&amp;u=http%3A%2F%2Fculture.gmw.cn%2Fnewspaper%2F2016-03%2F04%2Fcontent_111268437.htm" data-pos="3"> <b>蓬江</b>区残联举行乒乓球对抗赛 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '2016年广东江门市蓬江区招聘教职员公告' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '2016年广东江门市蓬江区招聘教职员公告'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";