s:21695:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>歌手阿杜宣布妻子怀孕 阿杜的妻子是谁是李鑫雨吗 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">歌手阿杜宣布妻子怀孕 阿杜的妻子是谁是李鑫雨吗 </h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-03-11 18:47:20</time></p> </header>  <div id="news-body"><p>今日，阿杜宣布妻子<a href="http://m.so.com/s?q=%E6%80%80%E5%AD%95&amp;src=newstranscode" class="qkw">怀孕</a>。以上介绍了歌手阿杜近况,阿杜转型当老板,投资某美容医院当老板,另外揭秘了阿杜老婆<a href="http://m.so.com/s?q=%E6%9D%8E%E9%91%AB%E9%9B%A8&amp;src=newstranscode" class="qkw">李鑫雨</a>真实身份,其老婆是一名女演员,两人交往多年已经秘密订婚。</p><p>阿杜近况转型当老板,以明星老板身份现身广州，出席有份投资的美容医院落户开业仪式。阿杜近照身材明显发福,有关阿杜老婆是谁也引起关注,接着,阿杜老婆李鑫雨身份背景曝光,是一位女演员,早在2011年就有传闻阿杜与女友李鑫雨已经秘密订婚。</p><p><img src="http://p31.qhimg.com/t01df07ad7f23f367da.jpg?size=460x242"></p><p>阿杜还在星光天地某金店定制一款价值近百万的钻戒，以表爱意。阿杜更是从<a href="http://m.so.com/s?q=%E6%96%B0%E5%8A%A0%E5%9D%A1&amp;src=newstranscode" class="qkw">新加坡</a>赶赴京城，与女友在北京共度中秋佳节。此外，阿杜定制一款价值近百万的钻戒，并送宝马车，表爱意。而李鑫雨也为在<a href="http://m.so.com/s?q=%E5%B0%8F%E6%B1%A4%E5%B1%B1&amp;src=newstranscode" class="qkw">小汤山</a>附近购置了一处别墅作为二人居所。</p><p>据知情人透露,阿杜与老婆李鑫雨于四年前在香港认识，今年年初两人发展成为恋人，阿杜近期还向李鑫雨送出了象征爱情的红色宝马车。而李鑫雨也为在小汤山附近购置了一处别墅作为二人居所，目前该别墅已装修完工。此外，李鑫雨也不时在微博上大秀爱情，似乎好事将近。</p><p><img src="http://p33.qhimg.com/t01b47c3151693d43d9.jpg?size=420x309"></p><p>以上介绍了歌手阿杜近况,阿杜转型当老板,投资某美容医院当老板,另外揭秘了阿杜老婆李鑫雨真实身份,其老婆是一名女演员,两人交往多年已经秘密订婚。&lt;</p><p><img src="http://p32.qhimg.com/t0159d1580ff15c21ee.jpg?size=439x405"></p><p class="img-title">阿杜宣布老婆李鑫雨怀孕</p><p>42岁的阿杜刚刚宣布妻李鑫雨子怀孕啦!今年1月11日，新加坡歌手阿杜在微博公布婚讯，阿杜的妻子并非圈内人，从事<a href="http://m.so.com/s?q=%E6%88%BF%E5%9C%B0%E4%BA%A7%E4%B8%9A&amp;src=newstranscode" class="qkw">房地产业</a>，两人在阿杜未出道前就在一起，中间分分合合经历了二十几年，终于修成正果。</p><p>1月份，阿杜在微博晒出婚戒照，宣布婚讯，他发文:“这一天终于来了，我结婚了，这么久以来非常感谢她一路的相伴、付出、容忍，让我学会了感谢、感恩!也谢谢你们对我的祝福，无限感激。”据悉两人交往二十多年，丈母娘也对阿杜非常满意。</p><p>当年一曲<a href="http://m.so.com/s?q=%E3%80%8A%E5%9D%9A%E6%8C%81%E5%88%B0%E5%BA%95%E3%80%8B&amp;src=newstranscode" class="qkw">《坚持到底》</a>走红的歌手阿杜，最近也成为了这一队伍的一份子。去年，阿杜以明星老板身份现身广州，出席有份投资的美容医院落户开业仪式。 &lt;</p><p><img src="http://p32.qhimg.com/t01901a057ee237ca30.jpg?size=403x377"></p><p>阿杜的妻子是圈内人吗?据了解，女友并非圈内人，从事房地产业，两人在阿杜未出道前就在一起，那一年阿杜22岁，中间分分合合已经经历了二十几年。女友在阿杜的事业低谷期一直陪在他身边，一路鼓励、相伴陪他走出低谷。</p><p>如今二人非常甜蜜，而丈母娘也对阿杜非常满意。据此前报道称因为阿杜本身的性格内向，相反这位女友则是外向性格，两人十分互补。</p><p class="header">阿杜老婆李鑫雨个人资料</p><p>李鑫雨，出生于陕西省，中国内地女演员。1999年出演首部电影作品《爱情是蓝色的》，开始演艺事业。2000年在电视剧<a href="http://m.so.com/s?q=%E3%80%8A%E4%BB%93%E5%BA%93%E9%87%8C%E7%9A%84%E7%A7%98%E5%AF%86%E3%80%8B&amp;src=newstranscode" class="qkw">《仓库里的秘密》</a>中饰演万丽敏。</p><p>2002年在周晓文执导的历史古装剧<a href="http://m.so.com/s?q=%E3%80%8A%E4%B9%B1%E4%B8%96%E8%8B%B1%E9%9B%84%E5%90%95%E4%B8%8D%E9%9F%A6%E3%80%8B&amp;src=newstranscode" class="qkw">《乱世英雄吕不韦》</a>和《大脚马皇后》，分别饰演秋菊和妃子。2003年参演张国立自导自演的民国题材电视剧《五月槐花香》。</p><p>2004年在杜德伟、陈德容、严宽主演的古装武侠剧<a href="http://m.so.com/s?q=%E3%80%8A%E8%BE%B9%E5%9F%8E%E5%B0%8F%E5%AD%90%E3%80%8B&amp;src=newstranscode" class="qkw">《边城小子》</a>中饰演寒樱。同年在<a href="http://m.so.com/s?q=%E9%97%AB%E5%AE%87%E5%BD%A4&amp;src=newstranscode" class="qkw">闫宇彤</a>执导的《案发现场之四十八小时》中饰演张燕。</p><p>2005年参演高希希执导，孙俪主演的军旅爱情剧《幸福像花儿一样》饰演刁钻“吴娜”。同年在陈坤主演的青春偶像剧《红色地毯黑色梦》中饰演模特大赛冠军高梅子。</p><p><img src="http://p32.qhimg.com/t010980f73da2823106.jpg?size=500x562"></p><p>2006年8月16日参演邢树民执导的悬疑探案电影<a href="http://m.so.com/s?q=%E3%80%8A%E8%B0%8B%E6%9D%80%E7%BB%A7%E7%BB%AD%E3%80%8B&amp;src=newstranscode" class="qkw">《谋杀继续》</a>上映。12月在话剧<a href="http://m.so.com/s?q=%E3%80%8A%E7%BB%9D%E5%91%BD%E5%B4%96%E3%80%8B&amp;src=newstranscode" class="qkw">《绝命崖》</a>中饰阿信。同年郭华执导的在情景喜剧《祝您健康》中饰演郝二梅。</p><p>2007年在<a href="http://m.so.com/s?q=%E6%9D%8E%E6%B0%B8%E8%B4%B5&amp;src=newstranscode" class="qkw">李永贵</a>自编自导的电视剧《牛知县真牛》中饰演石榴。同年在连奕名执导，王亚楠主演的红色经典抗日战争剧<a href="http://m.so.com/s?q=%E3%80%8A%E9%87%8E%E7%81%AB%E6%98%A5%E9%A3%8E%E6%96%97%E5%8F%A4%E5%9F%8E%E3%80%8B&amp;src=newstranscode" class="qkw">《野火春风斗古城》</a>中饰演蒲小蔓。</p><p>2008年在白凡主演的反腐刑侦剧<a href="http://m.so.com/s?q=%E3%80%8A%E7%BD%AA%E5%9F%9F%E3%80%8B&amp;src=newstranscode" class="qkw">《罪域》</a>中分饰两角，演一对性格迥然不同的双胞胎姐妹，姐姐叫陈元元，是公司白领;妹妹叫<a href="http://m.so.com/s?q=%E9%99%88%E7%9B%88%E7%9B%88&amp;src=newstranscode" class="qkw">陈盈盈</a>，是个典型的农村女孩。</p><p>2008年在家庭情感剧<a href="http://m.so.com/s?q=%E3%80%8A%E7%BB%A7%E6%AF%8D%E5%90%8E%E5%A6%88%E3%80%8B&amp;src=newstranscode" class="qkw">《继母后妈》</a>中饰演蓝雪。同年在王丽云主演的民国家族题材剧<a href="http://m.so.com/s?q=%E3%80%8A%E5%A4%A7%E5%AE%85%E9%99%A2%E7%9A%84%E5%A5%B3%E4%BA%BA%E3%80%8B&amp;src=newstranscode" class="qkw">《大宅院的女人》</a>中饰演天性纯良，楚楚动人的“四姨太”张文君。</p><p><img src="http://p34.qhimg.com/t013746bf5783c08694.jpg?size=500x586"></p><p>2009 年参与江珊主演的爱情剧《不离不弃》饰演林方西的初恋情人白小鸥。同年主持参与上海世博会中国企业领袖年会。</p><p>2010年10月做客重庆卫视时尚美妆节目<a href="http://m.so.com/s?q=%E3%80%8A%E7%BE%8E%E4%B8%BD%E4%BF%8F%E4%BD%B3%E4%BA%BA%E3%80%8B&amp;src=newstranscode" class="qkw">《美丽俏佳人》</a>。11月拍摄了一组以“四步引爆冬日爱情”为主题的写真。11月李鑫雨参与在苏州太湖举行的全明星高尔夫球队年度总决赛。</p><p>2011年受邀出演了惊悚悬疑情感剧《恶魔在身边》。随后主演马成赟执导的时尚爱情电影《第101场婚礼》，饰美丽善良的都市白领顾晓雯。7月助阵“第三届亚沙会形象大使”全国海选活动。10月推出个人首张国语专辑<a href="http://m.so.com/s?q=%E3%80%8A%E5%8B%87%E6%95%A2%E7%9A%84%E5%82%BB%E7%93%9C%E3%80%8B&amp;src=newstranscode" class="qkw">《勇敢的傻瓜》</a>，这也是她的首张国语慈善专辑。&lt;</p><p><img src="http://p35.qhimg.com/t0129a84af2e0e097fa.jpg?size=417x415"></p><p>阿杜疯了怎么回事?早前曾有传闻称“阿杜疯了”，令阿杜的广大歌迷们十分担心阿杜的身心健康，阿杜刚出道时以他独特的嗓音走红，但是在最红时，却又突然销声匿迹，甚至宣布了淡出歌坛，令人摸不着头脑。后来便有传闻流徙网络。这其中，阿杜疯了是最为惊悚的讹传。</p><p><img src="http://p33.qhimg.com/t010fd10ed69af53f9a.jpg?size=394x370"></p><p>至于恐慌症是怎么产生的，“是因为他的生活和阅历差别太大了，以前是做建筑行业的，后来很偶然地去唱歌，简直就是完全两个世界，加上阿杜性格本身很内向很宅，他的话本来就很少，非常腼腆的一个男人，要一下子突然面对那么多歌迷，面对那么多媒体，心理上适应不了，所以就害怕”。</p><p>在恐慌症最严重的时候，阿杜一度要靠药物来镇定，但随着时间和身边人对他的支持，经过一段时间的治疗后，阿杜的病情缓解，现在主要靠运动来排解压力。 “每天跑步什么的，用运动这种方式来平衡和释放”。而这次出现在 《我为歌狂》的舞台上，是阿杜第一次以PK的形象面对观众。</p><p>阿杜疯了的消息传出后，很多歌迷们都纷纷关注到底是怎么回事，他们都不相信自己的偶像真的疯了，对此，有相关人士表示，阿杜确实是有轻微的恐慌症，但绝对不是精神病:“恐慌症绝对和疯了没有半点关系，只是会时而发生害怕、紧张的状态。比如，害怕坐飞机、害怕坐过山车、害怕上台面对太多人唱歌，和许多人的恐高没什么区别。 ”</p><p>昨天，经纪人首次承认了阿杜的病情，“是得过恐慌症，就是不敢出现在人多的地方，害怕当着很多人的面唱歌，也不敢说话，会很紧张，压力很大，但不到抑郁症那么严重”。&lt;</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/ent/hot/4694713_1.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='d3d99ee7ca8fed6fc60275cca18a2e18'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>野火春风斗古城</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%87%8E%E7%81%AB%E6%98%A5%E9%A3%8E%E6%96%97%E5%8F%A4%E5%9F%8E&amp;pn=1&amp;pos=6&amp;m=dfe2366858e3924cd73e21691a434754f9473aed&amp;u=http%3A%2F%2Fmil.qianlong.com%2F37076%2F2014%2F06%2F25%2F7804%25409697245.htm" data-pos="1"> <b>野火春风斗古城</b> </a>   <li> <a href="/transcode?q=%E9%87%8E%E7%81%AB%E6%98%A5%E9%A3%8E%E6%96%97%E5%8F%A4%E5%9F%8E&amp;pn=1&amp;pos=7&amp;m=6f85fb320d06534efb66eebda4de6b43bd0a94bd&amp;u=http%3A%2F%2Fv.iqilu.com%2Fsdws%2Fjsyz%2F2014%2F1016%2F4135980.html" data-pos="2"> 李小龙讲述地下党真实生活 莫龙丹演唱《<b>野火春风斗古城</b>》 </a>   <li> <a href="/transcode?q=%E9%87%8E%E7%81%AB%E6%98%A5%E9%A3%8E%E6%96%97%E5%8F%A4%E5%9F%8E&amp;pn=1&amp;pos=8&amp;m=0db9d34df11c4948c25f1c3d8e31a39d80c8aca6&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F3992377.html" data-pos="3"> 河北文学馆"新装"亮相免费向公众开放 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '歌手阿杜宣布妻子怀孕 阿杜的妻子是谁是李鑫雨吗 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '歌手阿杜宣布妻子怀孕 阿杜的妻子是谁是李鑫雨吗 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";