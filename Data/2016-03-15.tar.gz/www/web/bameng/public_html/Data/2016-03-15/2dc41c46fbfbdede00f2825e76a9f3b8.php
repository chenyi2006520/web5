s:21913:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>俄军加速转向网络中心化作战- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">俄军加速转向网络中心化作战</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-14 14:55:34</time></p> </header>  <div id="news-body"><p><img src="http://p32.qhimg.com/t0107215fa7ad2d4f03.jpg?size=454x302"></p><p>俄罗斯国防指挥中心内部(资料图片)。</p><p>据俄罗斯<a href="http://m.so.com/s?q=%E3%80%8A%E7%8B%AC%E7%AB%8B%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《独立报》</a>网站报道，俄军正在<a href="http://m.so.com/s?q=%E5%8F%99%E5%88%A9%E4%BA%9A&amp;src=newstranscode" class="qkw">叙利亚</a>的军事行动中，积极探索机器人和<a href="http://m.so.com/s?q=%E7%BD%91%E7%BB%9C%E4%B8%AD%E5%BF%83%E6%88%98&amp;src=newstranscode" class="qkw">网络中心战</a>在信息化战场的有效运用。报道称，在打击叙境内武装分子过程中，叙利亚政府军在6台俄“平台”-M地面作战机器人和4台俄“阿尔戈”机器人的配合下，顺利完成了攻击任务，而这一系列作战机器人和战场指挥任务均由位于莫斯科的俄国防指挥中心“仙女座”-D自动化指挥系统负责监控。</p><p>俄国防指挥中心于2014年12月1日正式运行，是俄“<a href="http://m.so.com/s?q=%E6%96%B0%E9%9D%A2%E8%B2%8C&amp;src=newstranscode" class="qkw">新面貌</a>”军事改革后构建一体化信息作战联合指挥体制的重要标志。该中心规模庞大、设施完备，运行一年多来，已先后在数次军事行动和演习活动中发挥了突出的信息化指挥和监控作用，是俄军当之无愧的信息化联合一体作战“大脑”。</p><p><img src="http://p31.qhimg.com/t01ddfbe527ab0022cd.jpg?size=454x302"></p><p class="img-title">信息化时代联合一体作战的必然选择</p><p>近年来，俄罗斯周边安全环境发生巨大变化，俄军长期沿袭苏军大规模机械化作战样式，已经在车臣战争和<a href="http://m.so.com/s?q=%E6%A0%BC%E9%B2%81%E5%90%89%E4%BA%9A&amp;src=newstranscode" class="qkw">格鲁吉亚</a>冲突中频现劣势。战斗过程中，俄军依然沿用逐级指挥、定期汇报等指挥体制，迟滞了俄军的战场行动，甚至频频贻误战机，造成重大损失。<a href="http://m.so.com/s?q=%E7%8E%B0%E4%BB%A3%E6%88%98%E4%BA%89&amp;src=newstranscode" class="qkw">现代战争</a>是综合运用军事、政治、信息等多种手段进行体系性对抗的多维战争，战场态势瞬息万变，如何快速反应、高效决策，成为俄军联合作战指挥体制改革后必须面对的重要问题。</p><p>俄国防指挥中心位于<a href="http://m.so.com/s?q=%E8%8E%AB%E6%96%AF%E7%A7%91&amp;src=newstranscode" class="qkw">莫斯科</a>伏龙芝沿河大街的陆军司令部旧址，在和平时期主要负责监视国家安全状态，一旦战争爆发，将成为俄军<a href="http://m.so.com/s?q=%E8%81%94%E5%90%88%E4%BD%9C%E6%88%98&amp;src=newstranscode" class="qkw">联合作战</a>的信息化指挥中枢。目前，俄国防指挥中心按照战斗职能和任务分组运行，下辖战略核力量指挥、战斗指挥、日常活动指挥3个<a href="http://m.so.com/s?q=%E5%9F%BA%E6%9C%AC%E5%88%86&amp;src=newstranscode" class="qkw">基本分</a>中心，以及数据处理、通信、技术保障等多个职能部门。该中心充分适应未来作战需求，具有高度的信息化技术和极强的生存能力。目前中心配备的计算机设备数据存储总量领先美国国防部数倍，能够在1秒钟内处理完成相当于50个<a href="http://m.so.com/s?q=%E5%88%97%E5%AE%81&amp;src=newstranscode" class="qkw">列宁</a>国家图书馆的数据。中心核心设施按照“地下式”、“加固式”模式布局，具有较强的防护和机动能力。</p><p>“新面貌”改革完成后，俄军确立了军政、军令二元分立的领导指挥新框架。在这一框架下，国防部和总参谋部各司其职，国防部专职行政管理与联勤保障，总参谋部聚焦作战指挥。但二者缺少战略级的一体化指挥机构，在数次演习中俄军发现其联合作战和信息化指挥效率受到不同程度的制约。俄成立国防指挥中心，标志着在战略层面形成了高效统一的新型指挥平台。该中心成立既是顺应信息化作战这一时代潮流的必然选择，又充分体现出俄军改革后主动作为的坚强决心，标志着俄军在探索各军兵种联合作战指挥上迈出重要一步，势必会为其国防和军队信息化建设发挥重要作用。</p><p><img src="http://p32.qhimg.com/t01ffc88f72a86450e1.jpg?size=454x295"></p><p class="img-title">“三位一体”指挥平台正发挥重要作用</p><p>俄国防指挥中心在原武装力量中央指挥所的基础上组建，是俄军维护国家安全的“联合司令部”。中心平时担负俄国家、社会和军事安全“三位一体”联合保障体系的指挥重任，装备有现代化的通信和自动化设备，各类指挥活动24小时运行，是俄高度信息化的国家最高统帅指挥部。</p><p>俄国防指挥中心各司其职，协调高效运转。战略核力量指挥中心主要担负陆、海、空基战略核力量的作战指挥任务;战斗指挥中心负责对各军兵种作战力量实施统一指挥，并负责多维战场信息情报的搜集;日常活动指挥中心负责对部队战斗训练、国防采购、干部培训等情况进行指导监控，并负责军地协调等重要任务。依托国防指挥中心，俄国家领导人可以对战争行动和多样化军事任务进行<a href="http://m.so.com/s?q=%E8%BF%9C%E7%A8%8B%E7%9B%91%E6%8E%A7&amp;src=newstranscode" class="qkw">远程监控</a>和实时指挥，充分提升了俄国防指挥效能。</p><p>在安全威胁上升时或战争期间，俄国防指挥中心将成为真正意义上的“最高统帅部”。事实上，自去年9月底俄出兵打击叙利亚境内“伊斯兰国”极端组织以来，国防指挥中心在实战中经受检验并对俄军远程制胜发挥了重要作用。</p><p>一是国防指挥中心作为高级指挥中枢在汇集分析战场动态上发挥支撑作用。远程打击开始后，国防指挥中心实施昼夜战备值班，对叙利亚局势开展24小时不间断汇集、分析与战场评估，为俄总统<a href="http://m.so.com/s?q=%E6%99%AE%E4%BA%AC&amp;src=newstranscode" class="qkw">普京</a>、总参谋部和国防部进行相关决策提供参考建议。</p><p>二是国防指挥中心作为实体化指挥机构成为作战指挥司令部。在打击行动中国防指挥中心是俄军不折不扣的“中央司令部”，俄军战场的行动指令由该中心负责拟定发出。俄国防指挥中心通过空天军远程航空兵司令部等机构对前线部队进行指挥，可直接改变作战机组的攻击任务目标。</p><p>三是国防指挥中心作为新型信息化指挥中心成为俄高级领导人决策的重要参考。在打击过程中，俄国防指挥中心实时监控俄军在叙动态，及时评估打击效果并向高级首长直接进行展示。在俄军行动正式开始、出动战略轰炸机以及与法国合作反恐等关键时间节点，俄总统普京均亲临该中心听取汇报，并结合中心汇报内容作出相应部署。</p><p>四是国防指挥中心作为信息融合平台在对外宣传中发挥重要作用。目前国防指挥中心是俄国防部关于在叙军事行动进展的权威信息发布窗口，尤其是以美国为首的西方媒体频繁指责俄空袭效果不佳，先后出现伤及无辜、轰炸平民区等负面报道后，该中心均及时提供证据进行反驳，较好地维护了俄军形象。</p><p><img src="http://p31.qhimg.com/t01ca214f0f1e2c6bd6.jpg?size=454x351"></p><p>未来将成维护俄国家安全的<a href="http://m.so.com/s?q=%E8%B6%85%E7%BA%A7%E5%A0%A1%E5%9E%92&amp;src=newstranscode" class="qkw">超级堡垒</a></p><p>目前俄国防指挥中心已全面开启“大国防”新局面，俄罗斯将以国防指挥中心作为国家安全的“超级堡垒”，打造俄国家层面的军地一体、平战结合的新型信息化联合作战与保障体系。</p><p>一方面，俄国家高级领导人可以依托国防指挥中心，加强对军队及国防保障力量的一体化联合指挥。尤其是依托该中心先进的信息化终端，可充分发挥“在线式”“网络化”作战指挥，实现“一对一”“点对面”指令传输和信息交互模式，助推俄军由机械化向信息化和网络中心化作战的加速转变。另一方面，俄国防指挥中心初步实现了对军事工业、行政、外交、金融、交通、能源、通信、航天、国防服务等部门的组织协调，打破了部门壁垒，克服了原有部门指挥协同困难、国防运转效率低下等问题。俄国防指挥中心在必要时可直接接管整个国家，尤其是对于综合运用军事、政治、经济各方实力，充分协调军地一体，解决军地协同效能低下、配合意识不强、战备资源统筹混乱等问题具有重要作用。</p><p>俄罗斯在信息安全和网络终端上由于缺乏核心技术，曾对俄国家安全构成重大威胁。对此俄国防部和总参谋部铭记在心，在组建国防指挥中心时，俄军着力加强了信息安全能力建设。俄国防指挥中心配备了性能一流的超级计算机系统，采用国产软件处理日常信息，实施全方位物理干扰原则，确保了内网与外网的隔离运行，为俄国防信息数据安全处理、模拟和传输提供了保障。</p><p>目前，美国和北约加紧构建“全球快速打击”和反导系统，并在俄远东和北极地区频频施压，<a href="http://m.so.com/s?q=%E4%B9%8C%E5%85%8B%E5%85%B0&amp;src=newstranscode" class="qkw">乌克兰</a>问题悬而未决，中东地区和独联体国家社会思潮变幻不居、动荡不安，俄罗斯在战略环境上仍面临较大压力。对此，俄高层充分认识到，未来国家之间的抗争，已不再是单纯的军事力量较量。构建新的国防指挥体制，有效应对多样化安全威胁，强化对军地多领域<a href="http://m.so.com/s?q=%E6%88%98%E7%95%A5%E5%8A%9B%E9%87%8F&amp;src=newstranscode" class="qkw">战略力量</a>和资源的统筹指挥，是俄罗斯不得不做出的国家选择。</p><p>(来源:<a href="http://m.so.com/s?q=%E8%A7%A3%E6%94%BE%E5%86%9B%E6%8A%A5&amp;src=newstranscode" class="qkw">解放军报</a>客户端 作者:国防科学技术大学国际问题研究中心 执笔:马建光 <a href="http://m.so.com/s?q=%E5%BC%A0%E4%B9%83%E5%8D%83&amp;src=newstranscode" class="qkw">张乃千</a> 梅育源 转载请注明来源)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/article/4050137.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='3b20fbdcb9c2f24bcef9d366b08d2861'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>加速网络</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%8A%A0%E9%80%9F%E7%BD%91%E7%BB%9C&amp;pn=1&amp;pos=2&amp;m=b288726505b7e129b4960e61b462d8fa19c0bf12&amp;u=http%3A%2F%2Fpc.tgbus.com%2Fdanji_207%2F78803%2F" data-pos="1"> 全境封锁需要vpn吗 需要用<b>网络加速</b>器吗 </a>   <li> <a href="/transcode?q=%E5%8A%A0%E9%80%9F%E7%BD%91%E7%BB%9C&amp;pn=1&amp;pos=3&amp;m=e86d3d37d524579c18bd90bfce5b8bb471945f53&amp;u=http%3A%2F%2Fwww.nxing.cn%2Fwap%2Farticle%2F4012284.html" data-pos="2"> 凌锐蓝信:专线体验最亲民的<b>网络加速</b>服务"锐智通"全面上线 </a>   <li> <a href="/transcode?q=%E5%8A%A0%E9%80%9F%E7%BD%91%E7%BB%9C&amp;pn=1&amp;pos=4&amp;m=f4736ad7f6438cdfc7606a6efc5e4b070accad53&amp;u=http%3A%2F%2Fmedia.china.com.cn%2Fcmgc%2F2016-03-10%2F659050.html" data-pos="3"> <b>网络</b>立法工作亟须<b>加速</b>推进 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '俄军加速转向网络中心化作战' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '俄军加速转向网络中心化作战'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";