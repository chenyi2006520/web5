s:22447:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>那个时候不过节，军人用情书表达爱意- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">那个时候不过节，军人用情书表达爱意</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-14 15:20:33</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E3%80%8A%E6%AD%A4%E6%83%85%E5%8F%AF%E5%BE%85%3A1956-2005%E5%B9%B4%E7%9A%84%E6%83%85%E4%B9%A6%E3%80%8B&amp;src=newstranscode" class="qkw">《此情可待:1956-2005年的情书》</a></p><p>那些年爷爷写给奶奶、爸爸写给妈妈、军人写给军嫂的情书</p><p><img src="http://p31.qhimg.com/t01b03d08858df09299.jpg?size=436x588"></p><p class="img-title">内容简介:</p><p>这是一本情书集，收录了1956-2005年的情书共九束，年代情诗、<a href="http://m.so.com/s?q=%E6%B0%91%E9%97%B4%E6%83%85%E6%AD%8C&amp;src=newstranscode" class="qkw">民间情歌</a>、网恋语言各一札。它们出自干部、军人、医生、大学生等普通人之手，记录了各自或相濡以沫，或劳燕分飞，或相忘于江湖的爱情。</p><p class="header">主编简介</p><p>孔 见:1960年12月生于海南岛，现为<a href="http://m.so.com/s?q=%E6%B5%B7%E5%8D%97%E7%9C%81&amp;src=newstranscode" class="qkw">海南省</a>作家协会主席，中国作家协会全国委员会委员，天涯杂志社社长，海南大学、海南师范大学兼职教授。主要从事随笔、小说、诗歌创作和哲学研究，作品有随笔集<a href="http://m.so.com/s?q=%E3%80%8A%E5%8D%91%E5%BE%AE%E8%80%85%E7%9A%84%E7%94%9F%E5%AD%98%E6%99%BA%E6%85%A7%E3%80%8B&amp;src=newstranscode" class="qkw">《卑微者的生存智慧》</a>《我们的不幸谁来承担》，诗集<a href="http://m.so.com/s?q=%E3%80%8A%E6%B0%B4%E7%9A%84%E6%BB%8B%E5%91%B3%E3%80%8B&amp;src=newstranscode" class="qkw">《水的滋味》</a>, 评论集《韩少功评传》，以及小说集<a href="http://m.so.com/s?q=%E3%80%8A%E6%B2%B3%E8%B1%9A%E3%80%8B&amp;src=newstranscode" class="qkw">《河豚》</a>等，并有多篇论文发表。</p><p><a href="http://m.so.com/s?q=%E7%8E%8B%E9%9B%81%E7%BF%8E&amp;src=newstranscode" class="qkw">王雁翎</a>:《天涯》杂志主编。中国作家协会会员，海南省作家协会理事。资深文学编辑，所编作品曾两次获得“鲁迅文学奖”。1996年与<a href="http://m.so.com/s?q=%E9%9F%A9%E5%B0%91%E5%8A%9F&amp;src=newstranscode" class="qkw">韩少功</a>、蒋子丹一起参与<a href="http://m.so.com/s?q=%E3%80%8A%E5%A4%A9%E6%B6%AF%E3%80%8B&amp;src=newstranscode" class="qkw">《天涯》</a>杂志改版，供职至今。主要从事散文随笔及文学评论写作，著有散文集<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%8D%E8%83%BD%E6%9C%97%E8%AF%BB%E7%9A%84%E7%A7%98%E5%AF%86%E3%80%8B&amp;src=newstranscode" class="qkw">《不能朗读的秘密》</a>等。</p><p class="header">目 录</p><p class="header">生死契阔与子成说，执子之手与子偕老</p><p>--老干部<a href="http://m.so.com/s?q=%E6%97%A7%E6%97%A5%E6%83%85%E4%B9%A6&amp;src=newstranscode" class="qkw">旧日情书</a>(1956)</p><p class="header">人面不知何处去，桃花依旧笑春风</p><p>--写给“右派”的情书(1961-1962)</p><p class="header">只愿君心似我心，定不负相思意</p><p>--北大荒情书(1966 - 1967)</p><p class="header">两情若是久长时，又岂在朝朝暮暮</p><p class="header">--军医情书(1970)</p><p><a href="http://m.so.com/s?q=%E6%AC%B2%E5%AF%84%E5%BD%A9%E7%AC%BA%E5%85%BC%E5%B0%BA%E7%B4%A0&amp;src=newstranscode" class="qkw">欲寄彩笺兼尺素</a>，山长水阔知何处</p><p>--军旅情书(1971 - 1972)</p><p>蓦然回首，那人<a href="http://m.so.com/s?q=%E5%8D%B4%E5%9C%A8%E7%81%AF%E7%81%AB%E9%98%91%E7%8F%8A%E5%A4%84&amp;src=newstranscode" class="qkw">却在灯火阑珊处</a></p><p>--南北情书(1992 - 1997)</p><p class="header">相思相见知何日，此时此夜难为情</p><p>--女大学生致士兵的情书(1993 - 1995)</p><p class="header">山有木兮木有枝，心悦君兮君不知</p><p class="header">--世纪末的求爱信(1999)</p><p><a href="http://m.so.com/s?q=%E8%BF%98%E5%90%9B%E6%98%8E%E7%8F%A0%E5%8F%8C%E6%B3%AA%E5%9E%82&amp;src=newstranscode" class="qkw">还君明珠双泪垂</a>，恨不相逢未嫁时</p><p>--一个第三者的信(2004 - 2005)</p><p class="header">身无彩凤双飞翼，心有灵犀一点通</p><p class="header">--网恋语言</p><p><a href="http://m.so.com/s?q=%E9%94%A6%E7%91%9F%E6%97%A0%E7%AB%AF%E4%BA%94%E5%8D%81%E5%BC%A6&amp;src=newstranscode" class="qkw">锦瑟无端五十弦</a>，一弦一柱思华年</p><p class="header">--情诗两种</p><p><a href="http://m.so.com/s?q=%E6%88%91%E6%AC%B2%E4%B8%8E%E5%90%9B%E7%9B%B8%E7%9F%A5%EF%BC%8C%E9%95%BF%E5%91%BD%E6%97%A0%E7%BB%9D%E8%A1%B0&amp;src=newstranscode" class="qkw">我欲与君相知，长命无绝衰</a></p><p class="header">--民间情歌</p><p class="header">精彩章节:</p><p class="header">--军旅情书(1971-1972)</p><p class="header">四</p><p class="header">雨林同志:</p><p>您好!我于14日方收到您的来信。自从那天(8号)晚送您回去后，回到家，心情久久不能平静。特别是9号您走那天心里有说不出的难受，眼泪也不知怎么控制不住，一个劲往外流。这也就是我不去送您的原因。</p><p>我俩初识不久，您拉练时我为何没有这种感情激动的反应呢，我想那是印象与感觉的初步阶段。而这些天的会面与交谈，进一步加深了我对您的印象。</p><p>10号晚上支部副书记找我谈话。内容一个关于入党，一个关于个人生活。他要我经常向我们组的老胡同志(他负责培养我入党)汇报自己的思想，并要求我在党的五十周年生日前交份详细的思想汇报。关于个人问题，他说:组织上经过了解，表示热烈支持。并要我写信支持您在连队好好干，鼓励您为党做更多工作。</p><p>关于每月写一次信，我宣布收回这个“决定”，原则上可定为半月左右一次，有特殊情况可以灵活机动。</p><p class="header">祝好!</p><p class="header">绣于南昌</p><p class="header">1971年4月14日晚</p><p class="header">五</p><p class="header">亲爱的容绣同志:</p><p>您好!首先我胆怯地问您愿意接受这样的称呼吗?</p><p>今天是4月19日，如按您的“约法三章”，我这封信提前了五天，但别忘了，“有特殊情况可灵活机动”。</p><p>收到您的信后我接连看了两遍。是啊，有领导、同志们的关心帮助和支持、家庭的赞助，加上我们自己的努力，进一步发展这种纯洁真挚的感情，有什么样的问题不能解决呢?组织上的支持比什么力量都要大得多。</p><p>您说到入党问题，我认为思想汇报应着重于对党的思想认识，对伟大毛泽东思想和革命路线的认识。在三大革命实践中，思想觉悟应不断提高，树立为人民服务，解放全人类的思想。</p><p>昨天我收到家里的来信，信中对于我们的事情表示完全赞同，父母很欢喜。家中要我立即把您的照片寄去看看，于是我就把您那张小的照片寄走了，现在您的照片应奔驰在去浙江的道路上!您的容貌将展现在我父母及弟妹的面前，他们将为我高兴，而您在那张照片上<a href="http://m.so.com/s?q=%E5%8F%AA%E6%98%AF%E6%B3%A8%E8%A7%86%E7%9D%80&amp;src=newstranscode" class="qkw">只是注视着</a>前方，“她”不知道说什么好了!“她”害羞了!</p><p>以上两件事，促使我提前五天，在“灵活机动”范围内，写了这封信。</p><p>常言道:一日不见，如隔三秋。这对已建立了深挚感情的人来说是恰如其分的。我到这里已整整十天，总觉时间过得特别慢。想我们在一起时，时间像骏马般飞奔而过，其实时间它哪能理解人的心情啊，快慢只是感情的代言词。</p><p>我下连队的事情您向家里讲明白了吗?爸妈弟妹的身体都好吧?</p><p class="header">紧握!</p><p class="header">林于4月19日晚十时</p><p class="header">十六</p><p>您好!我于本月6日托人带给您的信想必已经收到。根据那封信中说的，今天照片取出再写信，乘(趁)寄照片之际，再写上几句。</p><p>上信中讲要去南昌的问题是这样的:因为今年我有探亲假，现在我们既然决定明年2月解决“此事”，那么这个探亲假就把它利用起来，根据连里的情况及本年度的工作情况，决定在本月中下旬探家。探家前先到您处几天，而后再回老家看看，然后再回您那里几天，结束二十天的假期。具体怎么安排，听您的意见，或者咱们再商量。</p><p>这只是我个人计划，能不能实现还要看形势的发展变化。从目前形势看，当前形势一片大好，特别是毛主席的外交路线取得了节节胜利，我国的国际声誉越来越高，世界上许多国家都把与我国的关系当作大事来研究。“八一社论”也明确指出当前形势，并向全军发出战斗号召。越是在这样的大好形势下，越要保持清醒的头脑，始终保持高度的战争警惕，防止敌人突然袭击。现在有迹象表明，美蒋反动派为摆脱目前困境，妄图垂死挣扎，现在加紧勾结日本反动派，进行种种军事演习(空降、登陆)，企图反攻大陆。</p><p>因此当前战备形势比较紧张，有鉴于这个情况，“小计划”不知能否实现，不过没关系，任何时候都应该把集体的利益、革命工作摆在首位，这里要做好这个思想准备。</p><p>照片照得不好，主要还是怪自己长得不好，背景也欠明亮，而且有些脏，这可能就是清江照相馆最高的艺术水平了，不过从照片上还是可看出我的面貌的，让您看看同四个月前有什么变化。</p><p class="header">最后代问父母好!并祝健康，愉快!</p><p class="header">您的林于1971年8月8日</p><p class="header">二十四</p><p class="header">亲爱的绣:</p><p>您好!今寄去结婚申请报告表两份，接到后请按表格的要求逐项填写，务必填写清楚。填完信请检查一下身体，表格随同身体检查证一起寄到我处，我再办好其他手续。我这边的领导已经研究同意了。</p><p>关于检查身体一事，这是我们部队的规定，是原则问题，我想您不会有任何误解的。</p><p>我们连决定成立一个演唱组，迎接春节的到来。随着演唱组的成立，带来一个具体问题，就是节目问题。最近我们自己编写了几个节目，但还很不够。您那边不知是否有现成的适合部队文艺宣传的材料(包括曲调)。</p><p>向您报告一个好消息，最近家里为迎接我们，正进行着积极的准备，呈现出一片喜洋洋的热闹局面。我的同学在来信中告诉我，他们也参与了这一行动。总之，老家正望眼欲穿地盼着我们早点回去。</p><p>我这边什么时候走都可以，问题在您那边，能不能按照预定计划?如果春节您还有工作上的问题确实离不开，那么没关系，咱们就主动把婚期往后移，什么时候有机会就在什么时候解决。</p><p class="header">祝好!寄布票十六尺，请查收。</p><p class="header">林于1972年元月12日晚</p><p>资料提供者:蔚文。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/article/4050807.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='666ad7598efd545a0e4242be64ac7a5d'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>生死契阔</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%94%9F%E6%AD%BB%E5%A5%91%E9%98%94&amp;pn=1&amp;pos=7&amp;m=0d0354966b5bc334e0137d2da64e2d0af659216e&amp;u=http%3A%2F%2Fepaper.dfdaily.com%2Fdfzb%2FHTML%2F2014-08%2F17%2Fcontent_916818.htm" data-pos="1"> <b>死生契阔</b> </a>   <li> <a href="/transcode?q=%E7%94%9F%E6%AD%BB%E5%A5%91%E9%98%94&amp;pn=1&amp;pos=8&amp;m=eda41dc29e06c4d87a722b942ddd903a4f31f0e5&amp;u=http%3A%2F%2Fnews.xkb.com.cn%2Fwenhua%2F2014%2F0530%2F327833.html" data-pos="2"> 《<b>死生契阔</b>》故事之④·阴谋 </a>   <li> <a href="/transcode?q=%E7%94%9F%E6%AD%BB%E5%A5%91%E9%98%94&amp;pn=1&amp;pos=9&amp;m=b7f081f553cf450a2150985926bbef58fff82607&amp;u=http%3A%2F%2Fmt.sohu.com%2F20160305%2Fn439469469.shtml" data-pos="3"> 执子之手,与子偕老。 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '那个时候不过节，军人用情书表达爱意' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '那个时候不过节，军人用情书表达爱意'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";