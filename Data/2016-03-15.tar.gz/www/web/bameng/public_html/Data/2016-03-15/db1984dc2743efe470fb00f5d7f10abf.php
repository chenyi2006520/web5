s:22393:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>猪油糕酒酿油闷笋 这些都是老苏州姆妈的米道 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">猪油糕酒酿油闷笋 这些都是老苏州姆妈的米道 </h1> <p id="source-and-time"><span id=source>网易</span><time id=time>2015-05-13 10:42:08</time></p> </header>  <div id="news-body"><p class="header">(来源:来自:名城苏州网)</p><p>小时候，放学回家第一句话就是:妈，我饿了。</p><p>小时候，半小时看不见妈妈，见人就问:看见我妈了吗?</p><p>吃到一个好吃的菜，随口夸一句好吃，这道菜连续做一周。</p><p class="header">现在你还记得妈妈的味道吗?</p><p>小编觉得最好吃的菜不是五星级饭店里的厨师所作，而是妈妈为你烹饪的那一道--妈妈的味道。</p><p>1、老苏州<a href="http://m.so.com/s?q=%E5%A7%86%E5%A6%88&amp;src=newstranscode" class="qkw">姆妈</a>米道猪油糕</p><p>旧时小时候总是巴望着过年，因为那时候妈妈就会做香甜软糯，枣香四溢的糕吃。妈妈开始准备食材，买来的<a href="http://m.so.com/s?q=%E7%8C%AA%E6%B2%B9&amp;src=newstranscode" class="qkw">猪油</a>洗净切块后，要用<a href="http://m.so.com/s?q=%E7%99%BD%E7%B3%96&amp;src=newstranscode" class="qkw">白糖</a>腌制时日，这样做出来时才能感觉到它的香，完全淹没它的肥腻，它与糕体混为一体。米粉是现磨的，糯米粉和粳米粉是有一定配比的，这样蒸出的糕不至于太软，也不至于太硬，用温水和匀。这时蒸屉里铺上干净的麻布，将和好的米粉均匀地放入，再在表面放上备好的松子仁、瓜子仁、核桃仁、红枣，撒上一些红丝绿丝，糕点透出浓浓地喜气，预示着来年的红红火火。我长大后走过许多江南的小镇，吃过好些糕点，只有妈妈的<a href="http://m.so.com/s?q=%E7%8C%AA%E6%B2%B9%E7%B3%95&amp;src=newstranscode" class="qkw">猪油糕</a>才有特色，它沿袭了传统，纯手工制作，灶头柴火蒸煮，好怀念妈妈做的美味。</p><p><img src="http://p32.qhimg.com/t0131af2ed453b71ee1.jpg?size=550x413"></p><p>2、老苏州姆妈米道<a href="http://m.so.com/s?q=%E8%85%8C%E8%8F%9C&amp;src=newstranscode" class="qkw">腌菜</a></p><p>苏州妈妈有腌菜的传统，一入冬，苏州街头巷尾，围墙下，摆出一地的<a href="http://m.so.com/s?q=%E9%9B%AA%E9%87%8C%E8%95%BB&amp;src=newstranscode" class="qkw">雪里蕻</a>、萝卜干，妈妈从菜场买回家新鲜的雪里蕻、青菜、萝卜，然后有滋有味地开始腌制。家有腌菜，寒冬不慌，腌菜打滚，吃的饭香!延续“老苏州”的生活方式，经过不同的制作和烹饪的方式，变成自家餐桌上美味的开胃小菜，自己腌的菜又香又鲜，好吃得很。</p><p><img src="http://p31.qhimg.com/t015ca5567b5414adcf.jpg?size=320x400"></p><p>3、老苏州姆妈米道<a href="http://m.so.com/s?q=%E8%85%8C%E8%82%89&amp;src=newstranscode" class="qkw">腌肉</a></p><p>妈妈过年喜欢去菜场肉案前巡视，东家看看，西家转转，专挑猪后座看，懂行的都知道这是来挑腌肉的，卖肉的掌柜起了劲的吆喝。还价交易……苏州有“小雪腌菜，大雪腌肉”的老习俗。一些老街巷里挂着成串的各式腌制品，腌点儿<a href="http://m.so.com/s?q=%E5%92%B8%E8%82%89&amp;src=newstranscode" class="qkw">咸肉</a>，风只把鸡，风几条鱼，灌点儿香肠，好像也已经形成了一种习惯。因为腊月里天气干冷，腌的东西时候放得长，又不得坏。妈妈总说自己腌的东西，吃起来心里多少笃定、保险啊!煮饭时切几片腌肉架在饭上蒸蒸，饭熟时肉也香喷喷的了...</p><p><img src="http://p35.qhimg.com/t01bb34b6ba600fa06a.jpg?size=550x357"></p><p class="img-title">4、老苏州姆妈米道酱</p><p>苏州的黄梅天，阴滋滋，妈妈就会准备一种独特的食物，一种让人念念不忘的味道。这就是酱。一种寻常得家家都有，却因为妈妈们喜好准备各不相同的食材，代表着不同家的味道。苏州人最爱的一种酱，叫做“双缸酱”，黄豆酱鲜，蚕豆酱甜，“双缸酱”既鲜亦甜，是上好的炒酱原料。每到<a href="http://m.so.com/s?q=%E8%8A%92%E7%A7%8D&amp;src=newstranscode" class="qkw">芒种</a>过后，家里姆妈就要开始忙碌了。虽然不是贵重的菜品，但是妈妈制作出来的酱，可谓是一丝不苟的，当年做的酱，当年就要吃掉，留到明年，就是隔年的“陈酱”了，味道自然差了一大截，也不符合苏州人讲究的口味了。</p><p><img src="http://p34.qhimg.com/t0143aa18a6385d4c82.jpg?size=550x364"></p><p>5、老苏州姆妈米道<a href="http://m.so.com/s?q=%E9%85%B1%E8%8F%9C&amp;src=newstranscode" class="qkw">酱菜</a></p><p>小时候甚至可以吃着酱菜，就能把饭吃了。妈妈最爱做的就是最简单的乳黄瓜，这可是老苏州餐桌上最常见的喝粥小菜。妈妈会选芒种和小暑之间采摘的乳黄瓜，幼嫩、少籽、色青、带花，加上白糖和蜂蜜，泡在酱里腌上几天，捞出来的时候，既保留了黄瓜清新的原味，不会被腌得太咸，又吸收了酱和蜂蜜的香甜，吃起来既水灵又鲜脆，是下粥的好菜，喷香的酱做好了之后，在餐桌上的地位，就立刻显现了。</p><p><img src="http://p32.qhimg.com/t013be2e5b9313a5d49.jpg?size=500x375"></p><p>6、老苏州姆妈米道<a href="http://m.so.com/s?q=%E9%85%92%E9%85%BF&amp;src=newstranscode" class="qkw">酒酿</a></p><p>酒酿是苏州妈妈很多家庭冬天或春节里的一道吃食。做时先把糯米干蒸熟，要让米硬一点，然后在蒸好的米中混入买来的酒酿芯，再把它放入棉被中保温，一般2~3天后即成，做时可加入桂花酱等。酒酿做得好吃不好吃，关键在买的酒酿芯子，所以一定要买名牌的，你所认可的牌子。酒酿酸酸甜甜的，配在小点心了，那美味就是当时所有的幸福了。</p><p><img src="http://p35.qhimg.com/t012efef8cf1271531d.jpg?size=402x371"></p><p>7、老苏州姆妈米道<a href="http://m.so.com/s?q=%E5%B9%B4%E7%B3%95&amp;src=newstranscode" class="qkw">年糕</a></p><p>苏州年糕的品种比较多，有白糖年糕、玫瑰年糕、桂花年糕、松子百菓年糕。其中白糖年糕是最多的，可以吃到农历三月，有时都长出霉点了，那也没关系，把霉点刮掉热一热就行。我小时候吃的年糕，都是妈妈自己做的，软糯香甜，我记得当时最爱放油里一炸，那种美味只有吃过了才知道。</p><p><img src="http://p33.qhimg.com/t013e4ddaaf13c036d4.jpg?size=550x364"></p><p>8、老苏州姆妈米道<a href="http://m.so.com/s?q=%E6%B2%B9%E9%97%B7%E7%AC%8B&amp;src=newstranscode" class="qkw">油闷笋</a></p><p>每年春笋下来时，妈妈就要买很多笋，把它切成斜刀片，然后用很多的菜油烧开煸炒，加适量酱油和盐，很好吃。炒好的油闷笋放在一个大瓷缸中，可以吃2~3月不会坏的，那时也没冰箱，保存的方法就是把它泡在烧开的油中就行。</p><p><img src="http://p33.qhimg.com/t01466a3b9ca91c170e.jpg?size=550x733"></p><p><img src="http://p31.qhimg.com/t011b94a5c126572d6f.jpg?size=550x414"></p><p>第二页:虾籽酱油、<a href="http://m.so.com/s?q=%E7%B2%BD%E5%AD%90&amp;src=newstranscode" class="qkw">粽子</a>、虾干、桂花酱、<a href="http://m.so.com/s?q=%E9%A6%84%E9%A5%A8&amp;src=newstranscode" class="qkw">馄饨</a>、菜饭</p><p>什么<a href="http://m.so.com/s?q=%E5%B1%B1%E7%8F%8D%E6%B5%B7%E5%91%B3&amp;src=newstranscode" class="qkw">山珍海味</a>，都不敌妈妈做出的家常饭!</p><p class="header">9、老苏州姆妈米道虾籽酱油</p><p>每年春，虾下籽的时候，妈妈要到市场上去买很多<a href="http://m.so.com/s?q=%E8%99%BE%E7%B1%BD&amp;src=newstranscode" class="qkw">虾籽</a>回来，那时卖虾的有把虾籽泡出来专门卖虾籽的，不知道现在还有没有这样的虾农?买来的虾籽要仔仔细细过滤一遍，把杂质都去掉，然后把虾籽倒在烧开的酱油中，熬成苏州的特产-- 虾籽酱油，味道鲜美极了。</p><p><img src="http://p34.qhimg.com/t01759a403ebdfb8481.jpg?size=550x353"></p><p class="img-title">10、老苏州姆妈米道粽子</p><p>妈妈做的棕子品种很多，有红豆的、小枣的、豆馅的、咸肉的，火腿的，我最爱吃蛋黄肉粽的，感到鲜美无比。记得以前看看妈妈<a href="http://m.so.com/s?q=%E5%8C%85%E7%B2%BD%E5%AD%90&amp;src=newstranscode" class="qkw">包粽子</a>，是先将肉泡在酱油中，入味后再包入糯米中做成忱头包粽子即成。粽子可是小时候的早饭经典品种，每天都吃不厌。</p><p><img src="http://p34.qhimg.com/t01e83332860a663816.jpg?size=400x300"></p><p>11、老苏州姆妈米道<a href="http://m.so.com/s?q=%E8%99%BE%E5%B9%B2&amp;src=newstranscode" class="qkw">虾干</a></p><p>每年太湖白虾下来时，妈妈会买很多虾，摘干净后在盐水中煮熟，然后放在菠箩中晒干，即成美味的虾干。可以另食，也可佐餐，味道真真是好极了。</p><p><img src="http://p34.qhimg.com/t018f888bc7e5c6e25d.jpg?size=400x300"></p><p class="img-title">12、老苏州姆妈米道桂花酱</p><p>记得桂花飘香时节，有花农挑担入城，走街串巷叫卖的，妈妈会买一些，用糖腌成桂花酱，可用来做馅或抹在点心上吃，腌桂花，桂花糕，桂花酒酿圆子，桂花糯米藕，冬酿酒，老苏州人肯定不陌生吧。香甜得一塌糊涂啊，随便加在什么里面，都能立刻灵动起来。</p><p><img src="http://p34.qhimg.com/t010975eb9a585b05eb.jpg?size=550x433"></p><p class="img-title">13、老苏州姆妈米道馄饨</p><p>苏州人冬至还有吃馄饨的习俗。苏州人便把它定为冬至节的应景美食。 老苏州人特别爱吃馄饨，光是馄饨馅就能变出很多花样，还有大馄饨，小馄饨，泡泡馄饨...把馄饨吃出了新高度，记得小时候妈妈就爱隔三差五包馄饨给我吃，早饭起来就下一碗鲜美的馄饨，吃完精气神十足，不禁感叹妈妈的手艺总是那么好。</p><p><img src="http://p31.qhimg.com/t0183decfed257f2ba1.jpg?size=550x328"></p><p>14、老苏州姆妈米道<a href="http://m.so.com/s?q=%E8%8F%9C%E9%A5%AD&amp;src=newstranscode" class="qkw">菜饭</a></p><p>立冬日吃上一碗咸肉菜饭，是老苏州们的特定习俗。天冷了，妈妈就会做一锅香喷喷的咸肉菜饭，寒霜打过的矮脚青肥美清甜、肥瘦兼有的咸肉丁、香肠，鲜香有嚼劲，配上糯滑香甜的新米，半个小时的功夫，灶台上就飘出了诱人的香气。稍微焖上片刻，用小瓷碗盛上一碗，再用小勺挖一小块杏色的猪油，借着菜饭的温度，猪油逐渐融化进饭里，米饭粒粒晶莹，渗入猪油的醇香和咸肉的鲜香，实为人间美味。</p><p><img src="http://p34.qhimg.com/t01cce00b8b6f10d987.jpg?size=550x385"></p><p>小时候没有什么山珍海味，而是妈妈就地取材制作的一些老苏州家庭小食，直到现在仍感觉非常幸福，久久难忘的妈妈的味道。</p><p>延伸阅读》》》[环球美食单]147期 街头巷尾的吴江小吃</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://travel.163.com/15/0513/10/APG6PHDH00063KE8.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='b0c978162bf609894db1628f1e8a94a4'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>姆妈</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%A7%86%E5%A6%88&amp;pn=1&amp;pos=5&amp;m=0e1e5a4be4f2f240d800a5de36ecab06be12cec3&amp;u=http%3A%2F%2Ftravel.163.com%2F15%2F0513%2F10%2FAPG6PHDH00063KE8.html" data-pos="1"> 猪油糕酒酿油闷笋 这些都是老苏州<b>姆妈</b>的米道 </a>   <li> <a href="/transcode?q=%E5%A7%86%E5%A6%88&amp;pn=1&amp;pos=6&amp;m=39769d5b2f782bf234d87fe9501c542ad4f7f695&amp;u=http%3A%2F%2Fsh.eastday.com%2Fm%2F20140728%2Fu1a8247256.html" data-pos="2"> 钱蕊蓉守护一方15年 "小<b>姆妈</b>"和她的"孩子们"[图] </a>   <li> <a href="/transcode?q=%E5%A7%86%E5%A6%88&amp;pn=1&amp;pos=7&amp;m=16d945f4d96007bbc6f1612642c41c8c61c3ab8f&amp;u=http%3A%2F%2Fnews.hexun.com%2F2015-02-12%2F173327196.html" data-pos="3"> 家乡年味是"<b>姆妈</b>"炒出来的 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '猪油糕酒酿油闷笋 这些都是老苏州姆妈的米道 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '猪油糕酒酿油闷笋 这些都是老苏州姆妈的米道 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";