s:24854:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>2015首届《魅力中国话》走向世界高端峰会在京召开- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">2015首届《魅力中国话》走向世界高端峰会在京召开</h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2015-05-20 13:44:00</time></p> </header>  <div id="news-body"><p>2015年5月16日，为贯彻和推动习近平总书记:“着力打造融通中外的新概念、新范畴表述，讲好中国故事、传播好中国声音”的指示精神。探讨语言对塑造国家形象，强化国家认同，实施国家治理的重要作用以及对外传播中华文化的重要功能。由中国教育电视协会、<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E4%BC%A0%E5%AA%92%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">中国传媒大学</a>出版社、洁妮(北京)国际文化传媒有限公司联合主办的“2015首届<a href="http://m.so.com/s?q=%E3%80%8A%E9%AD%85%E5%8A%9B%E4%B8%AD%E5%9B%BD%E8%AF%9D%E3%80%8B&amp;src=newstranscode" class="qkw">《魅力中国话》</a>走向世界高端峰会”，在北京举行，百余名专家学者和新闻界的朋友们齐聚一堂。就“语言与国家”这个既古老又新鲜的重要话题，让<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E8%AF%9D&amp;src=newstranscode" class="qkw">中国话</a>成为国家语言并走向世界展开理论性的研讨。</p><p><img src="http://p33.qhimg.com/t013dcd075c7c39e232.jpg?size=550x367"></p><p>全国政协第八届委员，第九、十届全国政协常委，著名经济学家、国务院参事、国家教育咨询委员会委员<a href="http://m.so.com/s?q=%E4%BB%BB%E7%8E%89%E5%B2%AD&amp;src=newstranscode" class="qkw">任玉岭</a></p><p><img src="http://p34.qhimg.com/t01e0a92b0839e1a8f6.jpg?size=550x367"></p><p>中国人权发展基金会常务副会长、政协外事委员会副主任<a href="http://m.so.com/s?q=%E6%9D%A8%E6%AD%A3%E6%B3%89&amp;src=newstranscode" class="qkw">杨正泉</a></p><p><img src="http://p34.qhimg.com/t0118e970feb1ba183c.jpg?size=550x367"></p><p>中宣部原办公厅主任，现任中宣部老干部局书记薛启亮</p><p><img src="http://p31.qhimg.com/t0136a58c0e1bb1ccbb.jpg?size=550x367"></p><p><a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E5%9B%BD%E9%99%85%E5%B9%BF%E6%92%AD%E7%94%B5%E5%8F%B0&amp;src=newstranscode" class="qkw">中国国际广播电台</a>资深媒体人、主任播音员、<a href="http://m.so.com/s?q=%E3%80%8A%E8%B7%9F%E6%88%91%E8%AF%B4%E6%99%AE%E9%80%9A%E8%AF%9D%E3%80%8B&amp;src=newstranscode" class="qkw">《跟我说普通话》</a>《魅力中国话》作者王浩瑜在会上发表了精彩的主题演讲</p><p><img src="http://p34.qhimg.com/t019794f1b66f8be60a.jpg?size=550x367"></p><p>中国传媒大学副校长<a href="http://m.so.com/s?q=%E8%94%A1%E7%BF%94&amp;src=newstranscode" class="qkw">蔡翔</a></p><p><img src="http://p31.qhimg.com/t01e931c5a23a65bb9d.jpg?size=550x367"></p><p>中央人民广播电台著名播音员<a href="http://m.so.com/s?q=%E9%92%9F%E7%91%9E&amp;src=newstranscode" class="qkw">钟瑞</a></p><p><img src="http://p35.qhimg.com/t01610474e0e90ca807.jpg?size=550x367"></p><p>中国传媒大学播音主持<a href="http://m.so.com/s?q=%E8%89%BA%E6%9C%AF%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">艺术学院</a>教授、博士生导师曾志华</p><p>本次峰会主题为“确立中国话的正统地位”。峰会上，著名经济学家、国务院参事任玉岭、 中国人权发展基金会常务副会长、政协外事委员会副主任杨正泉、中宣部原办公厅主任，现任中宣部老干部局书记薛启亮做了重要讲话、中国教育电视协会会长宋成栋、中国传媒大学副校长蔡翔、洁妮(北京)国际文化传媒董事长出席并致辞。专家学者们围绕“如何定义中国话、中国话在国际发展中的角色、地位及作用”等问题发表了精彩演讲。</p><p><img src="http://p35.qhimg.com/t01f20f2c1cef1d2ce0.jpg?size=550x367"></p><p class="img-title">中央电视台著名主持人阿丘</p><p>中国国际广播电台资深媒体人、主任播音员、《跟我说普通话》《魅力中国话》作者王浩瑜在会上发表了精彩的主题演讲，他说:“世界上任何一个多民族的国家，其现代化进程与一体化构建都需要借助一种“共同语”作为工具和载体来沟通各个民族。这种共同语一般叫国语，也有的国家没有国语，而称之为官方语言。国语，就是“国家语言”，是与国旗、国歌、国徽一起，在世界上作为某个国家的标志和象征。国语一般是国内众多语言中使用人口最多、使用最广泛、表现力最强的那种语言。国语享有至高无上的地位，是国家的象征。</p><p><img src="http://p34.qhimg.com/t011e72d0eae0b6e0fc.jpg?size=550x367"></p><p><img src="http://p32.qhimg.com/t01449bd0776ad31f3c.jpg?size=550x367"></p><p><img src="http://p32.qhimg.com/t0156059fb25acb3de5.jpg?size=550x367"></p><p><img src="http://p32.qhimg.com/t015521bea2fb638184.jpg?size=550x367"></p><p>当今世界上的绝大多数国家都有自己的国语，没有自己国语的国家很少。还有的国家既有国语，也有其官方语言。比如:新加坡的国语是马来语，其官方语言是英语、华语、马来语、和泰米尔语;老挝的国语是老挝语，官方语言是法语。在世界上少数没有自己国语的国家中就有我们中国，至今为止，中国就没有通过法律规定哪一种语言是国语。我国的汉语普通话可以称为官方语言或国家通用语言，但并不是通过法律确定的国语。尽管官方语言或国家通用语言在我国的政治、经济、文化等领域发挥了重要作用，但是，毋庸讳言，在凝聚国民意识、加强民族团结、尽早实现两岸和平统一，以及对外沟通交往等方面带来的不便也越来越多了，尽早确立我们中国自己的国家语言，也就是国语----中国话已刻不容缓。</p><p>近几年，一些有识之士已经意识到尽早确立国家语言的重要性。已故中国传媒大学教授、博士生导师<a href="http://m.so.com/s?q=%E5%BC%A0%E9%A2%82&amp;src=newstranscode" class="qkw">张颂</a>先生在为我的拙作《魅力中国话》作序时就旗帜鲜明地指出:“中国话，多年以来，写在书面上，挂在口头上，似乎习以为常了。但是，很少确立她的正统地位，总是用官话、普通话、国家通用语言替代她。久而久之，人们对于中国话反而淡漠了。我们郑重地提出这个问题，彰显了以汉民族共同语为表征的中华民族文化传承与时俱进的精神”。</p><p>2013年9月，<a href="http://m.so.com/s?q=%E4%B9%A0%E8%BF%91%E5%B9%B3&amp;src=newstranscode" class="qkw">习近平</a>主席在哈萨克斯坦纳扎尔巴耶夫大学演讲时倡议用创新的合作模式，共同建设丝绸之路经济带。同年10月，习近平主席访问印尼期间，又提出构建21世纪海上丝绸之路的战略构想。这“一带一路”战略构想高瞻远瞩、审时度势，对密切我国同<a href="http://m.so.com/s?q=%E4%B8%AD%E4%BA%9A&amp;src=newstranscode" class="qkw">中亚</a>、南亚周边国家以及欧亚国家之间的经济贸易关系，深化区域文化交流合作，统筹国内国际发展，维护周边环境，拓展西部大开发和对外开放的空间，都有着重大的意义。众所周知，丝绸之路经济带的建设离不开经济、文化的交流与合作，而经济与文化的交流与合作更离不开语言的沟通。当前，我国正处于发展的重要关口，大政方针已经明确，各项工作也在井然有序地落实，在这极其重要的机遇期，提出语言文化的诸种问题，恰逢其时。</p><p>将我国使用人口数量最多，最普及、表现力最强、历史积淀最长、民族融合最广泛的普通话确定为国家语言--------中国话，既有法律、现实的基础，也是顺应了语言发展的自然规律和社会、国家、国际的需求，同时也是对历史的尊重。</p><p>中共中央政治局委员、国务院副总理刘延东指出:“普通话和规范汉字是国家通用语言文字，其推广事关经济、社会发展和历史文化认同传承，事关国家统一和民族团结，是涉及国家核心利益的战略举措，是宪法规定的公民义务”。</p><p>自“雅言”始，在我国历史发展的长河中，百家争鸣的雄辩，<a href="http://m.so.com/s?q=%E8%AF%97%E7%BB%8F%E6%A5%9A%E8%BE%9E&amp;src=newstranscode" class="qkw">诗经楚辞</a>的诵读，唐诗宋词的吟唱，构成了<a href="http://m.so.com/s?q=%E4%B8%AD%E5%8D%8E%E6%B0%91%E6%97%8F&amp;src=newstranscode" class="qkw">中华民族</a>辉煌灿烂的语言史。同时，在中华文化和中国通用语形成的过程中，以汉文化和语言为主体，吸收、融合了许多兄弟民族的优秀文化和语言成果，甚至包括世界其他国家的优秀文化和语言成果。中国的文化和语言始终具有一种多元化和多样性统一体的特点。例如:在我国的先秦两汉时期，古汉语声母系统没有唇齿音和翘舌音。古人把唇齿音称为轻唇音，把翘舌音称为舌上音。清代历史学家、语言学家<a href="http://m.so.com/s?q=%E9%92%B1%E5%A4%A7%E6%98%95&amp;src=newstranscode" class="qkw">钱大昕</a>就首先提出来“古无轻唇音”的观点。只是后来经过民族的融合，汉语吸收、借鉴了其它北方少数民族的语言成果，才慢慢有了今天的唇齿音和翘舌音。还例如:古代的四声比较复杂，是根据清浊音的不同而分成阴阳两大类，即阴平、阴上、阴去、阴入和阳平、阳上、阳去、阳入，只是到了元明时期，汉语的声调才比秦汉和隋唐时期的声调简单多了。除了语音之外，汉语的词汇受到少数民族和其它国家语言的影响也是很大的。如:西汉以后，从西域和南海各少数民族传来的许多词汇陆续加入汉语词汇中:苜蓿、槟榔、胭脂、琉璃、琥珀、葡萄等。东汉以后，汉语又从古印度和古中亚吸收了跟佛教有关的大批外来词汇，如般若、菩提、涅盘、菩萨、罗汉、比丘、刹那等，这些外来词不仅进入到汉语的词汇当中，而且由于在社会和民众中应用较为广泛，最终成为汉语的常用词汇。此外，像我们今天汉语的常用词汇，胡同、蘑菇、褡裢、<a href="http://m.so.com/s?q=%E8%90%A8%E7%90%AA%E7%8E%9B&amp;src=newstranscode" class="qkw">萨琪玛</a>等，其实也都是从蒙古族和满族语言中吸收的外来词。</p><p>因此，应该旗帜鲜明地将普通话定位在全民族普通话的高度上，定位在中国话的高度上，而不仅仅是汉民族的普通话。唯有如此，不仅是对历史的尊重，而且，对内可以更好地增进国家的和谐与稳定，对外能够更好地促进中国文化在世界的传播。</p><p>当然，我国客观存在的各民族语言、各种方言，具有重要的实用价值、文化价值、情感价值、审美价值、历史价值和认同价值，是中华民族的重要文化遗产，我们一定要使用好、保护好、传承好。但是，保护和使用各民族语言和各地方言与尽早通过法律的手段确立中国国家语言并不矛盾。因为，在我国多样化的语言现实面前，能否尽早确立国家语言的正统地位，将直接影响到全国各族人民对祖国的全方位认同。前苏联从1989年开始的语言改革，也就是各加盟共和国放弃苏联国家语言，而改用各加盟共和国的自己语言成为国家分裂的第一块多米诺骨牌，然后是1990年的各加盟共和国主权化，再到1991年的苏联正式解体。</p><p>2012年11月29日，党的十八大当选的新一届中央领导集体走进国家博物馆，参观<a href="http://m.so.com/s?q=%E3%80%8A%E5%A4%8D%E5%85%B4%E4%B9%8B%E8%B7%AF%E3%80%8B&amp;src=newstranscode" class="qkw">《复兴之路》</a>展览。参观过程中，中共中央总书记、中央军委主席习近平发表了重要讲话，首次阐述了“<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E6%A2%A6&amp;src=newstranscode" class="qkw">中国梦</a>”。在十二届全国人大一次会议上，习近平总书记在讲话中进一步全面阐述了“中国梦”:实现全面建成小康社会、建成富强民主文明和谐的社会主义现代化国家的奋斗目标，实现中华民族伟大复兴的中国梦，就是要实现国家富强、民族振兴、人民幸福。</p><p>习主席“中国梦”的提出，为全体中国人民指出了今后明确的奋斗目标和广阔前景。沿着习主席为我们指明的<a href="http://m.so.com/s?q=%E5%85%89%E8%BE%89%E9%81%93%E8%B7%AF&amp;src=newstranscode" class="qkw">光辉道路</a>前行，我们将在实现“中国梦”的历史进程中，努力实现“语同音”的千年梦想，传承中华民族的文化精髓，弘扬中华民族的浩然正气，融入“为天地立心，为生民立命，为往圣继绝学，为万世开太平”的伟大洪流之中，自豪地去迎接民族复兴时代的到来。”</p><p>全球华人华侨华商联合会主席团主席、亚太旅游联合会会长何光晔，中国传媒大学 电视节目部副主任播音指导、原中央人民广播电台著名播音员钟瑞、华大学资深教授、联合国生态安全科学院院士彭培根，中国传媒大学播音主持艺术学院教授、博士生导师曾志华、人民大学文学院教授许鹏等都做了重要演讲。(杨锈祯、郭萌)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://nb.people.com.cn/n/2015/0520/c365610-24935353.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='e3af6ec4f9d2aedec6eb5b2731365e6c'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>中国话</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%B8%AD%E5%9B%BD%E8%AF%9D&amp;pn=1&amp;pos=8&amp;m=f8b16036a0bd3ae39ee20f176630779e52dd8dbd&amp;u=http%3A%2F%2Fnews.gmw.cn%2F2015-05%2F17%2Fcontent_15689218.htm" data-pos="1"> 《魅力<b>中国话</b>》走向世界高端峰会召开 </a>   <li> <a href="/transcode?q=%E4%B8%AD%E5%9B%BD%E8%AF%9D&amp;pn=1&amp;pos=9&amp;m=ac608731c7c6e5a78baee95e747089ec16c23663&amp;u=http%3A%2F%2Fent.163.com%2F15%2F0204%2F15%2FAHKCAJGK00031GVS.html" data-pos="2"> 《群英会》今晚亮相 探讨"<b>中国话</b>"的内涵 </a>   <li> <a href="/transcode?q=%E4%B8%AD%E5%9B%BD%E8%AF%9D&amp;pn=1&amp;pos=10&amp;m=91b25af9e567bfb59df3a0f1ee44e731cdda7f1c&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0401%2F12%2F9OODK7V300014JB6.html" data-pos="3"> <b>中国话</b>剧院《理查三世》美国首演获得成功 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '2015首届《魅力中国话》走向世界高端峰会在京召开' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '2015首届《魅力中国话》走向世界高端峰会在京召开'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";