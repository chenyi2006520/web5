s:20446:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>南存辉:浙商以创新坚守实业 以供给侧改革培育“新动能”- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">南存辉:浙商以创新坚守实业 以供给侧改革培育“新动能”</h1> <p id="source-and-time"><span id=source>浙江在线</span><time id=time>2016-03-12 21:11:00</time></p> </header>  <div id="news-body"><p>编者按:2016是“十三五”开局之年，随着全国两会拉开帷幕，中国开启走向全面小康的新航程。为了深刻全面展现浙江经济发展现状和发展规划，浙江在线新闻中心推出“浙企新思路”系列主题报道，解读近年来浙商创业创新、区域经济转型发展、传统产业转型升级的样本典型，总结推广浙江经济调结构、促转型的成功经验，探索浙江提高经济发展质量和效益、加速转型升级、深化改革开放、推进创新驱动、推进城乡区域协同<a href="http://m.so.com/s?q=%E5%8F%91%E5%B1%95%E6%96%B0%E6%80%9D%E8%B7%AF&amp;src=newstranscode" class="qkw">发展新思路</a>。</p><p><img src="http://p34.qhimg.com/t013b1a160883d5f94e.jpg?size=600x400"></p><p>浙江在线北京3月12日讯(浙江在线记者/曾杨希 杨俊霞 编辑/胡芸) “民营经济发展将迎来一个<a href="http://m.so.com/s?q=%E6%96%B0%E7%9A%84%E6%98%A5%E5%A4%A9&amp;src=newstranscode" class="qkw">新的春天</a>!”3月10日，全国政协常委、全国工商联常委、浙江省工商联主席、<a href="http://m.so.com/s?q=%E6%AD%A3%E6%B3%B0%E9%9B%86%E5%9B%A2&amp;src=newstranscode" class="qkw">正泰集团</a>董事长南存辉在<a href="http://m.so.com/s?q=%E5%85%A8%E5%9B%BD%E6%94%BF%E5%8D%8F&amp;src=newstranscode" class="qkw">全国政协</a>十二届四次会议第二次全体会议作大会发言，满怀深情地表达自己的心里话，引来全场二千多名委员的阵阵掌声。</p><p>作为民营企业家的代表，<a href="http://m.so.com/s?q=%E5%8D%97%E5%AD%98%E8%BE%89&amp;src=newstranscode" class="qkw">南存辉</a>对未来中国民营经济的发展、浙江民营企业的前景充满信心。</p><p>南存辉的底气来自习近平总书记3月4日在民建、工商联界别联组会上强调的“三个没有变”。</p><p><a href="http://m.so.com/s?q=%E4%B9%A0%E8%BF%91%E5%B9%B3&amp;src=newstranscode" class="qkw">习近平</a>指出，非公有制经济在我国经济社会发展中的地位和作用没有变，我们鼓励、支持、引导非公有制经济发展的方针政策没有变，我们致力于为非公有制经济发展营造良好环境和提供更多机会的方针政策没有变。</p><p>南存辉说:“习近平总书记的讲话给我们吃了颗定心丸。”</p><p>改革开放三十多年间，浙江的民营经济屡创奇迹，如今面对波诡云谲的世界经济环境，民营企业如何突围?两会期间，南存辉做客浙江在线北京演播室，为民企“爬坡过坎”建言献策。</p><p class="header">实体经济如何坚守</p><p class="header">浙商在环境变化中不断创新</p><p>敢为天下先的浙商，经过改革开放30多年磨砺，已然成为“中国第一大商帮”。作为深耕实业30年的浙商，南存辉对民营企业在新常态下如何发展，看得很透彻。访谈一开始，他就明确地提出了“产品总有生命周期”的观点。</p><p>“产品总要经历导入、成长、成熟、衰退这样的周期。优秀的企业不等产品周期结束，就会不断地进行创新，升级产品质量，优化产业结构，甚至把相关的产业整合，形成系统产业链的优势。”南存辉说。</p><p>“科技的日新月异对传统制造业带来了很大的挑战，出现了市场需求减弱的现象，与此同时生产成本却居高不下。”南存辉注意到，有的制造企业开始明显地感受到来自外部环境的压力。</p><p>然而，实体兴则经济兴。南存辉说，在浙江，一批优秀的企业家一直在坚守实业和主业优势，不断创新。</p><p>南存辉举例:“<a href="http://m.so.com/s?q=%E6%9D%8E%E4%B9%A6%E7%A6%8F&amp;src=newstranscode" class="qkw">李书福</a>，这几年不断通过并购，把发达国家的核心技术带回来，结合汽车需要，进行转型升级。<a href="http://m.so.com/s?q=%E5%BE%90%E5%86%A0%E5%B7%A8&amp;src=newstranscode" class="qkw">徐冠巨</a>，原来主要精力在农业，现在大力做物流，他依托自己的优势，正在打造全国的物流港。<a href="http://m.so.com/s?q=%E9%B2%81%E5%86%A0%E7%90%83&amp;src=newstranscode" class="qkw">鲁冠球</a>的万向集团也在不断并购，和世界接轨中。”他深有感触地说道，“其实，浙江的民营企业家们都有忧患意识和创新意识，整个浙商群体，一直在环境变化中适应并坚守。”</p><p class="header">抢抓发展机遇加快转型升级</p><p class="header">搞活机制“以大带小”是良方</p><p>“十八大提出的‘五位一体’和‘四个全面’，为各行各业指明了前进的方向，我们认真学习领会，商机在哪里，方向在哪里，其实很明确。”南存辉说。</p><p>创立于1984年的正泰集团，近年来，通过突围传统电气产业、布局光伏<a href="http://m.so.com/s?q=%E6%96%B0%E8%83%BD%E6%BA%90&amp;src=newstranscode" class="qkw">新能源</a>等方面重要的转型升级，不断赶超世界先进水平。</p><p><a href="http://m.so.com/s?q=%E6%AD%A3%E6%B3%B0&amp;src=newstranscode" class="qkw">正泰</a>的转型正是抢抓机遇、主动调结构的过程。南存辉介绍，近年来，正泰通过突围传统电气产业、布局光伏新能源等方面重要的转型升级，不断赶超世界先进水平。“一开始，正泰只做传统低压电器，后来我们形成了涵盖发电、输电、变电、配电、用电的全产业链，未来还将打造全球领先的<a href="http://m.so.com/s?q=%E6%99%BA%E6%85%A7%E8%83%BD%E6%BA%90&amp;src=newstranscode" class="qkw">智慧能源</a>系统解决方案提供商。”南存辉说，“国家大力鼓励发展清洁能源，看准这个机遇，我们选择到太阳能光伏领域去深耕，用信息化技术和传统产业相结合，并通过海外收购，把海外先进的企业买过来，引进资源、人才、技术后深入融合，带领整个行业往前走。”</p><p>2006年进军光伏产业以来，正泰大力发展清洁能源。正泰<a href="http://m.so.com/s?q=%E5%A4%AA%E9%98%B3%E8%83%BD&amp;src=newstranscode" class="qkw">太阳能</a>连续四年为浙江光伏出口第一大企业。目前，正泰已在全球建成并网运营上百座光伏电站，是国内最大的民营光伏发电投资运营商。</p><p>至于传统制造业在互联网大潮下应该如何应对，南存辉认为，在<a href="http://m.so.com/s?q=%E4%BA%92%E8%81%94%E7%BD%91%E6%97%B6%E4%BB%A3&amp;src=newstranscode" class="qkw">互联网时代</a>，大企业转型，一定要把机制搞活，小企业很灵活，创新比较容易，在企业中建立小分队，让小分队发挥自己的优势，以大带小。</p><p>供给侧改革培育“<a href="http://m.so.com/s?q=%E6%96%B0%E5%8A%A8%E8%83%BD&amp;src=newstranscode" class="qkw">新动能</a>”</p><p class="header">在动能转换中“强”起来</p><p><a href="http://m.so.com/s?q=%E6%9D%8E%E5%85%8B%E5%BC%BA&amp;src=newstranscode" class="qkw">李克强</a>总理在政府工作报告中提出，“在适度扩大总需求的同时，突出抓好供给侧结构性改革”。</p><p>民营企业如何适应供给侧结构性改革?这就要求在新旧发展动能转换中，不仅要“活”下来，而且更要“强”起来。在南存辉看来，其中最关键的核心是创新。他说:“只有坚持创新驱动，加快转型升级，实现由低端向中高端的发展，才能在激烈的市场竞争中占得一席之地。”</p><p>目前，正泰集团一年投入研发费用近20亿元，仅去年高端智能电器研发投入就达8亿元，取得300多项专利。正泰集团成功研发了我国首台薄膜太阳能电池关键高端生产设备，打破了西方长期垄断;自主开发了基于云计算技术、超过1000万点、技术先进的新型轨道交通综合监控云平台。</p><p>南存辉进一步指出，民企还要走出去，而且要走得好。目前，正泰的产品与服务已覆盖世界120多个国家和地区，在欧洲、<a href="http://m.so.com/s?q=%E5%8C%97%E7%BE%8E&amp;src=newstranscode" class="qkw">北美</a>、南美、中东等地建立了研发机构和营销网点，实现了本土企业向跨国企业的转型。他说:“我们要海纳百川，整合全球资源，立足实际，持续提升产品、服务的品质。在这个过程中，一定要清楚能做什么不能做什么，不贪心，也不偷懒，脚踏实地，勇于创新，牢牢抓住供给侧改革带来的巨大发展潜力和机遇!”</p><p>创新的主体是企业，创新的关键在人才。</p><p>南存辉建议，政府要为留住人才创造良好的环境，“这样，才能留得住真正优秀的人才，才能缩小与全球先进技术的差距。有了人才优势和技术优势，不仅能适应市场需求，还能创造需求，引领消费。”</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://zjnews.zjol.com.cn/system/2016/03/12/021062791.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='404f3861ddfe73088ad388d112527327'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>浙企新思路</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%B5%99%E4%BC%81%E6%96%B0%E6%80%9D%E8%B7%AF&amp;pn=1&amp;pos=7&amp;m=5447d8663acb419be7ec9739c2304ef7ed930853&amp;u=http%3A%2F%2Fnews.ef360.com%2FArticlesInfo%2F2014-10-16%2F256348.html" data-pos="1"> 传统<b>浙企</b>推出"智慧丝绸" </a>   <li> <a href="/transcode?q=%E6%B5%99%E4%BC%81%E6%96%B0%E6%80%9D%E8%B7%AF&amp;pn=1&amp;pos=8&amp;m=844278b75b669fb31bf8d603686834c27edf1463&amp;u=http%3A%2F%2Fbiz.zjol.com.cn%2Fsystem%2F2015%2F01%2F05%2F020446548.shtml" data-pos="2"> 2014<b>浙企新</b>状态- </a>   <li> <a href="/transcode?q=%E6%B5%99%E4%BC%81%E6%96%B0%E6%80%9D%E8%B7%AF&amp;pn=1&amp;pos=9&amp;m=d0b0bd51cacd91a588974e9711386260829d13db&amp;u=http%3A%2F%2Fnews.163.com%2F16%2F0305%2F01%2FBHC0QVIC00014AEE.html" data-pos="3"> 徐冠巨:实体经济是中国经济脊梁 积极推动物流一体化建设(组图) </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '南存辉:浙商以创新坚守实业 以供给侧改革培育“新动能”' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '南存辉:浙商以创新坚守实业 以供给侧改革培育“新动能”'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";