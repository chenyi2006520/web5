s:15712:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>补血食谱让奔三女人青春永驻! - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">补血食谱让奔三女人青春永驻! </h1> <p id="source-and-time"><span id=source>光明网</span><time id=time>2016-03-02 00:29:00</time></p> </header>  <div id="news-body"><p>繁重的工作压力、不规律的生活习惯、不合理的饮食……稍不留心，就会进入“黄脸婆”的行列:皮肤特别容易变得干燥、没有光泽，眼角、嘴角也会悄悄冒出小小的细纹。</p><p><img src="http://p32.qhimg.com/t01fd59889d02da1e90.jpg?size=500x300"></p><p><a href="http://m.so.com/s?q=%E6%9C%A8%E7%93%9C%E7%BA%A2%E6%9E%A3%E8%8E%B2%E5%AD%90%E8%9C%9C&amp;src=newstranscode" class="qkw">木瓜红枣莲子蜜</a>--补血养颜</p><p><a href="http://m.so.com/s?q=%E6%9C%A8%E7%93%9C&amp;src=newstranscode" class="qkw">木瓜</a>是尽人皆知的美白食品，它的<a href="http://m.so.com/s?q=%E7%BB%B4%E7%94%9F%E7%B4%A0a&amp;src=newstranscode" class="qkw">维生素a</a>含量极其丰富。中医认为，木瓜味甘、性平，能消食健胃、美肤养颜、滋补催乳，对消化不良或便秘的人也具有很好的食疗作用。美容食疗时，木瓜可配牛奶食用，也可以用来制作菜肴或粥食。<a href="http://m.so.com/s?q=%E7%BA%A2%E6%9E%A3&amp;src=newstranscode" class="qkw">红枣</a>是调节内分泌、补血养颜的传统食品，如果红枣配上<a href="http://m.so.com/s?q=%E8%8E%B2%E5%AD%90&amp;src=newstranscode" class="qkw">莲子</a>食用，又增加了调经益气、滋补身体的作用。</p><p><img src="http://p33.qhimg.com/t01dd7cd90c29518ef0.jpg?size=500x300"></p><p>干燥的秋冬季节，做一道热乎乎的木瓜红枣莲子蜜，不但暖身暖心，还能帮助皮肤抵御干燥的气候。准备好木瓜、红枣、莲子、<a href="http://m.so.com/s?q=%E8%9C%82%E8%9C%9C&amp;src=newstranscode" class="qkw">蜂蜜</a>、冰糖。首先，将红枣、莲子加适量<a href="http://m.so.com/s?q=%E5%86%B0%E7%B3%96&amp;src=newstranscode" class="qkw">冰糖</a>，煮熟待用。然后将木瓜剖开去籽，把红枣、莲子、蜂蜜放到木瓜里面，上笼蒸透后即可食用。</p><p><img src="http://p35.qhimg.com/t01d768e60e8ebe65d7.jpg?size=500x300"></p><p class="img-title">温馨提示:</p><p>食用时，一定要将木瓜一起吃掉。晚餐后，这道滋补佳品最适合作为一道甜品，让全家人一起享用。</p><p>女性到了30岁以后，繁重的工作压力、不规律的生活习惯、不合理的饮食……稍不留心，就会进入“黄脸婆”的行列:皮肤特别容易变得干燥、没有光泽，眼角、嘴角也会悄悄冒出小小的细纹。</p><p><img src="http://p31.qhimg.com/t0115c1ff3353ec5eca.jpg?size=500x300"></p><p><a href="http://m.so.com/s?q=%E6%9E%B8%E6%9D%9E%E9%85%92%E9%85%BF%E8%9B%8B&amp;src=newstranscode" class="qkw">枸杞酒酿蛋</a>--给你好脸色</p><p>很多人喜欢吃<a href="http://m.so.com/s?q=%E9%85%92%E9%85%BF%E9%B8%A1%E8%9B%8B&amp;src=newstranscode" class="qkw">酒酿鸡蛋</a>，但这里推荐的枸杞酒酿蛋用的是<a href="http://m.so.com/s?q=%E9%B9%8C%E9%B9%91%E8%9B%8B&amp;src=newstranscode" class="qkw">鹌鹑蛋</a>。这是因为鹌鹑蛋中含有丰富的蛋白质、b族维生素和维生素a、e等，与<a href="http://m.so.com/s?q=%E9%85%92%E9%85%BF&amp;src=newstranscode" class="qkw">酒酿</a>一起煮，它还会产生有利于女性皮肤的酶类与活性物质。每天一碗，让你的皮肤细嫩有光泽。</p><p><img src="http://p34.qhimg.com/t017bff9ef412fea781.jpg?size=500x300"></p><p>枸杞子则是滋补肝肾的佳品，也是<a href="http://m.so.com/s?q=%E7%BE%8E%E5%AE%B9%E8%8D%AF%E8%86%B3&amp;src=newstranscode" class="qkw">美容药膳</a>中常用的原料之一，维生素a的含量也特别丰富。这些食物加在一起后，更能促进营养成分的吸收，女性食用后的脸色更加滋润动人。</p><p><img src="http://p32.qhimg.com/t010bcf47d7fcf2c0fd.jpg?size=500x300"></p><p><a href="http://m.so.com/s?q=%E7%85%B2%E6%9E%B8%E6%9D%9E&amp;src=newstranscode" class="qkw">煲枸杞</a>酒酿蛋时，先将200克酒酿煮开，然后依次加入5克枸杞、适量冰糖和50克搅拌均匀的鹌鹑蛋<a href="http://m.so.com/s?q=%E8%9B%8B%E6%B6%B2&amp;src=newstranscode" class="qkw">蛋液</a>，最后大火煮开即可。</p><p>鹌鹑蛋的滋补作用要强于鸡蛋，但也可以使用鸡蛋。一定要记得把蛋黄吃了，其效用比蛋白更好，特别是其中的胆固醇对乳房发育也十分有利。产后新妈妈每天坚持食用，不但保证拥有优质的乳汁，皮肤也会越来越好。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://yangsheng.gmw.cn/2016-03/02/content_19116664.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='22dd06f83d51e97d4c8a2fdd59cb02bc'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>青春永驻</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%9D%92%E6%98%A5%E6%B0%B8%E9%A9%BB&amp;pn=1&amp;pos=4&amp;m=510ea06b1a584b5afa51bbf8a468f8e69add96f6&amp;u=http%3A%2F%2Fnews.hfhouse.com%2Fhtml%2F2397591.html" data-pos="1"> 【奥青城】祝愿女性同胞:<b>青春永驻</b> 幸福永远! </a>   <li> <a href="/transcode?q=%E9%9D%92%E6%98%A5%E6%B0%B8%E9%A9%BB&amp;pn=1&amp;pos=5&amp;m=6c18a2ac97e3818c3fb1bfab33069554c6fc070d&amp;u=http%3A%2F%2Fnews.hf.house365.com%2Fzx%2F20160308%2F026130824_all.html" data-pos="2"> 奥青城:祝愿女性同胞<b>青春永驻</b>幸福永远 </a>   <li> <a href="/transcode?q=%E9%9D%92%E6%98%A5%E6%B0%B8%E9%A9%BB&amp;pn=1&amp;pos=6&amp;m=f18d67f34369c37c14fadd0544893aa228d39d10&amp;u=http%3A%2F%2Fyangsheng.gmw.cn%2F2016-02%2F25%2Fcontent_19030046.htm" data-pos="3"> 令女性<b>青春永驻</b>的"八搓" </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '补血食谱让奔三女人青春永驻! ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '补血食谱让奔三女人青春永驻! '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";