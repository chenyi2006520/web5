s:20765:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>胡歌霍建华品质盛典揽四奖 刘诗诗婚礼敲定伴娘团- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">胡歌霍建华品质盛典揽四奖 刘诗诗婚礼敲定伴娘团</h1> <p id="source-and-time"><span id=source>中国日报网</span><time id=time>2016-03-09 09:15:21</time></p> </header>  <div id="news-body"><p><img src="http://p34.qhimg.com/t012f003eb29cb61368.jpg?size=600x341"></p><p><a href="http://m.so.com/s?q=%E9%83%91%E6%99%93%E9%BE%99&amp;src=newstranscode" class="qkw">郑晓龙</a>、王丽萍、马中骏、<a href="http://m.so.com/s?q=%E4%BE%AF%E9%B8%BF%E4%BA%AE&amp;src=newstranscode" class="qkw">侯鸿亮</a>、李星文</p><p>凤凰娱乐讯(采写/小南) 3月8日晚，由SMG影视剧中心主办的2016上海电视剧制播年会暨首届中国电视剧品质盛典在上海圆满落幕，<a href="http://m.so.com/s?q=%E3%80%8A%E8%8A%88%E6%9C%88%E4%BC%A0%E3%80%8B&amp;src=newstranscode" class="qkw">《芈月传》</a>《琅琊榜》《伪装者》等一大批在2015年取得良好收视和口碑的电视剧获得表彰，<a href="http://m.so.com/s?q=%E8%83%A1%E6%AD%8C&amp;src=newstranscode" class="qkw">胡歌</a>、霍建华、刘诗诗、<a href="http://m.so.com/s?q=%E7%8E%8B%E5%87%AF&amp;src=newstranscode" class="qkw">王凯</a>、靳东、刘涛等在2015年有出色代表作的群星也揽下了大部分奖项。</p><p class="header">郑晓龙获颁杰出导演成就奖</p><p>《芈月》<a href="http://m.so.com/s?q=%E3%80%8A%E7%90%85%E7%90%8A%E6%A6%9C%E3%80%8B&amp;src=newstranscode" class="qkw">《琅琊榜》</a>《虎妈》获品质大</p><p>在今年的品质电视剧表彰中，《平凡的世界》获品质特别奖，《芈月传》《琅琊榜》<a href="http://m.so.com/s?q=%E3%80%8A%E8%99%8E%E5%A6%88%E7%8C%AB%E7%88%B8%E3%80%8B&amp;src=newstranscode" class="qkw">《虎妈猫爸》</a>获品质大奖，《伪装者》<a href="http://m.so.com/s?q=%E3%80%8A%E4%BD%95%E4%BB%A5%E7%AC%99%E7%AE%AB%E9%BB%98%E3%80%8B&amp;src=newstranscode" class="qkw">《何以笙箫默》</a>《嘿，老头!》<a href="http://m.so.com/s?q=%E3%80%8A%E5%A4%A7%E5%A5%BD%E6%97%B6%E5%85%89%E3%80%8B&amp;src=newstranscode" class="qkw">《大好时光》</a>《大秧歌》获品质奖。另外，《他来了，请闭眼》和《反恐特战队》获题材创新奖，《铁核桃》、《爱情珠宝》、<a href="http://m.so.com/s?q=%E3%80%8A%E7%88%B7%E4%BB%AC%E5%84%BF%E3%80%8B&amp;src=newstranscode" class="qkw">《爷们儿》</a>获提升贡献奖。</p><p>除了<a href="http://m.so.com/s?q=%E4%B8%9C%E6%96%B9%E5%8D%AB%E8%A7%86&amp;src=newstranscode" class="qkw">东方卫视</a>梦想剧场之外，新闻综合频道、电视剧频道也是上海地区电视剧播放的重要平台。在此次的电视剧品质盛典上，东方卫视播出的《芈月传》、《虎妈猫爸》、《大好时光》、<a href="http://m.so.com/s?q=%E3%80%8A%E4%BA%8C%E8%83%8E%E6%97%B6%E4%BB%A3%E3%80%8B&amp;src=newstranscode" class="qkw">《二胎时代》</a>、《何以笙箫默》、《琅琊榜》，新闻综合频道播出的《英雄祭之生死上海滩》、《孤雁》、<a href="http://m.so.com/s?q=%E3%80%8A%E5%A4%A7%E7%A7%A7%E6%AD%8C%E3%80%8B&amp;src=newstranscode" class="qkw">《大秧歌》</a>、《炮神》、《我姥爷1945》，电视剧频道播出的《爷们儿》、《天涯女人心》、《千金女贼》、《妈妈向前冲》、《如果爱可以重来》等剧收获了“观众最喜爱电视剧”奖项的肯定。</p><p>主创制作奖项方面，著名导演郑晓龙凭借创下东方卫视建台以来最高收视纪录的电视剧《芈月传》当之无愧夺下杰出导演成就奖。孔笙、<a href="http://m.so.com/s?q=%E6%9D%8E%E9%9B%AA&amp;src=newstranscode" class="qkw">李雪</a>凭借《琅琊榜》获得年度最具品质导演奖。年度最具品质制作人奖花落《琅琊榜》、<a href="http://m.so.com/s?q=%E3%80%8A%E4%BC%AA%E8%A3%85%E8%80%85%E3%80%8B&amp;src=newstranscode" class="qkw">《伪装者》</a>的制片人候鸿亮，年度原创剧本奖则被《大好时光》的编剧<a href="http://m.so.com/s?q=%E7%8E%8B%E4%B8%BD%E8%90%8D&amp;src=newstranscode" class="qkw">王丽萍</a>和《虎妈猫爸》的编剧<a href="http://m.so.com/s?q=%E7%94%B3%E6%8D%B7&amp;src=newstranscode" class="qkw">申捷</a>共同捧走。</p><p><img src="http://p32.qhimg.com/t013ade294418f2cac7.jpg?size=600x364"></p><p>胡歌和<a href="http://m.so.com/s?q=%E9%9D%B3%E4%B8%9C&amp;src=newstranscode" class="qkw">靳东</a></p><p class="header">“胡霍CP”揽四奖</p><p class="header">“明家三兄弟”再聚首</p><p>除了电视剧目的颁奖，今年的制播年会还特别增设了演员及幕后创作者的奖项。其中，胡歌凭借《琅琊榜》、《伪装者》、《大好时光》三部收视与口碑齐飞的作品一人揽下年度品质表演大奖和年度最具市场号召力演员两项大奖，而他的“CP”<a href="http://m.so.com/s?q=%E9%9C%8D%E5%BB%BA%E5%8D%8E&amp;src=newstranscode" class="qkw">霍建华</a>则在获得年度最受欢迎男演员奖的同时和胡歌分享了年度最具市场号召力演员奖。有趣的是，胡歌和霍建华一起上台领奖时，颁奖人佟大为和<a href="http://m.so.com/s?q=%E5%88%98%E8%AF%97%E8%AF%97&amp;src=newstranscode" class="qkw">刘诗诗</a>错把胡歌的奖杯递给了霍建华、把霍建华的奖杯递给了胡歌。对此，胡歌打趣道:“其实都一样”。</p><p>作为相识多年的好友，胡歌和霍建华的“胡霍”CP最近又因为一组一起拍摄的时尚大片再度成为网友们热议的话题。现场胡歌主动谈起自己和霍建华的关系:“我相信每个人都有自己的气场，每个走得近的人都是气场非常合的人。我们能获得这个奖可能不仅仅是跟我们的戏有关，大家总开我和华哥的玩笑，我觉得这种情感也是一种号召力。”当被主持人要求用一句话形容他们的关系时，胡歌干脆放话:“是胡也是霍，是霍不用躲!”</p><p>“明台”获得两项大奖的肯定，他的两位哥哥“明楼”和“明诚”也同样在品质盛典的舞台上大放异彩:靳东获得年度最具实力男演员奖，王凯获得年度最具人气男演员奖。如此一来，表演大奖、实力大奖、人气大奖和号召力大奖这四大奖项便被明家三兄弟悉数收入囊中。</p><p><img src="http://p32.qhimg.com/t01c12e5d2b38a9781b.jpg?size=600x365"></p><p class="img-title">刘诗诗</p><p class="header">刘诗诗婚礼敲定伴娘团</p><p class="header">获吴奇隆隔开示爱</p><p>除了“胡霍CP”和“明家兄弟”之外，本届盛典最受媒体关注的嘉宾无疑就是即将在20日举行婚礼的刘诗诗。当晚，刘诗诗获颁年度最具影响力演员大奖，上台领奖时，丈夫吴奇隆意外“现身”送上VCR祝福。VCR中，吴奇隆一本正经地代表刘诗诗向盛典主办方和一众领导嘉宾表示感谢，尽显“当家人”风范。得到爱人祝福的刘诗诗动情地说:“我们一直忙工作的时候是各忙各的，他刚才还说要休息，我相信我们会越来越好。”</p><p>先前接受媒体采访时，刘诗诗一直对自己的婚礼筹备情况三缄其口、不愿多说。这次来到电视剧品质盛典的媒体中心，有老朋友胡歌陪伴的刘诗诗显然心情不错，终于略微松口坦诚自己已经敲定了伴娘团。可当有媒体追问具体人选时，刘诗诗又卖起了关子:“到时候大家就知道了!”关键时刻，胡歌挺身而出为好友“档枪”:“不要问了，给我留点悬念好不好!”</p><p class="header">完整获奖名单:</p><p class="header">中国电视剧品质盛典榜单</p><p class="header">品质特别奖《平凡的世界》</p><p>品质大奖《芈月传》《琅琊榜》《虎妈猫爸》</p><p>品质奖《伪装者》《何以笙箫默》《嘿，老头!》《大好时光》《大秧歌》</p><p>题材创新奖《他来了，请闭眼》《反恐特战队》</p><p>提升贡献奖《铁核桃》《爱情珠宝》《爷们儿》</p><p>观众最喜爱电视剧东方卫视《芈月传》《虎妈猫爸》《大好时光》《二胎时代》《何以笙箫默》《琅琊榜》</p><p>新闻综合《英雄祭之生死上海滩》《孤雁》《大秧歌》《炮神》《我姥爷1945》</p><p>电视剧频道《爷们儿》《天涯女人心》《千金女贼》《妈妈向前冲》《如果爱可以重来》</p><p class="header">杰出导演成就奖郑晓龙</p><p class="header">年度最具品质导演奖孔笙/李雪</p><p class="header">年度最具品质制作人侯鸿亮</p><p class="header">年度原创剧本奖王丽萍/申捷</p><p class="header">年度品质表演大奖胡歌</p><p class="header">年度最受欢迎男/女演员霍建华/刘涛</p><p>年度最具表现力男/女演员张嘉译/秦海璐</p><p class="header">年度最具价值男/女演员佟大为/海清</p><p class="header">年度最具实力男/女演员靳东/闫妮</p><p class="header">年度最具影响力演员刘诗诗</p><p class="header">年度最具市场号召力演员胡歌/霍建华</p><p class="header">年度最具人气男/女演员王凯/郑爽</p><p>年度最具魅力男/女演员刘恺威/陈乔恩</p><p class="header">年度最具突破演员贾乃亮</p><p class="header">年度新锐男/女演员韩东君/王晓晨</p><p>本文系凤凰娱乐独家稿件，未经授权，禁止以任何形式转载，否则将追究法律责任。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://cnews.chinadaily.com.cn/2016-03/09/content_23790862.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='f70cc4a26a2fb0090f4b5478edf6a647'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>刘诗诗伴娘</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%88%98%E8%AF%97%E8%AF%97%E4%BC%B4%E5%A8%98&amp;pn=1&amp;pos=7&amp;m=fa148fe1fe79c30c8df1a4c6a651f7a5b9054356&amp;u=http%3A%2F%2Fmt.sohu.com%2F20160315%2Fn440470896.shtml" data-pos="1"> 若兰刘心悠确认担任<b>刘诗诗伴娘</b> 婚礼细节不知情 </a>   <li> <a href="/transcode?q=%E5%88%98%E8%AF%97%E8%AF%97%E4%BC%B4%E5%A8%98&amp;pn=1&amp;pos=8&amp;m=af679d46497e0d13257315bf2b810c3236b8bbba&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Foverseas%2F2016-03%2F09%2Fc_128784515.htm" data-pos="2"> 胡歌与霍建华同框领奖 <b>刘诗诗</b>已敲定<b>伴娘</b>团 </a>   <li> <a href="/transcode?q=%E5%88%98%E8%AF%97%E8%AF%97%E4%BC%B4%E5%A8%98&amp;pn=1&amp;pos=9&amp;m=b25656cf78c048f0befb3c6a7420e72720cb3f0c&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fkuaixun_0315%2F4759501.html" data-pos="3"> <b>刘诗诗</b>吴奇隆梦幻海岛婚礼细节 刘心悠担任<b>伴娘</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '胡歌霍建华品质盛典揽四奖 刘诗诗婚礼敲定伴娘团' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '胡歌霍建华品质盛典揽四奖 刘诗诗婚礼敲定伴娘团'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";