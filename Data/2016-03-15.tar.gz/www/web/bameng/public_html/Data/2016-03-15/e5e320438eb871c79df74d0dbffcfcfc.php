s:18768:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>小户型装修美图 夏日阳光多彩滋味- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">小户型装修美图 夏日阳光多彩滋味</h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2015-05-22 15:11:00</time></p> </header>  <div id="news-body"><p>编者按:<a href="http://m.so.com/s?q=%E8%BD%BB%E8%A3%85%E4%BF%AE&amp;src=newstranscode" class="qkw">轻装修</a>重装饰是时下流行的装修风格，简约也可以很时尚很现代哦!今天小编就带大家看看几个装饰案例。</p><p><img src="http://p35.qhimg.com/t0161c51528ddf3788c.jpg?size=353x500"></p><p>房子，就是一个享受生活的居所，而这家主人，用她的冷静沉着塑造了一个充满智慧的温馨小 宅，她的居家生活里更具品质。</p><p><img src="http://p34.qhimg.com/t015635a20d309fc75b.jpg?size=397x500"></p><p>没有过多的电器，没有过多的家具，整个空间却显得精致而有力，使一股少有的禅意充斥于房间的每个角落，疲惫之时，房间中那种淡然、随性给人依靠。</p><p><img src="http://p32.qhimg.com/t01dc2af95e6027aa48.jpg?size=371x500"></p><p>整座房子是以黑白灰为主色调，而这样以冷暗色调为主的<a href="http://m.so.com/s?q=%E5%B0%8F%E6%88%B7%E5%9E%8B&amp;src=newstranscode" class="qkw">小户型</a>居室并没有带给屋内人预想中的阴冷、狭隘之感。</p><p><img src="http://p35.qhimg.com/t0160331046d2944955.jpg?size=500x333"></p><p><a href="http://m.so.com/s?q=%E7%99%BD%E8%89%B2%E8%8A%B1&amp;src=newstranscode" class="qkw">白色花</a>点的木地板，纯白的天花板又让纵向空间极度拉伸，白色的灯光让人在这样冷暗色调的房间里拥抱温暖，徜徉在一片自然祥和的氛围中。客厅顶板较 低，晓曼很自然地在顶部加了一个镜面，令屋内光线更足，压抑感荡然无存。</p><p><img src="http://p32.qhimg.com/t018428fb2d5264c5b8.jpg?size=373x500"></p><p>入门的玄关隔断是一抹黑色垂帘，放在那里却是一种难言的和谐。既保证了整体色调的统一，又增加了视觉上的舒适感，同时将<a href="http://m.so.com/s?q=%E5%B8%98%E5%90%8E&amp;src=newstranscode" class="qkw">帘后</a>的工作台与正门隔开， 拉伸了空间的宽度，更让人<a href="http://m.so.com/s?q=%E8%81%94%E6%83%B3&amp;src=newstranscode" class="qkw">联想</a>妩媚动人的主妇和她所烹饪出的美味，幸福生活的气息在这里最为浓厚。</p><p><img src="http://p35.qhimg.com/t0127fec578a80aa7a9.jpg?size=333x500"></p><p>空间整体的黑白灰色调协调统一，加之几点彩色装饰的设计让人有一种淡雅从容的感觉，墙上的白色壁灯仿佛讲述着一段传奇，亦或一段历史，更多的是在 诉说一个又一个漫长而悠远的生活故事。</p><p><img src="http://p32.qhimg.com/t01832a8ab78f16643d.jpg?size=368x500"></p><p class="img-title">每一瓶花都代表着生机</p><p><img src="http://p31.qhimg.com/t0146b0e985d2180ada.jpg?size=501x323"></p><p>深沉的黑色，带着一种大气和稳重的感觉，而明亮的米黄色让空间充满了温暖和浪漫的色彩。它们搭配在一起，让整个空间于理性中渗透着淡淡的愉悦和自然。</p><p><img src="http://p31.qhimg.com/t01647ad3fce56ce8ea.jpg?size=361x461"></p><p>装饰画是家居装饰中比较受人们喜爱的，不管从颜色、大小、数量还是形状，都可以随心所欲根据自己的品味去摆挂。从这面黑色墙上挂着琳琅满目大大小小的画可以看出，这对白领小夫妇很注重生活的品质和对时尚的追求。</p><p><img src="http://p35.qhimg.com/t018f6c7d33efbb88c3.jpg?size=361x461"></p><p>白色钢琴烤漆的多功能办公桌，款式简约而时尚，和旁边刻着花纹的黑色矮墙形成了鲜明的对比，让压抑的黑色立刻增添了几分妩媚，打破了沉静的气氛。浅咖啡色的办公椅和米黄色的靠枕都是麻质的，面料舒适，一年四季都可以适用。</p><p><img src="http://p31.qhimg.com/t01caa2942cbae31085.jpg?size=501x321"></p><p>简洁、大方的米色布艺沙发，搭配同是米色的靠枕会显的单调，精心的女主人特意在其中间摆放了个黑色皮质的靠枕，巧妙的搭配彰显了个性和空间的灵感。射灯的光线照射在墙面银色的隔物板和两幅银色相框的艺术画上，仿佛想要把作画人当时的情感解析出来。两面墙的颜色由浅至深使空间的层次感丰富了起来。墙角的双层隔物板上摆放了白领小夫妇最喜欢的CD和DVD，女主人还挂了一簇绿叶和方形茶几上的绿色植物相互呼应。</p><p><img src="http://p33.qhimg.com/t01a7b7361c813cd4e7.jpg?size=502x322"></p><p>客厅的主题墙设计也很简洁，搭配黑边的白色投影幕、落地式的音响，周末小夫妇两人拉上浅咖啡色的窗帘，坐在沙发上品着红酒看着电影，舒适的享受、优雅的气氛环绕着整个客厅。</p><p><img src="http://p32.qhimg.com/t016be47554606cd170.jpg?size=362x462"></p><p>厨房的整个设计是由小夫妇两人自己动手构思出来的，白色的台面搭配木质的橱柜，纯净中带着舒适、宁静中又带着活力，就想两个人争先着要把自己的厨艺展现给对方看一样，跃跃欲试的温馨感洋溢在这个小空间。</p><p><img src="http://p35.qhimg.com/t01cb697aaf1e153700.jpg?size=361x462"></p><p>女主人不放过每个房间，都在墙上挂上了装饰画，卧室大胆的用了土黄色的背景墙，没想到和米黄色的地板也能搭配出几乎完美的效果。床头的设计很别致，可根据需要随意调整。舒适的床品是必不可少的，木质的床头柜上一盆绿色盆栽也能贫添几分色彩。</p><p><img src="http://p31.qhimg.com/t01cdf951036d4bc193.jpg?size=503x321"></p><p>阳台改造的沐浴区，极尽浪漫与大胆，一个城市里的童话。</p><p>在生活的故事里，我们总能感受它本来的<a href="http://m.so.com/s?q=%E4%BA%94%E5%91%B3%E6%9D%82%E9%99%88&amp;src=newstranscode" class="qkw">五味杂陈</a>，而小小房子里的大<a href="http://m.so.com/s?q=%E5%A4%A7%E6%99%BA%E6%85%A7&amp;src=newstranscode" class="qkw">大智慧</a>，却总能带来不一样的甜蜜滋味，这种滋味叫幸福!</p><p><img src="http://p31.qhimg.com/t01556df02503759dcb.jpg?size=361x435"></p><p>对于一个小户型来说，黑与白的搭配是聪明的选择，可以让空间显得整齐、统一。</p><p><img src="http://p31.qhimg.com/t01fa01b7d52823ee87.jpg?size=363x432"></p><p>小空间的双重功能因为垂帘而更加清晰。</p><p><img src="http://p33.qhimg.com/t01726affdc331e7b62.jpg?size=362x433"></p><p>假如阳台单独作为沐浴区或休闲区出现，可能过于浪费空间，将两个功能合二为一就能将空间扩大至两倍。</p><p><img src="http://p33.qhimg.com/t0157be1274ed1a020b.jpg?size=360x434"></p><p>纯色的家具和配饰在搭配方面可以比较多变，对比色也可以使用。</p><p><img src="http://p31.qhimg.com/t01c9c7137b469279a7.jpg?size=360x433"></p><p>小户型一定要注意收纳的功能，井然有序是关键。</p><p><img src="http://p33.qhimg.com/t01c07c8ad4e9fc922a.jpg?size=361x433"></p><p>黑白花色的<a href="http://m.so.com/s?q=%E5%B8%98%E5%AD%90%E5%90%8E%E9%9D%A2&amp;src=newstranscode" class="qkw">帘子后面</a>是实用的储物区域，这样才使得卧室呈现出一派写意气质。</p><p><img src="http://p35.qhimg.com/t01626351cad46e1848.jpg?size=362x434"></p><p>舒适感对于小户型来说很重要，舒缓的情绪可以化解小空间的局促感。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiaju.people.com.cn/n/2015/0522/c151264-27043040.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='b5aeddbf2a7fb0e40b4c24c99773dee4'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>多彩装饰</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%A4%9A%E5%BD%A9%E8%A3%85%E9%A5%B0&amp;pn=1&amp;pos=5&amp;m=71393dc715d0273f1b90f72e866560705589d47a&amp;u=http%3A%2F%2Fjiaju.people.com.cn%2Fn%2F2015%2F0522%2Fc151264-27043040.html" data-pos="1"> 小户型<b>装修</b>美图 夏日阳光<b>多彩</b>滋味 </a>   <li> <a href="/transcode?q=%E5%A4%9A%E5%BD%A9%E8%A3%85%E9%A5%B0&amp;pn=1&amp;pos=6&amp;m=4a99e0655cd4c668a8115bcd6b16ee3fad0050de&amp;u=http%3A%2F%2Fwww.xfrb.com.cn%2Farea%2Fzonghezixun%2Floushi%2F2016-02-25%2F34300.html" data-pos="2"> 美不美主要看气质,欧巴黎4D<b>多彩</b>集成墙面<b>装饰</b>? </a>   <li> <a href="/transcode?q=%E5%A4%9A%E5%BD%A9%E8%A3%85%E9%A5%B0&amp;pn=1&amp;pos=7&amp;m=3e9bfbef1dc6c5a3147f5fc08f42a296b103206b&amp;u=http%3A%2F%2Fnews.163.com%2F16%2F0314%2F01%2FBI36C38M00014Q4P.html" data-pos="3"> 欢庆<b>多彩</b>季(组图) </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '小户型装修美图 夏日阳光多彩滋味' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '小户型装修美图 夏日阳光多彩滋味'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";