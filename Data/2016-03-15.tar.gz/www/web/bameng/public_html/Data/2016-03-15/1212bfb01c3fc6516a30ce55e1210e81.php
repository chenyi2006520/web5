s:21418:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>江汉路步行街车流穿梭 “任性”电动车让行人步步惊心- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">江汉路步行街车流穿梭 “任性”电动车让行人步步惊心</h1> <p id="source-and-time"><span id=source>武汉热线</span><time id=time>2015-05-07 08:16:00</time></p> </header>  <div id="news-body"><p>(武汉晚报记者 王莹明<a href="http://m.so.com/s?q=%E5%87%8C%E7%BF%94&amp;src=newstranscode" class="qkw">凌翔</a>图/记者杨少昆)有着“天下第一步行街”美誉的<a href="http://m.so.com/s?q=%E6%B1%9F%E6%B1%89%E8%B7%AF%E6%AD%A5%E8%A1%8C%E8%A1%97&amp;src=newstranscode" class="qkw">江汉路步行街</a>是武汉的一张城市名片，这条全长1600米的百年商业老街，每天往来的人流量不下20万人次。近期，却有不少市民向<a href="http://m.so.com/s?q=%E6%AD%A6%E6%B1%89%E6%99%9A%E6%8A%A5&amp;src=newstranscode" class="qkw">武汉晚报</a>反映，现在江汉路步行街上电动车随意乱窜，行人很担心被撞到，安全隐患大，还给人留下不文明的印象。</p><p>电动车为何在步行街上如此“任性”?为此，武汉晚报记者进行了探访。</p><p><img src="http://p35.qhimg.com/t01bc709b183a813930.jpg?size=400x266"></p><p>电动车在人流中“绕桩” 大人小孩步行街上心慌慌</p><p>昨天中午，记者在江汉路步行街上看到，熙熙攘攘的逛街人群中，不时冒出几辆电动车，车速较快，从行人身边“嗖”的一下就过去了，不少路人避之不及。</p><p>12点17分，一辆后座载人的电动车从新华小区方向驶向<a href="http://m.so.com/s?q=%E6%B1%9F%E6%B1%89%E8%B7%AF&amp;src=newstranscode" class="qkw">江汉路</a>地铁口，在通往步行街<a href="http://m.so.com/s?q=%E4%B8%AD%E5%BF%83%E7%99%BE%E8%B4%A7&amp;src=newstranscode" class="qkw">中心百货</a>广场时，人流密集，该车没怎么减速。只见骑行男子将两脚做悬空状，在三五成群的人流中进行S型“绕桩”，沿途没按一声喇叭，而后座上的男子正低头玩着手机。不少迎面而来的行人见状，只好站着不动，任其从身边绕过，而前面4个年轻的女孩因不知身后有车，依然说笑地逛着街，突然被眼前窜出的电动车吓了一大跳。</p><p>下午2点，市民刘女士带着不满5岁的儿子，在靠近江汉路天桥旧址的一处长凳上休息，坐不住的小男孩，边跑边追手中的氢气球。这时，一辆超标电动车在孩子正前方疾驶而来。吓得刘女士一身冷汗，赶紧跑过去把孩子抱到一旁，扭头对着电动车驾驶员斥道:“你讲不讲公德?看到小伢还骑这快，撞到了么办?”刘女士很纳闷:“怎么会有这么多电动车穿梭在步行街上?怎么就没人管?”不少行人表示，逛街心情受影响，走路心慌慌。</p><p>外卖电动车当街“任性” 一小时竟往返八趟</p><p>随后，记者来到江汉路步行街中心百货广场至江汉路天桥旧址路段蹲守发现，一个小时之内，竟有36辆电动车来回驶过。而本月5日晚上8点，记者蹲守同一地点发现，人流高峰时期，几乎每隔20秒钟，就有一辆电动车驶过，不时会引起路人惊呼。</p><p>昨天下午2点10分，一些载人、载货的电动车来回穿梭在步行街上，逛街行人避让不及。此时，一辆快餐店的外卖电动车把步行街当成了“快速通道”，送外卖的店员骑着车在人群中娴熟地穿梭着。一小时内，他竟在相同路段往返了八次。直到下午3点20分左右，几名巡逻的城管队员将该店门口的两辆外卖电动车搬离至步行街<a href="http://m.so.com/s?q=%E5%B2%94%E8%B7%AF%E5%8F%A3&amp;src=newstranscode" class="qkw">岔路口</a>外，并进店对其进行了口头警告。</p><p>而5日晚上8点，记者看到，一些满载四五个大纸箱的电动车，狂按喇叭急速穿梭于人群中。同时，新世界百货附近十字路口处，还有6辆“摩的”揽客。有些“摩的”对后座进行了改装，横截面变大，装货更多，在密集的人群中穿梭，经常会擦碰到逛街行人。路上还有一些年轻的滑轮爱好者，与来往电动车擦肩而过，险象环生。</p><p>周边一些商家表示，每到节假日和晚高峰时期，整条步行街几乎是人车共行，他们都见怪不怪了。</p><p>九个交会路口的隔离墩 半数可被电动车“<a href="http://m.so.com/s?q=%E9%92%BB%E7%A9%BA%E5%AD%90&amp;src=newstranscode" class="qkw">钻空子</a>”</p><p>作为一条百年商业老街，在每个路口交会处都设有隔离墩和过街护栏，这些电动车又是如何进入步行街的?记者对步行街的九个主要交会路口进行了探访。</p><p>在江汉路地铁B出口处，8辆“摩的”正在揽客。记者随机上了一辆“摩的”，并告知要去江汉路步行街中心百货。“摩的”车主先是载着记者抄近路从地铁A出口驶入，结果发现路面被几个大的石墩挡住了。于是，“摩的”便沿着<a href="http://m.so.com/s?q=%E5%89%8D%E8%BF%9B%E5%9B%9B%E8%B7%AF&amp;src=newstranscode" class="qkw">前进四路</a>、三新横街、前进五路，来到<a href="http://m.so.com/s?q=%E6%B1%9F%E6%B1%89%E4%B8%89%E8%B7%AF&amp;src=newstranscode" class="qkw">江汉三路</a>和步行街的交会处，而此处的隔离护栏有半米长的间距，“摩的”轻而易举就通过护栏驶进了步行街，原本5元的价格因为绕行被多加了2元。</p><p>途中，记者问“摩的”车主，电动车开进步行街，不怕有人来查?“摩的”车主笑称，只要不是机动车，自行车、电动车畅通无阻。一到晚上，他们还会把一些石墩移开，让间距变大，这样电动车抄近路走，来去更方便。</p><p>记者留意到，步行街上像江汉三路这种间隙较大的护栏不在少数，从<a href="http://m.so.com/s?q=%E6%B1%9F%E6%B1%89%E5%9B%9B%E8%B7%AF&amp;src=newstranscode" class="qkw">江汉四路</a>与步行街的交会处，一直到<a href="http://m.so.com/s?q=%E9%BB%84%E9%99%82%E8%A1%97&amp;src=newstranscode" class="qkw">黄陂街</a>与步行街的交会处，其中九个主要交会路口中，有四个路口的隔离墩和护栏存在“漏洞”。</p><p>在<a href="http://m.so.com/s?q=%E6%B1%9F%E6%B1%89%E4%BA%8C%E8%B7%AF&amp;src=newstranscode" class="qkw">江汉二路</a>与江汉路交会处，一个隔离墩主体部分早已不见，只剩下高约5厘米的“绊脚桩”，行人稍不留神就会被绊一跤。此处隔离墩之间的间距参差不齐，最宽的地方接近2米，最窄的地方也有0.5米，电动车进入毫无阻碍。</p><p>在江汉路与吉庆街交会处，记者从远处看见，一排L型的护栏整齐地排列在路口处。此时，一辆小型电动车竟然从花坛与护栏的空隙处“挤”了进去，走近才发现，此处护栏与花坛间距足有半米宽，护栏下方有个挂链条的钩子，但其中链条早已不见。</p><p>“人防”“器防”都有漏洞 管办人员希望公安介入管理</p><p>昨天，记者来到江汉路步行街管理办公室。一位<a href="http://m.so.com/s?q=%E5%A7%9A%E5%A7%93&amp;src=newstranscode" class="qkw">姚姓</a>负责人表示，按照相关规定，电动车肯定不允许进入步行街。遇到电动车进步行街，工作人员会拦截。但是，目前在管理上存在一些困难。</p><p>该负责人拿出2000年颁布的<a href="http://m.so.com/s?q=%E6%AD%A6%E6%B1%89%E5%B8%82%E6%94%BF%E5%BA%9C&amp;src=newstranscode" class="qkw">武汉市政府</a>令第121号文，根据<a href="http://m.so.com/s?q=%E3%80%8A%E6%AD%A6%E6%B1%89%E5%B8%82%E6%B1%9F%E6%B1%89%E8%B7%AF%E6%AD%A5%E8%A1%8C%E8%A1%97%E5%9C%B0%E5%8C%BA%E7%BB%BC%E5%90%88%E7%AE%A1%E7%90%86%E6%9A%82%E8%A1%8C%E8%A7%84%E5%AE%9A%E3%80%8B&amp;src=newstranscode" class="qkw">《武汉市江汉路步行街地区综合管理暂行规定》</a>中的第五条规定:除以车代步的残疾人使用的专用代步车和从中山大道、江汉四路横穿江汉路步行街的机动车以及从江汉四路横穿步行街的非机动车外，未经公安部门批准，机动车和非机动车不得进入江汉路步行街。违反规定的，由公安部门依照<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E5%8D%8E%E4%BA%BA%E6%B0%91%E5%85%B1%E5%92%8C%E5%9B%BD%E9%81%93%E8%B7%AF%E4%BA%A4%E9%80%9A%E7%AE%A1%E7%90%86%E6%9D%A1%E4%BE%8B%E3%80%8B&amp;src=newstranscode" class="qkw">《中华人民共和国道路交通管理条例》</a>和有关法规、规章的规定予以处理;其中非机动车擅自进入江汉路步行街或在步行街内任意停放的，由公安部门委托监察中队予以处理。</p><p>“我们城管队员没有扣车、处罚的权利。”该负责人解释，目前，步行街上没有监察中队，只有城管执法大队。这种情况下，公安并没有委托城管处理相关问题。执法人员只能口头劝说，一些素质较低的电动车主，被拦时会对执法人员破口大骂，有的甚至不听劝告、直接开车冲离，城管队员被刮伤蹭伤的情况并不少见。电动车躲避执法人员，很容易撞到行人，所以城管队员也不好去追赶电动车。</p><p>对于步行街入口处、交会处的隔离墩、防护栏间距大、有破损的情况，该负责人解释，有些是方便残疾人通过，留下的无障碍通道，但也会让一些不文明的电动车主“钻空子”。</p><p>如何有效避免电动车在步行街上出没?该负责人表示，要像惩治“酒驾”一样依法依规处理。其中，公安部门最好能介入进来，和城管进行联合执法，对在步行街上违规行驶的车辆进行处罚，引起当事人的重视，加强宣教力度，增强市民文明出行的意识。</p><p>读者朋友，你对江汉路步行街电动车任意穿行怎么看，管理上有何好的建议?请来电:82333333或@武汉晚报官方微博</p><p>责编:<a href="http://m.so.com/s?q=%E6%9D%8E%E8%8E%89%E8%8E%89&amp;src=newstranscode" class="qkw">李莉莉</a></p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://info.wuhan.net.cn/pub/2015/0507/1339541.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='547094f6bf9bece8105f46b8001e6c5c'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>江汉路步行街</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%B1%9F%E6%B1%89%E8%B7%AF%E6%AD%A5%E8%A1%8C%E8%A1%97&amp;pn=1&amp;pos=7&amp;m=f2e07a9666b09c27b6bb289efa513304e20545cf&amp;u=http%3A%2F%2Fhb.qq.com%2Fa%2F20150507%2F009212.htm" data-pos="1"> <b>江汉路步行街</b>电动车乱窜 高峰时每20秒驶过一辆 </a>   <li> <a href="/transcode?q=%E6%B1%9F%E6%B1%89%E8%B7%AF%E6%AD%A5%E8%A1%8C%E8%A1%97&amp;pn=1&amp;pos=8&amp;m=91549b7bbb04a904cc8aa84c8903aefe9940d93e&amp;u=http%3A%2F%2Fhb.sina.com.cn%2Fnews%2Fb%2F2014-12-23%2Fdetail-iavxeafr9147955.shtml" data-pos="2"> <b>江汉路步行街</b>铜像栅栏被拆除 市民可亲密接触(图) </a>   <li> <a href="/transcode?q=%E6%B1%9F%E6%B1%89%E8%B7%AF%E6%AD%A5%E8%A1%8C%E8%A1%97&amp;pn=1&amp;pos=9&amp;m=205b0f1bdb6fa74e8036168cffd580bf4da37339&amp;u=http%3A%2F%2Fhb.sina.com.cn%2Fnews%2Fb%2F2014-10-13%2Fdetail-icfkptvx3827071.shtml" data-pos="3"> 武汉<b>江汉路步行街</b>摆石墩阵 市民缝隙间穿行 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '江汉路步行街车流穿梭 “任性”电动车让行人步步惊心' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '江汉路步行街车流穿梭 “任性”电动车让行人步步惊心'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";