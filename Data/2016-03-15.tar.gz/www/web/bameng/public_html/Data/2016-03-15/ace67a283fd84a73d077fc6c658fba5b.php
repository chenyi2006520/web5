s:15248:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>慕尼黑味道- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">慕尼黑味道</h1> <p id="source-and-time"><span id=source>东方网</span><time id=time>2016-03-07 02:10:24</time></p> </header>  <div id="news-body"><p class="header">[导读]</p><p><a href="http://m.so.com/s?q=%E6%85%95%E5%B0%BC%E9%BB%91&amp;src=newstranscode" class="qkw">慕尼黑</a>味道</p><p>慕尼黑是个有活力的城市。位于市中心的<a href="http://m.so.com/s?q=%E5%9C%A3%E7%8E%9B%E4%B8%BD%E4%BA%9A&amp;src=newstranscode" class="qkw">圣玛丽亚</a>广场非常热闹，杂耍的、唱歌的、弹琴的，在众多游人关注下，玩儿得很嗨。周围老建筑里面的饭馆，提供慕尼黑传统美味，<a href="http://m.so.com/s?q=%E7%99%BD%E8%82%A0&amp;src=newstranscode" class="qkw">白肠</a>、烤鱼、猪肘子，当然，不能缺了啤酒。</p><p class="header">圣玛丽亚广场</p><p>慕尼黑的创新也很有味道。土生土长的H先生，曾在<a href="http://m.so.com/s?q=%E6%83%A0%E6%99%AE&amp;src=newstranscode" class="qkw">惠普</a>等大公司工作多年，自己创办过三家科技企业，目前经营一个区域创新平台:连接当地四所高校、几十家大公司、数百家新创企业、投资机构、欧盟及地方政府的创新生态系统。他说，慕尼黑的经济与社会发展一直在全国领先，当地人都很自信，有句老话，德国是由<a href="http://m.so.com/s?q=%E5%B7%B4%E4%BC%90%E5%88%A9%E4%BA%9A&amp;src=newstranscode" class="qkw">巴伐利亚</a>以及其他地区构成的。(也许类似的是，中国只有<a href="http://m.so.com/s?q=%E4%B8%8A%E6%B5%B7%E4%BA%BA&amp;src=newstranscode" class="qkw">上海人</a>和乡下人两种)不过，慕尼黑确有这个资本，这是<a href="http://m.so.com/s?q=%E5%A5%94%E9%A9%B0&amp;src=newstranscode" class="qkw">奔驰</a>、宝马的故乡，航空制造业发达，生物工程等新兴技术也都有一号。</p><p><a href="http://m.so.com/s?q=%E6%85%95%E5%B0%BC%E9%BB%91%E5%B7%A5%E4%B8%9A%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">慕尼黑工业大学</a>是德国最好的三所大学之一，拥有二十多位诺奖得主。学校在慕尼黑有三处校址，我们先去了位于市中心的总部，跟研究与创新办公室的负责人S女士进行了交流。</p><p>会见慕尼黑工业大学研究与创新办公室S女士</p><p>经S介绍，我们到访了慕尼黑工业大学位于城市西北部的校区，主要看了孵化器和创客中心。孵化器面向学校的教师、学生以及至少有一名<a href="http://m.so.com/s?q=%E5%B7%A5%E4%B8%9A%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">工业大学</a>毕业生的团队，经过严格筛选后，团队或企业可以免费在开放空间运营三个月，再经筛选过的，可以在一个十平米左右的<a href="http://m.so.com/s?q=%E7%8B%AC%E7%AB%8B%E7%A9%BA%E9%97%B4&amp;src=newstranscode" class="qkw">独立空间</a>免费运营一年，此后就要离开。这一年三个月里面，孵化器提供导师、社交、中介等免费服务，也提供实验仪器设备使用等有偿服务。</p><p>这里的创客空间足够豪华，制造工具、设备齐全，“车间”占地约一千平米，是创客们--主要是大学在校生真能发挥想象、实现创意的地方，是真正的创客空间。</p><p><a href="http://m.so.com/s?q=%E6%B7%84%E5%8D%9A&amp;src=newstranscode" class="qkw">淄博</a>瀚海慕尼黑科技园，主要由山东<a href="http://m.so.com/s?q=%E6%B7%84%E5%8D%9A%E5%B8%82&amp;src=newstranscode" class="qkw">淄博市</a>高新区、瀚海智业集团投资建设，成立于2013年。地理位置很好，坐落在一个大科技园内。独门独院，双体建筑，一圆一方，建筑面积面积五千平米。入住了十六家企业，本地和来自中国的机构各半。科技园运营近三年，为淄博市的<a href="http://m.so.com/s?q=%E6%8B%9B%E5%95%86%E5%BC%95%E8%B5%84&amp;src=newstranscode" class="qkw">招商引资</a>、引进项目和人才、开展境外培训等，做了大量工作，社会效益显著。物业价值增加了一倍，运营基本自负盈亏，是个相当成功的海外投资项目。</p><p class="header">慕尼黑工业大学创客中心</p><p>科技园的总经理，L博士，可是个“狠角色”。山东人，在德国拿的博士，长期任职工业界，是德国有相当影响力的电机专家，慕尼黑工业大学、同济大学教授，国内千人计划专家。目前，他还带领着一个研究团队，在开发几款电机，包括超高速、超低速、超低温、超导电机，这些东西，毫无疑问是国内制造业转型升级所急需的。</p><p>在L博士引领下，参观淄博瀚海慕尼黑科技园</p><p>看来，慕尼黑真是个有味道的地方，与我们的需要很对味。慕尼黑，我<a href="http://m.so.com/s?q=%E6%AC%A0%E4%BD%A0%E4%B8%80%E4%B8%AA%E6%8B%A5%E6%8A%B1&amp;src=newstranscode" class="qkw">欠你一个拥抱</a>，你欠我一桶啤酒。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.eastday.com/eastday/13news/auto/news/china/20160307/u7ai5374088.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='517b8a5595702e74cf4d35c64ed6156c'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>慕尼黑工业大学</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '慕尼黑味道' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '慕尼黑味道'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";