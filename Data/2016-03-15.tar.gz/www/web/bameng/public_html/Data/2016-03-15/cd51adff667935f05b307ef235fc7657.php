s:14908:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>未买到票车站大哭 不能回家背后故事引人泪奔 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">未买到票车站大哭 不能回家背后故事引人泪奔 </h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-01-27 19:49:53</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t011be479086b543eb1.jpg?size=550x330"></p><p>未买到票车站大哭 不能回家背后故事引人泪奔</p><p>未买到票车站大哭:春运故事:这名想<a href="http://m.so.com/s?q=%E5%9B%9E%E5%AE%B6%E7%9A%84%E7%94%B7%E4%BA%BA&amp;src=newstranscode" class="qkw">回家的男人</a>在火车站哭了三次</p><p>春运这场“大迁徙”里有着无数小人物的悲欢冷暖。</p><p>昨天(1月26日)，温州火车站客运作业长<a href="http://m.so.com/s?q=%E8%B5%B5%E6%B5%B7%E4%BA%91&amp;src=newstranscode" class="qkw">赵海云</a>描述了在春运首日见到的“一名想回家的男人在火车站三次哭泣”的故事。</p><p><img src="http://p34.qhimg.com/t0195800efcda4395bc.jpg?size=452x294"></p><p>未买到票车站大哭:1月24日下午2时许，<a href="http://m.so.com/s?q=%E8%BD%A6%E7%AB%99%E5%80%BC%E7%8F%AD%E5%91%98&amp;src=newstranscode" class="qkw">车站值班员</a>在站外巡查时发现一名成年男人在<a href="http://m.so.com/s?q=%E7%81%AB%E8%BD%A6%E7%AB%99%E5%B9%BF%E5%9C%BA&amp;src=newstranscode" class="qkw">火车站广场</a>大哭。他穿着单衣，双手发黑，像是刚从哪里干完活。</p><p>值班员上前与男子攀谈，男子停止哭泣说，哭是因为刚被验票的工作人员三次拒绝进站，回不了家。</p><p>其实，验票人员的拒绝是合理的，因为温州火车站实行实名制进站，要人、证、票一致方可进站上车。而该男子根本就没有票。</p><p><img src="http://p31.qhimg.com/t01621f675ca5068a1e.jpg?size=493x457"></p><p>未买到票车站大哭:春运首日，下午5时30分，温州火车站，一位乘客一手扛着包一手拉着孩子准备上车。</p><p>男子说，当天他先来到一个进站口，想跟着人群混进去，结果被查出来了。</p><p>几分钟后，他又到另一个进站口，还是被查出来。又过了一会儿，他又去了第三个检票口，结果还是被拒。验票人员每次都提醒他:要有票才行。</p><p>你为什么不买票?听到这个问题，男子又开始流泪，说起苦衷。</p><p>他说自己姓王，河南人，在温州打工，老婆和孩子在老家。在温一年，他没回家看过家人。前些日子，他得知孩子要在1月25日做眼部手术，就决定在24日回老家。</p><p><img src="http://p32.qhimg.com/t012e1c158027a6c25d.jpg?size=445x329"></p><p>未买到票车站大哭:可是，他面临的情况是之前在工地上忙到没时间出来买票。再则，工作没完成，老板不给结算工资，他手头也没有富余的钱买票。</p><p>24日，老板得知他的情况后，同意他提早回家，并把工资给了他。他高兴地跑到温州火车站售票大厅，却被告知已经没有票了。他懵了，实在想不出其他方法，这才动起了混进车站的“歪脑筋”。</p><p>“我想回家，能不能<a href="http://m.so.com/s?q=%E8%AE%A9%E6%88%91%E4%B8%8A%E8%BD%A6&amp;src=newstranscode" class="qkw">让我上车</a>，随便到哪里，我想办法转车也行。”他哭着向值班员重复着这句话。</p><p>了解核实男子情况后，值班员通过申请，启用了温州火车站“爱心”通道，将男子安排到当天下午温州开往<a href="http://m.so.com/s?q=%E5%95%86%E4%B8%98&amp;src=newstranscode" class="qkw">商丘</a>的列车上。</p><p>在车站里，踏上回家列车的男子，第三次哭了。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/2016/kuaixun_0127/3705723.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='a00a1404a211f3816b41d059217b2c23'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>赵海云</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%B5%B5%E6%B5%B7%E4%BA%91&amp;pn=1&amp;pos=6&amp;m=34d074ee4a7e4765a3dc1f1e627905fce67e03af&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fkuaixun_0127%2F3705033.html" data-pos="1"> 未买到票车站大哭 想回家的男人内心是崩溃的 </a>   <li> <a href="/transcode?q=%E8%B5%B5%E6%B5%B7%E4%BA%91&amp;pn=1&amp;pos=7&amp;m=49fffc12f48bbfb7463d01c9961cbc62f4704628&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fjsnews%2Fsociety%2F3704773_1.html" data-pos="2"> 男子未买到票车站大哭 春运大军来袭网友直叹回不了家的苦 </a>   <li> <a href="/transcode?q=%E8%B5%B5%E6%B5%B7%E4%BA%91&amp;pn=1&amp;pos=8&amp;m=4795581768d1dda98cfcac7626e33447cfd57240&amp;u=http%3A%2F%2Ffinance.huanqiu.com%2Froll%2F2016-01%2F8468111.html" data-pos="3"> 互联网公司"拼"抢春运蛋糕 北京拼车回上海比高铁便宜 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '未买到票车站大哭 不能回家背后故事引人泪奔 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '未买到票车站大哭 不能回家背后故事引人泪奔 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";