s:15127:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>放心吧! Apple Pencil 被移除的功能会回来- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">放心吧! Apple Pencil 被移除的功能会回来</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-02-24 19:04:23</time></p> </header>  <div id="news-body"><p>使用iPadPro和ApplePencil的用户们现在可能还在为iOS9.3测试版中，<a href="http://m.so.com/s?q=%E8%8B%B9%E6%9E%9C&amp;src=newstranscode" class="qkw">苹果</a>移除了ApplePencil部分功能的事情而闷闷不乐，不过不用担心。<a href="http://m.so.com/s?q=%E8%8B%B9%E6%9E%9C%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">苹果公司</a>目前已经通过TheVerge对此事进行了解释，</p><p>使用 <a href="http://m.so.com/s?q=iPad&amp;src=newstranscode" class="qkw">iPad</a> Pro 和 <a href="http://m.so.com/s?q=Apple&amp;src=newstranscode" class="qkw">Apple</a> Pencil 的用户们现在可能还在为 iOS 9.3 测试版中，苹果移除了 Apple <a href="http://m.so.com/s?q=Pencil&amp;src=newstranscode" class="qkw">Pencil</a> 部分功能的事情而闷闷不乐，不过不用担心。苹果公司目前已经通过 The Verge 对此事进行了解释，苹果公司的声明如下:</p><p>Apple Pencil 很受 iPad Pro 用户的喜爱，他们会用它来画画、做注释、做笔记等。我们认为手指才是用户在 iPad 上导航的首要方式，但是我们也能理解有些用户更喜欢使用 Apple Pencil 来进行导航，所以在iOS 9.3的测试版中我们一直在寻找新的方式以更好地支持用户，同时确保它的兼容性。我们将会在 iOS 9.3 的下个测试版中恢复这些功能。</p><p>从苹果公司的声明来看，iPad Pro 的 Apple Pencil 将不会失去什么功能，而且从苹果公司的声明来看，他们也不是有计划地削减 Apple Pencil 的功能。苹果表示他们还在完善 Apple Pencil 在这方面的功能，所以目前只是暂时的移除某些功能。</p><p><img src="http://p34.qhimg.com/t01d06368b5df925417.jpg?size=500x357"></p><p>无论如何，iPad Pro 用户你现在可以放心了，在下一个 iOS 9.3 测试版中，Apple Pencil 的功能都将恢复，而且 iOS 9.3 正式发布之后，Night Shift 等新特性都将到来。</p><p>本周早些时间 iOS 9.3 测试版发布后，一些 iPad Pro 用户注意到 Apple Pencil 在新版本当中的功能遭到了削弱。在目前的 iOS 9.2.1 版本当中，Apple Pencil 可以用来完成一系列导航操作。就像手指一样，用户可以通过 Apple Pencil 在 iPad Pro 的屏幕上进行点击、选择、滚动、切换软件、访问菜单、在非绘画软件内访问编辑控制程序等。</p><p>然而在 iOS 9.3 测试版的环境下，很多 Apple Pencil 的功能都被移除了。如果有一台 iPad Pro 安装了 iOS 9.3，那么所配对的 iPad Pro 将不能再进行选择文本又或者是像滚动翻页这样的操作了。最开始的时候，iPad Pro 用户认为功能被移除可能只是新系统当中的一个 bug，但是在 iOS 9.3 接下来的几次更新版本当中这个所谓的“bug”依然存在。</p><p>而且，苹果从来没有在 iOS 9.3 Beta 的更新日志里提到 Apple Pencil 部分功能被限是“已知问题”。因此，有人指出这是苹果有意为之，与 bug 并没有什么关系。国外电台 Relay.fm 联合创始人 Myke Hurley 则称，他已经通过内部人士了解到 Apple Pencil 的功能遭到削弱是苹果特意去设计的。</p><p>苹果推出 iPad Pro 之初，为了加强它是一款生产力工具的定位，所以特意带来了 Apple Pencil 手写笔。苹果对 iPad Pro 和 Apple Pencil 进行了优化，所以很多人都对这个组合的表现感到非常惊讶。每一个笔画都仿佛是由 Apple Pencil 笔尖流淌出的墨水一样连贯流畅，压感和倾角感应使得下笔的轻重缓急都能纤毫毕现地展现在屏幕之上，也难怪苹果公司对 Apple Pencil 的功能稍微做个调整都会在用户中引起这样的关注度。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/tech/rdzx/4302561_1.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='4acee52e6a35dcb695e841ca22f730cb'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>放心吧</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%94%BE%E5%BF%83%E5%90%A7&amp;pn=1&amp;pos=3&amp;m=4610cf9a3667a9db4089175b583c0bb9250b56ea&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Ftech%2Frdzx%2F4302561_1.html" data-pos="1"> <b>放心吧</b>! Apple Pencil 被移除的功能会回来 </a>   <li> <a href="/transcode?q=%E6%94%BE%E5%BF%83%E5%90%A7&amp;pn=1&amp;pos=4&amp;m=55febb269fdf3b12884358abac7de2836605d279&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fkuaixun_0310%2F4643251.html" data-pos="2"> 【好警嫂故事】芮小珍:"家里有我你<b>放心吧</b>" </a>   <li> <a href="/transcode?q=%E6%94%BE%E5%BF%83%E5%90%A7&amp;pn=1&amp;pos=5&amp;m=03660691737a1314f7a88a1b3840569d2c59b93c&amp;u=http%3A%2F%2Fsports.qq.com%2Fa%2F20160305%2F027305.htm" data-pos="3"> 泰达新老总:德拉甘是好教练 成绩?请<b>放心吧</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '放心吧! Apple Pencil 被移除的功能会回来' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '放心吧! Apple Pencil 被移除的功能会回来'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";