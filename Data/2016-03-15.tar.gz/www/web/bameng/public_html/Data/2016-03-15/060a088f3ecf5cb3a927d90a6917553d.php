s:20861:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>女人经期吃这物竟能延寿 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">女人经期吃这物竟能延寿 </h1> <p id="source-and-time"><span id=source>光明网</span><time id=time>2016-03-08 04:56:00</time></p> </header>  <div id="news-body"><p>一般来说，正常女性的生理期时间为3-7天，会有很多女性每次经期不超过3天的情况，若女性经期较短大多是内分泌失调，雌激素分泌过少所导致的。雌激素分泌过少，你可能正在一步步地走向衰老。</p><p>你们知道雌激素对于女生的重要性吗?雌激素还能促使皮下脂肪堆积，体态丰满，骨中钙的沉积等。还可以使女人的皮肤看上去柔嫩细腻。女性雌激素分泌过少，体内循环速度变慢，皮肤失去以往的光泽和弹性，长此以往，易出现衰老症状。</p><p class="header">女性经期太短竟是衰老标志</p><p>女性可以通过食疗来补充雌激素，增加月经量，预防早衰。</p><p class="header">1、多吃两豆</p><p><a href="http://m.so.com/s?q=%E9%BB%84%E8%B1%86&amp;src=newstranscode" class="qkw">黄豆</a></p><p><img src="http://p31.qhimg.com/t01b30c90503b177f12.jpg?size=400x294"></p><p>可帮助改善体内激素的分泌，有研究数据显示，黄豆和豆制品能够帮助平衡体内雌激素。因为黄豆富含大豆异黄酮，性质与雌激素相似。可调节雌激素代谢和平衡的维生素B6，建议女性每天早餐喝一杯<a href="http://m.so.com/s?q=%E8%B1%86%E6%B5%86&amp;src=newstranscode" class="qkw">豆浆</a>或午餐吃一份含豆腐的菜。</p><p><a href="http://m.so.com/s?q=%E9%BB%91%E8%B1%86&amp;src=newstranscode" class="qkw">黑豆</a></p><p>相比其它含植物雌激素的豆类，黑豆无疑含量是最高的。长期坚持使用黑豆打豆浆喝，是非常安全的补充植物性雌激素，对子宫和卵巢保养有很好的疗效。</p><p>2、多吃<a href="http://m.so.com/s?q=%E5%8D%97%E7%93%9C&amp;src=newstranscode" class="qkw">南瓜</a></p><p>南瓜富含维生素E，其作用于脑下垂体和卵巢，有控制雌激素分泌的功效。另外，维E能有效清除人体活性氧，有助皮肤健康和预防高血压等生活习惯病。</p><p class="header">3、当归泡水喝</p><p>女性发现自己身体内的雌激素明显减少时，有一个小方法可以帮助快速恢复:从药店买来一些<a href="http://m.so.com/s?q=%E5%BD%93%E5%BD%92&amp;src=newstranscode" class="qkw">当归</a>，每天放10克左右泡水喝，当成每天必喝的茶，循序渐进，也可自然地补充渐渐减少的雌激素，不到一个月就可看到明显效果了。</p><p>4、多吃<a href="http://m.so.com/s?q=%E8%83%A1%E8%90%9D%E5%8D%9C&amp;src=newstranscode" class="qkw">胡萝卜</a></p><p>每周平均吃5次胡萝卜的女性，患卵巢癌的可能性比普通女性降低50%，而美国的专家也得出了类似的结论。卵巢保养吃胡萝卜，不仅对卵巢有帮助，而且可以为女性摄入维生素，更有明目的作用。</p><p>食物应该以营养丰富、易消化为主，并且多吃新鲜的水果蔬菜，这样才能让营养得到充分的保障。</p><p><a href="http://m.so.com/s?q=%E9%A6%99%E8%95%89&amp;src=newstranscode" class="qkw">香蕉</a>中含有维生素B6，大姨妈来的期间，可以多吃香蕉，客气起到安定神经的作用，对于那些情绪不稳定的女性，很有用处。</p><p>受到大姨妈的影响，女性在月经期间会显得很郁郁寡欢，这主要是受到了内分泌的影响，所以，可以多吃一些鱼类来缓解这些病情。</p><p>温补的食品也是大姨妈期间不可少的东西，羊肉、<a href="http://m.so.com/s?q=%E9%B8%A1%E8%82%89&amp;src=newstranscode" class="qkw">鸡肉</a>、红枣、牛奶、<a href="http://m.so.com/s?q=%E7%BA%A2%E7%B3%96&amp;src=newstranscode" class="qkw">红糖</a>等，在大姨妈期间都可以适当的吃一些。</p><p>女性在大姨妈期间会丢失很多的铁元素，所以，可以多补充一点铁元素，比如说吃大豆、<a href="http://m.so.com/s?q=%E8%8F%A0%E8%8F%9C&amp;src=newstranscode" class="qkw">菠菜</a>、鱼、瘦肉等，荤素搭配才是最好的哦。</p><p><img src="http://p34.qhimg.com/t014ba190a668939d61.jpg?size=400x400"></p><p><a href="http://m.so.com/s?q=%E7%97%9B%E7%BB%8F&amp;src=newstranscode" class="qkw">痛经</a>是很多女性都很苦恼的问题，这时可以喝加蜂蜜的热牛奶，不仅可以痛经减少一点，还能稳定那不安分的心情，女性可以在睡之前试一试这个方法，也许会给你带来一个美好的夜晚。</p><p class="header">月经期排污血食谱大全</p><p class="header">1、红豆紫米粥</p><p>花生、紫米、红豆提前浸泡半天。将<a href="http://m.so.com/s?q=%E5%B1%B1%E8%8D%AF&amp;src=newstranscode" class="qkw">山药</a>削皮，切块。然后烧开一锅水将所有的材料都放进去，搅拌一下，再转小火慢慢煮。等豆子和山药都煮了就差不多了。期间差不多要40来分钟。在经期喝的话，可以加点红糖，这样有利于补血。</p><p class="header">2、玫瑰花茶</p><p>荷叶、何首乌各1、5钱，黄耆、玫瑰花、桑叶各1钱，炒决明子、茯苓、<a href="http://m.so.com/s?q=%E6%9E%B8%E6%9D%9E&amp;src=newstranscode" class="qkw">枸杞</a>各3钱，麦冬5钱。将上述的材料用开水冲泡即可饮用，有疏肝理气、降脂瘦身之功效。</p><p class="header">3、山楂桂枝红糖饮</p><p>山楂15克，桂枝10克，红糖30-50克。山楂肉、桂枝加水同煮，后加入红糖调匀，煮沸饮用。温经通脉、化淤止痛，适用于妇女寒性痛经证。</p><p>4、黑木耳<a href="http://m.so.com/s?q=%E7%BA%A2%E6%9E%A3&amp;src=newstranscode" class="qkw">红枣</a>饮</p><p>黑木耳30克，红枣20枚。将<a href="http://m.so.com/s?q=%E9%BB%91%E6%9C%A8%E8%80%B3&amp;src=newstranscode" class="qkw">黑木耳</a>、红枣洗净。红枣去核，二味加水煮沸，去渣服用。补中益气，养血止血，美肤益颜功效。适用于月经过多，贫血及身体虚弱者。</p><p class="header">5、韭汁红糖饮</p><p><a href="http://m.so.com/s?q=%E9%B2%9C%E9%9F%AD%E8%8F%9C&amp;src=newstranscode" class="qkw">鲜韭菜</a>300克，红糖100克。将鲜韭菜洗净，沥干水分，切碎后捣烂取汁备用。红糖放入铝锅内，加清水少许煮沸，至红糖融化后兑入韭菜汁，即可饮用。温经补气。适用于气血两虚型之痛经，并可使皮肤红润光洁。</p><p>6、当归<a href="http://m.so.com/s?q=%E7%94%9F%E5%A7%9C%E7%BA%A2%E6%9E%A3%E8%8C%B6&amp;src=newstranscode" class="qkw">生姜红枣茶</a></p><p>姜、当归、红枣、枸杞、红糖。当归、红枣用水洗干净后，浸泡十五分钟，然后连水一起倒入锅中，生姜洗净可去皮可不去，切片加入锅中。大火烧开后，转中火煮约二十分钟，加入适合自己甜度的红糖。糖融化后加入<a href="http://m.so.com/s?q=%E6%9E%B8%E6%9D%9E%E5%AD%90&amp;src=newstranscode" class="qkw">枸杞子</a>，稍煮两分钟即可出锅饮用，有补血活血，调经止痛，润肠通便的作用。</p><p class="header">7、姜枣红糖水</p><p><a href="http://m.so.com/s?q=%E5%B9%B2%E5%A7%9C&amp;src=newstranscode" class="qkw">干姜</a>10克，大枣、红糖各30克。将前两味洗净，干姜切片，<a href="http://m.so.com/s?q=%E5%A4%A7%E6%9E%A3&amp;src=newstranscode" class="qkw">大枣</a>去核，加红糖煎水。喝汤，吃大枣。温经散寒、缓急止痛，适用于寒性痛经兼呕吐者。</p><p class="header">月经期饮食的宜与忌</p><p class="header">忌生冷，宜温热</p><p>祖国医学认为，血得热则行，得寒则滞。月经期如食生冷，一则伤脾胃碍消化，二则易损伤人体阳气，易生内寒，寒气凝滞，可使血运行不畅，造成经血过少，甚至痛经。</p><p>即使在酷暑盛夏季节，月经期也不宜吃冰淇淋及其它冷饮。饮食以温热为宜有利于血运畅通。在冬季还可以适当吃些具有温补作用的食物，如牛肉、鸡肉、桂圆、枸杞子等。</p><p><img src="http://p33.qhimg.com/t0121073ae5bf694b08.jpg?size=400x400"></p><p class="img-title">忌酸辣，宜清淡</p><p>月经期常可使人感到非常疲劳，消化功能减弱，食欲欠佳。</p><p>为保持营养的需要，饮食应以新鲜为宜。新鲜食物不仅味道鲜美，易于吸收，而且营养破坏较少，污染也小。</p><p>月经期的饮食在食物制作上应以清淡易消化为主，少吃或不吃油炸、酸辣等刺激性食物，以免影响消化和辛辣刺激引起经血量过多。</p><p class="header">荤素搭配，防止缺铁</p><p>妇女月经期一般每次失血约为30~50毫升，每毫升含铁0.5毫克，也就是说每次月经要损失铁15~50毫克。</p><p>铁是人体必需的元素之一，它不仅参与血经蛋白及多种重要酶的合成，而且对免疫、智力、衰老、能量代谢等方面都发挥重要作用。因此，月经期进补含铁丰富和有利于消化吸收的食物是十分必要的。</p><p>多吃鱼类和各种动物肝、血、瘦肉、蛋黄等食物</p><p>鱼类和各种动物肝、血、瘦肉、蛋黄等食物含铁丰富。生物活性高，容易被人体吸收利用。而大豆、菠菜中富含的植物中的铁，则不易被肠胃吸收。</p><p>所以，制定食谱时最好是荤素塔配，适当多吃些动物类食品，特别是动物血，不仅含铁丰富，而且还富含优质蛋白质。是价廉物美的月经期保健食品。</p><p>可选择食用，满足妇女月经期对铁的特殊需要。总之，月经期仍应遵循平衡膳食的原则，并结合月经期特殊生理需要，供给合理膳食，注意饮食。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://yangsheng.gmw.cn/2016-03/08/content_19194960.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='8cdffcceef3f9f0dae6488fba1b6a505'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>鲜韭菜</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%B2%9C%E9%9F%AD%E8%8F%9C&amp;pn=1&amp;pos=10&amp;m=a06f44a3dfad44668162be0d509bb627a6e02200&amp;u=http%3A%2F%2Fyangsheng.gmw.cn%2F2016-03%2F07%2Fcontent_19200810.htm" data-pos="1"> 经期吃什么好 经期吃它补血有奇效 </a>   <li> <a href="/transcode?q=%E9%B2%9C%E9%9F%AD%E8%8F%9C&amp;pn=2&amp;pos=1&amp;m=85f8d7f19f61f2058cf197d45b30cba0b6cbecd3&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2FTravel%2Fhood%2Fmsrt%2F4574613_1.html" data-pos="2"> 饮食养生:<b>韭菜</b>+喝粥就能帮你饮食补肾 </a>   <li> <a href="/transcode?q=%E9%B2%9C%E9%9F%AD%E8%8F%9C&amp;pn=2&amp;pos=2&amp;m=cdd83abeeda2590e93daa288dfe0cf364e2b9361&amp;u=http%3A%2F%2Fnews.ifeng.com%2Fa%2F20160310%2F47774242_0.shtml" data-pos="3"> 小碗配面码儿 讲究不将就 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '女人经期吃这物竟能延寿 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '女人经期吃这物竟能延寿 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";