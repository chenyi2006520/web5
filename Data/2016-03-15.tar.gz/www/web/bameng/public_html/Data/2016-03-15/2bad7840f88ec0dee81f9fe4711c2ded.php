s:16540:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>电影《泡沫之夏》启动 梁咏琪首任制片人(组图) - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">电影《泡沫之夏》启动 梁咏琪首任制片人(组图) </h1> <p id="source-and-time"><span id=source>国际在线</span><time id=time>2015-08-13 10:56:42</time></p> </header>  <div id="news-body"><p><img src="http://p34.qhimg.com/t01029530db9e888184.jpg?size=700x306"></p><p class="img-title">主创团队成员合影</p><p>近日，由星皓影业投资制作的电影<a href="http://m.so.com/s?q=%E3%80%8A%E6%B3%A1%E6%B2%AB%E4%B9%8B%E5%A4%8F%E3%80%8B&amp;src=newstranscode" class="qkw">《泡沫之夏》</a>公布了主创班底。在这份汇聚了两岸三地超强<a href="http://m.so.com/s?q=%E7%94%B5%E5%BD%B1%E5%88%B6%E4%BD%9C%E4%BA%BA&amp;src=newstranscode" class="qkw">电影制作人</a>班底的名单上，最引入注目的莫过于由<a href="http://m.so.com/s?q=%E6%A2%81%E5%92%8F%E7%90%AA&amp;src=newstranscode" class="qkw">梁咏琪</a>担纲制片人。自结婚生子之后梁咏琪已暌违大银幕近三年之久，而《泡沫之夏》将是她首次转型成为幕后制片人的处女作。此外，曾获金马奖终身成就奖的台湾第一监制<a href="http://m.so.com/s?q=%E9%BB%84%E5%BF%97%E6%98%8E&amp;src=newstranscode" class="qkw">黄志明</a>与有台湾“鬼才编剧第一人”之称的<a href="http://m.so.com/s?q=%E8%8B%8F%E7%85%A7%E5%BD%AC&amp;src=newstranscode" class="qkw">苏照彬</a>都将担任该片监制。据悉，该片将于本月14日在台湾正式开机。</p><p><img src="http://p33.qhimg.com/t01aa62373f265516e5.jpg?size=700x467"></p><p class="img-title">梁咏琪校园气十足</p><p>梁咏琪跨界转型制片人 <a href="http://m.so.com/s?q=%E6%A0%A1%E5%9B%AD%E5%A5%B3%E7%A5%9E&amp;src=newstranscode" class="qkw">校园女神</a>回归</p><p>梁咏琪自出道以来便以青春玉女的形象而深受广大观众们的热爱与期待。首部作品<a href="http://m.so.com/s?q=%E3%80%8A%E7%83%88%E7%81%AB%E6%88%98%E8%BD%A6%E3%80%8B&amp;src=newstranscode" class="qkw">《烈火战车》</a>便揽获香港电影金像奖“最佳新人奖”，而《心动》的热映更是让她与金城武成为一代人心中的最佳银幕CP。昔日的偶像在事业的巅峰期选择了安心经营家庭，也令无数影迷歌迷为之扼腕。然而，与时下明星选择真人秀为复出战场的惯用方式不同，刚刚晋身为辣妈的梁咏琪重回娱乐圈视线的方式却是投身电影幕后。而身为观众心目中的校园女神，她选择了最为熟悉的青春题材作为她的试水之作，既迎合了时下大热的电影题材，又定位明晰，选片功力不容小觑。</p><p><img src="http://p31.qhimg.com/t0149b362acc03506cf.jpg?size=700x467"></p><p><a href="http://m.so.com/s?q=%E9%93%81%E4%B8%89%E8%A7%92&amp;src=newstranscode" class="qkw">铁三角</a>齐聚</p><p class="header">铁三角再聚首 打造青春爱情童话</p><p>曾获金马奖终身成就奖的台湾第一监制黄志明与有着台湾“<a href="http://m.so.com/s?q=%E9%AC%BC%E6%89%8D%E7%BC%96%E5%89%A7%E7%AC%AC%E4%B8%80%E4%BA%BA&amp;src=newstranscode" class="qkw">鬼才编剧第一人</a>”之称的苏照彬将再度联手担任为《泡沫之夏》保驾护航。作为台湾中生代最具代表性的电影人，黄志明拥有丰富的制片经验和资源整合力。无论是<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%8D%E8%83%BD%E8%AF%B4%E7%9A%84%E7%A7%98%E5%AF%86%E3%80%8B&amp;src=newstranscode" class="qkw">《不能说的秘密》</a>还是《左耳》，都不仅完美诠释了一代观众中对青春的解读，也让参演的艺人们从素人、歌手等角色成功转型为优质新生代演员。因此，《泡沫之夏》也极有潜力成为他的“青春三部曲”系列的扛鼎之作，获得票房与口碑的双丰收。而此次他与老搭档苏照彬的再次合作也或将因梁咏琪的新鲜加盟而催生出不一样的化学效应。然而毋庸置疑的是，这铁三角组合一祭出，《泡沫之夏》的成片质量自然不会令观众失望。</p><p><img src="http://p32.qhimg.com/t017e70e01ecc490afa.jpg?size=700x467"></p><p class="img-title">黄志明开怀一笑</p><p>泡沫之夏<a href="http://m.so.com/s?q=%E5%8D%81%E5%B9%B4%E4%B9%8B%E7%BA%A6&amp;src=newstranscode" class="qkw">十年之约</a> 青春片IP之王经典再现</p><p>近年来，IP电影渐渐成为电影市场最热门的话题。在这方面，《泡沫之夏》原著拥有的读者已经有近三千万之多，可以称得上是IP之王。早在2010年，由<a href="http://m.so.com/s?q=%E5%A4%A7S&amp;src=newstranscode" class="qkw">大S</a>、何润东与黄晓明主演的电视剧版本便在两岸三地都掀起了收视热潮。不仅如此，自《泡沫之夏》原著问世以来，已经有十年之久，是80后整整一代女生的集体回忆，被称作“女生世界的神作”。而原著作者<a href="http://m.so.com/s?q=%E6%98%8E%E6%99%93%E6%BA%AA&amp;src=newstranscode" class="qkw">明晓溪</a>也曾表示“每个故事都是我心爱的，但是如果一定要说一个最爱，那么《泡沫之夏》是我最用心的。”据悉，电影暂定明年暑期档上映，恰逢小说问世十周年，相信届时一定能为读者们忠实还原藏在她们青春记忆里的《泡沫之夏》。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://gb.cri.cn/27224/2015/08/13/8351s5065433.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='84c2dba45d5428827a836d08e5343a2c'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>鬼才编剧第一人</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%AC%BC%E6%89%8D%E7%BC%96%E5%89%A7%E7%AC%AC%E4%B8%80%E4%BA%BA&amp;pn=1&amp;pos=2&amp;m=a952cceca54313da28a01ad30586fc4662526331&amp;u=http%3A%2F%2Ftoutiao.com%2Fi6259708426037756417%2F" data-pos="1"> 2016年卫视竞争加剧,我们不得错过的六大IP </a>   <li> <a href="/transcode?q=%E9%AC%BC%E6%89%8D%E7%BC%96%E5%89%A7%E7%AC%AC%E4%B8%80%E4%BA%BA&amp;pn=1&amp;pos=3&amp;m=d7720e99a377b85198b2e7301e0da3ac37bae12d&amp;u=http%3A%2F%2Fent.ifeng.com%2Fa%2F20150813%2F42473311_0.shtml" data-pos="2"> 电影《泡沫之夏》梁咏琪首任制片人 铁三角打造IP之王 </a>   <li> <a href="/transcode?q=%E9%AC%BC%E6%89%8D%E7%BC%96%E5%89%A7%E7%AC%AC%E4%B8%80%E4%BA%BA&amp;pn=1&amp;pos=4&amp;m=0a39fdcfd5d512d4e271299ca594b36d2473af2d&amp;u=http%3A%2F%2Ffun.youth.cn%2F2015%2F0921%2F2152355.shtml" data-pos="3"> 《泡沫之夏》制造童话爱情 梁咏琪帮女生圆梦 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '电影《泡沫之夏》启动 梁咏琪首任制片人(组图) ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '电影《泡沫之夏》启动 梁咏琪首任制片人(组图) '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";