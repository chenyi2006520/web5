s:19181:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>东部战区某团四级军士长邵思国:巧带刺头兵- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">东部战区某团四级军士长邵思国:巧带刺头兵</h1> <p id="source-and-time"><span id=source>中国军视网</span><time id=time>2016-03-14 19:49:34</time></p> </header>  <div id="news-body"><p>邵思国，东部战区某团四级<a href="http://m.so.com/s?q=%E5%86%9B%E5%A3%AB%E9%95%BF&amp;src=newstranscode" class="qkw">军士长</a>，从军十六载，曾获“十佳士官”“爱军精武标兵”“优秀共产党员”等荣誉称号，荣立个人三等功2次，所在班荣立集体三等功1次。在团队，他像一首奋进的歌，保持冲锋姿态十六年，见证了两代装备革新的起起落落。</p><p>3月初，八闽江畔，一艘艘冲锋舟正在湍急的水流中疾驰。沿岸，两排某式<a href="http://m.so.com/s?q=%E8%88%9F%E8%BD%A6&amp;src=newstranscode" class="qkw">舟车</a>已列队完毕，伴随着发动机传出的轰鸣声，就待一声令下。</p><p>“快测河幅，上游水坝1小时后放水，不想加舟加时就抓紧架设!”合同舟下水溅起的浪花近五米高，透过漫天的<a href="http://m.so.com/s?q=%E6%B0%B4%E5%B9%95&amp;src=newstranscode" class="qkw">水幕</a>，笔者在摇晃的冲锋舟上稳了稳身子，争取从嘹亮的口号声中辨认出老邵来:一位表情严肃，个子不高，虽消瘦但精干的四级军士长。</p><p class="header">这就是邵思国。</p><p><img src="http://p35.qhimg.com/t01be99fcfbd3ee681a.jpg?size=750x496"></p><p class="img-title">邵思国正在瞄准靶台，据枪射击。</p><p class="header">传血性:言传身教的带兵经</p><p>2001年底，邵思国参军入伍来到某舟桥团，那时专业训练一块桥板40斤，他个子矮、素质差、底子薄，人工植桩、绳索链接、抱板训练等科目考核样样都垫底。“舟桥上面全是铁，磕磕碰碰都是血”，老式舟桥架桥作业非常注重协同，当时多数同年兵都不愿意跟他同组，怕被拖后腿。</p><p>下连没多久，一身都是伤，还没少挨批，从农村出来的邵思国有股倔劲儿，咬咬牙跟自己较起了劲。他瞒着班长，凌晨五点就起床，全副武装五公里，加练也成了家常便饭，没几天他就累得洗澡都脱不了衣服。班长看他这样，打心眼里喜欢上了这山东小伙。</p><p>专业、指挥、体能，在班长时不时为他“开小灶”的特殊照顾下，邵思国手上逐渐练出了厚厚一层老茧，身板硬了，名气也大了起来。第二年，在集团军组织的预提指挥士官集训中，邵思国凭借自身的过硬素质，从382名参训学员中脱颖而出，荣获“优秀学员”称号。同年，在该团全能尖子比武夺魁后，邵思国成了营里唯一的义务兵班长。</p><p>邵思国带兵十六年，干过炊事班长，代理过排长，班里先后出了2名<a href="http://m.so.com/s?q=%E5%86%9B%E6%A0%A1%E7%94%9F&amp;src=newstranscode" class="qkw">军校生</a>、30余名舟桥专业骨干、50余名军事特级尖子……近日荣立三等功的一班长汪猛，就是邵思国带的兵，笔者曾找他聊起邵班长，汪猛脸上满是敬佩之情。</p><p>汪猛是体校生入伍，素质强，谁都敢比，是个标准“刺头兵”。这样的兵没人想带，邵思国偏不信邪。那时，集团军对团队进行“一级团达标”考核，代理二排排长的邵思国在第一个科目就被铁器扎穿了脚。“我走了，排里的兄弟怎么办?”邵思国简单包扎了下，哪怕考官再三劝阻，依然要求坚持参加考核。</p><p>成绩出来了，军直属团排名第一，建制团排名第三。爆破、体能、门桥指挥，一连八项科目，考了五小时，当汪猛亲自为邵思国脱下战靴时，湿漉漉的战靴血水直往下淌，可他依然在坚持。扶邵班长去卫生室的路上，他那即使疼到冷汗直流依然一脸刚毅的神情，让汪猛至今难忘。</p><p class="header">砺战忙:一波三折的休假难</p><p>前几年装备体制调整，作为整整研究了十四年主战某式舟桥的邵思国来说，推翻几代老前辈积累的经验一切从零开始，是件难以想象的事。5月份新装备列装完毕，9月份就要形成战斗力，谁也不敢保证一定能够完成任务。</p><p>团队要求组建示范教学小组后，作为单位最精通老式舟桥装备的“那批人”，团长点名让邵思国带队。</p><p>接到任务后，一门心思扑在新装备上的邵思国怎么也没想得到，才过一个星期，妻子<a href="http://m.so.com/s?q=%E9%82%B5%E5%AE%B9&amp;src=newstranscode" class="qkw">邵容</a>便打来电话哭诉，刚满一岁半的儿子左臂被开水<a href="http://m.so.com/s?q=%E7%83%AB%E4%BC%A4&amp;src=newstranscode" class="qkw">烫伤</a>，覆盖面达80%，医生建议立即做<a href="http://m.so.com/s?q=%E6%A4%8D%E7%9A%AE%E6%89%8B%E6%9C%AF&amp;src=newstranscode" class="qkw">植皮手术</a>。妻子的电话让邵思国满心焦虑，父亲患有“三高”，母亲体弱多病，柔弱的妻子该怎么担起这个家?</p><p>当他找到指导员，看着指导员一脸憔悴的神情，邵思国怎么也开不了口。最后，在得知实情后，连队立即委托一名同乡休假的战友帮助照看邵思国家属，他带着对家人的歉意，转头咬牙又扎进了攻研工作。</p><p>白天码头实物摸索，晚上对照资料开会研究撰写经验心得，小到器材零部件，大到器材整体的钢索位置、阀门要领，单个门桥的800余个零部件逐个记录在了邵思国的笔记本里。</p><p>三个月，新装备战技术性能、作业流程、新战法逐步研发到位，邵思国这才长舒了一口气。正当他准备休假回家与家人团聚时，新装备又有了新问题:如何保养?</p><p>以往，老式重型舟桥保养都是用吊车配合将舟车分离，方便官兵在陆上进行保养作业。可新装备是组合模块，单一门桥都是在水面上分解开来，陆地该怎么展开。得知休假又要延后时，邵思国心怀愧疚地给妻子打了个电话，便再次投入了研究工作。</p><p>借鉴运用以往经验，结合新型舟桥装备的构造特点，他摸索总结出“手动分解门桥岸上作业方法步骤”“新型舟桥保养标准规定”等整理成册并下发各连，从而规范操作流程，对新装备各部件保养明确标准，新装备保养工作得以展开。</p><p>一事未平事又起。10月初，闽南某水域，集团军组织作战能力评估考核，以检验团队新装备成型能力，邵思国又进入了忙碌的工作状态……</p><p><img src="http://p32.qhimg.com/t011418af989770f636.jpg?size=750x496"></p><p class="img-title">邵思国正在进行教学法试训。</p><p class="header">临改革:最后一年也在冲锋</p><p>邵思国十六年没回家过过春节了，今年连队安排让他休年假，指导员还特意将休假报告拟好交到他手中，可又被他笑着推了回来:“年终岁尾，都想回家过年，这时候走我不放心。”</p><p>他不放心的事有很多，军改正当时，大量新科目还没有形成规范，大家都在“摸着石头过河”。“一定要比战士先上岸、早上岸”是邵思国内心最真实的想法，这个入伍十六年的老兵仍在<a href="http://m.so.com/s?q=%E8%BE%B9%E5%AD%A6%E8%BE%B9%E7%94%A8&amp;src=newstranscode" class="qkw">边学边用</a>，他在以自己的实际行动引领着战士们努力的方向。</p><p>前不久，连队将邵思国多年来积攒的20余万字的学习笔记、3万多字的训练心得整理成册，并将他拟定的多套结合时代新要求的训练计划纳入连队训练准备大纲，并邀请他多次为战友讲述成长历程，用扎根军营多年的朴实经历，搞好盯紧打赢的“传帮带”。</p><p>新训初始，邵思国又忙开了，即使今年是他的最后一年，他依然保持着冲锋姿态。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.js7tv.cn/news/201603_39567.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='01f96333ab6acabba88b7d741fe9614d'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>军士长</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%86%9B%E5%A3%AB%E9%95%BF&amp;pn=1&amp;pos=5&amp;m=9659ee2581562bfe876cd9761e40e73750db5ac2&amp;u=http%3A%2F%2Fwww.js7tv.cn%2Fnews%2F201603_39567.html" data-pos="1"> 东部战区某团四级<b>军士长</b>邵思国:巧带刺头兵 </a>   <li> <a href="/transcode?q=%E5%86%9B%E5%A3%AB%E9%95%BF&amp;pn=1&amp;pos=6&amp;m=b64c6461f8f501ca9c7a98dc4097bac9dc0361cb&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Fmil%2F2015-11%2F04%2Fc_128385495.htm" data-pos="2"> 北京军区兵种训练基地三级<b>军士长</b>郭峰故事集 </a>   <li> <a href="/transcode?q=%E5%86%9B%E5%A3%AB%E9%95%BF&amp;pn=1&amp;pos=7&amp;m=d8f04ec87ce67e1deeae63f72dcfa332ee1fbcd1&amp;u=http%3A%2F%2Fwww.nxing.cn%2Fwap%2Farticle%2F4049516.html" data-pos="3"> 营长和四级<b>军士长</b>的故事:为了心中共同的弹道 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '东部战区某团四级军士长邵思国:巧带刺头兵' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '东部战区某团四级军士长邵思国:巧带刺头兵'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";