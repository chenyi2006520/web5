s:16538:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>郑洁再进澳网女双八强 昔日搭档晏紫发短信祝贺- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">郑洁再进澳网女双八强 昔日搭档晏紫发短信祝贺</h1> <p id="source-and-time"><span id=source>凤凰网</span><time id=time>2015-01-28 01:52:00</time></p> </header>  <div id="news-body"><p class="header">金花女双进四强九年前澳网夺冠</p><p>昨天是澳网第9个比赛日，除了31岁的<a href="http://m.so.com/s?q=%E9%83%91%E6%B4%81&amp;src=newstranscode" class="qkw">郑洁</a>之外，所有出战的中国大陆球员已经全部被淘汰出局。像10年前一样，川妹子继续扛起了中国网球的大旗——她和<a href="http://m.so.com/s?q=%E8%A9%B9%E5%92%8F%E7%84%B6&amp;src=newstranscode" class="qkw">詹咏然</a>的“新海峡组合”以2比0横扫<a href="http://m.so.com/s?q=%E7%AE%80%E6%A3%AE&amp;src=newstranscode" class="qkw">简森</a>/克雷帕克，晋级女双四强。</p><p class="header">直落两盘横扫黑马</p><p>本届澳网郑洁单双打两线作战，虽然单打首轮出局，但<a href="http://m.so.com/s?q=%E5%8F%8C%E6%89%93&amp;src=newstranscode" class="qkw">双打</a>她却发挥出色。在和詹咏然搭档的前三场比赛中，她们都是两盘击败对手过关。昨天，“<a href="http://m.so.com/s?q=%E6%B5%B7%E5%B3%A1%E7%BB%84%E5%90%88&amp;src=newstranscode" class="qkw">海峡组合</a>”迎来了赛会黑马简森/<a href="http://m.so.com/s?q=%E5%85%8B%E9%9B%B7&amp;src=newstranscode" class="qkw">克雷</a>帕克。</p><p>首盘比赛，郑洁和詹咏然顺利<a href="http://m.so.com/s?q=%E4%BF%9D%E5%8F%91&amp;src=newstranscode" class="qkw">保发</a>，并且在对手的发球局取得破发。尽管在第三局她们遭到了回破，可在第四局她们又将优势掌握在自己手中。很快，14号种子就以6比1先下一城。第二盘比赛一开场，双方继续展开破发大战。“海峡组合”凭借着多一个破发球局的优势，确定了3比1的局分领先。此后她们将比分进一步扩大，以5比2进入到<a href="http://m.so.com/s?q=%E5%8F%91%E7%90%83&amp;src=newstranscode" class="qkw">发球</a>胜赛局。最终，她们以6比2胜出，晋级本届澳网女双四强。</p><p>半决赛中，郑洁和詹咏然将要迎战13号种子<a href="http://m.so.com/s?q=%E5%85%8B%E6%8B%89%E5%90%89%E5%A1%9E%E5%85%8B&amp;src=newstranscode" class="qkw">克拉吉塞克</a>和斯特里科娃。按照赛程，“海峡组合”与克拉吉塞克/<a href="http://m.so.com/s?q=%E6%96%AF%E7%89%B9%E9%87%8C&amp;src=newstranscode" class="qkw">斯特里</a>科娃的这场半决赛将于周三在<a href="http://m.so.com/s?q=%E7%8E%9B%E6%A0%BC%E4%B8%BD%E7%89%B9%C2%B7%E8%80%83%E7%89%B9&amp;src=newstranscode" class="qkw">玛格丽特·考特</a>球场举行。他们的对手虽然在巡回赛中名不见经传，但都经验丰富。</p><p class="header">触景生情感慨变老</p><p>这是郑洁和詹咏然首次搭档参加<a href="http://m.so.com/s?q=%E5%A4%A7%E6%BB%A1%E8%B4%AF&amp;src=newstranscode" class="qkw">大满贯</a>比赛，半决赛绝不是她们终点。尽管在单打比赛首轮输给中华台北选手<a href="http://m.so.com/s?q=%E5%BC%A0%E5%87%AF%E8%B4%9E&amp;src=newstranscode" class="qkw">张凯贞</a>，可是川妹子还是和另外一位中华台北选手联手在双打赛场上高歌猛进。</p><p>澳网可以算作是郑洁的福地，2006年她就搭档好姐妹<a href="http://m.so.com/s?q=%E6%99%8F%E7%B4%AB&amp;src=newstranscode" class="qkw">晏紫</a>成功夺冠。那一年是郑洁和中国网球大丰收的一年，随后她和晏紫又拿下了WTA一级赛事<a href="http://m.so.com/s?q=%E6%9F%8F%E6%9E%97&amp;src=newstranscode" class="qkw">柏林</a>公开赛的冠军以及温布尔登的冠军。她还在2010年和<a href="http://m.so.com/s?q=%E6%9D%8E%E5%A8%9C&amp;src=newstranscode" class="qkw">李娜</a>一起在墨尔本公园球场闯入四强，那是首次有两名中国球员晋级大满贯赛事单打四强。</p><p>如今，再一次闯入澳网女双四强，去年11月底才做了一个手术的川妹子对自己相当满意，“我觉得在球场上没有什么可输的，多打一场球，我就多一次享受这个过程。虽然这个世界没有如果，但有时确实会想，如果我再年轻个五岁八岁，那该多好啊。”</p><p class="header">昔日搭档短信祝贺</p><p>这是郑洁职业生涯第四次在<a href="http://m.so.com/s?q=%E5%A2%A8%E5%B0%94%E6%9C%AC&amp;src=newstranscode" class="qkw">墨尔本</a>公园闯入女双半决赛，此前她全部和晏紫搭档。尽管现在老搭档已经退役生子，可后者还是关心着郑洁的成绩。在此前一轮闯入八强后，晏紫就给郑洁发了短信:“又进八强了!”后者的回复是:“享受就好。”</p><p>“还是希望能保持清醒的头脑，否则想多了对打比赛没有什么好处。”走到四强，川妹子没有太多兴奋:“清醒一点，简单一点，结果更好。毕竟这种心理上的东西还是挺微妙的，放在5年前、10年前，你要说去享受网球，即便自己真这么想，可实际上是做不到的。不过，现在随着年龄增长，经历越来越多以后，会更从容去面对。尤其是双打，享受比赛会更容易一些。”</p><p>“现在来到半决赛，任何事情都可能发生。能够打到四强，对手肯定也不是省油的灯，所以也得小心。”郑洁说道。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://sports.ifeng.com/a/20150128/43034569_0.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='c9bbcb920de40f7e51d09b5411e89605'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>晏紫</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%99%8F%E7%B4%AB&amp;pn=1&amp;pos=9&amp;m=8355d655fc6b0d30559a19014058bb6c08d57e92&amp;u=http%3A%2F%2Fsports.sohu.com%2F20150129%2Fn408190012.shtml" data-pos="1"> <b>晏紫</b>:06年踩场被当作小球员 郑洁有机会再夺冠 </a>   <li> <a href="/transcode?q=%E6%99%8F%E7%B4%AB&amp;pn=1&amp;pos=10&amp;m=c3512e516d0c59a94b2762ab5b2798ddf4312263&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0222%2F06%2F9LLUVG4N00014AED.html" data-pos="2"> <b>晏紫</b>:花园影城与咖啡馆 </a>   <li> <a href="/transcode?q=%E6%99%8F%E7%B4%AB&amp;pn=2&amp;pos=1&amp;m=6e011b6427bd2c6431657f867b9d065241a6f271&amp;u=http%3A%2F%2Fwww.china.com.cn%2Fv%2Fcul%2F2014-07%2F09%2Fcontent_32900114.htm" data-pos="3"> 2006年7月9日 郑洁、<b>晏紫</b>首摘温网女双冠军 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '郑洁再进澳网女双八强 昔日搭档晏紫发短信祝贺' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '郑洁再进澳网女双八强 昔日搭档晏紫发短信祝贺'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";