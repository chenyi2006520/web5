s:18851:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>中国汽车不缺好设计为何总出垃圾车?- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">中国汽车不缺好设计为何总出垃圾车?</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-13 19:35:46</time></p> </header>  <div id="news-body"><p>写到这个标题，其实是矛盾的。<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E6%B1%BD%E8%BD%A6&amp;src=newstranscode" class="qkw">中国汽车</a>不缺好设计嘛?缺，而且是奇缺。不然这么多车企山寨国际大牌。当看到<a href="http://m.so.com/s?q=%E9%95%BF%E5%AE%89&amp;src=newstranscode" class="qkw">长安</a>CS75版路虎、<a href="http://m.so.com/s?q=%E9%99%86%E9%A3%8E&amp;src=newstranscode" class="qkw">陆风</a>X7版极光、众泰T700版<a href="http://m.so.com/s?q=%E5%8D%A1%E5%AE%B4&amp;src=newstranscode" class="qkw">卡宴</a>、T600版途锐，甚至连名字都一样的瑞风A6版奥迪A6，以及<a href="http://m.so.com/s?q=%E6%AF%94%E4%BA%9A%E8%BF%AA&amp;src=newstranscode" class="qkw">比亚迪</a>多年来的日系风，单纯看这些靓丽的外观，简直让我们兴奋到了试衣间，可惜，这种毫无顾忌的拿来主义，结果只能让我们哭昏在厕所!</p><p><img src="http://p34.qhimg.com/t0150b2d1ac29bfb795.jpg?size=462x513"></p><p>一来山寨是条不归路，双环已经用自己的“生命”告诫各位，山寨的路上只会饮鸩止渴，越发孤独。不要告诉我等长安CS75的销量已经高的向SUV冠军H6叫板，这是山寨的胜利典型?那是因为长安还在上升的路上，只顾得上攀高，还未真正将自己定位成一个充满正能量的民族品牌;二来山寨所担负的法律风险正在加大，<a href="http://m.so.com/s?q=%E4%BF%9D%E6%97%B6%E6%8D%B7&amp;src=newstranscode" class="qkw">保时捷</a>如果忍无可忍，<a href="http://m.so.com/s?q=%E4%BC%97%E6%B3%B0&amp;src=newstranscode" class="qkw">众泰</a>定将先于尝到销量甜头就吃到法律制裁的苦头，好在众泰还过于弱小，不值得一掐。其他车企也是一样，不是大家对于山寨的容忍度足够高，而是这些车企还孱弱的不足以让被山寨<a href="http://m.so.com/s?q=%E6%96%B9%E6%8B%BF&amp;src=newstranscode" class="qkw">方拿</a>起法律武器。</p><p><img src="http://p31.qhimg.com/t018286f2c6aa9c1c5d.jpg?size=600x592"></p><p>至于国产车企为何喜欢山寨的问题，已被讨论了千万遍，大家都一致认为这是节约成本的最好捷径，但是也有一种观点认为，这正是在“看脸”时代，自主车企造出外观靓丽车型的无奈之举。为什么这么说，因为在历史上，曾经发生过在设计上无比华丽，但在模具开发和造型定型上，遭遇到了技术难题。我们的工艺水平达不到，造型设计再好，也只能无奈束之高阁。<a href="http://m.so.com/s?q=%E4%B8%80%E4%BB%A3%E5%A5%87%E8%91%A9&amp;src=newstranscode" class="qkw">一代奇葩</a>丑屁股的奇瑞A5就是一个很好的例子，在最初设计时，它的屁股没有这么突兀，只是随着从设计阶段向生产阶段的推进，造型不断向生产实际妥协，最后整出了量产车那种造型。</p><p><img src="http://p34.qhimg.com/t01584c565281fe1685.jpg?size=550x331"></p><p>那么，在山寨依旧流行的今天，自主车企有没有好的设计?答案也是有的。这也正形成了目前自主车企发展的两条路径方向问题，一个就是延续性的逆向开发，数量之多不再列举;第二个方向就是正向研发，在造型设计和制造工艺上同步在进行改进。</p><p><img src="http://p32.qhimg.com/t011f18e0694df6584e.jpg?size=550x280"></p><p>逆向开发的车型，自然是挑选市场热销的产品来进行，正向开发目前则主要由厂商主导，这两者均有优劣势。逆向研发除去“山寨”的弊端，在产品设计上具有严重得滞后性，尤其是目前产品节奏更新换代的进一步加快，这种弊端表现的会愈加明显;而正向研发，由于目前国内的优秀设计车型，虽然由自主车企发起，但实际的设计操作，基本都是外方代理机构在主导，也存在一个与消费者需求直接沟通的问题。</p><p>这就出现了一个比较尴尬的问题，即使我们设计出了优秀的产品，但也不一定在市场上就得以成功。曾经赢得自主车企车型设计最大奖项的<a href="http://m.so.com/s?q=%E5%A5%87%E7%91%9E&amp;src=newstranscode" class="qkw">奇瑞</a>TX，赢得日内瓦车展“2012年度最佳概念车奖”，成为首个获得此项汽车设计重量级国际大奖的中国汽车品牌;而另一款获奖无数的车型<a href="http://m.so.com/s?q=%E8%A7%82%E8%87%B4&amp;src=newstranscode" class="qkw">观致</a>，连续获得红点设计大奖--荣誉奖，德国设计委员会主办的年度汽车品牌大赛至尊奖<a href="http://m.so.com/s?q=%E6%97%A5%E5%86%85%E7%93%A6&amp;src=newstranscode" class="qkw">日内瓦</a>车展的展台设计夺得“品牌建筑奖”等等。但TX的量产化仍然不见踪影，而观致的设计理念赢得的更多是欧洲人的青睐，其最核心的亚洲市场市场表现仍然不尽人意。</p><p><img src="http://p34.qhimg.com/t011dd24ebc29ff72e7.jpg?size=501x244"></p><p class="img-title">2012年度最佳概念车奖得主TX</p><p>所以，我们不缺好的设计，也不缺好的<a href="http://m.so.com/s?q=%E6%A8%A1%E4%BB%BF%E9%AB%98%E6%89%8B&amp;src=newstranscode" class="qkw">模仿高手</a>，我们缺的是消费者真正喜欢的产品。最近，一大批互联网汽车和新能源汽车理念雨后春笋般兴起，如<a href="http://m.so.com/s?q=%E4%B9%90%E8%A7%86&amp;src=newstranscode" class="qkw">乐视</a>造车、游侠汽车、百度、<a href="http://m.so.com/s?q=%E9%98%BF%E9%87%8C&amp;src=newstranscode" class="qkw">阿里</a>、腾讯等一干造车潮，都在寻求设计上的突破。还有近期<a href="http://m.so.com/s?q=%E9%83%91%E5%85%86%E7%91%9E&amp;src=newstranscode" class="qkw">郑兆瑞</a>所带领的凯翼汽车，也是大胆的玩起一个全新的概念，叫众包造车，提出用<a href="http://m.so.com/s?q=%E4%BA%92%E8%81%94%E7%BD%91%E6%80%9D%E7%BB%B4&amp;src=newstranscode" class="qkw">互联网思维</a>造车。听起来有点玄乎，也正因为这种颠覆，接下来的众包造车发布会甚至取名就叫“一场不靠谱的发布会”。到底有多不靠谱?看看最近流露出的车型设计草图，倒也够绚丽。</p><p><img src="http://p33.qhimg.com/t011f8af769536994ad.jpg?size=600x383"></p><p><img src="http://p34.qhimg.com/t01dc03f6a2bfcc5608.jpg?size=600x337"></p><p>从这些曝光的设计图来看，自主车企确实不缺好的设计，这车型不论是外观还是内饰，都足够现代化、国际化。问题是，这种号称通过互联网思维造出来的车型设计，如何能够概念车化，并快速转变成量产车，并赢得市场，这才是众包造车理念的胜利。</p><p>不论是哪种设计形式，自主车企都到了压力最大的时候，扎扎实实打造出消费者喜欢的产品，永远是第一位的。现在情况是，“山寨”依然有理，长城和比亚迪的销量说明一切，而正向研发正在经历转型的痛苦，<a href="http://m.so.com/s?q=%E5%90%89%E5%88%A9&amp;src=newstranscode" class="qkw">吉利</a>和奇瑞还在自我磨砺期，一大批互联网造车的颠覆者也都处在设计阶段，到底能不能下个“金蛋”出来，还都是未知数。当然，<a href="http://m.so.com/s?q=%E8%B4%BE%E8%B7%83%E4%BA%AD&amp;src=newstranscode" class="qkw">贾跃亭</a>、马云和郑兆瑞们都还年轻，可别忽悠我们!</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/wap/article/4021819.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='8fc9783e465ef9c6c58f97f4573cd97c'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>最佳展台设计</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9C%80%E4%BD%B3%E5%B1%95%E5%8F%B0%E8%AE%BE%E8%AE%A1&amp;pn=1&amp;pos=8&amp;m=989d22d1b2dea46b7f9a68a378bb8115c5a51e88&amp;u=http%3A%2F%2Fwww.pcauto.com.cn%2Fqcbj%2F635%2F6356023.html" data-pos="1"> 全解2015上海车展 Porsche<b>展台最佳</b>之最 </a>   <li> <a href="/transcode?q=%E6%9C%80%E4%BD%B3%E5%B1%95%E5%8F%B0%E8%AE%BE%E8%AE%A1&amp;pn=1&amp;pos=9&amp;m=4b71ff877dbfafb8602d3d307b6adc8b1f708395&amp;u=http%3A%2F%2Fwww.pcauto.com.cn%2Fqcbj%2F634%2F6340974.html" data-pos="2"> 哈弗荣获2015上海车展<b>最佳</b>车展<b>展台</b>创意奖 </a>   <li> <a href="/transcode?q=%E6%9C%80%E4%BD%B3%E5%B1%95%E5%8F%B0%E8%AE%BE%E8%AE%A1&amp;pn=1&amp;pos=10&amp;m=7feec07d130576a29641cadc0c43d1a8da4bde3e&amp;u=http%3A%2F%2Fnews.gmw.cn%2Fnewspaper%2F2015-11%2F04%2Fcontent_109746800.htm" data-pos="3"> 我市在省"地方旅游特色菜"大赛获佳绩 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '中国汽车不缺好设计为何总出垃圾车?' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '中国汽车不缺好设计为何总出垃圾车?'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";