s:15645:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>恒兴大厦: 5A甲级写字楼标杆 湛江商务中心新地标- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">恒兴大厦: 5A甲级写字楼标杆 湛江商务中心新地标</h1> <p id="source-and-time"><span id=source>湛江新闻网</span><time id=time>2016-03-12 11:46:00</time></p> </header>  <div id="news-body"><p><img src="http://p31.qhimg.com/t0181177dc324f0c31c.jpg?size=550x292"></p><p>由<a href="http://m.so.com/s?q=%E6%81%92%E5%85%B4&amp;src=newstranscode" class="qkw">恒兴</a>集团、荣基集团强强联合的巅峰之作--<a href="http://m.so.com/s?q=%E9%93%B6%E9%9A%86%E5%B9%BF%E5%9C%BA&amp;src=newstranscode" class="qkw">银隆广场</a>，是湛江首席5A甲级写字楼，甫上市即被投资者抢购一空。如今，这两大巨头再度携手，银隆广场的姊妹篇--恒兴大厦现已华丽绽放，再次引爆<a href="http://m.so.com/s?q=%E6%B9%9B%E6%B1%9F&amp;src=newstranscode" class="qkw">湛江</a>写字楼市场。</p><p><a href="http://m.so.com/s?q=%E5%B9%BF%E4%B8%9C%E6%81%92%E5%85%B4%E9%9B%86%E5%9B%A2%E6%9C%89%E9%99%90%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">广东恒兴集团有限公司</a>是一家主营养殖、水产品加工、房地产开发，参股金融和港口业务的大型民营企业集团，旗下拥有数十家子公司，遍布广东、广西、海南、福建等地区，是中国民营500强企业。广东荣基集团有限公司则是一间以建设管桩为基础，以房地产为龙头，建设工程、管桩生产、建材生产、物业服务、商业管理为一体的跨行业经营企业集团，公司实力雄厚，商誉响遍全国。荣基集团在湛江房地产行业深耕多年，精准把握市场需求，户型设计科学合理，深得市场肯定。</p><p>恒兴大厦座落于湛江经济技术开发区<a href="http://m.so.com/s?q=%E4%B9%90%E5%B1%B1&amp;src=newstranscode" class="qkw">乐山</a>路，贯通双城市主干道(人民大道、<a href="http://m.so.com/s?q=%E6%B5%B7%E6%BB%A8%E5%A4%A7%E9%81%93&amp;src=newstranscode" class="qkw">海滨大道</a>)，雄踞湛江CBD(<a href="http://m.so.com/s?q=%E4%B8%AD%E5%A4%AE%E5%95%86%E5%8A%A1%E5%8C%BA&amp;src=newstranscode" class="qkw">中央商务区</a>)核心，尊享霞山、<a href="http://m.so.com/s?q=%E8%B5%A4%E5%9D%8E&amp;src=newstranscode" class="qkw">赤坎</a>双区资源;东连<a href="http://m.so.com/s?q=%E6%B5%B7%E6%B9%BE%E5%A4%A7%E6%A1%A5&amp;src=newstranscode" class="qkw">海湾大桥</a>，直达蓬勃发展中的<a href="http://m.so.com/s?q=%E6%B5%B7%E4%B8%9C&amp;src=newstranscode" class="qkw">海东</a>新区，西接湖光快线、<a href="http://m.so.com/s?q=%E7%96%8F%E6%B8%AF&amp;src=newstranscode" class="qkw">疏港</a>大道，离建设中的湛江高铁枢纽-湛江西客站仅15分钟车程，快速直达<a href="http://m.so.com/s?q=%E4%B8%9C%E6%B5%B7%E5%B2%9B&amp;src=newstranscode" class="qkw">东海岛</a>宝钢基地、交通极其便捷。项目周边银行、星级酒店、政务机关林立，配套资源完备，尽享CBD无限发展前景。</p><p>该项目首层10.15米挑高商务大堂，充分彰显企业形象;2、3层层高4.6米，4-25层为办公层，3.9米标准层高，办公环境开阔舒适，共490个套间，可根据企业需求自由组合并高效利用，充分满足不同行业的个性办公需要，是新锐企业理想的办公空间。</p><p>恒兴大厦采用时尚简约的装修风格，<a href="http://m.so.com/s?q=%E6%A0%87%E5%87%86%E5%B1%82&amp;src=newstranscode" class="qkw">标准层</a>面积1900平方米，65-195㎡创意商务空间可自由组合与分割;高效能OA地板、VRV<a href="http://m.so.com/s?q=%E6%97%A5%E7%AB%8B&amp;src=newstranscode" class="qkw">日立</a>多联变频中央空调系统、智能办公系统、9部德国<a href="http://m.so.com/s?q=%E8%92%82%E6%A3%AE&amp;src=newstranscode" class="qkw">蒂森</a>高速电梯等的配备，充分满足企业立体化商务需求，全面提速工作效率。项目<a href="http://m.so.com/s?q=%E5%A4%96%E7%AB%8B%E9%9D%A2&amp;src=newstranscode" class="qkw">外立面</a>采用中空LOW-全玻璃幕墙，节能环保低耗，外观新锐时尚，并设有超大公共休闲空间，员工餐厅、商务休闲设施等完善的配套。</p><p class="header">最新动态:</p><p>现推出一口价精装修纯商务现房，7980元/㎡起，即买即用即收益。</p><p class="header">销售热线:0759-8226666</p><p>项目地址:广东湛江经济技术开发区乐山路23号</p><p>投资商:恒兴集团、荣基集团</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.gdzjdaily.com.cn/zjzt/2016/content/2016-03/12/content_2102431.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='9517e4024b1be9e3732603e1ec8e7d7d'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>新地标</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%96%B0%E5%9C%B0%E6%A0%87&amp;pn=1&amp;pos=9&amp;m=3181bbb1f05b9c0ded981a402e7bd94e776001b9&amp;u=http%3A%2F%2Fwww.ln.chinanews.com%2Fhtml%2F2016-03-14%2F1305109.html" data-pos="1"> 闯行天下人才市场 沈阳招聘会"<b>新地标</b>" </a>   <li> <a href="/transcode?q=%E6%96%B0%E5%9C%B0%E6%A0%87&amp;pn=1&amp;pos=10&amp;m=422724cf5c288de4e7cf2586259c21392f01eb99&amp;u=http%3A%2F%2Fxmwb.xinmin.cn%2Fhtml%2F2016-03%2F14%2Fcontent_1_4.htm" data-pos="2"> "云海山石"中诞生文化<b>新地标</b> </a>   <li> <a href="/transcode?q=%E6%96%B0%E5%9C%B0%E6%A0%87&amp;pn=2&amp;pos=1&amp;m=f6f1f6852ac328964cb3e44418829df9cf47e9db&amp;u=http%3A%2F%2Fwww.js.xinhuanet.com%2F2016-03%2F10%2Fc_1118285773.htm" data-pos="3"> 大戏院将成为昆山文化<b>新地标</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '恒兴大厦: 5A甲级写字楼标杆 湛江商务中心新地标' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '恒兴大厦: 5A甲级写字楼标杆 湛江商务中心新地标'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";