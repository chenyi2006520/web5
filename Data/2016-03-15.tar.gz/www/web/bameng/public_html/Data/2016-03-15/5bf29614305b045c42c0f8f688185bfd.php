s:15490:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>老邮局内体验新邮政- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">老邮局内体验新邮政</h1> <p id="source-and-time"><span id=source>中国邮政报</span><time id=time>2015-02-28 15:02:25</time></p> </header>  <div id="news-body"><p>小朋友在家长的帮助下一同填写国内小包详情单。</p><p>2月7日，四川省达州市<a href="http://m.so.com/s?q=%E9%80%9A%E5%B7%9D%E5%8C%BA&amp;src=newstranscode" class="qkw">通川区</a>邮政局火车站支局二楼营业厅比往常热闹许多，22名年龄在5~7岁的儿童在其家长的陪同下与5组邮局员工家庭一起进行“认识邮局”的体验活动。</p><p>这些5~7岁的儿童刚刚处于文化启蒙阶段，很多汉字都还不会写，到邮局能看懂什么呢，能得到什么启发呢?“我们不仅要将这次活动做成公益项目，而且要借此宣传现代邮政企业的新业务、新产品，展示现代邮政企业的新风貌。”<a href="http://m.so.com/s?q=%E8%BE%BE%E5%B7%9E%E5%B8%82&amp;src=newstranscode" class="qkw">达州市</a>分公司提出将微信打印机、动画邮票等儿童感兴趣、互动性强的产品作为宣传的重点，以此吸引他们的关注。</p><p>高端大气的邮政形象广告首先成了活动的<a href="http://m.so.com/s?q=%E5%BC%80%E5%9C%BA%E7%99%BD&amp;src=newstranscode" class="qkw">开场白</a>，然后，达州市分公司员工用通俗易懂的语言向孩子及家长介绍了邮政的主要业务，以此增加大家对邮政的认知。在包裹交寄环节，孩子们在爸爸妈妈的帮助下，一笔一划地填写了国内小包详情单，第一次寄出了一份装满友谊的邮件。尽管孩子们还有很多字不会写，或者写得歪歪扭扭，但他们写得十分认真，有的要爸爸妈妈手把手教，有的要邮局工作人员面对面指导，当终于写完时，孩子们高兴得手舞足蹈，还要爸爸妈妈拍照用作留念。</p><p>要说现场最热闹的，还属观赏邮票的环节。夹杂着花朵及油墨香气的桃花邮票异形邮折吸引了孩子们的目光，纷纷嚷着要爸爸妈妈买一套带回家。扫描二维码观看动画则是<a href="http://m.so.com/s?q=%E3%80%8A%E5%A4%A7%E9%97%B9%E5%A4%A9%E5%AE%AB%E3%80%8B&amp;src=newstranscode" class="qkw">《大闹天宫》</a>邮票设计的吸睛点，在邮政工作人员的演示下，孩子们的目光紧盯着孙悟空的一举一动，尖叫声、欢呼声此起彼伏。一个小男孩被集邮年册的人文题材所吸引，在妈妈的支持下，买下了人生第一本集邮年册。<a href="http://m.so.com/s?q=%E5%BE%AE%E4%BF%A1&amp;src=newstranscode" class="qkw">微信</a>打印机可以实现手机照片即时打印、现场交寄。有了邮局工作人员的示范，家长们很快学会了操作技巧，将手机里的生活照片以及现场活动照片打印出来。在邮政工作人员的帮助下，孩子们纷纷向亲朋好友送去了新年的美好祝福。</p><p>然后，大家来到位于西外<a href="http://m.so.com/s?q=%E9%82%AE%E6%94%BF%E8%8A%B1%E5%9B%AD&amp;src=newstranscode" class="qkw">邮政花园</a>的邮件处理中心。一位从事函件分拣工作的员工用自己的经历告诉孩子们，她从事这项工作已经20多年了，当把信件快速、准确地进行分拣处理后，确保能安全无误地送到用户手里，她觉得很满足、很有意义。朴实无华的话语、真挚动人的情愫，感动了现场每一个人，孩子们齐声向在场的所有邮政员工道了一声:“你们辛苦了!”</p><p>参观火车站投递班是此次体验活动的最后环节。孩子们一到投递班，就好奇地这瞅瞅、那看看，一个劲地问这问那，“这(邮戳)是干什么的呀?”“这(<a href="http://m.so.com/s?q=%E8%98%B8%E6%B0%B4&amp;src=newstranscode" class="qkw">蘸水</a>盒)又是做什么的呀?”整场体验活动持续了两个半小时。尽管时间短暂，孩子们还不能完全掌握邮政业务的具体处理流程，但基本知晓了一封信、一份报纸、一个邮件都需要经过好多邮局叔叔阿姨的手，才能送到他们的手里。一位从事小学教育工作的家长说:“这次活动很有意义，孩子们体验了邮件的处理流程，认知了邮政这个行业，扩大了孩子的知识面，以后希望能够继续与邮政合作，让高年级的孩子也能够来邮局体验一下。”</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.chinapostnews.com.cn/newspaper/epaper/html/2015-02/28/content_69806.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='4f9f611bd734d5cc80702f3214870971'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>老邮局</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%80%81%E9%82%AE%E5%B1%80&amp;pn=1&amp;pos=7&amp;m=23bd37516f1b2b264a00ea1ef5fd5b4960392d68&amp;u=http%3A%2F%2Fxiaofei.china.com.cn%2Fnews%2Finfo-36-9-78311.html" data-pos="1"> 离开了周转房 百年<b>老邮局</b>有新家了 </a>   <li> <a href="/transcode?q=%E8%80%81%E9%82%AE%E5%B1%80&amp;pn=1&amp;pos=8&amp;m=2b6330834abe75b76e8164109eae9c75931cdf46&amp;u=http%3A%2F%2Fjrzb.zjol.com.cn%2Fhtml%2F2014-11%2F20%2Fcontent_2888964.htm" data-pos="2"> 乌镇<b>老邮局</b> 为互联网大会 推出纪念戳 </a>   <li> <a href="/transcode?q=%E8%80%81%E9%82%AE%E5%B1%80&amp;pn=1&amp;pos=9&amp;m=792585f6882d811a727387f4f6ce8f11ee72ec3c&amp;u=http%3A%2F%2Fsjzrb.sjzdaily.com.cn%2Fhtml%2F2014-07%2F25%2Fcontent_1101591.htm" data-pos="3"> 华盛顿<b>老邮局</b>将改造成豪华酒店 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '老邮局内体验新邮政' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '老邮局内体验新邮政'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";