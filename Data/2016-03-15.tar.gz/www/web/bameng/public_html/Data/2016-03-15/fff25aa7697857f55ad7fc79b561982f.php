s:18669:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>乡镇调研:从发展性搬迁做好大城市周边城乡统筹- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">乡镇调研:从发展性搬迁做好大城市周边城乡统筹</h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2016-03-14 17:44:00</time></p> </header>  <div id="news-body"><p>人民网北京3月14日电  今年开始，中国将进入“<a href="http://m.so.com/s?q=%E5%8D%81%E4%B8%89%E4%BA%94&amp;src=newstranscode" class="qkw">十三五</a>”规划实施的五年期。 “十三五”时期经济社会发展必须补好扶贫开发这块“短板”。北京被认为是中国发展程度最高、发展速度最快的城市之一，然而其所处的京津冀辐射区域内的城乡统筹情况却与北京本身的发展形成了鲜明的反差，城市周边自然条件较差的乡镇成为了京津冀区域内的“短板”。北京<a href="http://m.so.com/s?q=%E6%88%BF%E5%B1%B1%E5%8C%BA&amp;src=newstranscode" class="qkw">房山区</a>通过对辖区内山区农村居民搬迁，使得居民的生产生活得到了有效改善，也存在些许问题，或可成为补齐“短板”的借鉴。</p><p>在以往政府开发和学界研究中，大城市周边的乡镇被认为能因征地自然而成为城市的一部分，获得城市扩展红利，因而对城市周边乡镇的统筹研究不多。而事实上，以北京<a href="http://m.so.com/s?q=%E6%88%BF%E5%B1%B1&amp;src=newstranscode" class="qkw">房山</a>山区为代表的一些乡镇，受较为不利的自然环境约束，城市难以扩展过去，居民的生活并没有受到来自附近城市高速发展的影响。另一方面房山山区生态环境相对脆弱，资源接近枯竭，又经常发生泥石流。为此，房山区政府没有选择修路到村乡，而是采取了人口搬迁工程来解决人地发展的问题。</p><p>搬迁后居民的生活质量如何?未搬迁居民如何看待搬迁工程?这两点都成为评价这项生态移民扶贫工作的标准。我们通过对房山的四个村落政府部门，及当地的12户居民进行了面对面的访谈，从政府、搬迁户多角度了解他们对这一工程的看法。</p><p class="header">一、 维护移民利益的法律问题</p><p>目前中国直接使用“生态移民”概念的法律法规有<a href="http://m.so.com/s?q=%E3%80%8A%E6%B0%B4%E5%9C%9F%E4%BF%9D%E6%8C%81%E6%B3%95%E3%80%8B&amp;src=newstranscode" class="qkw">《水土保持法》</a>、《防沙治沙法》、<a href="http://m.so.com/s?q=%E3%80%8A%E5%9C%9F%E5%9C%B0%E7%AE%A1%E7%90%86%E6%B3%95%E3%80%8B&amp;src=newstranscode" class="qkw">《土地管理法》</a>和《退耕还林条例》等，这些法律法规的主要立法目的和规范重点是在生态环境保护、地区扶贫开发等方面，而具体的补偿主体和客体、补偿标准、补偿方式、权利的救济途径等内容都没有明确规定，这使得在生态移民过程中移民利益的维护存在较大的法律空白。在对房山区89名山区移民调查后发现，71%的移民对搬迁是满意的，29%表示一般。但是我们结合各地案例分析认为，在依法治国的大背景下，亟需把移民样本中的成功经验用法律固化下来，避免各地在执行移民过程中的随意性，切实维护移民包括原有房产(含<a href="http://m.so.com/s?q=%E5%AE%85%E5%9F%BA%E5%9C%B0&amp;src=newstranscode" class="qkw">宅基地</a>)、土地(含附着物)以及发展性补偿等一系列利益。</p><p class="header">二、 实施搬迁的收支不平衡问题</p><p>移民<a href="http://m.so.com/s?q=%E5%AE%89%E7%BD%AE%E6%88%BF&amp;src=newstranscode" class="qkw">安置房</a>(及配套公建)和安置区市政道路等配套基础设施的建设，需要一大笔资金来满足。安置房的标准还应不低于安置区周边居民的平均标准才能使移民安居。此外，为安置国家建设征地农民户转为居民户的原农村劳动力中年龄超过转工安置年限(男满60周岁，女满50周岁及其以上)人员，含无人赡养的孤寡老人以及不能进入<a href="http://m.so.com/s?q=%E7%A4%BE%E4%BC%9A%E4%BF%9D%E9%99%A9&amp;src=newstranscode" class="qkw">社会保险</a>体系的病残人员，还需补齐社保资金的经费空白。而另一方面，受现行土地政策制约，迁移人员腾退出宅基地、耕地、山场、林地等资源性资产受土地政策制约，无法按照资产市场化模式运作，开发空间小，收益低，难以平衡山区人口资金缺口。调研中，78名未搬迁人员里有46户存在承受不起搬迁开支的困难。对现有土地政策进行略微补充、修改，使得移民迁出地的资源性资产得到更好利用;用人<a href="http://m.so.com/s?q=%E5%9C%B0%E9%92%B1&amp;src=newstranscode" class="qkw">地钱</a>的思路统筹考虑，加大城市对迁入区域的财政转移支付力度;给具有稳定劳动力的困难家庭提供无息小额贷款助其渡过难关，这些做法都是值得探讨的</p><p class="header">三、 搬迁后的生活保障问题</p><p>通过调研我们发现，搬迁人口年龄在30-50岁居多的同时，也表现出较大的年龄跨度，而未搬迁人口中老年人的比例较大，在对公共服务的需求上，青少年的教育与老年人的养老并存。此外，搬迁人口和未搬迁人口中受教育程度在初中以下者居多，93%的移民认为 搬迁后的好处是房子条件好，“就医/上学”因素排在第二。这表明仅仅通过包含货币和住房的一次性物质补偿，是较难满足移民对于美好生活的期待的。在提供配套公建如学校、体育场、医院、养老院等硬件的同时，由于移民过去在山区居住的分散性，更应提供相关的人员、组织提供软件的服务。鉴于此前提到的资金缺口问题，棋牌室、运动场乃至养老院一类介于盈利与非盈利之间的设施，可采取PPP或者BOT模式引入社会投资者进行运作，移民在使用时可领取政府补贴。</p><p class="header">四、 搬迁后的生产发展问题</p><p>调研中发现，搬迁后居民的家庭年收入有显著提高，65%的家庭年收入达到2-6万元，平均收入3.72万元，与未搬迁居民家庭平均收入2.47万元相比提升了50.6%，形成了搬迁的正向激励。但同时，移民最大的担忧仍然是工作，未搬迁居民认为搬迁能够增加收入的人数，也远低于对住房和上学就医的期待。出现事实和意愿相背离的主要原因在上文中已经指出，就是山区居民原有的受教育程度普遍较低，而未搬迁居民比移民相对来说年龄更大、文化水平更低，不具有竞争力。在移民所从事的工作中，政府提供的岗位远超过<a href="http://m.so.com/s?q=%E4%B8%AA%E4%BD%93%E6%88%B7&amp;src=newstranscode" class="qkw">个体户</a>和依旧从事农业的总和，这表明对于大量低教育水平的搬迁移民来说，政府的主导作用不可或缺。政府可一方面直接或采取购买服务的方式为移民按照个人兴趣开展职业技能培训，以培养移民的一技之长;另一方面可适当承接来自北京城市中心区的劳动密集型产业和服务业。同时，对移民创业的可给予更多税收水电的减免政策，使<a href="http://m.so.com/s?q=%E5%85%B4%E4%B8%9A&amp;src=newstranscode" class="qkw">兴业</a>筑牢安居基础。(作者:人大附中FarFromCity社会研究小组)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://society.people.com.cn/n1/2016/0314/c1008-28198471.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='0db2a347fd1e305a2d07057c4bc389ff'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>乡镇经济</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%B9%A1%E9%95%87%E7%BB%8F%E6%B5%8E&amp;pn=1&amp;pos=3&amp;m=9297313bc5c3220519fb51a3ce8fec55be49884e&amp;u=http%3A%2F%2Fnews.hbfzb.com%2F2016%2Fjiancha_0309%2F20465.html" data-pos="1"> 武邑检方:搭建"三座桥梁" 服务<b>乡镇经济</b>发展 </a>   <li> <a href="/transcode?q=%E4%B9%A1%E9%95%87%E7%BB%8F%E6%B5%8E&amp;pn=1&amp;pos=4&amp;m=96377c031aa10eec7e6df10ea9ad1227eabb5588&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fgxnews_0314%2F4738371.html" data-pos="2"> 江州区领导到部分<b>乡镇</b>调研扶贫项目建设工作 </a>   <li> <a href="/transcode?q=%E4%B9%A1%E9%95%87%E7%BB%8F%E6%B5%8E&amp;pn=1&amp;pos=5&amp;m=e1594fec622d0755583b5b2e049eb5e3ea105175&amp;u=http%3A%2F%2Fnews.163.com%2F16%2F0314%2F08%2FBI3RDC7700014AED.html" data-pos="3"> 我区乡贤分会实现<b>乡镇</b>(街道)全覆盖 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '乡镇调研:从发展性搬迁做好大城市周边城乡统筹' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '乡镇调研:从发展性搬迁做好大城市周边城乡统筹'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";