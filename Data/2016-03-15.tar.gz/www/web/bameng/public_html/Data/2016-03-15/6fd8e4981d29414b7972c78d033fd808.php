s:15930:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>刘益谦10.84亿元再购名画 扫货旋风从A股刮到拍卖场- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">刘益谦10.84亿元再购名画 扫货旋风从A股刮到拍卖场</h1> <p id="source-and-time"><span id=source>中国经济网</span><time id=time>2015-11-11 08:13:00</time></p> </header>  <div id="news-body"><p>在广大剁手党喜迎”双11”的前一日，资本大佬<a href="http://m.so.com/s?q=%E5%88%98%E7%9B%8A%E8%B0%A6&amp;src=newstranscode" class="qkw">刘益谦</a>也在国际拍卖场上展示了中国富豪阶层“买买买”的能量。</p><p>据了解，当地时间11月9日晚，在<a href="http://m.so.com/s?q=%E7%BA%BD%E7%BA%A6&amp;src=newstranscode" class="qkw">纽约</a>佳士得“画家与缪斯晚间特拍”上，拍前最受瞩目的<a href="http://m.so.com/s?q=%E8%8E%AB%E8%BF%AA%E9%87%8C%E9%98%BF%E5%B0%BC&amp;src=newstranscode" class="qkw">莫迪里阿尼</a>作品《侧卧的裸女》最终以1.74亿美元(约合人民币10.84亿元)被中国藏家刘益谦拍得。这一成交价也令莫迪里阿尼的这件作品跻身世界第二高价艺术品。</p><p class="header">拍卖场上的“任性哥”</p><p>刘益谦在艺术品市场上纵横捭阖已久。早在2012年6月，刘益谦与夫人<a href="http://m.so.com/s?q=%E7%8E%8B%E8%96%87&amp;src=newstranscode" class="qkw">王薇</a>就曾入选美国权威杂志<a href="http://m.so.com/s?q=%E3%80%8AARTNEWS%E3%80%8B&amp;src=newstranscode" class="qkw">《ARTNEWS》</a>公布的全球200位顶级收藏家榜单，这也是中国藏家首次入选该榜单。</p><p>近年来，刘益谦更是凭借拍卖场上的豪气“扫货”之举时不时抢上一把头条。</p><p>2014年4月份，刘益谦以超2.8亿港元成交价拍下一件“明成化斗彩鸡缸杯”，这一价格刷新了彼时中国瓷器拍卖的世界记录。有意思的是，拿到这只价值连城鸡缸杯后，刘益谦直接倒了一杯茶水并一口气喝光。此举随即被传播到互联网上，引发网友热议。谈到为何要用这件文物喝茶时，刘益谦表示:“这杯子距今有600年了，当年皇帝、妃子都应该拿它来用过，我无非是想吸一口仙气。”</p><p>2014年11月份，刘益谦以3.1亿港元拍下流失海外近200年的“明朝永乐御制红閰摩敌刺绣唐卡”。刘益谦随后在微博上晒出了该藏品，并感叹:“硬从老外手上夺爱，3.1亿港币落锤，好辛苦。任性!”</p><p>2015年3月份，刘益谦以1400万美元的价格拍下600年前中国明代佛教艺术与书法集藏“大明楷书御制佛经”。据悉，这一拍卖价超过估价百倍，创下了当时中国书画作品在亚洲以外地区竞拍的最高成交纪录。</p><p>随后，刘益谦还曾以1亿1390万港元拍下南宋时期的一件花瓶，刷新南宋时期陶瓷器皿拍卖纪录，并以8050万人民币拍下<a href="http://m.so.com/s?q=%E6%B8%85%E5%AE%AB%E6%97%A7%E8%97%8F&amp;src=newstranscode" class="qkw">清宫旧藏</a>《宋人摹郭忠恕四猎骑图》，创下当季最贵古代书画成交纪录。</p><p>这也意味着，加上此次收入囊中的<a href="http://m.so.com/s?q=%E3%80%8A%E4%BE%A7%E5%8D%A7%E7%9A%84%E8%A3%B8%E5%A5%B3%E3%80%8B&amp;src=newstranscode" class="qkw">《侧卧的裸女》</a>，刘益谦今年以来至少已经在拍卖场上豪掷了16亿元。</p><p class="header">扫货A股也不手软</p><p class="header">很多人不免要问，刘益谦到底多有钱?</p><p>公开资料显示，刘益谦现任新理益集团有限公司、<a href="http://m.so.com/s?q=%E5%A4%A9%E8%8C%82%E5%AE%9E%E4%B8%9A%E9%9B%86%E5%9B%A2%E8%82%A1%E4%BB%BD%E6%9C%89%E9%99%90%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">天茂实业集团股份有限公司</a>董事长，同时也是<a href="http://m.so.com/s?q=%E5%9B%BD%E5%8D%8E%E4%BA%BA%E5%AF%BF%E4%BF%9D%E9%99%A9%E8%82%A1%E4%BB%BD%E6%9C%89%E9%99%90%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">国华人寿保险股份有限公司</a>的法人代表。在2013年新财富中国富豪榜上，刘益谦以170亿元的身家排在第三十位。</p><p>对于巨额财富从何而来，刘益谦曾表示:“我是中国资本市场发展壮大的既得利益者，我的财富主要来自中国资本市场。”</p><p>在中国资本市场上，刘益谦有两个声名赫赫的外号:法人股大王和定增大王。2000年成立新理益集团后，刘益谦专注于二级市场投资，主要涉足领域包括国有股和法人股，曾相继成为琼能源、<a href="http://m.so.com/s?q=%E5%8C%97%E5%A4%A7&amp;src=newstranscode" class="qkw">北大</a>车行、河北华玉等上市公司的大股东。2009年到2011年，刘益谦又大举参与上市公司的增发，单2009年参与的项目数量就近十家。</p><p>值得一提的是，今年6月份股市发生前所未有的暴跌之后，这位资本大佬宣布自己将回归A股。他在<a href="http://m.so.com/s?q=%E5%BE%AE%E4%BF%A1&amp;src=newstranscode" class="qkw">微信</a>朋友圈发了一张摆有5台电脑的交易室图片，并配文，“很久没进交易室了，不知当年看电脑判断的感觉还在吗?”</p><p>随后，刘益谦在二级市场开始大肆“扫货”之旅。据本报此前统计，在本轮股市大幅调整中，刘益谦耗资约40亿元，举牌了有研新材、<a href="http://m.so.com/s?q=%E6%96%B0%E4%B8%96%E7%95%8C&amp;src=newstranscode" class="qkw">新世界</a>、东湖高新、华鑫股份、<a href="http://m.so.com/s?q=%E5%9B%BD%E5%86%9C%E7%A7%91%E6%8A%80&amp;src=newstranscode" class="qkw">国农科技</a>、天辰科技等多家上市公司。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.ce.cn/culture/gd/201511/11/t20151111_6971918.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='430db83284a39adf0d865e6f7526ff44'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>刘益谦</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '刘益谦10.84亿元再购名画 扫货旋风从A股刮到拍卖场' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '刘益谦10.84亿元再购名画 扫货旋风从A股刮到拍卖场'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";