s:22883:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>济南大学A-level中心全面招生 来读世界名校- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">济南大学A-level中心全面招生 来读世界名校</h1> <p id="source-and-time"><span id=source></span><time id=time>2015-06-01 12:34:34</time></p> </header>  <div id="news-body"><p>44名牛津剑桥、常春藤学生，260多名学子进入世界前十大学，1200多学子迈入世界百强名校。2014年71名学生收到<a href="http://m.so.com/s?q=%E7%89%9B%E6%B4%A5&amp;src=newstranscode" class="qkw">牛津</a>、剑桥的面试邀请,11名学生收到牛剑、剑桥预录取通知。还在高中苦读的你，会成为下一个传奇吗?近日， 培诺教育<a href="http://m.so.com/s?q=%E6%B5%8E%E5%8D%97%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">济南大学</a>A-level中心进入全面招生季，出国读名校不再是难事儿。</p><p>培诺教育目前已经获得“2014年度培生爱德思优秀中心”奖项，董事长郭宏获得英国爱德思考试局10年来在亚洲地区第一次办法的“国际教育杰出贡献奖” ，并连年获得新浪网、新华网“最受认可国际预科项目”、“最具品牌影响力教育连锁机构”、“最具综合实力教育集团”、“中国最具综合实力教育集团”等称号。</p><p>培诺教育已有9名学子走进了美国“常春藤”:刘好被<a href="http://m.so.com/s?q=%E5%AE%BE%E5%A4%95%E6%B3%95%E5%B0%BC%E4%BA%9A%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">宾夕法尼亚大学</a>录取、林俊园被杜克大学录取、周英策被哥伦比亚大学录取、孙永鑫被宾夕法尼亚大学录取、<a href="http://m.so.com/s?q=%E5%AD%9F%E7%B9%81%E8%B6%85&amp;src=newstranscode" class="qkw">孟繁超</a>被宾夕法尼亚大学录取、李兴宇被宾夕法尼亚大学录取。</p><p><img src="http://p34.qhimg.com/t011e716518d425f9c1.jpg?size=600x310"></p><p class="img-title">美国“常春藤”学子</p><p>从培诺已经走出21名牛津、剑桥在读生:龙子琦、权钺、<a href="http://m.so.com/s?q=%E9%82%B5%E9%9C%87&amp;src=newstranscode" class="qkw">邵震</a>、李佳恩、郑雯今、顾吉特、常嘉玮、卢晓雨、葛梦洋、<a href="http://m.so.com/s?q=%E9%99%86%E6%B2%BB&amp;src=newstranscode" class="qkw">陆治</a>、闫玉、刘晓鹏、冯琳舒、伊程、王奕浏、李太焰等;</p><p>今年以来，培诺教育已经有11名学生收到牛津、剑桥预录取通知:施圣安、<a href="http://m.so.com/s?q=%E7%8E%8B%E6%B5%B7%E5%AE%B9&amp;src=newstranscode" class="qkw">王海容</a>、陈泓霖、张叶川、柯宏、钟宇彬、曹倩颖、杨硕、胡嘉慧、费伊茗、林同学;</p><p>内地高考状元才能入读的亚洲名校也不是问题:贾樱被新加坡国立大学录取，郭文卿、郝圣子被香港中文大学录取，于跃被香港科技大学录取。</p><p><img src="http://p32.qhimg.com/t017ae7a34c82c9459c.jpg?size=600x375"></p><p class="img-title">亚洲名校学子</p><p>仅仅三年，培诺已有1000多名学子步入世界百强名校:张雪琪被美国UCLA(<a href="http://m.so.com/s?q=%E5%8A%A0%E5%B7%9E%E5%A4%A7%E5%AD%A6%E6%B4%9B%E6%9D%89%E7%9F%B6%E5%88%86%E6%A0%A1&amp;src=newstranscode" class="qkw">加州大学洛杉矶分校</a>)录取，李宇宸被加州大学录取，<a href="http://m.so.com/s?q=%E7%8E%8B%E5%A4%A9%E9%BD%90&amp;src=newstranscode" class="qkw">王天齐</a>、刘方石等被加拿大多伦多大学录取，马思诚、费泽亮、王悦莹等被澳洲国立大学录取，方舒康、吕悦、祝润泽等被悉尼大学录取，郑玉洁、舒扬、孙若凡、薛亮等60余名学生被帝国理工学院录取，李岱童、姜子琪、孟凝等130余名学生被伦敦大学学院UCL录取……</p><p>今年截至目前，培诺教育已有71名学生收到了牛津、剑桥的面试邀请……</p><p><img src="http://p35.qhimg.com/t015407f6b6575dbd5e.jpg?size=478x366"></p><p class="img-title">荣誉称号</p><p>课程优势● <a href="http://m.so.com/s?q=A-Level&amp;src=newstranscode" class="qkw">A-Level</a>:1、76选3，不再做偏科生</p><p>学习A-Level的学生只需根据个人兴趣及特长选择三门至四门功课作为主攻方向，可避开国内高中十余门功课的压力，避开了高考独木桥，学生可在相对较短的时间内集中主要精力攻读A-Level集中课程，在申请国外大学时又有绝对的优势，考出高分。曾经是偏科生的赵艺凡通过学习A-Level就获得了剑桥大学的面试邀请。</p><p class="header">2、摆脱“一考定终身”</p><p>在英国A-Level学制为两年，每年设1月、6月两次考试。A-Level试为单科考试，学生可根据自身情况进行单科突破。尤其突出的一点，学生如果在此次考试中发挥不好，可选择重考，成绩以最好的一次计算，明显地区别于国内考试的“一考定终身”。高考失利的孟繁超因为学习A-Level改变了他的人生，目前他在世界排名前30的布里斯托大学就读本硕连读课程。</p><p>● <a href="http://m.so.com/s?q=GAC-ACT&amp;src=newstranscode" class="qkw">GAC-ACT</a>:1、全球认可，且有奖学金</p><p>学生完成GAC-ACT课程可以申请全美高校，以及英国，<a href="http://m.so.com/s?q=%E6%BE%B3%E5%A4%A7%E5%88%A9%E4%BA%9A&amp;src=newstranscode" class="qkw">澳大利亚</a>加拿大等英语国家的大部分学校。GAC-ACT成绩作为大学入学标准以及奖学金发放的标准。</p><p class="header">2、留学直通车</p><p>根据国外教育体制，<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E9%AB%98%E4%B8%AD%E7%94%9F&amp;src=newstranscode" class="qkw">中国高中生</a>要想进入国外大学深造，都必须通过半年左右的语言学习及1年的大学预科课程;而GAC-ACT课程合格的学生即有机会获得GAC-ACT合作的国外大学最高可达39个学分的减免，从而可以节省大约1年的留学时间。</p><p class="header">3、专为中国学生量身打造的国际课程</p><p>GAC-ACT课程形成了由浅至深、循序渐进的教学模式和适合中国学生学习特点的课程体系，克服了中国学生学习国外原版课程无法适应的弊病，这是国内众多国际高中、国内大学中外合作办学项目所无法做到的，甚至比在国外大学语言中心的学习更利于学生快速突破语言关。</p><p>传奇背后的奥秘1、加注“<a href="http://m.so.com/s?q=%E9%A6%99%E6%B8%AF&amp;src=newstranscode" class="qkw">香港</a>A-Level学籍”，换个“身份”考取世界名校</p><p>内地学生考大学竞争的是“211”“985”大学，清华和北大往往就是最高目标。而香港的学生们读大学放眼的是全世界的学校，有更多所世界名校可以选择。可选择的范围大相径庭，2000所中国大学:160个国家上万所大学，升学竞争的范围广度明显不同。</p><p>另外，注册一个与香港学生一样的A-Level学籍，一方面，被名校录取的标准相应降低，另一方面，A-Level课程难度与中国高考比较而言相对容易:录取仅选3门课程、提前1年预录、每年2次考试、可以分单元重复考试等。这些课程对数理化知识扎实牢固的中国高中生来说，拿出高考一半的拼劲，完全能够轻松上香港及世界名校。我们在国内考国外水平的试卷，拿我们最优势的科目去和别人竞争。简言之，升学竞争的优势更大了。</p><p class="header">2、培诺线上和线下相结合的学习模式</p><p>除了传统的面授课程，培诺还自主研发开辟了线上课程平台，课程形式多样，既有真题剖析的常规课，又有提炼知识精华的 “微课”，让学生随时随地掌握知识。课程内容涵盖广泛，既有A-Level、GAC-ACT全部配套课程，又有雅思、托福课，帮助学生轻松达到美国大学的各项入学标准。</p><p class="header">3、优质的远程平台</p><p>投入使用4年来，已服务学生逾千人。内容丰富，课件包括雅思、托福、GAC-ACT、A-Level、IGCSE、升学指导、签证咨询等。随时、随地、随心学习优质课程，突破地域限制和时空限制，有网络即可学习。14岁神童施圣安就是通过学习远程课程获得牛津大学的预录取通知。</p><p class="header">4、强大的留学申请团队</p><p>培诺教育专业的申请团队老师会对申请大学各个环节进行全面专业的指导，全能型的留学专家为学生提供一站式服务，从留学规划到申请文书修改到大学申请再到签证的办理。</p><p class="header">5、留学手拉手APP</p><p>培诺留学手拉手APP为国内学生提供与千名海外学子在线交流的机会，及时了解到相关留学的一手信息!学生还可以通过观看培诺留学手拉手APP独创的留学指南微课提前了解国外的风土人情。</p><p class="header">课程简介A-Level:</p><p>A-Level(General Certificate of Education Advanced Level)，英国高中教育，它是英国的普通中等教育证书考试高级水平课程，是英国的全民课程体系，也是英国学生的大学入学考试课程。A-LEVEL课程证书被几乎所有英语授课的大学作为招收新生的入学标准。每年有数百万学生参加由这些考试局组织的统一考试，学生可持三科A-Level合格的考试成绩即可直接申报英国、澳大利亚、美国、<a href="http://m.so.com/s?q=%E5%8A%A0%E6%8B%BF%E5%A4%A7&amp;src=newstranscode" class="qkw">加拿大</a>、新加坡、香港、<a href="http://m.so.com/s?q=%E6%96%B0%E8%A5%BF%E5%85%B0&amp;src=newstranscode" class="qkw">新西兰</a>等150多个国家和地区的11000多所大学。因此，AA-Level课程被国际教育界誉为“金牌”教育课程和全球大学入学的“金牌”标准。</p><p class="header">GAC-ACT:</p><p>GAC-ACT(American College Test)即美国大学入学考试，是对申请入读美国本科一年级课程的学生进行的入学资格考试，是美国大学本科的入学条件之一，也是奖学金发放的重要依据之一。GAC-ACT成绩被全美包括哈佛大学等常青藤名校在内的3000多所大学接受为本科入学标准。如今，GAC-ACT被全球各国广泛推崇，学生凭借美国高考GAC-ACT成绩,可以申请美国、加拿大、澳大利亚、英国、新西兰、爱尔兰、<a href="http://m.so.com/s?q=%E6%96%B0%E5%8A%A0%E5%9D%A1&amp;src=newstranscode" class="qkw">新加坡</a>等国外大学。</p><p class="header">培诺教育各地分中心:</p><p>●咨询热线:4008-118-532</p><p>●青岛地址:山东省青岛市香港东路7号青岛大学东一教520室(总部)</p><p>●济南地址:山东省济南市舜耕路13号济南大学东校区文史楼412室 咨询电话:0531-82767885</p><p>●杭州地址:浙江省杭州市凯旋路268号浙江大学华家池校区中心大楼260室</p><p>●大连地址:辽宁省大连市沙河口区黑石礁街52号大连海洋大学10号教学楼202室</p><p>●沈阳地址:辽宁省沈阳市皇姑区崇山中路66号辽宁大学崇山校区(老校区)蕙星楼128室</p><p>●天津地址:天津市河西区马场道117号天津外国语大学第6教学楼110室</p><p>●太原地址:山西省太原市西矿街53号太原理工大学</p><p>●宁波地址:浙江省宁波市环城北路西段625号<a href="http://m.so.com/s?q=%E5%AE%81%E6%B3%A2%E6%95%99%E8%82%B2%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">宁波教育学院</a></p><p>●上海地址:上海市宜昌路575号上海第二工业大学普陀校区1号楼1102室</p><p>●成都地址:四川省成都市锦江区静安路5号四川师范大学校本部<a href="http://m.so.com/s?q=%E4%B9%9D%E6%95%99&amp;src=newstranscode" class="qkw">九教</a>412室</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://mt.sohu.com/20150601/n414206356.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='afe185949e6e28ded19260a82cecb4e1'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>邵震</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%82%B5%E9%9C%87&amp;pn=1&amp;pos=9&amp;m=dbe221ca177f78804b55295c888fcff7b407a90d&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0709%2F16%2FA0NO49DD00014AED.html" data-pos="1"> 130名学生从这里走进世界前十名校(组图) </a>   <li> <a href="/transcode?q=%E9%82%B5%E9%9C%87&amp;pn=1&amp;pos=10&amp;m=ed52f01bb87e56dd9f311fee9978bb237780580f&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0611%2F15%2F9UFIP40V00014AED.html" data-pos="2"> 不放弃高中,初三毕业生6月底前别忘注册"香港学籍"(组图) </a>   <li> <a href="/transcode?q=%E9%82%B5%E9%9C%87&amp;pn=2&amp;pos=1&amp;m=fc7547c3456c5c0f2795488e9ac54e4d589074b3&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F0416%2F16%2F9PVDMITO00014AED.html" data-pos="3"> 不放弃高中50名初、高中生5月底前可加注"香港学籍"(组图) </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '济南大学A-level中心全面招生 来读世界名校' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '济南大学A-level中心全面招生 来读世界名校'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";