s:15561:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>聚焦两会:管理层表态释放活力 题材概念百花齐放- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">聚焦两会:管理层表态释放活力 题材概念百花齐放</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-14 13:45:06</time></p> </header>  <div id="news-body"><p><img src="http://p34.qhimg.com/t014a4a3ccf6f38d234.jpg?size=323x231"></p><p>受到刘士余讲话刺激，今日三大股指均高开，随后股指一路单边震荡上行，盘面上由于注册制受到延缓，以中小创为代表的题材股是否活跃，成交量也有所放大，截止收盘，沪指上涨近2.5%，<a href="http://m.so.com/s?q=%E5%88%9B%E4%B8%9A%E6%9D%BF&amp;src=newstranscode" class="qkw">创业板</a>大涨近3.8%。</p><p class="header">热点板块:</p><p>今日市场出现久违的普涨行情，盘面上，受到国产软件将提速影响，国产软件、计算机应用今日涨幅居首，<a href="http://m.so.com/s?q=%E7%94%A8%E5%8F%8B&amp;src=newstranscode" class="qkw">用友</a>网络(600588)、<a href="http://m.so.com/s?q=%E8%B6%85%E5%9B%BE%E8%BD%AF%E4%BB%B6&amp;src=newstranscode" class="qkw">超图软件</a>(300036)、<a href="http://m.so.com/s?q=%E9%87%91%E8%AF%81%E8%82%A1%E4%BB%BD&amp;src=newstranscode" class="qkw">金证股份</a>(600446)等超20只个股涨停;<a href="http://m.so.com/s?q=%E4%BA%BA%E5%B7%A5%E6%99%BA%E8%83%BD&amp;src=newstranscode" class="qkw">人工智能</a>板块同样表现优异，<a href="http://m.so.com/s?q=%E6%B1%9F%E5%8D%97%E5%8C%96%E5%B7%A5&amp;src=newstranscode" class="qkw">江南化工</a>(002226)、思创医惠(300078)强势涨停;虚拟现实同样表现优异，<a href="http://m.so.com/s?q=%E6%A3%95%E6%A6%88%E5%9B%AD%E6%9E%97&amp;src=newstranscode" class="qkw">棕榈园林</a>(002431)、信息发展(300469)、中科创达(300496)、<a href="http://m.so.com/s?q=%E5%B7%9D%E5%A4%A7%E6%99%BA%E8%83%9C&amp;src=newstranscode" class="qkw">川大智胜</a>(002253)强势封涨停板;另外，4G、<a href="http://m.so.com/s?q=%E6%99%BA%E6%85%A7%E5%9F%8E%E5%B8%82&amp;src=newstranscode" class="qkw">智慧城市</a>、在线教育等板块同样表现优异。</p><p class="header">消息面上:</p><p>1、刘士余表示，注册制必须搞，但不可以单兵突进;中证金退出为时尚早，深港通今年肯定通。分析来看，周末<a href="http://m.so.com/s?q=%E8%AF%81%E7%9B%91%E4%BC%9A&amp;src=newstranscode" class="qkw">证监会</a>主席刘士余的一番标题强烈刺激市场，在上周连续地量低位盘整过后，今日市场早盘大幅放量，尤其是创业板在题材股的活跃带动下，仅半日释放量能就超过前一交易日一天的量能，可见此番表态给了市场一定的信心。</p><p>2、财政部发布2016年<a href="http://m.so.com/s?q=%E5%85%A8%E5%9B%BD%E4%BA%BA%E5%A4%A7&amp;src=newstranscode" class="qkw">全国人大</a>财政经济委员会的中央和地方预算草案审查报告。国务院提出的2016年中央和地方预算草案，全国一般公共预算收入157200亿元，比2015年预算执行数增长3%;全国一般公共预算支出180715亿元，剔除地方上年使用结转结余及调入资金后同口径增长6.7%;收支总量相抵，赤字21800亿元，比上年增加5600亿元。</p><p>3、发改委今日在例行新闻发布会上明确，2016年，将北京、天津、冀南、冀北、山西、陕西、江西、湖南、四川、重庆、广东、广西等12个省级电网，以及国家电力体制改革综合试点省份的电网和华北区域电网列入输配电价改革试点范围。扩大试点范围后，将覆盖全国18个省级电网和1个区域电网，标志着我国输配电价改革全面提速。</p><p>总体策略:从K线图上看到，在持续近一周的缩量低位盘整过后，今日沪指放量站上所有短期均线，意味着市场反弹行情开启，不过<a href="http://m.so.com/s?q=%E5%AE%8F%E8%A7%82%E7%BB%8F%E6%B5%8E&amp;src=newstranscode" class="qkw">宏观经济</a>增长仍面临较大压力，货币政策受制于杠杆债务，短时间内不会有强刺激政策。因此建议投资者适当参与反弹行情，注意板块的选择，操作上建议关注创业板超跌的股票。</p><p>如果散户朋友在选股方面存在很大的疑问，股票深套，买卖点把握不好的欢迎关注公众<a href="http://m.so.com/s?q=%E5%BE%AE%E4%BF%A1&amp;src=newstranscode" class="qkw">微信</a>平台【yizhan688】学习。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://mt.sohu.com/20160314/n440344575.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='c931b1a43ee1666c3276bfb9988f5191'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>百花</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%99%BE%E8%8A%B1&amp;pn=1&amp;pos=9&amp;m=9543d681044444554da10c531d2f1f42d8485a41&amp;u=http%3A%2F%2Fmt.sohu.com%2F20160314%2Fn440390417.shtml" data-pos="1"> 今日盘面<b>百花</b>齐放,20股大资金疯狂流出,有望翻倍 </a>   <li> <a href="/transcode?q=%E7%99%BE%E8%8A%B1&amp;pn=1&amp;pos=10&amp;m=15e7ccf04f542c78e5d22a8550ae57996948a547&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fkuaixun_0311%2F4675753.html" data-pos="2"> 黄花开处<b>百花</b>杀!小心,别被这株清纯的小黄花骗了 </a>   <li> <a href="/transcode?q=%E7%99%BE%E8%8A%B1&amp;pn=2&amp;pos=1&amp;m=275f3c15ae5e3d69bdb9450010b9c798072628ee&amp;u=http%3A%2F%2Fln.people.com.cn%2Fn2%2F2016%2F0314%2Fc340422-27927341.html" data-pos="3"> 三月踏青好时节 <b>百花</b>齐放引人醉 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '聚焦两会:管理层表态释放活力 题材概念百花齐放' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '聚焦两会:管理层表态释放活力 题材概念百花齐放'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";