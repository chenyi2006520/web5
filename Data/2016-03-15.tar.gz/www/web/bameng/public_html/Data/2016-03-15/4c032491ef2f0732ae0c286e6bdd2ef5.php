s:18910:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>如果你爱上一个人，请温柔待他(图)- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">如果你爱上一个人，请温柔待他(图)</h1> <p id="source-and-time"><span id=source>网易</span><time id=time>2016-02-29 13:57:35</time></p> </header>  <div id="news-body"><p><img src="http://p35.qhimg.com/t01f9b2f9eab027353b.jpg?size=399x600"></p><p>老舒最近可算得上享福了，不用刷碗、拖地，想画多久就画多久，想什么时候睡就什么时候睡，保证除了一杯桂圆水，不会有一句唠叨抱怨来干扰心神。没有老蔡发飙咆哮的每一天都称得上是个好日子，世界清静极了，可天数一多，老舒却有点消受不良，他忐忑不安着，如此温柔贤惠，可不是老蔡坚守了二十多年的风格啊。</p><p>仔细回想，变化似乎从他犯病之后开始的。<a href="http://m.so.com/s?q=%E5%BF%83%E8%84%8F%E7%97%85&amp;src=newstranscode" class="qkw">心脏病</a>是这样的，一犯就九死一生，极其凶险。过后就跟好好的人一样，自己不说，任谁也看不出来他的胸口揣着一颗随时发生状况的炸弹。</p><p>老蔡那天是被吓个够呛，脸色苍白，嘴唇和手一直抖，眼泪还哗哗地往外流。结婚二十余年，老舒几乎要忘了老蔡会哭，是个女人。她焦躁、暴戾、跋扈，<a href="http://m.so.com/s?q=%E6%8E%8C%E6%8E%A7%E6%AC%B2&amp;src=newstranscode" class="qkw">掌控欲</a>强，语气和身体一样硬邦邦的，好像不砸伤人就不会说话似的。老舒曾经特别失落，整天吵吵嚷嚷的生活让他觉得自己很糟糕，是老蔡活生生地拉低了他的生活质量。</p><p>现在好了，随便老舒是半夜不睡，还是饭后即卧，老蔡全视而不见毫不干涉。刚开始，她的温柔伎俩使用不娴熟，常要憋出一个“深情凝望”的眼神，附一个欲言又止的表情。老舒表面不动声色，心里却笑得直扑腾，猜测着，老蔡究竟能忍到何时才会来一场大爆发呢?总要爆发一次吧，那样他才会踏实点。可惜，老舒的算盘落空，现在的老蔡已经软如春风拂过，根本不计较他这根柳条是横着还是歪着。</p><p><a href="http://m.so.com/s?q=%E6%8B%94%E4%B8%9D%E5%B1%B1%E8%8D%AF&amp;src=newstranscode" class="qkw">拔丝山药</a>、番茄牛腩、凉拌西兰花，<a href="http://m.so.com/s?q=%E8%8D%89%E9%B1%BC&amp;src=newstranscode" class="qkw">草鱼</a>麻辣锅。周末中午，有时间，老蔡做了一桌子菜，全是老舒爱吃的，老舒心头的不适应感已经爆棚了，根本没心思大快朵颐。</p><p>饭后，老蔡起身收拾碗筷，老舒也乖顺地没去沙发里躺着，假模假样地在书房转悠几圈，然后，躲在门旁偷看厨房里的老蔡。她腰上系着他那条深咖色围裙，手脚麻利地刷着碗碟筷、擦刀挂菜板、整理灶台，那些曾让他厌恶不已的活在她眼里仿佛成了健身的项目，做得认真又投入，隐约还哼着歌儿，像个快乐的小姑娘。老舒看得越来越糊涂了。</p><p>晚上九点多，老舒主动把手机拿去充电，去卫生间刷牙洗漱，临出来又转回身，把随手窝成团，扔在洗衣机盖子上的袜子再次打开，仔细洗了，晾到阳台上去。</p><p>卧室里放着舒缓轻柔的<a href="http://m.so.com/s?q=%E5%82%AC%E7%9C%A0%E9%9F%B3%E4%B9%90&amp;src=newstranscode" class="qkw">催眠音乐</a>，老蔡正坐在床上看书，老舒掀被上床，凑过去看了一眼封皮，竟然是本旧诗集。怎么还读上诗了?老蔡抬眼看他，笑着说，没事看着玩呗。不过，我现在才发现，有些诗我当时没看懂，现在读读，觉得写得是真好。老舒点头，读诗至少比玩手机看娱乐圈新闻要好。</p><p>躺下时，胳膊蹭到老蔡的新睡衣，冰冷丝滑，老舒的脑袋里一下子蹦出这个广告语来。原来老蔡不止脾气变好了，品位也提升了?以前她常年一件肥到膝盖的紫色T恤，那是打折时她给他买的，断号，只能选大一码的，涂鸦的花纹跟一堆乱麻似的，他嫌弃不穿，她就拿过去自己穿，一穿就是七八年。</p><p>老舒忍了又忍，还是开口说道，我以前也犯过病，没见你吓成这样呀。这回你可反常挺长时间了，凡事要适可而止，你赶紧恢复原状吧，没你吵吵嚷嚷的，我一天天的真不习惯。</p><p>老蔡嘿嘿笑了，把书扣到床头柜上，关了手机音乐，熄了台灯。黑暗中酝酿了好一会儿才说:你刚出院那会儿，我们单位老林的男人去世了，<a href="http://m.so.com/s?q=%E8%84%91%E5%87%BA%E8%A1%80&amp;src=newstranscode" class="qkw">脑出血</a>。当时，我没敢跟你提。老林现在老后悔了，她说白天时两人吵了好几架，都是为鸡毛蒜皮的小事。要知道晚上这人就没了，她怎么也要对他好些。也有人说，如果不那么总吵，人不一定会走那么早，病一般都从气上来的，一股火……</p><p>老舒赶紧安慰她说，我可不是你气的，我心脏打小就有点毛病。再说，你管我是为我好，让我锻炼，早睡，注意养生，这些我都明白，就是有点懒，不愿做，这回我保证，以后自己多监督自己，保证不让你太操心了。可你还是该管就管，<a href="http://m.so.com/s?q=%E5%88%AB%E5%A4%AA%E6%B8%A9%E6%9F%94&amp;src=newstranscode" class="qkw">别太温柔</a>了，本宝宝都要吓坏了。</p><p>老舒大半辈子都属于<a href="http://m.so.com/s?q=%E6%9C%A8%E8%AE%B7%E5%AF%A1%E8%A8%80&amp;src=newstranscode" class="qkw">木讷寡言</a>那一类人，第一次听他说这么一大段的话，最后的“宝宝”二字更是搞笑。本来伤感的氛围硬生生让他给搅散了，老蔡没忍住哈哈大笑起来。老舒也跟着笑起来。真畅快，他觉得整个房间都透亮起来了。</p><p>老蔡又说:“那天，我看到有篇文章里说‘如果一个人抱怨自己拥有得太少，那是因为他失去得还不够多。’说的真对。现在，我半夜醒来，听到你的呼噜声都觉得好听，安心。反正，我想好了，以后我要温柔地爱人，不光爱你，还有我自己。把每一天都当成<a href="http://m.so.com/s?q=%E7%94%9F%E5%91%BD%E7%9A%84%E6%9C%80%E5%90%8E%E4%B8%80%E5%A4%A9&amp;src=newstranscode" class="qkw">生命的最后一天</a>来感恩地度过。”</p><p>第二天，老舒醒来时天色已经大亮，老蔡不在床上，侧耳倾听，厨房有叮当的动静。他蹭到<a href="http://m.so.com/s?q=%E5%BA%8A%E7%9A%84%E5%8F%A6%E4%B8%80%E8%BE%B9&amp;src=newstranscode" class="qkw">床的另一边</a>，伸手拿过那本扣放的书，是席慕容的诗集，翻开的页上是那首<a href="http://m.so.com/s?q=%E3%80%8A%E6%97%A0%E6%80%A8%E7%9A%84%E9%9D%92%E6%98%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《无怨的青春》</a>:</p><p class="header">在年轻的时候，</p><p class="header">如果你爱上了一个人，</p><p class="header">请你，请你一定要温柔地对待他。</p><p>年轻时老舒曾整首地把它抄在写给老蔡的信上。老蔡说的对，有些好东西是不怕时光荏苒，甚至越来越好。<a href="http://m.so.com/s?q=%E6%97%A0%E6%80%A8%E7%9A%84%E9%9D%92%E6%98%A5&amp;src=newstranscode" class="qkw">无怨的青春</a>要改成无怨的人生才好。</p><p>老舒坐起来，他要神清气爽地出去，吃老蔡的早餐时，要夸她手艺高超，注重营养，还<a href="http://m.so.com/s?q=%E8%89%B2%E9%A6%99%E5%91%B3%E4%BF%B1%E5%85%A8&amp;src=newstranscode" class="qkw">色香味俱全</a>。吃完一定要抢回刷碗权，好歹干了这么多年，早习惯了。这几天不刷碗，浑身僵得难受极了……</p><p>蔡敏乐</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.163.com/16/0229/13/BH0E1A4T00014AED.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='f5554ae672df712595988c6b11cf1680'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>无怨的青春</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%97%A0%E6%80%A8%E7%9A%84%E9%9D%92%E6%98%A5&amp;pn=1&amp;pos=8&amp;m=6d294dfdf61f2463b443433d3a4154cb3427eb44&amp;u=http%3A%2F%2Fwww.wenming.cn%2Fwmpl_pd%2Fyczl%2F201505%2Ft20150514_2613910.shtml" data-pos="1"> 劳动价值让<b>青春无怨</b>无悔 </a>   <li> <a href="/transcode?q=%E6%97%A0%E6%80%A8%E7%9A%84%E9%9D%92%E6%98%A5&amp;pn=1&amp;pos=9&amp;m=6926ec11081e779cbed152623e8e3b9659ab9d0e&amp;u=http%3A%2F%2Fwww.chexun.com%2F2014-08-25%2F102567311.html" data-pos="2"> 福特新嘉年华"正<b>青春</b>"音乐征集活动启动 </a>   <li> <a href="/transcode?q=%E6%97%A0%E6%80%A8%E7%9A%84%E9%9D%92%E6%98%A5&amp;pn=1&amp;pos=10&amp;m=76a522d0547cab3d19ae75eb507e89200ef20b3a&amp;u=http%3A%2F%2Fwww.81.cn%2Fzggfs%2F2016-02%2F18%2Fcontent_6916051.htm" data-pos="3"> 国防生版《小幸运》,温暖你的心! </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '如果你爱上一个人，请温柔待他(图)' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '如果你爱上一个人，请温柔待他(图)'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";