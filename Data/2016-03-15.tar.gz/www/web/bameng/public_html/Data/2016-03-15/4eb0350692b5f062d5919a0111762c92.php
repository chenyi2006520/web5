s:17271:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>职场故事:安徽农大毕业生卖水果 英语砍价可打折 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">职场故事:安徽农大毕业生卖水果 英语砍价可打折 </h1> <p id="source-and-time"><span id=source>新华网</span><time id=time>2015-05-13 13:00:55</time></p> </header>  <div id="news-body"><p><img src="http://p31.qhimg.com/t01077135c2adc2ac6b.jpg?size=542x231"></p><p class="img-title">[他说]</p><p>任性=Do what I want 前段时间不是很多专业人士都不知道怎么翻译“任性”吗?我觉得就是:Dowhat Iwant，Idowhat I like.(我做我想要的，我做我喜欢的。 )</p><p>杭州街头有个水果摊，不仅卖水果还“卖打”。顾客用英语还价可打九折，花5元钱可打一次老板，打得过就能得到2000元奖励。这个憨憨的水果摊老板叫<a href="http://m.so.com/s?q=%E5%AD%99%E9%9B%A8&amp;src=newstranscode" class="qkw">孙雨</a>，是亳州人，毕业于<a href="http://m.so.com/s?q=%E5%AE%89%E5%BE%BD%E5%86%9C%E4%B8%9A%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">安徽农业大学</a>英语专业，英语专业八级水平。</p><p class="header">五元一次杭州街头“卖打”</p><p>“热烈祝贺安徽<a href="http://m.so.com/s?q=%E9%98%BF%E9%9B%A8&amp;src=newstranscode" class="qkw">阿雨</a>独门硬气功大超市于5月1日正式开业运营，任你挑，任你选，<a href="http://m.so.com/s?q=%E4%BB%BB%E4%BD%A0%E6%89%93&amp;src=newstranscode" class="qkw">任你打</a>……本硬气功自1月1日试运营以来，共有107人前来切磋，挑战试拳，5元钱一次，击打部位为胸部、腹部，可以拳打、脚踢、肘顶、膝撞、掌推，只要你能把本人搞倒，现场奖励2000元。”</p><p>杭州河东路，孙雨在贩卖水果的小货车旁立了一个牌子，这就是“气功大超市”，没有门面，人在哪里哪里就是“超市”。有人真的出5元钱来打一次，“他站着不动，没有一个人把他打倒。”附近的小贩说。</p><p>孙雨长年光着膀子，他个头不高，肌肉也不算突出，但像石头一样稳稳当当。有人花钱来打，孙雨扎稳马步屏住呼吸，孙妈妈心疼，要把5元钱还给人家，孙雨不干，绷着脸让她走开，“我正挨打呢，你别打断，我泄了气更疼。”“找打”吸引了很多好奇的人，不管打不打，都顺手买点水果，居然对生意有好处。</p><p class="header">英语砍价买水果打九折</p><p>孙雨在别人眼里有些怪。之前，他还搞过另一个花样:“<a href="http://m.so.com/s?q=%E7%BB%8F%E6%B5%8E%E5%85%A8%E7%90%83%E5%8C%96&amp;src=newstranscode" class="qkw">经济全球化</a>，全球一体化，购物练练外语，给你一点折扣。”旁边配上英文:“Economic globalization，Global integration，Shopping in English，Give you a discount。”</p><p>来他这里讲英语买水果的，一天能遇到两三个，还有几个<a href="http://m.so.com/s?q=%E5%8D%81%E4%B8%89%E5%9B%9B%E5%B2%81%E7%9A%84%E5%AD%A9%E5%AD%90&amp;src=newstranscode" class="qkw">十三四岁的孩子</a>，孙雨给他们的优惠更大。孙妈妈不愿意了，本来利润就薄，打九折赚得更少了。孙雨只得作罢。</p><p>一些人觉得这些是孙雨精心策划的“炒作”。孙雨着急辩解:“我这、这不是炒作，顶多是促销。”</p><p class="header">英语八级曾经考研三次</p><p>除了卖水果是“接地气”之外，孙雨其他时间大多“神游”在自己的世界里。</p><p>孙雨介绍，在老家的乡镇中学，他是当年考上大学的两个人之一。从<a href="http://m.so.com/s?q=%E4%B8%89%E8%81%94%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">三联学院</a>英语专业毕业后，孙雨发奋自考本科，2005年考上了安农大英语专业。在安农大，他更加疯狂地学习英语，轻松通过了专业八级考试。</p><p>本科毕业后，他继续考英语专业研究生，可是由于二外日语太差，没有考上，“我一学日语就想看英语。”之后，他到<a href="http://m.so.com/s?q=%E5%88%A9%E8%BE%9B&amp;src=newstranscode" class="qkw">利辛</a>一所私立学校当英语老师。“我中学时的目标就是当翻译，我管不好人，学生常气得我肺疼。”他辞了职，到广东<a href="http://m.so.com/s?q=%E4%BD%9B%E5%B1%B1&amp;src=newstranscode" class="qkw">佛山</a>投奔开小货车的父亲，一边上班一边考研，立志考广州<a href="http://m.so.com/s?q=%E5%A4%96%E5%9B%BD%E8%AF%AD%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">外国语学院</a>，但考了三年都没有考上。</p><p class="header">三年前，他又来到杭州卖水果。</p><p class="header">苦练气功每天自捶万次</p><p>“我、我感兴趣的只有两样，英语和气功。我的气功是自己的门派，都是自学的。”孙雨加快语速，很骄傲。每天，他至少花三个小时练习气功。他练气功还有一个方法，就是捶打肌肉，一天一万锤。</p><p>父母常常看着儿子叹气，“花那么多钱培养出个大学生，却在卖水果。 ”更让他们着急的是，1981年出生的孙雨至今仍单身。</p><p>孙雨的水果摊上总是摆着英语书，他只看英语原版，每月至少三本。他还用英语写了一本<a href="http://m.so.com/s?q=%E3%80%8A%E6%88%91%E7%9A%84%E8%80%83%E7%A0%94%E8%A1%80%E6%B3%AA%E5%8F%B2%E3%80%8B&amp;src=newstranscode" class="qkw">《我的考研血泪史》</a>，“类似卢梭的<a href="http://m.so.com/s?q=%E3%80%8A%E5%BF%8F%E6%82%94%E5%BD%95%E3%80%8B&amp;src=newstranscode" class="qkw">《忏悔录》</a>。”孙雨打算继续考研，他还想把家乡<a href="http://m.so.com/s?q=%E4%BA%B3%E5%B7%9E&amp;src=newstranscode" class="qkw">亳州</a>的五禽戏融合到气功里。</p><p class="header">“你心里有落差吗?”记者问。</p><p>“有也是有的，但是<a href="http://m.so.com/s?q=%E7%88%B1%E6%83%85%E8%BF%99%E4%B8%AA%E4%B8%9C%E8%A5%BF&amp;src=newstranscode" class="qkw">爱情这个东西</a>要靠缘分;工作呢，我的目标是翻译兼保镖。”</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.xinhuanet.com/edu/2015-05/13/c_127796343.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='2e2c92f83dcdde2d20c2cfcb7bb9622b'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>安徽农大</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%AE%89%E5%BE%BD%E5%86%9C%E5%A4%A7&amp;pn=1&amp;pos=2&amp;m=a0b3103268d547358f74fa47f7ad5d7d613ef8bd&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Fedu%2F2015-05%2F13%2Fc_127796343.htm" data-pos="1"> 职场故事:<b>安徽农大</b>毕业生卖水果 英语砍价可打折 </a>   <li> <a href="/transcode?q=%E5%AE%89%E5%BE%BD%E5%86%9C%E5%A4%A7&amp;pn=1&amp;pos=3&amp;m=8dd5561e4ebb58e9be217bf4795949b37c2c0a5d&amp;u=http%3A%2F%2Flearning.sohu.com%2F20150304%2Fn409335624.shtml" data-pos="2"> <b>安徽农业大学</b>2015考研调剂注意事项 </a>   <li> <a href="/transcode?q=%E5%AE%89%E5%BE%BD%E5%86%9C%E5%A4%A7&amp;pn=1&amp;pos=4&amp;m=566c8766e2d271e2eaa2e61803370e2aa4d8c4d3&amp;u=http%3A%2F%2Fnews.sina.com.cn%2Fo%2F2015-06-16%2F060031954338.shtml" data-pos="3"> <b>安徽农大</b>"绿色课堂"为孩子解惑 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '职场故事:安徽农大毕业生卖水果 英语砍价可打折 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '职场故事:安徽农大毕业生卖水果 英语砍价可打折 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";