s:17535:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>官方高调曝光东风-41出厂转运照片 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">官方高调曝光东风-41出厂转运照片 </h1> <p id="source-and-time"><span id=source>凤凰网</span><time id=time>2014-02-20 08:10:00</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E8%91%A3%E5%98%89%E8%80%80&amp;src=newstranscode" class="qkw">董嘉耀</a>:本周有关日本的话题我们先放一边，本周还留意一下外界相当的关注到，虽然美国很多情报提到中国拥有了东风41包括巨浪2，但是中国官方和军方一直没有证实，但是本周外间注意到中国大陆官方的媒体引述了中国少将公开的文章，提到东风41包括巨浪2的试射到底有什么含义呢，看一个片段。</p><p>解说:据香港<a href="http://m.so.com/s?q=%E3%80%8A%E5%8D%97%E5%8D%8E%E6%97%A9%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《南华早报》</a>报道，中国大陆重要的官方的军事集团中国航太科技集团直属的官方报纸，<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E5%9B%BD%E8%88%AA%E5%A4%AA%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《中国航太报》</a>特别刊发了中国大陆解放军的少将军事评论家<a href="http://m.so.com/s?q=%E5%BE%90%E5%85%89%E8%A3%95&amp;src=newstranscode" class="qkw">徐光裕</a>将军的一篇名为<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E5%9B%BD%E8%AF%95%E5%B0%84%E5%AF%BC%E5%BC%B9%E4%BF%83%E8%BF%9B%E5%92%8C%E5%B9%B3%E5%AE%89%E5%85%A8%E5%8F%91%E5%B1%95%E3%80%8B&amp;src=newstranscode" class="qkw">《中国试射导弹促进和平安全发展》</a>的文章，而这篇文章当中，中国官方媒体和徐光裕将军直接使用了解放军的东风-41代号巨浪-2型代号导弹的正式的名称，确认了这两款导弹试射的正式消息。</p><p>香港的媒体报道注意到，这是中国大陆官方媒体首度以官方的身份证实了东风-41和巨浪-2型导弹的存在，而之前官方媒体在报道导弹试验的时候，通常用的代号是洲际运载火箭，或者远程运载火箭作为代称的，而这次是中国大陆解放军的官方媒体和中国解放军的少将代表官方首次证实，解放军东风-41还有巨浪-2型导弹确实展开过试验的消息。</p><p>另一方面，据美国的<a href="http://m.so.com/s?q=%E3%80%8A%E5%8D%8E%E7%9B%9B%E9%A1%BF%E8%87%AA%E7%94%B1%E7%81%AF%E5%A1%94%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《华盛顿自由灯塔报》</a>报道说，中国大陆解放军的东风-41的机动型的洲际弹道导弹从制造厂转运出来，给军事单位的照片，最近在中国大陆的互联网曝光。不过，官方到底是故意曝光还是被动曝光，但是不管怎么样也反映出解放军东风-41已经高调地曝光，而这张中国大陆解放军所谓东风-41型的长程导弹的照片，是一月底由中国大陆的军事爱好者上传到网站的，当时导弹正从中国大陆解放军的某个军工厂运出来。</p><p>从这张照片可以看到，这个东风-41的导弹蒙着蓝色的帆布，从工厂驶出的时候是有警力一路护送的，照片上看到导弹是中国大陆战略<a href="http://m.so.com/s?q=%E5%AF%BC%E5%BC%B9%E9%83%A8%E9%98%9F&amp;src=newstranscode" class="qkw">导弹部队</a>二炮的所谓东风-41型的长程导弹，代号DF-41，而一些军事界也猜测说，东风-41长程导弹是俄罗斯原来的<a href="http://m.so.com/s?q=%E7%99%BD%E6%9D%A8&amp;src=newstranscode" class="qkw">白杨</a>-M型导弹，洲际弹道导弹的中国版本，而有中国大陆的军事网民提到，解放军这款东风-41的长程导弹与俄罗斯的所谓白杨-M型的洲际弹道导弹相比，解放军的东风-41具有较明显的中国制造，<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E5%86%9B%E4%BA%8B&amp;src=newstranscode" class="qkw">中国军事</a>的特色。</p><p>报道相信解放军这个东风-41的长程弹道导弹的机动底盘，比起俄罗斯的白杨-M型导弹更加低一些和短一些，更加适合在中国大陆的山区，特别是解放军可以在铁路和公路的隧道进行移动和机动。</p><p>西方的军事评论员指出，解放军的东风-41的长程机动式的洲际弹道导弹轮廓较低，因此可以在卫星运行的监视区以外，随时从解放军的一个发射的隧道转移到另外一个隧道，而不被敌方发现，而中国大陆现在解放军二炮部队拥有大约三千英里的在中国大地广袤大地底下的隧道，这些隧道专门为了解放军二炮躲避美军的打击，避免中国的核反击力量、核发射阵地、核指挥阵地被摧毁，而秘密在地下建设的，而美国的卫星很难追踪这些中国大陆机动式的导弹阵地。</p><p>美国最新的情报还指出，解放军这个东风-41的长程洲际弹道导弹可以携带多达十枚的分弹头的核弹头，对美国本土构成严重巨大的威慑，而美国的《华盛顿自由灯塔报》还刚刚报道过中国大陆解放军二炮部队就在刚刚过去的2013年的年底，第二次试射了东风-41长程洲际弹道导弹的消息，美国的情报机构一直密切地监视中国这款所谓最新的长程的东风-41导弹的发射的情况，试验的情况，而这枚导弹当时是从中国北方的省份<a href="http://m.so.com/s?q=%E5%B1%B1%E8%A5%BF%E7%9C%81&amp;src=newstranscode" class="qkw">山西省</a>的太原市的五寨导弹发射场发射的，根据美国<a href="http://m.so.com/s?q=%E4%BA%94%E8%A7%92%E5%A4%A7%E6%A5%BC&amp;src=newstranscode" class="qkw">五角大楼</a>掌握最新的情报，而在这之前，解放军东风-41的第一次的试射，是在2012年的7月24号，美国说解放军任何有关这种长程导弹的试射风吹草动美国都全程地侦测，全程地掌握，而美国发现解放军还要测试这款导弹未来的飞行的监控，包括弹着点是否准确等等，今年解放军还要进行两次以上的试验。</p><p>美国国防部最新的情报说，解放军的东风-41长程导弹射程大约一万一千到一万两千公里，使用分导式的多弹头的战斗部，而且可以分导避开<a href="http://m.so.com/s?q=%E5%AF%BC%E5%BC%B9%E6%8B%A6%E6%88%AA&amp;src=newstranscode" class="qkw">导弹拦截</a>网络，一枚导弹可以同时打击美国多个城市。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.ifeng.com/mainland/detail_2014_02/20/33995527_0.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='bd4dc15268b33fe9d1d74eb2ae7748e6'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>被动转运</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%A2%AB%E5%8A%A8%E8%BD%AC%E8%BF%90&amp;pn=1&amp;pos=5&amp;m=caf7632be40d41bb990544201ef01256354e5ec7&amp;u=http%3A%2F%2Fsports.qq.com%2Fa%2F20150603%2F042412.htm" data-pos="1"> 针锋相对!辽足痛失尖刀盼围城 绿城急需<b>转运</b> </a>   <li> <a href="/transcode?q=%E8%A2%AB%E5%8A%A8%E8%BD%AC%E8%BF%90&amp;pn=1&amp;pos=6&amp;m=7362adfb0c23631591bc14ca048d5c1590021865&amp;u=http%3A%2F%2Fnews.ifeng.com%2Fmainland%2Fdetail_2014_02%2F20%2F33995527_0.shtml" data-pos="2"> 官方高调曝光东风-41出厂<b>转运</b>照片 </a>   <li> <a href="/transcode?q=%E8%A2%AB%E5%8A%A8%E8%BD%AC%E8%BF%90&amp;pn=1&amp;pos=7&amp;m=d792c7d99e856cd34148c7993858c1e0e770d17a&amp;u=http%3A%2F%2Fah.sina.com.cn%2Fnews%2Fhefei%2F2014-09-17%2F0704116482.html" data-pos="3"> 新桥机场运营一余年 已有52名空中患者急救<b>转运</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '官方高调曝光东风-41出厂转运照片 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '官方高调曝光东风-41出厂转运照片 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";