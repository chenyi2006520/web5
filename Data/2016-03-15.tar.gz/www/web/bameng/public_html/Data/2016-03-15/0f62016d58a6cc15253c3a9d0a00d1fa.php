s:14103:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>高清图:蒂亚戈跪地仰天咆哮 穆勒振臂握拳怒吼- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">高清图:蒂亚戈跪地仰天咆哮 穆勒振臂握拳怒吼</h1> <p id="source-and-time"><span id=source>搜狐</span><time id=time>2016-03-13 03:57:50</time></p> </header>  <div id="news-body"><p>北京时间3月13日凌晨1时30分，2015-16赛季德甲第26轮的一场较量，领头羊、<a href="http://m.so.com/s?q=%E5%8D%AB%E5%86%95%E5%86%A0%E5%86%9B&amp;src=newstranscode" class="qkw">卫冕冠军</a>拜仁慕尼黑坐镇<a href="http://m.so.com/s?q=%E5%AE%89%E8%81%94%E7%90%83%E5%9C%BA&amp;src=newstranscode" class="qkw">安联球场</a>5-0大胜近来状态不错的不来梅。这是两队历史上整整第100场德甲对战。第9分钟，<a href="http://m.so.com/s?q=%E7%A7%91%E6%9B%BC&amp;src=newstranscode" class="qkw">科曼</a>传中，蒂亚戈门前抢点先拔头筹。第31分钟，又是科曼的助攻，<a href="http://m.so.com/s?q=%E7%A9%86%E5%8B%92&amp;src=newstranscode" class="qkw">穆勒</a>完成破门。第66分钟，穆勒门前补射梅开二度。第86分钟，莱万前场断球后单刀得手。第90分钟，科曼右路突破再次助攻蒂亚戈破门，完成助攻帽子戏法。</p><p><img src="http://p33.qhimg.com/t0140d6b83a4bbbe772.jpg?size=748x563"></p><p>高清图:蒂亚戈跪地仰天咆哮 穆勒振臂握拳怒吼</p><p><img src="http://p32.qhimg.com/t0144dffde16f4ef349.jpg?size=878x563"></p><p><img src="http://p32.qhimg.com/t01b410f6493bae35c0.jpg?size=940x562"></p><p><img src="http://p35.qhimg.com/t01c1b9ee1332c4d82b.jpg?size=898x563"></p><p><img src="http://p33.qhimg.com/t01b76b45bcb7a49afc.jpg?size=877x563"></p><p><img src="http://p35.qhimg.com/t018038204fd5b61684.jpg?size=411x563"></p><p><img src="http://p33.qhimg.com/t01d97153460d0c66b4.jpg?size=904x563"></p><p><img src="http://p35.qhimg.com/t0172e0c47c59b502ac.jpg?size=820x563"></p><p><img src="http://p31.qhimg.com/t013f284cebd668d5ff.jpg?size=770x563"></p><p><img src="http://p35.qhimg.com/t01e58a42d86b07b70e.jpg?size=740x563"></p><p><img src="http://p32.qhimg.com/t01883e4550756c4ea5.jpg?size=475x563"></p><p><img src="http://p35.qhimg.com/t01b0a4adb3e0710ab4.jpg?size=418x563"></p><p><img src="http://p34.qhimg.com/t01ee69a57c7d5538a5.jpg?size=784x563"></p><p><img src="http://p34.qhimg.com/t01eaf78a0533b23216.jpg?size=753x563"></p><p><img src="http://p32.qhimg.com/t01f89c4e4ba23e5049.jpg?size=876x563"></p><p><img src="http://p33.qhimg.com/t01c87816a94d12ada7.jpg?size=574x563"></p><p><img src="http://p33.qhimg.com/t018befabdc029934d6.jpg?size=468x563"></p><p><img src="http://p35.qhimg.com/t019aabcebddc3c632d.jpg?size=703x563"></p><p><img src="http://p35.qhimg.com/t0105c48a1694acf4f1.jpg?size=734x563"></p><p><img src="http://p34.qhimg.com/t01227f5d9d32181a87.jpg?size=744x563"></p><p><img src="http://p34.qhimg.com/t010dbc17ede5227d39.jpg?size=722x563"></p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://pic.sports.sohu.com/911202/911210/group-718478.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='84c24271d96a984bdf8dc29a3d87c501'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>穆勒</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%A9%86%E5%8B%92&amp;pn=1&amp;pos=8&amp;m=36741e0b27e621865d5f54a1e6e023f8c9647327&amp;u=http%3A%2F%2Fpic.sports.sohu.com%2F911202%2F911210%2Fgroup-718478.shtml" data-pos="1"> 高清图:蒂亚戈跪地仰天咆哮 <b>穆勒</b>振臂握拳怒吼 </a>   <li> <a href="/transcode?q=%E7%A9%86%E5%8B%92&amp;pn=1&amp;pos=9&amp;m=7d33563d05a5a407179d0b0636ececcea710aa71&amp;u=http%3A%2F%2Fsports.sina.com.cn%2Fglobal%2Fgermany%2F2016-03-10%2Fdoc-ifxqhmvc2244048.shtml" data-pos="2"> <b>穆勒</b>:拜仁能抗衡宇宙巴萨 不觉得他们比我们强 </a>   <li> <a href="/transcode?q=%E7%A9%86%E5%8B%92&amp;pn=1&amp;pos=10&amp;m=bf3ae5a72de6509b4022c412f6a72ef99431eb7a&amp;u=http%3A%2F%2Fcxzg.china.com.cn%2Fnews%2F2554_2015_08%2Fworker%2Fshow-2554-5363-1.html%3FWebShieldDRSessionVerify%3DTBPllafPZCjVq0ScNtgy" data-pos="3"> 必赢|进球视频-里贝里转身凌空抽射 <b>穆勒</b>机敏补射捡漏 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '高清图:蒂亚戈跪地仰天咆哮 穆勒振臂握拳怒吼' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '高清图:蒂亚戈跪地仰天咆哮 穆勒振臂握拳怒吼'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";