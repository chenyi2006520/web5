s:14855:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>马刺拍本季全队合影 邓肯:是否轮休听波波的- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">马刺拍本季全队合影 邓肯:是否轮休听波波的</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-03-15 07:26:17</time></p> </header>  <div id="news-body"><p>核心提示: 3月15日，<a href="http://m.so.com/s?q=%E9%A9%AC%E5%88%BA&amp;src=newstranscode" class="qkw">马刺</a>全队在今天拍摄了本赛季的大合影，在接受采访时，<a href="http://m.so.com/s?q=%E8%92%82%E5%A7%86-%E9%82%93%E8%82%AF&amp;src=newstranscode" class="qkw">蒂姆-邓肯</a>表示目前他们并不关心能否拿到常规赛70胜的战绩，而对于是否会在接下来的常规赛程中轮休，<a href="http://m.so.com/s?q=%E9%82%93%E8%82%AF&amp;src=newstranscode" class="qkw">邓肯</a>表示会一切听格雷格-<a href="http://m.so.com/s?q=%E6%B3%A2%E6%B3%A2%E7%BB%B4%E5%A5%87&amp;src=newstranscode" class="qkw">波波维奇</a>的安排。</p><p><img src="http://p32.qhimg.com/t017cd0eb2ec249fa35.jpg?size=550x550"></p><p class="img-title">马刺今天拍摄了全队大合影</p><p>马刺在今天的训练之余拍摄了本赛季的全队大合影。在马刺官方IG发布的一张照片里，邓肯似乎一脸不怀好意地看着前排<a href="http://m.so.com/s?q=%E5%AE%89%E5%BE%B7%E7%83%88-%E7%B1%B3%E5%8B%92&amp;src=newstranscode" class="qkw">安德烈-米勒</a>的后脑。</p><p><img src="http://p34.qhimg.com/t0151c266383c9ff7d8.jpg?size=550x308"></p><p>遥想战胜雷霆比赛当中他“击打”<a href="http://m.so.com/s?q=%E9%98%BF%E5%B0%94%E5%BE%B7%E9%87%8C%E5%A5%87&amp;src=newstranscode" class="qkw">阿尔德里奇</a>的画面，似乎这位“球霸”并不想放过每一个新队友的后脑勺……</p><p><img src="http://p33.qhimg.com/t01634be2c7de84f853.jpg?size=378x194"></p><p>马刺剩余的赛程非常艰难，他们现在落后勇士3.5个胜场，而在剩余的赛程里他们还将三次遇到勇士，对于他们来说，依旧存在着跟<a href="http://m.so.com/s?q=%E5%8D%AB%E5%86%95%E5%86%A0%E5%86%9B&amp;src=newstranscode" class="qkw">卫冕冠军</a>争夺西部第一的可能，而在剩余的赛程里，他们是否会选择安排邓肯等主力轮休呢?面对这个问题，阿呆再次打起了太极拳:</p><p>“我们一直把这件事情的决定权放在波波那里，他一直非常擅长安排是否轮休这件事情，所以他会做决定的。”</p><p>除了勇士以外，其实目前56胜10负的马刺也是有追逐70胜的可能性的，而且他们本赛季至今主场还没有输过球。不过邓肯对于这种纪录并不太在意。</p><p>“我们并不太在意我们是否会创造哪些纪录，”邓肯说，“我们只希望在正确的时间打出良好的表现，并且保持健康。”</p><p>马刺将在下一场主场迎战快船，对于对阵这个曾经在去年首轮淘汰自己的球队，邓肯感觉很兴奋。</p><p>“他们去年跟我们打季后赛的时候表现的很好，而这次对阵他们将会是一场比较<a href="http://m.so.com/s?q=%E8%89%B0%E9%9A%BE%E7%9A%84%E6%AF%94%E8%B5%9B&amp;src=newstranscode" class="qkw">艰难的比赛</a>。不过我们喜欢跟快船比赛，因为这会给我们球队一些压力，让我们更加专注。”</p><p>马刺现在联盟战绩第二，不过<a href="http://m.so.com/s?q=%E9%B2%8D%E9%87%8C%E6%96%AF-%E8%BF%AA%E5%A5%A5&amp;src=newstranscode" class="qkw">鲍里斯-迪奥</a>似乎还不太满意球队的表现。“我们每方面都能进步的，”迪奥说，“每样。我们在场上的每样东西都可以做得稍微再好一些。”</p><p class="header">不知道这是不是攒人品。</p><p class="header">国搜体育专题报道:</p><p>】</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/2016/kuaixun_0315/4752113.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='e05d560a873d50dc0bd290c1ea267f4e'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>马刺</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%A9%AC%E5%88%BA&amp;pn=1&amp;pos=2&amp;m=cb25c335baa6a80e07d089f95163fe725ad403d8&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fsport%2Ftyxw%2F4751471_1.html" data-pos="1"> 邓肯:不关心<b>马刺</b>能否70胜 健康和状态最重要 </a>   <li> <a href="/transcode?q=%E9%A9%AC%E5%88%BA&amp;pn=1&amp;pos=3&amp;m=556e705047b16ae277d2e6420748ae0f0024da88&amp;u=http%3A%2F%2Fsports.people.com.cn%2Fn1%2F2016%2F0314%2Fc22149-28197176.html" data-pos="2"> 85比93不敌<b>马刺</b> 雷霆再度习惯性崩盘 </a>   <li> <a href="/transcode?q=%E9%A9%AC%E5%88%BA&amp;pn=1&amp;pos=4&amp;m=e44c4e76b19d9c42576b2edb870f0b1e087f8382&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fsport%2Ftyxw%2F4747891_1.html" data-pos="3"> 林书豪完胜哈登 勇士<b>马刺</b>主场依旧无敌 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '马刺拍本季全队合影 邓肯:是否轮休听波波的' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '马刺拍本季全队合影 邓肯:是否轮休听波波的'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";