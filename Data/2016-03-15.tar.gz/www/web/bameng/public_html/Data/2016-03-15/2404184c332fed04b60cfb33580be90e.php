s:16099:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>通讯:俄罗斯远东民众欢庆送冬节- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">通讯:俄罗斯远东民众欢庆送冬节</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-03-14 15:04:35</time></p> </header>  <div id="news-body"><p>新华社<a href="http://m.so.com/s?q=%E7%AC%A6%E6%8B%89%E8%BF%AA%E6%B2%83%E6%96%AF%E6%89%98%E5%85%8B&amp;src=newstranscode" class="qkw">符拉迪沃斯托克</a>3月14日专电 通讯:俄罗斯远东民众欢庆送<a href="http://m.so.com/s?q=%E5%86%AC%E8%8A%82&amp;src=newstranscode" class="qkw">冬节</a></p><p class="header">新华社记者吴刚</p><p>为期一周的俄罗斯传统节日送冬节13日结束。在这一周里，人们自发组织化装游行、民间歌舞、游戏、溜冰、<a href="http://m.so.com/s?q=%E6%BB%91%E9%9B%AA&amp;src=newstranscode" class="qkw">滑雪</a>、乘三套马车兜风等娱乐活动。在俄远东城市符拉迪沃斯托克的喷泉<a href="http://m.so.com/s?q=%E6%B8%B8%E4%B9%90%E5%9B%AD&amp;src=newstranscode" class="qkw">游乐园</a>，记者亲身感受了这一节日的独特魅力。</p><p>送冬节是俄罗斯多神教时期流传下来的传统节日。顾名思义，送冬节有“别寒冬、迎暖春”之意。同时，送冬节又称谢肉节、烤<a href="http://m.so.com/s?q=%E8%96%84%E9%A5%BC&amp;src=newstranscode" class="qkw">薄饼</a>周。这是因为送冬节后是东正教为期40天的大斋期，期间人们不能吃肉和娱乐，因而在斋期开始前一周，人们尽情享乐，为接下来<a href="http://m.so.com/s?q=%E8%8B%A6%E8%A1%8C%E5%83%A7&amp;src=newstranscode" class="qkw">苦行僧</a>式的生活积聚能量。今年的送冬节从3月7日持续到3月13日。</p><p>进入活动会场，记者很快就被<a href="http://m.so.com/s?q=%E8%8A%82%E6%97%A5%E7%9A%84%E6%AC%A2%E4%B9%90&amp;src=newstranscode" class="qkw">节日的欢乐</a>气氛所包围。舞台上，演员们身着<a href="http://m.so.com/s?q=%E4%BC%A0%E7%BB%9F%E6%B0%91%E6%97%8F%E6%9C%8D%E8%A3%85&amp;src=newstranscode" class="qkw">传统民族服装</a>，打着手鼓、应着节拍、载歌载舞、好不热闹。互动环节里，大家一起拍拍掌跺跺脚，一起大声呐喊，声音里透着欢乐的调子，好像这样有声有力的动静能驱走严寒，给来年生活带来一个好的开端!</p><p>孩子们手里拿着气球，围在舞台周围，随着音乐、鼓点欢呼雀跃。暖洋洋的笑脸、清脆的童声驱散冬天的寒气，在这个迎春的日子里让人格外舒心、快乐。俄罗斯圆圈舞在这样的活动里不可或缺，陌生人之间也挽着手、转着圈、跟着音乐节拍摆动。围成的圆圈，载着欢歌笑语，温暖着每一个参与者。</p><p>活动的举办者<a href="http://m.so.com/s?q=%E6%8B%89%E9%87%91&amp;src=newstranscode" class="qkw">拉金</a>诺夫·尼古拉耶夫是一名<a href="http://m.so.com/s?q=%E4%B9%90%E5%9B%A2%E6%8C%87%E6%8C%A5&amp;src=newstranscode" class="qkw">乐团指挥</a>。他表示，大家能在这样的节日里聚在一起，是他非常愿意见到的事情。</p><p>游戏也是这个传统节日里不可分割的一部分。袋鼠跳<a href="http://m.so.com/s?q=%E6%8E%A5%E5%8A%9B%E8%B5%9B&amp;src=newstranscode" class="qkw">接力赛</a>和木马接力赛让孩子们热情高涨。他们站在队伍里，等待着自己出场，探出小脑袋不时张望，看看自己的队伍有没有领先，脸上流露出笑容和焦急的期盼。</p><p>来自符拉迪沃斯托克希望区一位带着孩子的母亲对记者说:“我们非常喜欢今天的活动，孩子们很开心，我们度过了非常愉快的一天。我的女儿在图书馆里也参加了送冬节的活动，老师给学生们介绍送冬节的由来以及这个传统节日对于俄罗斯人民的意义。对于一个家庭来说，这是一个欢乐的团圆节，我们会一起烤薄饼，一起庆祝，非常欢乐。”</p><p>这边游戏还在进行中，远处一位骑着马的姑娘徐徐而来。蓝衣带来凛冽的感觉，<a href="http://m.so.com/s?q=%E7%99%BD%E8%89%B2%E9%9B%AA%E8%8A%B1&amp;src=newstranscode" class="qkw">白色雪花</a>的装饰则表明了她的身份。她是来跟大家告别的<a href="http://m.so.com/s?q=%E5%86%AC%E5%A7%91%E5%A8%98&amp;src=newstranscode" class="qkw">冬姑娘</a>。她祝福大家，问候感受到她严寒魅力的人们，同时与人们相约来年再聚。送走冬姑娘，春姑娘头戴花环缓缓登场。她笑容和煦、服饰鲜艳、头顶上的花环也昭示着春天的温暖和美好。</p><p>送冬节的活动最后会烧掉一个象征冬日的稻草人，表明寒冬已过。熊熊的火焰中，稻草人化为灰烬，迎接它的则是生机勃勃的春天。活动结束后，每个人都可以得到送冬节必不可少的传统食物--金黄色的薄饼，它象征着春日的暖阳，也映衬出人们喜悦的脸庞。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.china.com.cn/live/2016-03/14/content_35527637.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='e83141ffe47190bc4a2b5f9f552cf724'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>节日的欢乐</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%8A%82%E6%97%A5%E7%9A%84%E6%AC%A2%E4%B9%90&amp;pn=1&amp;pos=10&amp;m=b709cd5e8b7055e267d50b93744b29d214209512&amp;u=http%3A%2F%2Fnews.163.com%2F16%2F0311%2F09%2FBHS9H33500014AEE.html" data-pos="1"> 舞钢农商银行举办登山活动 庆祝国际劳动妇女节(组图) </a>   <li> <a href="/transcode?q=%E8%8A%82%E6%97%A5%E7%9A%84%E6%AC%A2%E4%B9%90&amp;pn=2&amp;pos=1&amp;m=4b28149abd654cef4bd8ad08de8c3761ccd689bb&amp;u=http%3A%2F%2Fwww.fmprc.gov.cn%2Fweb%2Fwjbz_673089%2Fxghd_673097%2Ft1345972.shtml" data-pos="2"> 外交小灵通:王毅外长没有讲述的故事 </a>   <li> <a href="/transcode?q=%E8%8A%82%E6%97%A5%E7%9A%84%E6%AC%A2%E4%B9%90&amp;pn=2&amp;pos=2&amp;m=e8f1940b18aaa629d288916d31d50f67f6ff91f5&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fgznews_0310%2F4659745.html" data-pos="3"> 新蒲新区开投公司开展三八妇女节庆祝活动 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '通讯:俄罗斯远东民众欢庆送冬节' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '通讯:俄罗斯远东民众欢庆送冬节'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";