s:14312:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>情侣首次精心的约会 只要10块钱- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">情侣首次精心的约会 只要10块钱</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-14 21:31:18</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t017b75014073136187.jpg?size=566x296"></p><p>两个人之间谈恋爱避免不了约会，约会免不了花钱。其实，不用花巨资，10块钱，也能完美打造第一次精心的约会，没开玩笑，开看一下吧!</p><p class="header">情侣首次精心的约会 只要10块钱</p><p>如果你遇到了真爱，那她一定是一个不会嫌弃你没有钱的人。这样的情况下，你带她去哪里都不是最重要的，重要的是跟谁在一起。那到底去哪里才能花10块完成一次约会呢?答案是--公园。</p><p>公园之所以叫公园，是因为它是一个公共场所，只要是涉及公共，一般都不需要消费。在这里，你可以跟她聊聊天，了解对方，一起看看虫鸟花草，是第一次约会的最好地方。</p><p>那10块要怎么花掉呢?你这样干坐着，只是看看虫鸟花草，聊聊天，时间长了也会累，口也会渴。怎么办呢?你可以花费3元买两瓶矿泉水，聊天的时候口渴就可以喝了。</p><p>当然，剩下的7块也不能浪费，等到一天中较为温暖的时候，你可以跑去为她买一个可爱多3.5，自己肯定不要买，因为你要让她感觉你是一个成熟的有个人魅力的男生，吃<a href="http://m.so.com/s?q=%E9%9B%AA%E7%B3%95&amp;src=newstranscode" class="qkw">雪糕</a>会失了自己颜面。剩下的3.5买7个口味不同的<a href="http://m.so.com/s?q=%E9%98%BF%E5%B0%94%E5%8D%91%E6%96%AF%E6%A3%92%E6%A3%92%E7%B3%96&amp;src=newstranscode" class="qkw">阿尔卑斯棒棒糖</a>，可爱多的含义大家都看过广告，这是一款爱的雪糕，这也相当于你在跟她表白。如果你有歌喉，还可以唱唱<a href="http://m.so.com/s?q=%E6%9E%97%E4%BF%8A%E6%9D%B0&amp;src=newstranscode" class="qkw">林俊杰</a>的可爱多。你们就可以这样愉快的度过两个小时。</p><p>当然<a href="http://m.so.com/s?q=%E6%A3%92%E6%A3%92%E7%B3%96&amp;src=newstranscode" class="qkw">棒棒糖</a>肯定是分开的时候送，放在口袋里面，肯定会鼓鼓的。当她问你是什么的时候，你可以告诉她，是惊喜。然后她要看的时候，你就说:“可以，你闭上眼睛!”当她闭上眼睛的时候，你可以偷偷亲她的脸颊。只要是喜欢你，应该都不会介意，当她意识到不对睁开眼睛的时候，你就可以把7个棒棒糖拿在她眼前并且告诉她:“这个有七个口味的棒棒糖，一个星期有七天，我希望你的每一天都有不一样的精彩，但是你的每一天都会有同样的一个我守候。”</p><p>以上真的不是开玩笑，情侣之间如果是真爱是不会计较约会的花销大小的。当然了，也不能每次都这样，那女朋友会觉得你小气而吓跑的哦!</p><p>添加乐鱼老师的<a href="http://m.so.com/s?q=%E5%BE%AE%E4%BF%A1&amp;src=newstranscode" class="qkw">微信</a>号:Lovemee8，获得一对一的咨询机会。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://mt.sohu.com/20160314/n440400000.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='58f024aec98636efcb693b72eead1328'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>首次约会</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%A6%96%E6%AC%A1%E7%BA%A6%E4%BC%9A&amp;pn=1&amp;pos=3&amp;m=961a58b9cb334a63648c87c0e55553a1df942eed&amp;u=http%3A%2F%2Fmt.sohu.com%2F20160314%2Fn440400000.shtml" data-pos="1"> 情侣<b>首次</b>精心的<b>约会</b> 只要10块钱 </a>   <li> <a href="/transcode?q=%E9%A6%96%E6%AC%A1%E7%BA%A6%E4%BC%9A&amp;pn=1&amp;pos=4&amp;m=ed71f1e8b9f873b212009f999c7d9c2fd2baf6ce&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fent%2Fhot%2F4584337_1.html" data-pos="2"> 陈小春应采儿<b>首次约会</b>地点曝光 揭秘应采儿陈小春情史 </a>   <li> <a href="/transcode?q=%E9%A6%96%E6%AC%A1%E7%BA%A6%E4%BC%9A&amp;pn=1&amp;pos=5&amp;m=e7ecb74b981684747e0dfb087a3cc2edcb749c48&amp;u=http%3A%2F%2Fwww.yznews.com.cn%2Fyzsbs%2Fhtml%2F2016-03%2F14%2Fcontent_768088.htm" data-pos="3"> 16所学校足球老师组队 每月"<b>约会</b>"一次 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '情侣首次精心的约会 只要10块钱' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '情侣首次精心的约会 只要10块钱'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";