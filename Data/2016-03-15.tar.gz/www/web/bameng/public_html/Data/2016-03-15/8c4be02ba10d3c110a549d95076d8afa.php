s:27817:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>天津医科大学2015年招生章程- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">天津医科大学2015年招生章程</h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2015-05-12 10:54:00</time></p> </header>  <div id="news-body"><p class="header">第一章 总则</p><p>第一条 为规范我校招生工作，保证学校依法招生，维护考生合法权益，根据<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E5%8D%8E%E4%BA%BA%E6%B0%91%E5%85%B1%E5%92%8C%E5%9B%BD%E6%95%99%E8%82%B2%E6%B3%95%E3%80%8B&amp;src=newstranscode" class="qkw">《中华人民共和国教育法》</a>、《中华人民共和国高等教育法》和<a href="http://m.so.com/s?q=%E3%80%8A%E6%95%99%E8%82%B2%E9%83%A8%E5%85%B3%E4%BA%8E%E5%81%9A%E5%A5%BD2015%E5%B9%B4%E6%99%AE%E9%80%9A%E9%AB%98%E7%AD%89%E5%AD%A6%E6%A0%A1%E6%8B%9B%E7%94%9F%E5%B7%A5%E4%BD%9C%E7%9A%84%E9%80%9A%E7%9F%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《教育部关于做好2015年普通高等学校招生工作的通知》</a>有关规定，结合我校实际情况，制定本章程。</p><p>第二条 本章程是<a href="http://m.so.com/s?q=%E5%A4%A9%E6%B4%A5%E5%8C%BB%E7%A7%91%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">天津医科大学</a>向社会公布有关招生政策、规定及相关信息的基本方式，也是天津医科大学开展招生工作和录取新生的基本依据。</p><p class="header">第三条 学校概况</p><p class="header">一、学校名称:天津医科大学</p><p>二、办学类型:公办全日制<a href="http://m.so.com/s?q=%E6%99%AE%E9%80%9A%E9%AB%98%E7%AD%89%E5%AD%A6%E6%A0%A1&amp;src=newstranscode" class="qkw">普通高等学校</a></p><p>三、办学层次:博士、硕士、本科、高职</p><p class="header">四、学校代码:10062</p><p>五、学校地址:主校区:天津市<a href="http://m.so.com/s?q=%E5%92%8C%E5%B9%B3%E5%8C%BA&amp;src=newstranscode" class="qkw">和平区</a>气象台路22号</p><p><a href="http://m.so.com/s?q=%E5%B9%BF%E4%B8%9C%E8%B7%AF&amp;src=newstranscode" class="qkw">广东路</a>校区:天津市河西区广东路1号</p><p class="header">六、学校基本概况:</p><p>天津医科大学的前身<a href="http://m.so.com/s?q=%E5%A4%A9%E6%B4%A5%E5%8C%BB%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">天津医学院</a>创建于1951年，是新中国成立后原国家政务院批准建立的高等医学院校，著名内分泌学家、医学教育家朱宪彝教授为首任校长。1993年，天津市委、市政府决定天津医学院与天津第二医学院合并组建天津医科大学，同年12月得到国家教委批准。1994年6月，天津医科大学正式组建成立。学校现任党委书记为姚智教授，校长为著名生物化学与分子生物学家、中国科学院院士<a href="http://m.so.com/s?q=%E5%B0%9A%E6%B0%B8%E4%B8%B0&amp;src=newstranscode" class="qkw">尚永丰</a>教授。学校为国家“211工程”重点建设院校。</p><p>天津医科大学是继协和医学院后，国家最早批准试办八年制的医学院校，也是首批试办七年制的15所院校之一。现有全日制本科以上在校生9676人，其中，本科生5330人，硕士生2826人，博士生441人，学历留学生1079人。</p><p>学校现有本科专业19个，博士学位授权一级学科7个，博士学位授权二级学科41个，硕士学位授权一级学科11个，硕士学位授权二级学科73个，博士后流动站6个。博士生导师229人，硕士生导师751名。</p><p>学校现有国家级特色专业5个，国家级专业综合改革试点1个，国家级精品视频公开课3门，国家级精品资源共享课5门，国家级精品课程7门，国家级双语示范课程3门，国家级教学团队2个，国家级人才培养模式创新实验区3个，国家级实验教学示范中心2个。自建校以来，学校已培养了40000余名各层次医学人才。2002年和2008年，学校均以优秀成绩通过教育部本科教学和七年制高等医学教育教学工作水平评估。学校分别通过了护理专业、口腔医学专业和临床医学专业认证。2005年以来，学校获得国家级教学成果一等奖1项、二等奖1项，市级教学成果一等奖8项、二等奖12项。</p><p>学校拥有一批国内外知名的教授、学者，现有教职工8970人，其中各类专业技术人员8509人，包括正高级专业技术人员568人，副高级专业技术人员1041人。现有中国科学院院士1人，<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E5%B7%A5%E7%A8%8B%E9%99%A2%E9%99%A2%E5%A3%AB&amp;src=newstranscode" class="qkw">中国工程院院士</a>2人，国家“千人计划”4人，教育部“长江学者”特聘教授5人，教育部“长江学者”特聘讲座教授5人，“973”首席科学家4人，国家杰出青年科学基金资助者4人，国家“万人计划”领军人才3人，国家自然基金委“优秀青年科学基金”资助者3人，人事部新世纪百千万人才工程国家级人选5人，教育部新世纪优秀人才17人，国家有突出贡献专家6人，<a href="http://m.so.com/s?q=%E5%8D%AB%E7%94%9F%E9%83%A8&amp;src=newstranscode" class="qkw">卫生部</a>有突出贡献中青年专家6人。</p><p>学校现有国家级重点学科5个，“211工程”重点建设学科10个，<a href="http://m.so.com/s?q=%E5%A4%A9%E6%B4%A5%E5%B8%82&amp;src=newstranscode" class="qkw">天津市</a>重点学科17个，省部级重点实验室14个，研究所14个。“十五”以来，学校共承担国家和各部委及天津市科研项目2414项，获省部级及其以上科技奖励261项，其中国家级科技奖励5项，获省部级一等奖12项、二等奖74项。</p><p>学校有6所<a href="http://m.so.com/s?q=%E5%A4%A7%E5%AD%A6%E5%8C%BB%E9%99%A2&amp;src=newstranscode" class="qkw">大学医院</a>，15所非直属临床学院，1所教学医院，共计19216张教学床位。大学医院有:总医院、第二医院、<a href="http://m.so.com/s?q=%E8%82%BF%E7%98%A4%E5%8C%BB%E9%99%A2&amp;src=newstranscode" class="qkw">肿瘤医院</a>、口腔医院、代谢病医院、眼科医院。肿瘤医院是全国首批国家肿瘤临床医学研究中心。13个专科入选国家临床重点专科建设项目。</p><p>学校先后与22个国家的96所大学和科研机构建立了学术交流与合作关系，成立了“外国专家顾问委员会”。聘请了119位世界知名医学专家、教授担任我校各学科的名誉教授和客座教授，在医学和生物医药领域开展高水平国际科技合作。</p><p class="header">第二章 组织机构与监督机制</p><p>第四条 学校设有招生委员会，全面负责学校的招生工作，制定招生政策、招生计划，决定有关招生的重大事宜。招生办公室负责本科、高职招生日常工作。</p><p>第五条 招生委员会下设招生监察办公室，对学校招生工作进行监督、检查。监察办公室常务机构设在监察处，负责日常工作的组织与协调。</p><p class="header">第三章 招生计划及收费标准</p><p>第六条 学校根据发展规模、办学条件、学科发展、生源状况和社会需求，按照教育部核准下达的具体招生专业、招生人数，面向全国27个省、自治区、直辖市制定2015年招生计划，按照教育部核准下达的招生计划在规定时间内寄送到各省、自治区、直辖市招生委员会。通过各省、自治区、直辖市招生主管部门向考生公布，同时我校还将通过媒体及其它方式向社会公布。分省分专业招生计划以有关省级招办公布的招生计划为准。在录取过程中我校根据各招生省、自治区、直辖市的生源及招生计划执行情况，按教育部相关文件精神，经校招生工作领导小组批准，在总计划内可对招生计划作适当的调整。预留计划数不超过学校招生计划的1%，主要用于生源较好的省、自治区和直辖市以及最低分同分录取或顺延录取。</p><p class="header">第七条 收费标准</p><p>一、学费标准:本科4400~5800元/生、年，高职收费标准为5500元/生、年。</p><p>“5+3”一体化专业研究生阶段按照研究生学费标准收费。</p><p>二、住宿费标准:根据不同住宿条件，住宿费为800~1000元/生、年。</p><p>各专业收费标准详见省、自治区、直辖市招生委员会公布的招生计划表和我校下发的新生报到须知。如政府对当年度收费标准进行调整，以政府规定的标准为准。</p><p class="header">第四章 录取规则</p><p>第八条 学校招生录取工作遵循公平竞争、公正选拔、公开程序的原则;执行国家教育部和各省、自治区、直辖市招生委员会制定的录取政策，以及本章程公布的有关规定;以考生填报的志愿和高考文化课成绩为主要录取依据，兼顾德、智、体、美全面考核，择优录取。录取过程中，自觉接受各省、自治区、直辖市招生委员会、纪检监察部门、考生和社会各界的监督。</p><p>第九条 院校志愿录取执行所在省、自治区及直辖市的相关政策，分为顺序志愿和平行志愿两种录取规则。</p><p>按照顺序志愿规则录取:院校录取以“志愿优先、按志愿顺序依次投档”为原则，在同一科类、相应批次的省、自治区、直辖市录取控制分数线上，报考我校第一志愿考生从高分到低分录取，当报考人数少于招生计划时，录取第二志愿考生，依次类推，院校志愿不设分数级差;</p><p>按照平行志愿规则录取:院校录取以“分数优先、遵循志愿、一次投档”为原则，先对同一科类、相应批次的省、自治区、直辖市录取控制分数线上符合条件的考生，按高考成绩从高分到低分进行排序，依次检索每位考生填报的高校志愿;若考生符合其中一所以上高校的投档条件时，则投档到序号在前的高校;若考生只符合其中一所高校的投档条件，则直接投档到该高校。</p><p>第十条 专业志愿录取以分数优先为原则，先对同一科类、相应批次学校录取控制分数线上符合条件的考生，按高考成绩从高分到低分排序，依次检索每位考生填报的专业志愿，若考生符合其中一个以上专业的录取条件时，则录取到序号在前的专业;若考生只符合其中一个专业的录取条件，则直接录取到该专业;若考生高考成绩达到学校录取控制分数线且符合录取条件，但未达到所填报专业的录取分数，凡服从专业调剂者将被调剂到未录满的专业;不服从调剂者，作退档处理，专业志愿不设分数级差。</p><p>第十一条 多元评价选拔模式的省市录取原则。</p><p>一、在江苏省录取中，实行先分数后等级规则排序，决定能否录取与所录专业。选测科目和等级按照招生计划中公布的内容为准。</p><p>二、在天津市录取中，在天津市普通高中学业水平考试中语文、数学、物理、化学、生物、政治、地理、历史等8个学科成绩等第均获得A(简称“8A”)的考生，如投档后排名在院校前10%的，可优先安排专业。优先安排专业时，按照8A考生的高考成绩和专业志愿，以高考分数优先的原则安排专业。</p><p>在天津市录取中，如考生高考分数相同，依次参考普通高中学业水平考试成绩和综合素质评价结果。如考生学业水平考试成绩和综合素质评价结果相同，再依次参考学业水平单科考试成绩，即文科考生依次参考化学、生物、数学、物理的学业水平考试成绩;理科考生依次参考语文、政治、历史、地理的学业水平考试成绩。〔比较考生的<a href="http://m.so.com/s?q=%E9%AB%98%E4%B8%AD%E5%AD%A6%E4%B8%9A%E6%B0%B4%E5%B9%B3%E8%80%83%E8%AF%95&amp;src=newstranscode" class="qkw">高中学业水平考试</a>成绩时，先比较获得A等第的个数，如A等第个数相同，再比较获得B等第的个数，以此类推。评价考生的综合素质时，依据考生的学业类(含学业成绩、课程修习情况)和非学业类(含道德品质、社会实践、社区服务、获奖情况)两方面情况综合比较，进行评价。〕</p><p>三、在内蒙古自治区录取中，实行“招生计划1:1范围内按专业志愿排队录取”的录取规则。</p><p>第十二条 对政策加分考生的录取，按照教育部规定的实行考生属地化管理的原则，执行考生所在省、自治区、直辖市招生委员会制定的加分政策和录取规定。体育特长生必须经过学校面试考核。临床医学(5+3)、口腔医学(5+3)、临床医学(医学影像学，5+3)、临床医学、基础医学专业，在学生德、智、体全面发展的前提下，不考虑任何加分因素，按考生原始高考成绩录取。</p><p>第十三条 同等条件下，优先录取获得省级优秀学生、优秀学生干部、三好学生等荣誉称号及专业相关科目分数较高的考生。</p><p>第十四条 体检标准依照教育部、卫生部、中国残疾人联合会2003年颁发的<a href="http://m.so.com/s?q=%E3%80%8A%E6%99%AE%E9%80%9A%E9%AB%98%E7%AD%89%E5%AD%A6%E6%A0%A1%E6%8B%9B%E7%94%9F%E4%BD%93%E6%A3%80%E5%B7%A5%E4%BD%9C%E6%8C%87%E5%AF%BC%E6%84%8F%E8%A7%81%E3%80%8B&amp;src=newstranscode" class="qkw">《普通高等学校招生体检工作指导意见》</a>执行。鉴于医学类专业的培养要求和就业特点，建议报考护理、口腔专业身高低于1.55米者、残疾考生慎报。</p><p>第十五条 新生入学后，学校将重新对考生进行资格和身体健康状况审查，对弄虚作假、不符合标准的考生，按照<a href="http://m.so.com/s?q=%E3%80%8A%E5%A4%A9%E6%B4%A5%E5%8C%BB%E7%A7%91%E5%A4%A7%E5%AD%A6%E6%99%AE%E9%80%9A%E5%85%A8%E6%97%A5%E5%88%B6%E6%9C%AC%E7%A7%91%E7%94%9F%E5%AD%A6%E7%B1%8D%E7%AE%A1%E7%90%86%E8%A7%84%E5%AE%9A%E3%80%8B&amp;src=newstranscode" class="qkw">《天津医科大学普通全日制本科生学籍管理规定》</a>、《天津医科大学普通全日制专科生学籍管理规定》等规章制度进行处理。</p><p>第十六条 非英语专业的公共外语课程均为英语,小语种考生慎重填报。报考英语专业的考生，须参加统一组织的英语口语测试且成绩合格。护理学专业有性别限制，具体见招生计划。</p><p>第十七条 报考本校、符合入学条件的考生，经所在省、自治区、直辖市招生主管部门批准后，学校即向其发放<a href="http://m.so.com/s?q=%E5%BD%95%E5%8F%96%E9%80%9A%E7%9F%A5%E4%B9%A6&amp;src=newstranscode" class="qkw">录取通知书</a>，录取通知书一律以特快专递方式寄出。</p><p class="header">第五章 后续管理</p><p>第十八条 按照国家招生规定录取的新生，持录取通知书，按学校有关要求和规定的期限到校办理入学手续。因故不能按期入学者，应当向学校请假。未请假或者请假逾期者，除因不可抗力等正当事由以外，视为放弃入学资格。</p><p>第十九条 新生入学后，学校依据《天津医科大学普通全日制本科生学籍管理规定》、<a href="http://m.so.com/s?q=%E3%80%8A%E5%A4%A9%E6%B4%A5%E5%8C%BB%E7%A7%91%E5%A4%A7%E5%AD%A6%E6%99%AE%E9%80%9A%E5%85%A8%E6%97%A5%E5%88%B6%E4%B8%93%E7%A7%91%E7%94%9F%E5%AD%A6%E7%B1%8D%E7%AE%A1%E7%90%86%E8%A7%84%E5%AE%9A%E3%80%8B&amp;src=newstranscode" class="qkw">《天津医科大学普通全日制专科生学籍管理规定》</a>等规章制度进行管理，按照教学计划对学生进行培养。学校实施弹性学制，无转专业政策。</p><p>第二十条 学校专业介绍、奖贷学金政策等详细信息见<a href="http://m.so.com/s?q=%E3%80%8A%E5%A4%A9%E6%B4%A5%E5%8C%BB%E7%A7%91%E5%A4%A7%E5%AD%A62015%E5%B9%B4%E6%8B%9B%E7%94%9F%E7%AE%80%E7%AB%A0%E3%80%8B&amp;src=newstranscode" class="qkw">《天津医科大学2015年招生简章》</a>。学校设立校长奖学金，凡高出本科第一批次录取线160分的各省考生(不含各种政策性加分)，报考我校并被录取者，学校免除其在学期间学费和住宿费。</p><p>第二十一条 学生完成规定学业经审查达到毕业标准的，颁发天津医科大学全日制普通高等学校毕业证书，高职毕业生的毕业证书注明“高职”字样。对符合天津医科大学学位授予条件的毕业生，颁发学位证书。</p><p class="header">第六章 附则</p><p>第二十二条 本章程仅适用于2015年普通本科、高职招生工作。</p><p>第二十三条 本章程经学校招生委员会审查通过，报上级主管部门审核。</p><p>第二十四条 本章程由天津医科大学招生办公室负责解释。</p><p>第二十五条 在招生咨询过程中我校咨询人员的意见、建议仅作为考生填报志愿的参考，不作为学校录取的依据及承诺。</p><p>第二十六条 学校以往有关招生工作的要求、规定如与本章程冲突，以本章程为准。</p><p>第二十七条 招生咨询与录取信息公布方式。</p><p>网址:http://web.tmu.edu.cn/cn/jwch/recruit/index.htm</p><p>E-mail:zhaoban@tijmu.edu.cn</p><p>招生期间咨询电话:022-83336711</p><p class="header">邮编:300070</p><p>地址:天津市和平区<a href="http://m.so.com/s?q=%E6%B0%94%E8%B1%A1%E5%8F%B0%E8%B7%AF&amp;src=newstranscode" class="qkw">气象台路</a>22号</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://edu.people.com.cn/n/2015/0512/c244541-26987597.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='617b2067f0cb50c465c13f31ca1b67a3'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>天津医科大学</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '天津医科大学2015年招生章程' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '天津医科大学2015年招生章程'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";