s:18760:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>深圳市第23期小型汽车号牌号码拍卖公告- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">深圳市第23期小型汽车号牌号码拍卖公告</h1> <p id="source-and-time"><span id=source>和讯网</span><time id=time>2016-03-14 14:37:35</time></p> </header>  <div id="news-body"><p>受<a href="http://m.so.com/s?q=%E6%B7%B1%E5%9C%B3%E5%B8%82&amp;src=newstranscode" class="qkw">深圳市</a>财政委员会委托，定于2016年3月29日-30日在www.<a href="http://m.so.com/s?q=szpm123&amp;src=newstranscode" class="qkw">szpm123</a>.com(小型汽车号牌号码拍卖平台)公开拍卖粤BA699J等300个小型汽车号牌号码:</p><p class="header">一、竞买人资格</p><p>除财政核发、核补经费的行政事业单位和国有企业、社会团体及部队外，凡已购车并依据<a href="http://m.so.com/s?q=%E3%80%8A%E6%B7%B1%E5%9C%B3%E5%B8%82%E5%B0%8F%E6%B1%BD%E8%BD%A6%E5%A2%9E%E9%87%8F%E8%B0%83%E6%8E%A7%E7%AE%A1%E7%90%86%E5%AE%9E%E6%96%BD%E7%BB%86%E5%88%99%E3%80%8B&amp;src=newstranscode" class="qkw">《深圳市小汽车增量调控管理实施细则》</a>规定取得深圳市小汽车指标证明文件或符合<a href="http://m.so.com/s?q=%E3%80%8A%E6%B7%B1%E5%9C%B3%E5%B8%82%E4%BA%BA%E6%B0%91%E6%94%BF%E5%BA%9C%E5%85%B3%E4%BA%8E%E5%AE%9E%E8%A1%8C%E5%B0%8F%E6%B1%BD%E8%BD%A6%E5%A2%9E%E9%87%8F%E8%B0%83%E6%8E%A7%E7%AE%A1%E7%90%86%E7%9A%84%E9%80%9A%E5%91%8A%E3%80%8B&amp;src=newstranscode" class="qkw">《深圳市人民政府关于实行小汽车增量调控管理的通告》</a>规定无需申请办理小汽车指标证明文件情形，取得车管所出具的机动车业务受理凭证(注册登记、转移登记)的9座(含9座)以下小型载客汽车的单位或个人均可参加竞买。</p><p>2014年12月29日18时前已购车并取得车管所出具的机动车业务受理凭证(注册登记、转移登记)的9座(含9座)以下小型载客汽车的单位或个人亦可参加竞买。</p><p>特别提醒:因深圳市已实行小汽车增量调控管理政策，请有意竞买者认真阅读相关政策，慎重考虑参加竞买;已选取号牌号码的，不得参加小型汽车号牌号码拍卖;在参加小型汽车号牌号码竞拍过程中，不得以“十选一、自编自选”等其他方式选取汽车号牌号码;参加小型汽车号牌号码拍卖成功竞得者，不得再以“十选一、自编自选”等其他方式选取汽车号牌号码。</p><p class="header">二、参加竞买手续</p><p>1、须提交竞买资料:身份证明:个人提供本人身份证明，单位提供<a href="http://m.so.com/s?q=%E3%80%8A%E7%BB%84%E7%BB%87%E6%9C%BA%E6%9E%84%E4%BB%A3%E7%A0%81%E8%AF%81%E3%80%8B&amp;src=newstranscode" class="qkw">《组织机构代码证》</a>、《企业法人营业执照》、法定代表人证明书以及法定代表人身份证明。如委托他人代理竞买的，还须提供授权委托书及委托代理人身份证明;机动车业务受理凭证(注册登记、转移登记，须未选取号牌号码的);缴纳竞买保证金凭证;已在小型汽车号牌号码拍卖平台注册的手机号码(须真实，能联系车主本人)。</p><p>2、提交方式:将上述四项竞买资料(扫描件或清晰可辨识的照片)发送至深圳市公共资源拍卖中心电子邮箱:szsgpzx@163.com;或到深圳市公共资源拍卖中心现场提交。邮件须注明竞买人姓名、注册手机号码、缴纳竞买保证金账户的开户银行(代付款的须注明)。</p><p>3、提交时间:自本公告发布之日起至2016年3月24日17时止，逾期不予受理。</p><p class="header">三、竞买保证金</p><p>竞买人须缴纳10000元竞买保证金。必须以银行转账方式缴纳，在2016年3月24日17时前(以到账时间为准)转到以下账户:户名:深圳市公共资源拍卖中心;开户行:<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E5%B7%A5%E5%95%86%E9%93%B6%E8%A1%8C&amp;src=newstranscode" class="qkw">中国工商银行</a>(601398,股吧)深圳市国财支行;账号:4000027929200202224</p><p>竞买保证金付款人账户应是竞买人名下银行账户。如委托他人代付，缴款时必须注明手机号和 “代XXX付竞买保证金”。拍卖未成交的，于拍卖会结束后次日起3个工作日内按原账号全额无息退回竞买保证金;拍卖成交的，竞买保证金不冲抵成交价款、拍卖佣金，直接转为履约保证金，买受人在规定时间内办理成交确认手续的，于办结手续次日起3个工作日内按原账号全额无息退回履约保证金。</p><p class="header">四、成交确认及缴款手续</p><p>买受人必须在拍卖成交后次日起3个工作日内前往深圳市公共资源拍卖中心办理成交确认手续，签订成交确认书，缴纳全额成交价款并支付成交价款5%的拍卖佣金。买受人可现场刷卡或在市财政委委托的代收银行一次性缴纳成交价款;可通过转账、现场刷卡或现金支付拍卖佣金(如委托他人转账代付佣金，缴款时必须注明“代XXX付拍卖佣金”)。</p><p>办理成交确认手续须提交上述竞买资料项(验原件交复印件，须买受人签名或盖章;买受人为单位的，如现场签署成交确认书需携带公章办理)。</p><p>地址:深圳市福田区福中路17号国际人才大厦6楼605室;办公时间:周一至周五上午9:30-12:00，下午2:00-5:00;咨询电话:0755-82538376、82538378、82538379。</p><p class="header">五、其他事项</p><p>竞价成交的号牌号码不得更改，不得转卖，不得转赠。竞买须知、授权委托书(样式)等资料请登录小型汽车号牌号码拍卖平台(www.szpm123.com)、深圳市拍卖业协会网站(www.szaa2002.com)“拍卖信息”栏以及政府招标确定的12家拍卖机构<a href="http://m.so.com/s?q=%E6%B7%B1%E5%9C%B3%E5%B8%82%E6%8B%8D%E5%8D%96%E8%A1%8C%E6%9C%89%E9%99%90%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">深圳市拍卖行有限公司</a>、广东迅兴拍卖有限公司、深圳市<a href="http://m.so.com/s?q=%E4%B8%8D%E5%8A%A8%E4%BA%A7&amp;src=newstranscode" class="qkw">不动产</a>拍卖行有限公司、深圳市金槌拍卖行有限公司、广东<a href="http://m.so.com/s?q=%E6%BD%9C%E9%BE%99&amp;src=newstranscode" class="qkw">潜龙</a>拍卖有限公司、<a href="http://m.so.com/s?q=%E6%B7%B1%E5%9C%B3%E5%B8%82%E8%81%94%E5%90%88%E6%8B%8D%E5%8D%96%E6%9C%89%E9%99%90%E8%B4%A3%E4%BB%BB%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">深圳市联合拍卖有限责任公司</a>、广东旭通达拍卖有限公司、深圳市<a href="http://m.so.com/s?q=%E4%B8%9C%E5%AE%9D&amp;src=newstranscode" class="qkw">东宝</a>拍卖有限公司、广东华士德(深圳)拍卖行有限公司、深圳市中际汉威拍卖有限公司、广东和合拍卖行有限公司、广东惠丰拍卖有限公司网站查询。</p><p>六、竞价发放号牌号码及具体拍卖时间安排:</p><p class="header">拍卖会时间</p><p class="header">2016年3月29日上午9:30</p><p class="header">起拍价</p><p class="header">竞价阶梯</p><p class="header">竞价发放号牌号码(粤BXXXXX)</p><p>A699J、A699K、A699L、A699M、A699N、A699P、A699Q、A699R、A699S、A699T、A699U、A699V、A699W、A699X、A699Y、A699Z、B699A、B699B、B166A、B166F、B166G、B166H、B166L、B166M、B166N、B166P、B166Q、B166R、B166S、B166T、B166U、B166V、B166W、B166X、B166Y、B166Z、C188J、C188K、C188L、C188M、C188N、C188R、C188S、C188T、C188U、C188V、C188W、C188X、C188Y、C188Z</p><p class="header">5千元</p><p class="header">1千元</p><p class="header">附件: 1、竞买须知</p><p class="header">2、授权委托书</p><p class="header">3、常见问答</p><p class="header">4、流程指引</p><p class="header">5、拍卖号牌明细表</p><p class="header">深圳市联合拍卖有限责任公司</p><p class="header">深圳市拍卖行有限公司</p><p class="header">广东迅兴拍卖有限公司</p><p class="header">深圳市不动产拍卖行有限公司</p><p class="header">深圳市金槌拍卖行有限公司</p><p class="header">广东潜龙拍卖有限公司</p><p class="header">广东旭通达拍卖有限公司</p><p class="header">深圳市东宝拍卖有限公司</p><p class="header">广东华士德(深圳)拍卖行有限公司</p><p class="header">深圳市中际汉威拍卖有限公司</p><p class="header">广东和合拍卖行有限公司</p><p class="header">广东惠丰拍卖有限公司</p><p>2016年3月11日</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://auto.hexun.com/2016-03-14/182745212.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='2976e8749994d1db81777d09d88655b0'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>竞买须知</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '深圳市第23期小型汽车号牌号码拍卖公告' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '深圳市第23期小型汽车号牌号码拍卖公告'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";