s:14843:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>四季财行酒令，品酒论英雄- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">四季财行酒令，品酒论英雄</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-01 15:03:40</time></p> </header>  <div id="news-body"><p><img src="http://p32.qhimg.com/t01d2d74f3b6c016897.png?size=536x401"></p><p>白酒是我国独有的传统饮品，历史悠久，源远流长。在中国的传统文化与<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E4%BA%BA%E7%9A%84%E5%BF%83%E7%90%86&amp;src=newstranscode" class="qkw">中国人的心理</a>传承中，白酒都有着独特的地位。作为一种特殊的文化形式，中国白酒文化长期以来形成了特有的文化生态。</p><p>中国的白酒，大多数是以粮食酿造的。它依附于农业，是农业经济的一部分。人常说“酒足饭饱”，其实是饭饱酒足，人民生活先富足而后才出现酿酒业。所以说，白酒是社会文明的标志。品质上好的白酒馥郁芳香，醇厚甘鲜，回味无穷。细品慢酌，便可以尝到各种滋味。而且往往随着时间的久远会更为浓烈。所以白酒是陈的香。其营养物质含量高，而且易被人体消化和吸收。因此，如果啤酒被列为营养食品，称为“液体面包”的话，白酒被誉为“液体蛋糕”是当之无愧的。</p><p>酒作为一种特殊的商品，给人们的生活也增添了不少丰富的色彩。白酒不可以用来解渴，是用来表达情感、表现品位、点缀美好生活的奢侈品。自从我们的老祖宗从腐烂了的野果的酸香味中受到启发，发明了酿酒术，制作出人间醇厚甘香的白酒，从此人类的生活丰富多彩了许多，人类的文化也变得斑斓多姿。</p><p>酒令文化是饮酒过程中的另外一个文明的标志。酒令对于活跃酒席气氛，增强交流沟通情感，还有传递知识起到了一定的作用。古人行酒令把<a href="http://m.so.com/s?q=%E7%BB%8F%E5%8F%B2%E7%99%BE%E5%AE%B6&amp;src=newstranscode" class="qkw">经史百家</a>、诗文词曲、歌谣谚语、典故对联等等文化内容，都出神入化地囊括到酒令中去了。酒令是对人的聪明才智、知识水平、文学修养和应变能力的严峻考验。</p><p>我国还有许多的<a href="http://m.so.com/s?q=%E9%85%92%E4%BF%97&amp;src=newstranscode" class="qkw">酒俗</a>与酒习，也是色彩艳丽的民族文化。生活上的酒俗与酒习有:有婚嫁酒，生丧酒、寿酒、时节酒、清明酒、<a href="http://m.so.com/s?q=%E7%AB%AF%E5%8D%88&amp;src=newstranscode" class="qkw">端午</a>酒、生活酒、新居酒，宴宾酒，除游乐性的如“元宵赏灯”、“中秋赏月”、“重阳登高”、“赏菊品蟹”等约亲友小酌外，尚有“洗尘酒”、“接风酒”、“饯行酒”、“送别酒”等。另外，还有“会酒”、“罚酒”、“谢情酒”等等。</p><p>中国人爱喝酒是一种习俗，尤其是一边喝酒，一边行酒令，这其中更是包含了<a href="http://m.so.com/s?q=%E4%B8%AD%E5%8D%8E%E6%B0%91%E6%97%8F&amp;src=newstranscode" class="qkw">中华民族</a>很多的文化，例如酒桌礼仪，<a href="http://m.so.com/s?q=%E4%BA%A4%E5%BE%80%E7%A4%BC%E4%BB%AA&amp;src=newstranscode" class="qkw">交往礼仪</a>等等，今后跟小酒妹一起品美酒，论英雄，行酒令，真是人生一大快事啊!</p><p>关注我们<a href="http://m.so.com/s?q=%E5%BE%AE%E4%BF%A1&amp;src=newstranscode" class="qkw">微信</a>【四季财白酒】或登录官网www.sjc023.cn，了解更多四季财白酒资讯哦!</p><p>重庆四季财酒类销售有限公司总部位于重庆<a href="http://m.so.com/s?q=%E4%BA%91%E9%98%B3&amp;src=newstranscode" class="qkw">云阳</a>，公司是集生产和...</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://mt.sohu.com/20160301/n439007332.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='be28e1ea0b3aecb76d8dc4fdd0364a12'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>品酒知识</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%93%81%E9%85%92%E7%9F%A5%E8%AF%86&amp;pn=1&amp;pos=6&amp;m=c4376405f111ec29b9805a285a923f9749fe4ee7&amp;u=http%3A%2F%2Fmt.sohu.com%2F20150514%2Fn413049536.shtml" data-pos="1"> 红酒小<b>知识</b>:怎样<b>品酒</b>才是正确的? </a>   <li> <a href="/transcode?q=%E5%93%81%E9%85%92%E7%9F%A5%E8%AF%86&amp;pn=1&amp;pos=7&amp;m=1d99c84740a530aa8bb1f66352647291c7332a7f&amp;u=http%3A%2F%2Fchihe.sohu.com%2F20160301%2Fn439065073.shtml" data-pos="2"> WSET国际<b>品酒</b>师课程初级/中级深圳即将开课 </a>   <li> <a href="/transcode?q=%E5%93%81%E9%85%92%E7%9F%A5%E8%AF%86&amp;pn=1&amp;pos=8&amp;m=d473dcb23800821b412dc923a77fc624149428cf&amp;u=http%3A%2F%2Fchihe.sohu.com%2F20160301%2Fn439019985.shtml" data-pos="3"> 【漂洋过海来喂你】:<b>品酒</b>人生先来杯威士忌 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '四季财行酒令，品酒论英雄' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '四季财行酒令，品酒论英雄'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";