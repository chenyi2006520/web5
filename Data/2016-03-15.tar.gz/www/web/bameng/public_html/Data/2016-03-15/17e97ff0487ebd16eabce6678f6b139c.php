s:17134:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>QQ情侣个性签名_愿得一人心、白首不分离- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">QQ情侣个性签名_愿得一人心、白首不分离</h1> <p id="source-and-time"><span id=source>太平洋电脑网</span><time id=time>2015-01-30 14:42:24</time></p> </header>  <div id="news-body"><p class="header">呼吸着有你的味道，不能休息。</p><p class="header">呼吸着有爱的空气，不能停息</p><p>我上辈子欠了多少债，<a href="http://m.so.com/s?q=%E9%81%87%E4%B8%8A%E4%BA%86%E4%BD%A0&amp;src=newstranscode" class="qkw">遇上了你</a>。</p><p class="header">你上辈子积了多少德，遇上了我。</p><p class="header">小时候，幸福是件很简单的事。</p><p class="header">长大后，简单是件很幸福的事。</p><p><a href="http://m.so.com/s?q=%E6%88%91%E7%9A%84%E7%88%B1%E5%BE%88%E7%AE%80%E5%8D%95&amp;src=newstranscode" class="qkw">我的爱很简单</a>，就是要让你感到快乐</p><p class="header">我的快乐很简单，就是和你一起生活</p><p>你的眼神魅力无法可挡丶<a href="http://m.so.com/s?q=%E8%AE%A9%E6%88%91%E7%88%B1%E4%B8%8A%E4%BD%A0&amp;src=newstranscode" class="qkw">让我爱上你</a>ㄣ</p><p>你的气质迷惑天生丽质丶<a href="http://m.so.com/s?q=%E4%BD%95%E5%BF%85%E5%9C%A8%E4%B8%80%E8%B5%B7&amp;src=newstranscode" class="qkw">何必在一起</a>ㄣ</p><p>我的手冷了/快到我身边把我的手捂暖//</p><p><a href="http://m.so.com/s?q=%E6%88%91%E7%9A%84%E5%BF%83%E7%A9%BA%E4%BA%86&amp;src=newstranscode" class="qkw">我的心空了</a>/快到我心里把我的心注满//</p><p class="header">为什么连一个小小的解释，我都要说。</p><p class="header">为什么连一个小小的解释，都不要说。</p><p><a href="http://m.so.com/s?q=%E5%A6%82%E6%9E%9C%E6%B2%A1%E6%9C%89%E6%84%9F%E8%A7%89&amp;src=newstranscode" class="qkw">如果没有感觉</a>，就不要给我错觉</p><p class="header">如果没有真心，就别扰乱我的心</p><p><a href="http://m.so.com/s?q=%E5%A6%82%E6%9E%9C%E6%B2%A1%E6%9C%89%E5%A6%82%E6%9E%9C&amp;src=newstranscode" class="qkw">如果没有如果</a>，曾经已是曾经，</p><p class="header">过去早已过去，做自己的自己，</p><p>轻轻的问候，渐渐演变为<a href="http://m.so.com/s?q=%E6%88%91%E4%BB%AC%E7%9A%84%E6%83%85&amp;src=newstranscode" class="qkw">我们的情</a></p><p class="header">你不要太难过,因为我一直都在</p><p class="header">你不要在寂寞,因为我不曾离开</p><p class="header">让你在没有我的地方疯狂，</p><p>让我<a href="http://m.so.com/s?q=%E5%9C%A8%E6%B2%A1%E6%9C%89%E4%BD%A0%E7%9A%84%E4%B8%96%E7%95%8C&amp;src=newstranscode" class="qkw">在没有你的世界</a>坚强”.</p><p>不管他爱不爱她，她永远都<a href="http://m.so.com/s?q=%E5%8F%AA%E7%88%B1%E4%BB%96&amp;src=newstranscode" class="qkw">只爱他</a>。</p><p class="header">不管她爱不爱他，她永远都只爱他。</p><p class="header">你对我的誓言，曾经又对多少人说过?</p><p class="header">我对你的诺言，以后将会对多少人说?</p><p><a href="http://m.so.com/s?q=%E6%88%91%E4%BB%AC%E7%9A%84%E6%97%B6%E6%97%B6%E5%88%BB%E5%88%BB&amp;src=newstranscode" class="qkw">我们的时时刻刻</a>，我记得很清楚。</p><p class="header">我们的点点滴滴，我记得很清楚。</p><p><a href="http://m.so.com/s?q=%E4%B8%8D%E8%A6%81%E7%AD%89%E6%88%91&amp;src=newstranscode" class="qkw">不要等我</a>哭了，才说多么心疼我。</p><p class="header">不要等我走了，才说你多么爱我。</p><p><a href="http://m.so.com/s?q=%E4%BD%A0%E8%8B%A5%E4%B8%8D%E7%A6%BB%E4%B8%8D%E5%BC%83%EF%BC%8C%E6%88%91%E4%BE%BF%E7%94%9F%E6%AD%BB%E7%9B%B8%E4%BE%9D&amp;src=newstranscode" class="qkw">你若不离不弃，我便生死相依</a>。</p><p class="header">你若不离不弃，我便生死相随。</p><p class="header">末日之前、趁你还在、我还爱</p><p><a href="http://m.so.com/s?q=%E6%9C%AB%E6%97%A5%E8%BF%87%E5%90%8E&amp;src=newstranscode" class="qkw">末日过后</a>、你我不在、爱还在</p><p><a href="http://m.so.com/s?q=%E5%9B%A0%E4%B8%BA%E6%87%82%E5%BE%97%EF%BC%8C%E6%89%80%E4%BB%A5%E6%85%88%E6%82%B2&amp;src=newstranscode" class="qkw">因为懂得，所以慈悲</a>。因为理解，所以接受。</p><p>因为放弃，所以忘记。因为难忘，所以回忆。</p><p>-我想的不是你，是曾经掏心掏肺的自己。</p><p>-我恨的不是你，是曾经痛伤过你的自己。</p><p>除了你，我谁都不会爱 qq个性<a href="http://m.so.com/s?q=%E6%83%85%E4%BE%A3%E7%AD%BE%E5%90%8D&amp;src=newstranscode" class="qkw">情侣签名</a></p><p>除了我，你谁都不准爱 <a href="http://m.so.com/s?q=qq%E6%83%85%E4%BE%A3&amp;src=newstranscode" class="qkw">qq情侣</a>签名大全</p><p><a href="http://m.so.com/s?q=%E7%BB%99%E4%BD%A0%E5%80%BE%E5%9F%8E%E7%9A%84%E6%B8%A9%E6%9F%94&amp;src=newstranscode" class="qkw">给你倾城的温柔</a>，恋我半世的流离。</p><p class="header">于你半生的宠溺，尽我三生的颠簸。</p><p class="header">他的情,变成了一种冷漠╮</p><p class="header">她的爱,变成了一种施舍╮</p><p>盛夏，谁染指的流年，我们的回忆，是否还在。</p><p>流年，谁勾勒的盛夏，我们的曾经，是否依存。</p><p class="header">不愿清醒，宁愿一直沉迷放纵。</p><p>不知归路，宁愿<a href="http://m.so.com/s?q=%E4%B8%80%E4%B8%96%E6%97%A0%E6%82%94&amp;src=newstranscode" class="qkw">一世无悔</a>追逐。</p><p class="header">放空整颗心脏丶只容纳你一个人。</p><p class="header">放空整颗心脏丶只留给你一个人。</p><p class="header">末日后，你若依在，我便爱。</p><p>末日后，<a href="http://m.so.com/s?q=%E4%BD%A0%E8%8B%A5%E4%B8%8D%E5%9C%A8&amp;src=newstranscode" class="qkw">你若不在</a>，我便亡。</p><p>男人,狼心狗肺,但不能没用心疼过一个女人、</p><p>女人,没心没肺,但不能没真正爱过一个男人</p><p class="header">愿得一人心、白首不分离</p><p class="header">愿得一人心、生死不离弃</p><p class="header">全世界还有谁,比我们还绝配//*</p><p class="header">全世界还有谁,比你懂我的泪//*</p><p class="header">我只求，执一人手，偕老不相弃</p><p class="header">我只愿，得一人心，白首不相离</p><p class="header">从此以后，不再动心，不用真心。</p><p class="header">从此以后，花花世界，不再当真</p><p>有些事，不说不代表没发生，比如我爱你。</p><p>有些事，输了不代表是真的，比如忘记你。</p><p class="header">我曾经说过。你不会遇见第二个我。</p><p class="header">我早就说过。你不会遇见第二个我。</p><p>一直一直以为自己已经可以麻木到抵抗一切</p><p>一直一直以为自己已经可以坚强到独立面对</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://pcedu.pconline.com.cn/608/6081978.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='82bf7e6387b0e0f2bc8736db14c0696d'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>给你倾城的温柔</em>的其它新闻:</h3> <ul>   </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + 'QQ情侣个性签名_愿得一人心、白首不分离' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + 'QQ情侣个性签名_愿得一人心、白首不分离'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";