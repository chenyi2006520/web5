s:14779:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>特朗普言论成动员令 拉美移民纷纷申请入籍美国- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">特朗普言论成动员令 拉美移民纷纷申请入籍美国</h1> <p id="source-and-time"><span id=source>中国青年网</span><time id=time>2016-03-09 09:28:15</time></p> </header>  <div id="news-body"><p><img src="http://p32.qhimg.com/t01ad1d9847d610fe03.jpg?size=550x373"></p><p class="img-title">资料图:特朗普</p><p>中新网3月9日电 据外媒报道，美国共和党总统参选人特朗普以对移民言辞强硬著称，他一再重申要递解数美国百万无证件移民，在美墨边境建立高墙。这些表态将特朗普推到共和党参选人的最前列，但也促使大批移民申请入籍美国，以便在今年11月决定是否让特朗普入主<a href="http://m.so.com/s?q=%E7%99%BD%E5%AE%AB&amp;src=newstranscode" class="qkw">白宫</a>时发出自己的声音。</p><p>美国<a href="http://m.so.com/s?q=%E7%A7%91%E7%BD%97%E6%8B%89%E5%A4%9A%E5%B7%9E&amp;src=newstranscode" class="qkw">科罗拉多州</a>居民、两个孩子的妈妈维利加斯(Hortensia Villegas)是将近10年前来自墨西哥的合法移民。她表示，在特朗普民调支持率上升之前，她从来没有感到入籍的需要。她表示想在大选中投票，“让特朗普赢不了”。</p><p>报道指出，这并非维利加斯一人的想法。她的妹妹和父母以及她丈夫的父母都已加入拉美裔移民申请大军，试图及时入籍以便参加今年的大选投票。</p><p>据统计，到今年1月底为止的6个月，申请入籍美国人数比去年同期上升14%。社会活动家称，申请人数每周都在增加，估计到今年9月底的2016财年总申请人数可能接近100万，比去年增加20%。</p><p>报道称，从历史上看，<a href="http://m.so.com/s?q=%E5%A2%A8%E8%A5%BF%E5%93%A5&amp;src=newstranscode" class="qkw">墨西哥</a>移民申请入籍比例低于其他族裔。根据皮尤研究中心数据，合格的墨西哥移民只有36%申请入籍，而全体移民申请入籍的比例高达68%。而多亏有了特朗普，这种状况正在改变。</p><p>美国“全国新美国人伙伴”副主任Tara Raghuveer说，“合格的人们都真正感到站出来的紧迫性。他们担心总统参选人说出的可恨之事成真。”</p><p>工会和<a href="http://m.so.com/s?q=%E9%9D%9E%E6%94%BF%E5%BA%9C%E7%BB%84%E7%BB%87&amp;src=newstranscode" class="qkw">非政府组织</a>是帮助880万非公民移民入籍申请的主力。白宫也在去年9月发起帮助人们申请入籍的全国运动，在公共图书馆建立“公民之角”并招聘移民明星做广告。</p><p>联邦政府上周也承诺为非政府组织拨款1000万美元，帮助移民完成申请程序。不过，许多保守派将这看做在<a href="http://m.so.com/s?q=%E4%BD%9B%E7%BD%97%E9%87%8C%E8%BE%BE&amp;src=newstranscode" class="qkw">佛罗里达</a>、科罗拉多和内华达等摇摆州扩大民主党支持率的做法。</p><p>国安部美国公民和移民局(USCIS)局长<a href="http://m.so.com/s?q=%E7%BD%97%E5%BE%B7%E9%87%8C%E6%A0%BC%E5%85%B9&amp;src=newstranscode" class="qkw">罗德里格兹</a>表示，“我不关心他们注册为那个党，我只希望他们成为公民。”</p><p>不过，特朗普本人却仍然相信自己能赢得拉美裔选票。他的竞选团队发言人<a href="http://m.so.com/s?q=%E5%B8%8C%E5%85%8B%E6%96%AF&amp;src=newstranscode" class="qkw">希克斯</a>说，“特朗普支持劳工的移民改革将让数百万已把美国当做自己家的移民受益最大。”</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.youth.cn/jsxw/201603/t20160309_7722144.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='178aa6361c28aa0ef9f5dbda1ed11dfb'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>紧急动员</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%B4%A7%E6%80%A5%E5%8A%A8%E5%91%98&amp;pn=1&amp;pos=9&amp;m=ded47af9d551fd8dcf03156bd76ceba25612d2c8&amp;u=http%3A%2F%2Fnews.youth.cn%2Fjsxw%2F201603%2Ft20160309_7722144.htm" data-pos="1"> 特朗普言论成<b>动员</b>令 拉美移民纷纷申请入籍美国 </a>   <li> <a href="/transcode?q=%E7%B4%A7%E6%80%A5%E5%8A%A8%E5%91%98&amp;pn=1&amp;pos=10&amp;m=4b166056c93a7a751f865c5f88a6f3e3a2c21acd&amp;u=http%3A%2F%2Fleaders.people.com.cn%2Fn1%2F2016%2F0310%2Fc396370-28188111.html" data-pos="2"> 唐山市召开迎世园城市环境卫生综合整治<b>动员</b>大会 </a>   <li> <a href="/transcode?q=%E7%B4%A7%E6%80%A5%E5%8A%A8%E5%91%98&amp;pn=2&amp;pos=1&amp;m=322b56f183eb7d480d8569f3cf44901ea4ff9e5c&amp;u=http%3A%2F%2Fjjsx.china.com.cn%2Flm2518%2F2016%2F382915.htm" data-pos="3"> 小店区刘家堡乡召开乡领导班子换届工作<b>动员</b>会 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '特朗普言论成动员令 拉美移民纷纷申请入籍美国' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '特朗普言论成动员令 拉美移民纷纷申请入籍美国'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";