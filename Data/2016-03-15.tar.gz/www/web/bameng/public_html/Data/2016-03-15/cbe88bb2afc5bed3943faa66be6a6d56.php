s:33015:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>雅昌专访杨述:破坏流行审美趣味，制造画面与观者“躲迷藏”- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">雅昌专访杨述:破坏流行审美趣味，制造画面与观者“躲迷藏”</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-13 13:27:00</time></p> </header>  <div id="news-body"><p><img src="http://p32.qhimg.com/t01923e21ca96234488.jpg?size=500x714"></p><p><a href="http://m.so.com/s?q=%E6%9D%A8%E8%BF%B0&amp;src=newstranscode" class="qkw">杨述</a> 《自画像》 纸面油画 79×53.5cm 1984</p><p>我的艺术不是精致而是粗鲁的，是批判而非歌颂;因为在我的眼里，或者说心里，世道之荒诞不合逻辑，而人们却心安理得、乐在其中，令人费解。</p><p class="header">我想，他们需要受到刺激。</p><p>--杨述(<a href="http://m.so.com/s?q=%E3%80%8A%E6%88%91%E7%9A%84%E8%89%BA%E6%9C%AF%E4%B8%8D%E6%98%AF%E7%B2%BE%E8%87%B4%E8%80%8C%E6%98%AF%E7%B2%97%E9%B2%81%E7%9A%84%E3%80%8B&amp;src=newstranscode" class="qkw">《我的艺术不是精致而是粗鲁的》</a>)</p><p><img src="http://p34.qhimg.com/t01795422189a29dd2b.jpg?size=500x370"></p><p class="img-title">艺术家杨述在其作品前</p><p>3月12号，成都千高原艺术空间即将举行艺术家杨述同名个展“杨述”，以文献研究和作品梳理为基础，展示艺术家从1978年至今的艺术作品，其中包含不同阶段的部分重要作品、手稿、以及文献记录。</p><p>艺术家杨述自1988年从四川美院油画系研究生毕业后，一直在“非具象绘画”领域进行探索。画面中将结构主义、表现主义、涂鸦等元素结合在一起，作品介于具象和<a href="http://m.so.com/s?q=%E6%8A%BD%E8%B1%A1%E7%BB%98%E7%94%BB&amp;src=newstranscode" class="qkw">抽象绘画</a>之间，形成了极富辨识度，却又充满变化，层次丰富的作品脉络。从学院的具象，到此后对于非具象的探索之间是如何过渡的?在杨述看来，80年代对于自己是一个启蒙的年代，一方面通过学习学院传统，另一方面艺术家却又并不满足于此，仍在不停地寻求变化。习惯于即兴工作的他，创作方式属于“走到哪儿算哪儿”，并没有一个既定目标。这些工作方式也将他作品中的随性表露出来。</p><p>1995年，他去<a href="http://m.so.com/s?q=%E8%8D%B7%E5%85%B0&amp;src=newstranscode" class="qkw">荷兰</a>驻留，在国外近距离的接触到艺术大师的原作，打开了视野。加之与艺术界人士的交流，使他了解很多关于艺术在社会里面的状态。确立了自己的艺术观念，即破坏世俗的审美趣味，从中获取更多的想法。</p><p>警惕“风格”形成的同时，《无题》成为了杨述作品中出现频率最高的标题。将作品的主题或者其他内容尽量隐藏在画面中，在他看来是比较满意的状态。而此后作品中那些荧光色的文字，则是艺术家的“歪楼游戏”。那些具有导向性的标题，将观众引向了以为读懂了作品，却早早被艺术家看穿且隐藏起来的关系中。最新作品中对于材料的使用，也是他为了避免风格化与日常化而寻求继续创作的途径。</p><p>杨述除开艺术家的身份，还是重庆器•Haus空间(<a href="http://m.so.com/s?q=Organhaus&amp;src=newstranscode" class="qkw">Organhaus</a> Art Space)的创办人之一。2006年成立至今，器•Haus空间走过十个年头的同时也已成为中国西部最为重要和活跃的国际艺术实验场域。之所以做这样的空间，杨述说，是为了给自己找点画画外的事情做。</p><p>展览前夕，小编走入千高原艺术空间的展览现场，杨述正在三楼忙碌的布展。指导工人调整作品与墙壁之间的间距后，他坐下来接受了<a href="http://m.so.com/s?q=%E9%9B%85%E6%98%8C%E8%89%BA%E6%9C%AF%E7%BD%91&amp;src=newstranscode" class="qkw">雅昌艺术网</a>的采访。</p><p><img src="http://p34.qhimg.com/t0113e480b824c75bbf.jpg?size=500x666"></p><p class="img-title">千高原艺术空间布展现场</p><p class="header">主流或边缘，与艺术本质无太大关系</p><p>雅昌艺术网:麻烦杨老师介绍下这次同名个展“杨述”的基本情况。</p><p>杨述:这次展出作品的年代跨度比较大，基本上从我大学毕业到现在，每一个阶段的作品都有所呈现。可以说这次的展览是一个很重要的节点，将我早期以及现在的作品，以脉络的形式梳理出来，当然主要的作品还是以近两年创作的为主。除此之外，还会有手稿以及文献记录的展示。</p><p>雅昌艺术网:去年7月，千高原的 “蹊径”--重访1990年代的四个个案展览(王川、<a href="http://m.so.com/s?q=%E7%86%8A%E6%96%87%E9%9F%B5&amp;src=newstranscode" class="qkw">熊文韵</a>、杨述、朱小禾)中，您也是其中的个案之一。那次展览和这次有哪些不同?</p><p>杨述:“蹊径”更多的是梳理90年代我们几个艺术家在当时的工作状态，像1988年的西南现代艺术展、1989年<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E7%BE%8E%E6%9C%AF%E9%A6%86&amp;src=newstranscode" class="qkw">中国美术馆</a>举办的“中国现代艺术大展”等，90年代的作品比较多。</p><p>雅昌艺术网:当时那个展览用了“重访”一词，记得当时写的一段话是说“重访的目的不是为了修正历史，而是为了避免历史被本质化，意在呈现一个多歧的1990年代”。“非具象绘画”在川美并非主流，是否当时处于一种“被低估”或者是“被淹没”状态，才会有现在的“重访”?</p><p>杨述:我从来没想过这个问题，什么是主流或者什么是边缘，这些跟艺术本质没有太大的关系。每一位艺术家都是不一样的，他们所经历的创作道路也是不一样的，有一些艺术家可能会被历史所选择。从现在的角度去回望过去，我觉得不论哪个方向的艺术家，都有他自身的价值在里面。从他们的角度去理解那个时代，通过各自的艺术方式去有所呈现。每一位不同的艺术家都有他的价值。</p><p>雅昌艺术网:那可以理解成艺术家还是以创作为主，梳理性的东西交由机构和艺术评论者来做?</p><p>杨述:艺术家也要梳理，但是从本质上来谈还是要回到艺术本身。不是说艺术能够影响这个时代，你要怎么样，而是说你有没有一些新的东西或者是通过你的一种实践有没有一种可能可以呈现出来，更多的是那种状态。</p><p>雅昌艺术网:在校期间您还是以具象绘画为主，1988年从美院研究生毕业后，您就开始创作非具象的绘画。从具象到非具象间，这中间创作形式是如何转变的?</p><p>杨述:创作变化我觉得有两个方面，学习可能是一个方面，通过去看一些不同的东西，获取新的资讯来补充自己的学习又是另一个方面。80年代实际上是一个启蒙的年代，当时自己很自觉地通过学习发现到了一些新的东西。因为历史的局限性，很多东西在以前是都没有见到过的。学习的背景有限，资讯也有限。以前的学习背景都是传统的那一套方法，但是艺术家个体并不满足于此，都在不停地寻找一些变化。对我有影响的展览一个是成都举行的蒙克展，还有一个是在北京<a href="http://m.so.com/s?q=%E5%86%9B%E4%BA%8B%E5%8D%9A%E7%89%A9%E9%A6%86&amp;src=newstranscode" class="qkw">军事博物馆</a>举行的德国表现主义画家的展览。通过展览看到西方大师油画原作后，才了解到什么是真正的油画。那个年代，我们一下子认识了很多西方美术史上的大师，并接触到他们的作品，很多艺术家也会通过对现代主义的了解去实践作品。当时艺术圈的“85新潮”很是活跃，不管是模仿还是借鉴，对于艺术家都是一种外在的触动，能找到一些影响自己的点。</p><p>雅昌艺术网:您的作品不完全是抽象，还会通过涂鸦或者一些很细碎的材料随意的拿来用在画面中，看上去是比较随性的。</p><p>杨述:这可能跟方法有关。我的创作方式是走到哪儿算哪儿，并没有一个既定目标。譬如有一个想法或者灵感被某种东西刺激出来，我会将这种情绪立刻呈现于画面当中。</p><p>雅昌艺术网:其实西南这一块做抽象或者是说做非具象的艺术家并不是特别多。</p><p>杨述:我也不知道，可能跟自己的习惯有所关系。对我自己来说，确实不想做那种像一件作品的作品，或者是很漂亮的一个什么东西，按照计划去工作的方法对我而言也是有点困难的。可能还是跟思维方式有关，我更多的还是想即兴地去工作。</p><p><img src="http://p32.qhimg.com/t016f8d90c8c10193da.jpg?size=500x349"></p><p>杨述 <a href="http://m.so.com/s?q=%E3%80%8A%E6%97%A0%E9%A2%982015+No.3%E3%80%8B&amp;src=newstranscode" class="qkw">《无题2015 No.3》</a> 布面丙烯、树枝麻绳 210×300×17.5cm 2015</p><p>荷兰留学，从破坏流行审美趣味中获取想法</p><p>雅昌艺术网:在1995年的时候，您去到荷兰留学了一年。当时是怎样的一个契机过去的?</p><p>杨述:1995年，我获得赞助在荷兰Amsterdam Rijksakdemie进修了一年。其实在94年的时候我就申请过一次，那个时候需要进行面试，我没有办法去到荷兰，甚至电话面试都很困难，因为那个时候我并没有电话。比较幸运的是，第二年申请的时候这些步骤都没有了，学院接受了我。这是一个非常好的机会，是一个全资助的项目，会给到你很多的经费。那个时候我已经在美院教了几年书，经费比那会国内的工资要高得多。那个学院不是严格意义上的学校，每个人都有自己的工作室来做作品，有点儿像一个大的驻留项目，每年在全世界范围内接受30个名额。那边的老师更多的是像顾问，学院会请到一些策展人和艺术家，你可以定期的跟他们预约，找他们谈话。</p><p>雅昌艺术网:这个经历对您的艺术创作或者是思维方式拓展方面有哪些影响?</p><p>杨述:那是一个能够开阔自己眼界的重要机会，感觉自己一下子见到了很多东西。像阿姆斯特丹很重要的皇家美术馆、<a href="http://m.so.com/s?q=%E6%A2%B5%E9%AB%98%E7%BE%8E%E6%9C%AF%E9%A6%86&amp;src=newstranscode" class="qkw">梵高美术馆</a>还有市立美术馆等，我都去逛了，看到了很多大师的原作。当时<a href="http://m.so.com/s?q=%E4%BE%AF%E7%80%9A%E5%A6%82&amp;src=newstranscode" class="qkw">侯瀚如</a>正好也在荷兰，并且策划了比较当代的展览，我们之间也有一些交流、谈话。</p><p>对我的影响还是和80年代的那些东西有联系。在国内我们看到的作品多是平面的印刷品，接触原作的机会有，但是不多。95年那次我是第一次去西方这个完全不同的社会，通过在那儿的生活也了解很多关于艺术在社会里面的状态。</p><p><img src="http://p33.qhimg.com/t012599bcf97587d0ed.jpg?size=500x635"></p><p>杨述 <a href="http://m.so.com/s?q=%E3%80%8A%E6%97%A0%E9%A2%983%E3%80%8B&amp;src=newstranscode" class="qkw">《无题3》</a> 布面油彩及综合材料 150×120cm 1998</p><p>雅昌艺术网:此前您在一个访谈里说过自己去荷兰之前的作品更有组织和秩序，后来的作品非理性的成分更多。</p><p>杨述:对。其实在国内现在都是如此，很多时候我们观看一件作品还是从做的程度如何来看。像画得好不好，用不用功，体验材料深入与否的角度。后来我对这些东西有点儿反感，我比较认同现代主义的前卫观念，即破坏世俗的审美趣味。我有点故意去破坏流行的审美趣味，更多的时候是想从那些过程中获取一些想法。</p><p>把内容藏在某个地方，寻找创作的可能性</p><p>雅昌艺术网:对于作品风格，您怎么看?</p><p>杨述:怎么说呢，有一些东西可能会自然地变成一种很俗套、很一样的东西，就像同时期做一些习惯性的事情就会形成“风格”，那个对我也不是太重要。</p><p>雅昌艺术网:还是像此前您说到的现代主义的前卫观念一样，有一点警惕“风格”的形成?</p><p>杨述:说是这么说，但其实风格的形成是很难避免的。多少还是会有习惯性的东西在其中，比如颜色或者方法，如果这些算风格。每个人都有他自己习惯性去做的一些事情。我不太习惯做一些项目类型的事，譬如让我专门就一个展览或者特定的主题来进行创作。此前和汽车品牌保时捷有过<a href="http://m.so.com/s?q=%E4%B8%BB%E9%A2%98%E5%88%9B%E4%BD%9C&amp;src=newstranscode" class="qkw">主题创作</a>的合作，感觉还是会受到一点限制。我比较满意的状态是作品的主题或者其他内容尽量被隐藏起来。</p><p>雅昌艺术网:所以您很多作品的名字都叫《无题》，也是想把内容隐藏起来?</p><p>杨述:(笑)我实在想不出更贴切的名字。现在我也会找一些比较拗口或者特别的句子来做标题。</p><p>雅昌艺术网:就像有些出现在您画面中的标语，都可以作为作品的标题?</p><p>杨述:对。本质上看起来是那么回事，但实际上也是没有任何意义的。</p><p>雅昌艺术网:相较于《无题》，有名字的作品可能观众理解起来会好一点。</p><p>杨述:标题很多时候都是具有导向性的，这些可能是一个诱饵，让观者觉得自己好像能够理解和进入作品。</p><p><img src="http://p34.qhimg.com/t0121f88ecd3f89964d.jpg?size=500x758"></p><p>杨述 <a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%8D%E5%90%8C%E6%97%B6%E8%80%85%E7%9A%84%E5%90%8C%E6%97%B6%E6%80%A7%E3%80%8B&amp;src=newstranscode" class="qkw">《不同时者的同时性》</a> 木板丙烯、综合材料 366×244cm 2016</p><p>雅昌艺术网:您不喜欢这些导向性的东西?</p><p>杨述:我也在弄。像我有件作品的名称叫做《不同时者的同时性》，其实是我从书上找的句子，确实也没有什么意义。有点像达达，随意的指一个东西，也是为了做一点区别。</p><p>雅昌艺术网:有可能理论家会拿这些标题来做一定的研究。</p><p>杨述:看他们如何理解吧。这也是一个再创作的过程，评论家跟观众还不一样。</p><p><img src="http://p34.qhimg.com/t0127ea1d803046bbdc.jpg?size=500x345"></p><p>杨述 <a href="http://m.so.com/s?q=%E3%80%8A%E9%95%9C%E5%AD%90%E3%80%8B&amp;src=newstranscode" class="qkw">《镜子》</a> 木板、led灯、布面丙烯 180×260×8.2cm 2016</p><p>雅昌艺术网: 我们可以看到您新作与之前作品的变化，新作上会有一些拼贴的东西，像布条、木板，还有LED灯的出现。</p><p>杨述:我在淘宝上买一些材料放在工作室里，什么时候要用就可以去拿，比较方便。或者说我突然看到一个材料了，有可能部分画面的灵感或者要做的东西都跟这些有关系。可能因为这一块布，会做一个画面。从方法上在朝这个方向去做，其实可能跟以前没有太大的区别。像那个LED灯，本来我想写几个字上去，结果买来坏掉了，那也很好玩，坏掉有坏掉的感觉。</p><p>雅昌艺术网:就像是以前画面中用颜料的部分变成了现在画面中用材料的部分?</p><p>杨述:可能也不是很重要的事情。有点儿差异，你就能说它有多重要或者很特别吗?我不这么认为。</p><p><img src="http://p35.qhimg.com/t01a264ba323e3c4468.jpg?size=500x374"></p><p>杨述 <a href="http://m.so.com/s?q=%E3%80%8A%E6%97%A0%E9%A2%982016No.16%E3%80%8B&amp;src=newstranscode" class="qkw">《无题2016No.16》</a> 纸板、刺绣、丙烯、拼贴 41×55cm 2016</p><p>雅昌艺术网:可以理解为一种尝试，就是这段时间您更愿意用这种方式来表达。</p><p>杨述:对。比如说那种东西你做的很讨厌了，那就换一种方法继续推进，很多时候我们要找一些继续创作的理由。一直重复会让人觉得很烦，找其他的方法可能会比较有意思。我有一类作品是买的刺绣的<a href="http://m.so.com/s?q=%E7%8E%B0%E6%88%90%E5%93%81&amp;src=newstranscode" class="qkw">现成品</a>，我会在上面重新做一些东西。像之前我在千高原做的一个项目就是用手机相片打印出来做的。其实本质上还是在找一种推进的可能性，继续朝这个方向或者另一个方向走的创作的可能性。</p><p>雅昌艺术网:荧光颜色是什么时候出现在您作品中的?</p><p>杨述:大概从2004年的样子，差不多十多年了。在这之前用粉色也比较多，像描绘人体局部，会用很刺激的桃红色。大概在2007,2008年左右，荧光色用的比较多，会在画面上写一些字。</p><p class="header">雅昌艺术网:那些字是随意找的?</p><p>杨述:我在创作的过程中可能是涂一下，然后找一些字或者是怎么样，有点像构成一件作品。很难判断是不是刻意为之。有时候，我会故意朝这个方向去找，譬如有一些字一定是中英文对照的。我会放一些比较奇怪的词语上去，像是藏在某个地方，然后观者突然发现了它，觉得比较好笑，那么我的意图就达到了。</p><p>雅昌艺术网:流行的网络词汇或者流行的东西会放上去吗?</p><p>杨述:有一段时间也用。但是那一类东西跟我们的日常太接近了，容易造成联想并且没有陌生感，会过于熟悉。</p><p>雅昌艺术网:其实就是不想让别人看到您在做什么，让大家很有意思的去找，去猜，又猜不对。</p><p>杨述:对，像一个游戏。有段时间内，有形象的和没有形象的画面都在弄。我对形象的东西没有特别的兴趣，也许以后会尝试做一些真正的人物画之类的，但目前还没想好如何切入。但肯定不是一个透视场景的东西，那不是我喜欢的方法。</p><p><img src="http://p33.qhimg.com/t0118a4c2dcbd640f82.jpg?size=500x751"></p><p>杨述 <a href="http://m.so.com/s?q=%E3%80%8A%E6%97%A0%E6%84%8F%E7%9A%8425%E3%80%8B&amp;src=newstranscode" class="qkw">《无意的25》</a> 木板丙烯 366×244cm 2016</p><p>雅昌艺术网:跟我们聊几件您的作品吧。</p><p>杨述:这件作品叫《无意的25》。其实这些格子是没有什么意义的，做板子的木匠在上面弹好线后正好是24个格子，于是我将它作为一个进入的契机，其中有一格是由两格组成，而产生出另外的一格，为其取名《无意的25》 。</p><p>旁边那两件作品(其中一件为《不同时者的同时性》 ，前文有配图)，是我找了两个席梦思的床单贴在上面。从局部出发开始来做。对我来说重要的是可能进入的这个点，又或者是最后呈现出来的状态会对别人产生什么影响。</p><p>雅昌艺术网:挺有意思的，一开始大家并没有注意到是一个席梦思床单，可能观众看的时候会突然一下发现原来是这样。</p><p>杨述:观众可以在画面中寻找某些东西。所谓这些很多东西都是一次一次不同的涂抹，那些颜色都是一些表面的现象。</p><p><img src="http://p34.qhimg.com/t01be5b01614552c083.jpg?size=500x331"></p><p>重庆器•Haus空间(Organhaus Art <a href="http://m.so.com/s?q=Space&amp;src=newstranscode" class="qkw">Space</a>)</p><p>成立器•Haus空间是给自己找件事情做</p><p>雅昌艺术网:您2006年同倪昆在重庆合作创办的重庆器•Haus空间(Organhaus Art Space)迄今已有十年之久。空间也已经成为中国西部最为重要和活跃的国际艺术实验场域。当初为什么会做这样一个空间?</p><p>杨述:做器•Haus空间就是为了给自己找件事情做。在重庆这边，还没有这样的生态。我正好有国外艺术家朋友或者基金会这种的资源，2006年那会也是比较成熟的时机，有一点钱，就把这个事情给做了。现在已经走过了十年，在这期间还是有很多正面收获的，不论是对我而言还是对其他人，面对一个真正国际化常态的现场，那种多样性是很有意思的，对于艺术家创作应该是有所收益的。同时，空间也提供的城市或者是不同文化之间的交换项目。</p><p>雅昌艺术网:作为非盈利艺术机构，日常的花销是怎样的?</p><p>杨述:我们采用的方式非常便宜，包括做展览也是。</p><p class="header">雅昌艺术网:艺术家驻地这块呢。</p><p>杨述:我们邀请西方艺术家来驻留，他们可以找一些合作机构去申请经费开销。有一些交换项目，艺术家就自己付钱，我们负责接待就行了。这边有套房子，艺术家直接过来住就是了。</p><p>雅昌艺术网:《我的艺术不是精致而是粗鲁的》一文是您1992年写的一篇文章，在结尾处，您写道“我悟到，绘画是无法传达出如此复杂的含义的。我用一把刷子沾上黑色，把它涂掉，终于轻松了。”那个时候您毕业没几年，现在已经过去24年。您的心态有哪些变化?</p><p>杨述:其实在每个阶段都有一些小的变化。从成功学的角度来看，每个人都希望自己的作品能够被接受，但从另外一个角度来看，也得有能够面对挫折、失败的能力，得想得通。</p><p class="header">雅昌艺术网:谢谢!</p><p class="header">作者:李璞</p><p class="header">编辑:高静</p><p>更多收藏类信息请扫描二维码，下载“雅昌兜藏”app</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://toutiao.com/i6261409527669719553/">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='1463bf70dac71bdcfc19ed5dd5f712f3'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>躲迷藏</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%BA%B2%E8%BF%B7%E8%97%8F&amp;pn=1&amp;pos=5&amp;m=7fae09d49dddde0131f77985a0f40b06ba712b20&amp;u=http%3A%2F%2Fwww.hb.chinanews.com%2Fnews%2F2015%2F0610%2F215730.html" data-pos="1"> 当阳一毒贩与警方"<b>躲迷藏</b>"终落网 </a>   <li> <a href="/transcode?q=%E8%BA%B2%E8%BF%B7%E8%97%8F&amp;pn=1&amp;pos=6&amp;m=f19b6a42d2a033de7c518265d1d0cbc2cbd80cb2&amp;u=http%3A%2F%2Fwww.cq.xinhuanet.com%2F2014-11%2F11%2Fc_1113195517.htm" data-pos="2"> 重庆:小朋友<b>躲迷藏</b>从飘窗坠楼亡 玩伴都要担责 </a>   <li> <a href="/transcode?q=%E8%BA%B2%E8%BF%B7%E8%97%8F&amp;pn=1&amp;pos=7&amp;m=e437e2a2b6f87c122e99ea9412800c21ff13c722&amp;u=http%3A%2F%2Fngzb.gxnews.com.cn%2Fhtml%2F2014-09%2F04%2Fcontent_1021171.htm" data-pos="3"> 赌徒会"<b>躲迷藏</b>" 警方有"回马枪" </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '雅昌专访杨述:破坏流行审美趣味，制造画面与观者“躲迷藏”' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '雅昌专访杨述:破坏流行审美趣味，制造画面与观者“躲迷藏”'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";