s:15153:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>爸妈团惊现唯美照片树 孙坚边走边拿成“特务”- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">爸妈团惊现唯美照片树 孙坚边走边拿成“特务”</h1> <p id="source-and-time"><span id=source>汉网</span><time id=time>2016-03-04 15:30:00</time></p> </header>  <div id="news-body"><p><img src="http://p35.qhimg.com/t0170aa181a0760f74d.jpg?size=500x333"></p><p>爸妈团惊现唯美照片树 <a href="http://m.so.com/s?q=%E5%AD%99%E5%9D%9A&amp;src=newstranscode" class="qkw">孙坚</a>边走边拿成&quot;特务&quot;</p><p>搜狐娱乐讯 江西卫视<a href="http://m.so.com/s?q=%E3%80%8A%E5%B8%A6%E7%9D%80%E7%88%B8%E5%A6%88%E5%8E%BB%E6%97%85%E8%A1%8C2%E3%80%8B&amp;src=newstranscode" class="qkw">《带着爸妈去旅行2》</a>本周将如约与观众见面，<a href="http://m.so.com/s?q=%E6%96%AF%E9%87%8C%E5%85%B0%E5%8D%A1&amp;src=newstranscode" class="qkw">斯里兰卡</a>站的最后一天，节目组为嘉宾们准备了充满旅程回忆的唯美“<a href="http://m.so.com/s?q=%E7%85%A7%E7%89%87%E6%A0%91&amp;src=newstranscode" class="qkw">照片树</a>”，期间性格一向外向活泼的孙坚看到众多自己与母亲的合照，赞不绝口的同时情绪激动直呼“要把这些照片都带回家”，随后便让母亲“放哨”，边走边将照片放入怀中，左顾右盼的姿态颇有一番“特务”的气势。</p><p>“<a href="http://m.so.com/s?q=%E7%88%B8%E5%A6%88%E5%9B%A2&amp;src=newstranscode" class="qkw">爸妈团</a>”现回忆长廊，唯美“照片树”引众赞</p><p>“爸妈团”体验过坐杆钓鱼、女王<a href="http://m.so.com/s?q=%E8%BA%B2%E9%81%BF%E7%90%83&amp;src=newstranscode" class="qkw">躲避球</a>、野外生存挑战等一系列独具斯里兰卡特色的生活模式后，到达了斯里兰卡站的最后一天，在众人齐齐对未知的下一站旅程期待万分之际，节目组以“出门散步”为由，将“爸妈团”成员分别带到了挂满众人照片的绿茵园···</p><p>一望无际的绿茵园内，大量“爸妈团”的照片与灌木融为一体，照片内容贯穿济州岛、斯里兰卡的旅程，风格更是各种各样，包括明星家庭成员之间温馨、趣味、唯美的不经意抓拍，而对于此份神秘惊喜毫不知情的“爸妈团”成员，在看到宏伟的“照片墙”之后，齐齐表示难以置信，口中对于摄影师技术赞不绝口的同时，开始你一言我一语进入“回忆模式”，现场瞬间被类似于“这是在济州岛拍的”、“当时我们吃的什么来着 ”之类的声音覆盖，陷入回忆中的“爸妈团”成员幸福满溢，甚至开始谈论起了“旅程前”与“旅程后”的差别，其乐融融颇似一个温馨大家庭。</p><p class="header">孙坚变“特务”，边走边拿彪演技</p><p>而性格一向外向活泼的孙坚，面对唯美“照片树”时情绪相当激动，口中不停直呼“太美”之际，还一脸严肃对着摄影师的角度问道“你们怎么拍得这么漂亮”，随后更是爱不释手表示“我要把这些照片都带回家”。</p><p>说完便来回穿梭在“照片树”周围开始挑选照片，火急火燎让母亲为其“放哨”。中途或是时不时对镜头发出一个意味深长的笑容，或是假装与母亲讲话，手上却快速将照片放入怀中，全程左顾右盼的表现，加之一脸认真的表情、气势十足的转身，颇有一番“特务孙”的气势，幽默搞怪的表现，致使其余成员齐齐发出“这个可以拿走呀”、“我也要拿”之类的呼声，随即便开始各自挑选中意的照片，作为“带头人”的孙坚看到成员们的表现，一脸认真的表情走向摄影师，仿若说着“你们拿，我放哨”，引发现场爆笑不断。众人“带照片回家”的计划能否顺利实施?“爸妈团”随后是否会再遇神秘惊喜时刻?更多精彩内容，尽在本周日晚21:15江西卫视《带着爸妈去旅行2》 !</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.cnhan.com/html/yule/20160304/539405.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='48c895e5f532fbcb28b0a0ee525a6a84'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>爸妈团</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%88%B8%E5%A6%88%E5%9B%A2&amp;pn=1&amp;pos=6&amp;m=39c5577add9723d8ac20e64ba6e59ae674d1b85c&amp;u=http%3A%2F%2Fnews.cnhan.com%2Fhtml%2Fyule%2F20160304%2F539405.htm" data-pos="1"> <b>爸妈团</b>惊现唯美照片树 孙坚边走边拿成"特务" </a>   <li> <a href="/transcode?q=%E7%88%B8%E5%A6%88%E5%9B%A2&amp;pn=1&amp;pos=7&amp;m=991d58320d0adf0eb0c258e46190fb35eee584e6&amp;u=http%3A%2F%2Fhb.ifeng.com%2Fnews%2Fcjgc%2Fdetail_2015_06%2F26%2F4044297_0.shtml" data-pos="2"> "状元效应"引爆襄阳学区房 武汉<b>爸妈团</b>来"抢房" </a>   <li> <a href="/transcode?q=%E7%88%B8%E5%A6%88%E5%9B%A2&amp;pn=1&amp;pos=8&amp;m=010c98be573dd23f27e085ef6512c76399db84f2&amp;u=http%3A%2F%2Fedu.gmw.cn%2F2014-01%2F15%2Fcontent_10122543.htm" data-pos="3"> 女孩被精神病母亲虐待 16个陌生人组成<b>爸妈团</b>救助 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '爸妈团惊现唯美照片树 孙坚边走边拿成“特务”' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '爸妈团惊现唯美照片树 孙坚边走边拿成“特务”'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";