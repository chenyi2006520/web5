s:16404:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>刘益谦10亿拍下《裸女》 中国买家只认最贵的?- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">刘益谦10亿拍下《裸女》 中国买家只认最贵的?</h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2015-11-11 08:39:00</time></p> </header>  <div id="news-body"><p>上海收藏家<a href="http://m.so.com/s?q=%E5%88%98%E7%9B%8A%E8%B0%A6&amp;src=newstranscode" class="qkw">刘益谦</a>以10.84亿人民币的天价拍下<a href="http://m.so.com/s?q=%E8%8E%AB%E8%BF%AA%E5%88%A9%E5%AE%89%E5%B0%BC&amp;src=newstranscode" class="qkw">莫迪利安尼</a>作品《侧卧的裸女》。这位土豪买家去年曾以2.8亿港元竞得成化斗彩鸡缸杯，谈到自己的收藏标准时，刘益谦曾用一句“只买最贵的”来回应。</p><p class="header">浙江新闻客户端评论员 陆文琳</p><p>当地时间11月9日晚，<a href="http://m.so.com/s?q=%E4%BD%B3%E5%A3%AB%E5%BE%97&amp;src=newstranscode" class="qkw">佳士得</a>“画家与缪斯晚间特拍”在<a href="http://m.so.com/s?q=%E7%BA%BD%E7%BA%A6&amp;src=newstranscode" class="qkw">纽约</a>洛克菲勒中心举槌，上海收藏家刘益谦以人民币10.84亿元拍下莫迪利安尼作品<a href="http://m.so.com/s?q=%E3%80%8A%E4%BE%A7%E5%8D%A7%E7%9A%84%E8%A3%B8%E5%A5%B3%E3%80%8B&amp;src=newstranscode" class="qkw">《侧卧的裸女》</a>。中国买家再次以天价竞拍闪耀国际市场。</p><p>其实，承包国外艺术品市场的中国买家并不止刘益谦一人。</p><p>今年5月，在纽约苏富比“印象派及现代艺术”晚间场上，<a href="http://m.so.com/s?q=%E4%B8%87%E8%BE%BE%E9%9B%86%E5%9B%A2&amp;src=newstranscode" class="qkw">万达集团</a>董事长王健林以2041万美元(约合人民币1.27亿元)的高价拍得莫奈的作品<a href="http://m.so.com/s?q=%E3%80%8A%E7%9D%A1%E8%8E%B2%E6%B1%A0%E4%B8%8E%E7%8E%AB%E7%91%B0%E3%80%8B&amp;src=newstranscode" class="qkw">《睡莲池与玫瑰》</a>，华谊兄弟传媒股份有限公司董事长<a href="http://m.so.com/s?q=%E7%8E%8B%E4%B8%AD%E5%86%9B&amp;src=newstranscode" class="qkw">王中军</a>则以2993万美元(约合人民币1.85亿元)的高价拍得<a href="http://m.so.com/s?q=%E6%AF%95%E5%8A%A0%E7%B4%A2&amp;src=newstranscode" class="qkw">毕加索</a>油画《盘发髻女子坐像》。</p><p>中国土豪频频在海外艺术品市场出手，创造一个接一个新的拍卖纪录。只不过，中国买家们高价寻宝，究竟是为了艺术品背后的价值，还是为了花钱博一个好品位的名声?</p><p>2013年11月，也是在纽约，<a href="http://m.so.com/s?q=%E4%B8%87%E8%BE%BE&amp;src=newstranscode" class="qkw">万达</a>以2816万美元(约合1.72亿元人民币)拍下毕加索的名作<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%A4%E4%B8%AA%E5%B0%8F%E5%AD%A9%E3%80%8B&amp;src=newstranscode" class="qkw">《两个小孩》</a>。当时是中国企业购买西方艺术品的最大手笔。拍卖会后有记者联系到万达集团艺术品收藏负责人<a href="http://m.so.com/s?q=%E9%83%AD%E5%BA%86%E7%A5%A5&amp;src=newstranscode" class="qkw">郭庆祥</a>，他透露，拿下毕加索《两个小孩》后，<a href="http://m.so.com/s?q=%E7%8E%8B%E5%81%A5%E6%9E%97&amp;src=newstranscode" class="qkw">王健林</a>表态:继续关注类似毕加索这样具有世界影响力的大师精品，再接再厉。</p><p>从这位中国现任首富的表态看来，他们购买海外艺术品的范围非常明确，非大师级藏品不买。艺术品的价值虽难以用金钱估量，但如果是得到海外艺术市场认可的名家作品，即使当初天价拍下，想来也不算是亏本的买卖。</p><p>另一位土豪王中军的回应就文艺得多了，他买毕加索这幅画是因为:喜欢画背后的故事。这就是妥妥的有钱任性啊，花了近2亿元买一个“我喜欢”。</p><p>不管是为了炫富还是看中了艺术品的收藏价值，中国富豪买家频频出手，在国际上确实是好好刷了存在感。刚刚有钱的我们或许还只摸到了艺术品收藏的门槛，不过，总算是有了进门的资格。</p><p><img src="http://p34.qhimg.com/t01b99467ae41f78a42.jpg?size=350x446"></p><p class="img-title">上海著名收藏家刘益谦</p><p><img src="http://p32.qhimg.com/t01adac073142a4fc0b.jpg?size=550x550"></p><p>莫迪利安尼《侧卧的裸女》(1917-18)，成交价1.7亿美元</p><p>最终裸女系列是亚美迪欧·莫迪利安尼的一个传奇，藏家对于“传奇”的追捧也能够理解，这也成为了莫迪利安尼作品价格走高的主要原因。</p><p>纽约佳士得印象派及现代艺术部总监Brooke Lampley认为:“此次上拍的《侧卧的裸女》可以说是莫迪里亚尼最伟大的作品之一，而且在过去5年里，莫迪里亚尼的裸女画始终都是每一位顶级藏家最渴望获得的艺术品。”</p><p>而就在上周，苏富比首场陶博曼收藏专拍上，莫迪利安尼创作于1919年的<a href="http://m.so.com/s?q=%E3%80%8A%E5%AE%9D%E4%B8%BD%E7%89%B9%C2%B7%E8%8C%B9%E4%B8%B9%E8%82%96%E5%83%8F%E3%80%8B&amp;src=newstranscode" class="qkw">《宝丽特·茹丹肖像》</a>刚刚以4281万美元成交，约合人民币2.71亿元</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://art.people.com.cn/n/2015/1111/c206244-27801901.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='31f505fac7411ee1edea160c78def418'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>刘益谦</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%88%98%E7%9B%8A%E8%B0%A6&amp;pn=1&amp;pos=7&amp;m=92ae10337fb43fd45879e7ff2d76d5b3e31d771d&amp;u=http%3A%2F%2Fart.people.com.cn%2Fn%2F2015%2F1111%2Fc206244-27801901.html" data-pos="1"> <b>刘益谦</b>10亿拍下《裸女》 中国买家只认最贵的? </a>   <li> <a href="/transcode?q=%E5%88%98%E7%9B%8A%E8%B0%A6&amp;pn=1&amp;pos=8&amp;m=ab3a710378c4a4cf6cf94606020dfe6abacf1d68&amp;u=http%3A%2F%2Fwww.ce.cn%2Fculture%2Fgd%2F201511%2F11%2Ft20151111_6971918.shtml" data-pos="2"> <b>刘益谦</b>10.84亿元再购名画 扫货旋风从A股刮到拍卖场 </a>   <li> <a href="/transcode?q=%E5%88%98%E7%9B%8A%E8%B0%A6&amp;pn=1&amp;pos=9&amp;m=24215453364843521cf8359c531eb9d6a01798c9&amp;u=http%3A%2F%2Ffinance.china.com.cn%2Fmoney%2Fcollection%2Fscxw%2F20151111%2F3436888.shtml" data-pos="3"> <b>刘益谦</b>10.84亿再购名画 扫货旋风从A股刮到拍卖场 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '刘益谦10亿拍下《裸女》 中国买家只认最贵的?' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '刘益谦10亿拍下《裸女》 中国买家只认最贵的?'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";