s:15137:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>旧城镇“五创新”破解植树造林难- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">旧城镇“五创新”破解植树造林难</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-01 23:01:07</time></p> </header>  <div id="news-body"><p>经报讯(通讯员<a href="http://m.so.com/s?q=%E8%B5%B5%E5%AD%A6%E5%8B%87&amp;src=newstranscode" class="qkw">赵学勇</a>姚春林)泸西县<a href="http://m.so.com/s?q=%E6%97%A7%E5%9F%8E%E9%95%87&amp;src=newstranscode" class="qkw">旧城镇</a>自2013年启动以矿山复绿为重点的植树造林工作来，创新五大机制，破解植树造林难题，使全镇的植树造林工作呈现出良好发展态势。</p><p>创新责任机制，破解了谁负责的问题。按照“政府领导、部门引导、企业主导、社会参与”的矿山复绿责任机制，成立了党委书记任组长的矿山复绿行动计划领导小组，负责全镇矿区复绿工作的推进落实。实行“1+N”包干负责制，即由一名党政领导+N名镇村组党员干部包干一个片区，监督辖区内的矿主和业主依法履行矿山生态环境保护和恢复治理义务，加大了复绿工作力度和进度。</p><p>创新规划机制，破解了怎么绿的问题。始终坚持生态效益、经济效益、社会效益同步发展的原则，科学制定造林规划，做到一个坐落一个规划，一个坐落一个方案。按照“因地制宜、突出重点、先易后难、注重实效”的原则，对现有林地以“封”为主、疏林地以“填”为主、灌木林以“补”为主、未成林造林地以“抚”为主、荒山以“造”为主、现有<a href="http://m.so.com/s?q=%E6%A1%89%E6%A0%91&amp;src=newstranscode" class="qkw">桉树</a>以“改”为主、荒山耕地以“果”为主、涉及的所有林地以“管”为主，实现了生态经济化、经济生态化、树种多样化，稳步推进了植树造林工作。</p><p>创新融资机制，破解了资金源的问题。在植树造林工作中，积极探索创新融资机制。采取“政府筹一点、企业投一点、项目补一点”的造林经费筹措机制和“谁破坏、谁治理，边开发、边恢复”的生态效益补偿制度，引导煤矿企业增加煤矿山环境保护和恢复治理投入，鼓励各类社会投资主体投资煤矿山生态环境建设。多方筹措造林经费1400万元，确保了植树造林工作的顺利开展。</p><p>创新绿化机制，破解了谁造林的问题。根据各年造林任务安排，结合涉及到的村组、坐落、面积、树种等因素，对权属煤矿业主的坐落，由煤矿业主组织人员造林;权属属于集体的坐落，由村集体组织群众造林;权属属于个人承包的坐落，由承包者组织人员造林，确保了植树造林工作按时、按质、按量完成。</p><p>创新管护机制，破解了怎么管的问题。创新造林绿化管理体系，建立镇、村、组、矿齐抓共管新机制。镇林业部门负责定期或不定期加强巡查整治，依靠行政执法手段，坚决遏制乱砍滥伐毁林案件的发生。各村护林人员负责日常巡查管护。各村组将造林护林绿化工作写进村规民约，向群众宣传“<a href="http://m.so.com/s?q=%E7%88%B1%E6%9E%97&amp;src=newstranscode" class="qkw">爱林</a>护林，共建共享绿色家园”的理念。煤矿企业划片包干管护，安排专人加强日常巡查、补植补造，确保“造一片、活一片、管一片、绿一片”。建立社会监督机制，实行有奖举报制度，全力巩固绿化造林成果。</p><p>目前，全镇共投资1400万元栽植川滇桤木、杉木、<a href="http://m.so.com/s?q=%E9%93%B6%E6%9D%8F%E6%A0%91&amp;src=newstranscode" class="qkw">银杏树</a>、滇朴等390万株，其它绿化苗木25万株，提前三年完成矿山复绿13334.1亩、公路沿线绿化1000亩、村寨绿化200亩，补植补造1500余亩，所栽植的树苗成活率达95%。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.hnflcm.com/hnnew/2016-03-01/14568444674187.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='29d805d967a5de880f7885b6d291ddb9'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>旧城镇</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%97%A7%E5%9F%8E%E9%95%87&amp;pn=1&amp;pos=5&amp;m=c64a3b92c14a54b1042d1bf5c09cd05fb6a267d5&amp;u=http%3A%2F%2Fgov.eastday.com%2Fshjs%2Fnode6%2Fnode31%2Fu1ai95855.html" data-pos="1"> [松江]<b>旧城镇</b>改造和"城中村"治理加速推进 老旧房住户有望提前迁新居 </a>   <li> <a href="/transcode?q=%E6%97%A7%E5%9F%8E%E9%95%87&amp;pn=1&amp;pos=6&amp;m=d025ff1e2f3a98c24af78435d85166eff97a2e0e&amp;u=http%3A%2F%2Fwww.hh.cn%2Fnews_1%2Fxw01%2F201602%2Ft20160229_1194339.html" data-pos="2"> <b>旧城镇</b>高标准农田建设任务过半 </a>   <li> <a href="/transcode?q=%E6%97%A7%E5%9F%8E%E9%95%87&amp;pn=1&amp;pos=7&amp;m=223c9cf48c77faee0bc195cb22dc1df552a4bfaa&amp;u=http%3A%2F%2Fshzw.eastday.com%2Fshzw%2FG%2F20160302%2Fu1ai9238576.html" data-pos="3"> 松江区<b>旧城镇</b>改造和"城中村"治理加速推进 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '旧城镇“五创新”破解植树造林难' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '旧城镇“五创新”破解植树造林难'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";