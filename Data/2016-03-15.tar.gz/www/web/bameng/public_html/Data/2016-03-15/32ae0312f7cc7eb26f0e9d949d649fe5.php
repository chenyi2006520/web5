s:16115:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>少女时代林允儿快乐大本营首秀 跟着允儿学穿搭美美哒(图) - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">少女时代林允儿快乐大本营首秀 跟着允儿学穿搭美美哒(图) </h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-14 22:14:10</time></p> </header>  <div id="news-body"><p><img src="http://p32.qhimg.com/t0134c5217ab18423e2.gif?size=400x218"></p><p><a href="http://m.so.com/s?q=%E5%85%81%E5%84%BF&amp;src=newstranscode" class="qkw">允儿</a>李易峰</p><p>少女时代<a href="http://m.so.com/s?q=%E6%9E%97%E5%85%81%E5%84%BF&amp;src=newstranscode" class="qkw">林允儿</a>将出演中国综艺节目<a href="http://m.so.com/s?q=%E3%80%8A%E5%BF%AB%E4%B9%90%E5%A4%A7%E6%9C%AC%E8%90%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《快乐大本营》</a>。</p><p><img src="http://p31.qhimg.com/t01dd755391fa8b3831.jpg?size=440x623"></p><p>据中国多位负责人透露，林允儿将与共同出演<a href="http://m.so.com/s?q=%E3%80%8A%E6%AD%A6%E7%A5%9E%E8%B5%B5%E5%AD%90%E9%BE%99%E3%80%8B&amp;src=newstranscode" class="qkw">《武神赵子龙》</a>的演员们在14日一起参加《快乐大本营》的节目录制。</p><p>林允儿出演的《武神赵子龙》由<a href="http://m.so.com/s?q=%E6%9E%97%E6%9B%B4%E6%96%B0&amp;src=newstranscode" class="qkw">林更新</a>、金桢勋、高以翔等人出演，将于4月3日进行首播。</p><p><img src="http://p33.qhimg.com/t01112adc3bc16bbd71.jpg?size=440x585"></p><p>林允儿这次不是作为少女时代的成员而是以演员的身份首次参加《快乐大本营》的消息引来了当地粉丝的热烈关注。</p><p><a href="http://m.so.com/s?q=%E6%9D%8E%E6%98%93%E5%B3%B0&amp;src=newstranscode" class="qkw">李易峰</a>的新歌MV《请跟我联络》牵手韩国女神林允儿，在布拉格拍摄，MV中俩人甜蜜牵手，演绎一对倔强的小情侣。MV中允儿清新甜美，在韩国，允儿被称为“国民理想型”是少女时代里的门面担当。超级会穿衣服，而且机场街拍每次都成为时尚圈关注的焦点。</p><p><img src="http://p34.qhimg.com/t013ebf4bbf073f48f4.jpg?size=500x750"></p><p><a href="http://m.so.com/s?q=LOOK&amp;src=newstranscode" class="qkw">LOOK</a>1:卫衣搭配黑色短裙，休闲舒服。</p><p><img src="http://p34.qhimg.com/t0181035123747caf23.jpg?size=500x684"></p><p>LOOK2:帅气的机车外套内搭白Tee，牛仔裤和踝靴，整体非常有型。</p><p><img src="http://p33.qhimg.com/t010c6c038d0b538d62.jpg?size=500x803"></p><p>LOOK3:牛仔太空棉外套搭配樱花粉百褶裙，懒人鞋和袜子非常韩范儿味道。</p><p><img src="http://p32.qhimg.com/t014bbddd3217c8bba7.jpg?size=500x750"></p><p>LOOK4:穿起<a href="http://m.so.com/s?q=%E9%BB%91%E8%89%B2%E5%A5%97%E8%A3%85&amp;src=newstranscode" class="qkw">黑色套装</a>也毫不马虎，利落的<a href="http://m.so.com/s?q=%E4%B8%B8%E5%AD%90%E5%A4%B4&amp;src=newstranscode" class="qkw">丸子头</a>搭配黑色踝靴，All black的搭配帅气有型。</p><p><img src="http://p32.qhimg.com/t011b39b0ffe7930e8d.jpg?size=500x750"></p><p>LOOK5:长款风衣搭配黑色短裤和白Tee，简约的<a href="http://m.so.com/s?q=%E9%BB%91%E7%99%BD%E9%85%8D&amp;src=newstranscode" class="qkw">黑白配</a>非常经典。</p><p><img src="http://p32.qhimg.com/t01cc423fd004ae2f78.jpg?size=500x750"></p><p><a href="http://m.so.com/s?q=LOOK6&amp;src=newstranscode" class="qkw">LOOK6</a>:街头味道的棒球外套搭配黑色铅笔裤，运动减龄。</p><p><img src="http://p33.qhimg.com/t01e4ebb737ae044374.jpg?size=500x753"></p><p class="img-title">LOOK6:街头休闲动减龄。</p><p><img src="http://p32.qhimg.com/t015542fa8d5fa20f2e.jpg?size=500x682"></p><p>LOOK8:牛仔连衣裙搭配闪光粉手拿包，少女味道十足。</p><p><img src="http://p34.qhimg.com/t01c8d948cad39a9e13.jpg?size=500x750"></p><p>LOOK9:黑红白格子的大衣外套内搭素色毛衣，抢眼十足。</p><p><img src="http://p35.qhimg.com/t01e3818d2a6adbd457.jpg?size=500x750"></p><p>LOOK10:黑白条纹毛衣搭配黑色裹身裙，用帽子作为配饰，让整体LOOK非常有型。</p><p><img src="http://p31.qhimg.com/t015e76a6f66bc0c096.jpg?size=500x723"></p><p>LOOK11:出席活动时的允儿更加甜美，淡粉色<a href="http://m.so.com/s?q=%E8%95%BE%E4%B8%9D%E8%BF%9E%E8%A1%A3%E8%A3%99&amp;src=newstranscode" class="qkw">蕾丝连衣裙</a>优雅迷人。</p><p><img src="http://p35.qhimg.com/t01f748797a05d714b1.jpg?size=500x725"></p><p>LOOK12:白色泡泡袖衬衫搭配黑色短裙，复古又大气。</p><p><img src="http://p31.qhimg.com/t01efe174349a6ece55.jpg?size=500x724"></p><p>LOOK13:一袭淡粉色长礼服，搭配简单的妆容和发型，完全就是女神的气质。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://yule.qlwb.com.cn/2016/0314/571523.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='74d074b1e44385c70e09d6efaadeee3c'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>林允儿快乐大本营</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9E%97%E5%85%81%E5%84%BF%E5%BF%AB%E4%B9%90%E5%A4%A7%E6%9C%AC%E8%90%A5&amp;pn=1&amp;pos=10&amp;m=4ede311cb2189fff4827b162ca014487e66c5551&amp;u=http%3A%2F%2Fyule.qlwb.com.cn%2F2016%2F0314%2F571523.shtml" data-pos="1"> 少女时代<b>林允儿快乐大本营</b>首秀 跟着允儿学穿搭美美哒(图) </a>   <li> <a href="/transcode?q=%E6%9E%97%E5%85%81%E5%84%BF%E5%BF%AB%E4%B9%90%E5%A4%A7%E6%9C%AC%E8%90%A5&amp;pn=2&amp;pos=1&amp;m=971e0b34a2d9ace4911ff7084f532263d16e4bdf&amp;u=http%3A%2F%2Fmedia.comnews.cn%2Fn%2Fyl%2F2016-03-14%2F2980.html" data-pos="2"> 网曝<b>林允儿</b>将录制<b>快乐大本营</b> 深扒<b>林允儿</b>李升基分手原因涉及郑秀妍? </a>   <li> <a href="/transcode?q=%E6%9E%97%E5%85%81%E5%84%BF%E5%BF%AB%E4%B9%90%E5%A4%A7%E6%9C%AC%E8%90%A5&amp;pn=2&amp;pos=2&amp;m=8102a2c5c318317c9114f7804a63ca70cc924669&amp;u=http%3A%2F%2Fwww.hanyutai.com%2Fthread-25848-1-1.html" data-pos="3"> 少女时代<b>林允儿</b>单独出演《<b>快乐大本营</b>》,众粉丝翘首以待! </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '少女时代林允儿快乐大本营首秀 跟着允儿学穿搭美美哒(图) ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '少女时代林允儿快乐大本营首秀 跟着允儿学穿搭美美哒(图) '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";