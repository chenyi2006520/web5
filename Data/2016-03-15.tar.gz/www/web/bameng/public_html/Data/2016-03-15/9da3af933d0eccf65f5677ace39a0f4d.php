s:18676:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>伊顿公学咋招生?100多名尖子生曾全军覆没!- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">伊顿公学咋招生?100多名尖子生曾全军覆没!</h1> <p id="source-and-time"><span id=source>中国日报网</span><time id=time>2015-09-11 17:35:24</time></p> </header>  <div id="news-body"><p>--【9.18活动预告】世界名校面试官与你相约蓉城，不见不散!</p><p class="header">主题:世界顶级名校教育和移民分享会</p><p>时间:9月18号 14:00-17:00</p><p>地点:<a href="http://m.so.com/s?q=%E6%88%90%E9%83%BD%E9%A6%99%E6%A0%BC%E9%87%8C%E6%8B%89%E5%A4%A7%E9%85%92%E5%BA%97&amp;src=newstranscode" class="qkw">成都香格里拉大酒店</a>3楼 稻城剑阁</p><p>特邀嘉宾:<a href="http://m.so.com/s?q=%E4%BC%8A%E9%A1%BF%E5%85%AC%E5%AD%A6&amp;src=newstranscode" class="qkw">伊顿公学</a>面试官，瑞士玫瑰山学校校长及招生官，四川<a href="http://m.so.com/s?q=%E6%98%8E%E7%82%AC&amp;src=newstranscode" class="qkw">明炬</a>律师事务所移民总监</p><p>预约热线:<a href="http://m.so.com/s?q=028-66500042&amp;src=newstranscode" class="qkw">028-66500042</a>   400-86-16851</p><p><img src="http://p33.qhimg.com/t01c14e80092d3500e0.jpg?size=554x368"></p><p>在全球化的背景下，越来越多的父母为了培养孩子的国际视野和国际眼光，纷纷把孩子送到国外接受教育，而且年龄也越来越低龄化。如今“低龄化”似乎已经成为国内一种留学趋势，在很多家长们看来，将孩子送到国外的中小学有诸多的益处:首先是从小就给孩子一个学习英语的语言环境;其次，我国基础教育更加注重理论教学，在英国等国家，中小学阶段更加注重创新、实践、开拓能力的培养;此外还有一个比较关键的问题是，在英国等国家进入知名院校(如哈佛、<a href="http://m.so.com/s?q=%E7%89%9B%E6%B4%A5&amp;src=newstranscode" class="qkw">牛津</a>、剑桥等)学习的机会，相对中国激烈的高考竞争，要容易获得一些，而且子女也没有那么大的压力。但是如果只是单纯的出国留学，在学校申请、专业选择、留学费用以及就业机会等方面都会有诸多限制，所以现在越来越多的家长为了子女的教育而选择移民，不仅可以给子女创造更好的教育环境，而且对于家庭也拥有了一个全球化平台。</p><p>择校一直是家长们非常头疼的问题，而且国外的中学也和中国的中学一样，都有参差不齐，那么怎样为子女选择一个最好的学校，就成了所有家长们最关心的问题，为此明炬侨美特邀<a href="http://m.so.com/s?q=%E5%A8%81%E5%BB%89%E7%8E%8B%E5%AD%90&amp;src=newstranscode" class="qkw">威廉王子</a>和哈里王子的母校伊顿公学的面试官以及全欧洲最好的中学瑞士国际中学的面试官，分别来为大家介绍两所世界名校中学的申请要求、申请流程、学校教育质量、学校软硬设施以及学校丰富的校园生活，让大家在择校方面没有后顾之忧。在考虑学校的同时我们也一样关心移民问题，四川明炬<a href="http://m.so.com/s?q=%E5%BE%8B%E5%B8%88%E4%BA%8B%E5%8A%A1%E6%89%80&amp;src=newstranscode" class="qkw">律师事务所</a>投资移民部移民总监<a href="http://m.so.com/s?q=%E5%90%B4%E4%BD%B3&amp;src=newstranscode" class="qkw">吴佳</a>女士将会为大家介绍英国移民方式，以及移民对<a href="http://m.so.com/s?q=%E5%AD%90%E5%A5%B3%E6%95%99%E8%82%B2&amp;src=newstranscode" class="qkw">子女教育</a>和家庭的好处。 这是一次千载难逢的机会，即可以近距离接触世界名校的面试官，又可以了解英国移民及移民优势，如果有任何问题，还可以进行现场咨询。</p><p>伊顿公学是英国最著名的贵族中学，排名全英前十。是一座古老的学府，由<a href="http://m.so.com/s?q=%E4%BA%A8%E5%88%A9%E5%85%AD%E4%B8%96&amp;src=newstranscode" class="qkw">亨利六世</a>于1440年创办。伊顿以“精英摇篮”、“绅士文化”闻名世界，也素以军事化的严格管理著称，学生成绩大都十分优异，被公认是英国最好的中学，是<a href="http://m.so.com/s?q=%E8%8B%B1%E5%9B%BD%E7%8E%8B%E5%AE%A4&amp;src=newstranscode" class="qkw">英国王室</a>、政界经济界精英的培训之地。这里曾造就过20位英国首相，培养出了诗人<a href="http://m.so.com/s?q=%E9%9B%AA%E8%8E%B1&amp;src=newstranscode" class="qkw">雪莱</a>、经济学家凯恩斯，演员<a href="http://m.so.com/s?q=%E6%B1%A4%E5%A7%86%C2%B7%E5%B8%8C%E5%BE%B7%E5%8B%92%E6%96%AF%E9%A1%BF&amp;src=newstranscode" class="qkw">汤姆·希德勒斯顿</a>、埃迪·雷德梅恩，还有“站在食物链顶端的男人”<a href="http://m.so.com/s?q=%E8%B4%9D%E5%B0%94%C2%B7%E6%A0%BC%E9%87%8C%E5%B0%94%E6%96%AF&amp;src=newstranscode" class="qkw">贝尔·格里尔斯</a>。也是英国王位第二号继承人，威廉王子和哈里王子的母校。伊顿每年250名左右的毕业生中，70余名进入牛津、剑桥，70%进入世界名校。</p><p><img src="http://p32.qhimg.com/t01bd5b2807f17d7d69.jpg?size=373x205"></p><p>.<a href="http://m.so.com/s?q=%E7%91%9E%E5%A3%AB&amp;src=newstranscode" class="qkw">瑞士</a>玫瑰山学校</p><p>瑞士<a href="http://m.so.com/s?q=%E7%8E%AB%E7%91%B0%E5%B1%B1&amp;src=newstranscode" class="qkw">玫瑰山</a>学校成立于1889年，是世界上闻名遐迩的寄宿制中学之一。该校位于一个100,000平米的<a href="http://m.so.com/s?q=%E7%A7%81%E4%BA%BA%E5%85%AC%E5%9B%AD&amp;src=newstranscode" class="qkw">私人公园</a>中，能够俯瞰中世纪的圣加仑城，有着悠久历史的古建筑群。该校以个性化的教学方式以及国际化的教育理念文明。认为学生不仅仅需要学习书本知识，更需要锻炼一系列的社交能力。诸多公司高管、艺术界、政界和欧洲皇室及名流皆出自该校，这为学生提供了广泛而扎实的校友关系网。同时该学校拥有自己的私立的瑞士顶级<a href="http://m.so.com/s?q=%E6%BB%91%E9%9B%AA%E5%9C%BA&amp;src=newstranscode" class="qkw">滑雪场</a>之一，冬季是最理想的私密度假胜地。</p><p>明炬侨美:四川明炬律师事务所投资移民部是四川明炬律所下唯一投资移民部门，拥有专业的移民顾问及移民律师团队，为客户移民提供专业化、个性化、私密化的移民法律服务。移民国家包括美国、英国、法国、匈牙利、西班牙、葡萄牙、意大利、希腊、<a href="http://m.so.com/s?q=%E6%96%90%E6%B5%8E&amp;src=newstranscode" class="qkw">斐济</a>等。</p><p class="header">明炬侨美移民优势:</p><p>1、西南地区首家特大律所领导投资移民机构。</p><p>2、国内外资深业内人士双重保障助您移民申请无忧。</p><p>3、专业优秀的咨询服务团队确保申请成功。</p><p class="header">4、及时准确的信息反馈。</p><p class="header">5. 专业的项目团队</p><p>明炬侨美小编温馨提示:如果您有任何美国移民问题都可以咨询我们哦!</p><p class="header">全国电话:400-86-16851</p><p class="header">咨询热线:028-66500042</p><p>公司网站:http://www.qmvisa.com/</p><p>公司地址:成都市天府大道北段1700号<a href="http://m.so.com/s?q=%E7%8E%AF%E7%90%83%E4%B8%AD%E5%BF%83&amp;src=newstranscode" class="qkw">环球中心</a>N1-11F</p><p class="header">.</p><p><img src="http://p35.qhimg.com/t015e6f936ee73d2370.jpg?size=404x187"></p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://cnews.chinadaily.com.cn/2015-09/11/content_21845477.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='138c22d7871276368d0c2846d5c208f5'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>伊顿公学</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%BC%8A%E9%A1%BF%E5%85%AC%E5%AD%A6&amp;pn=1&amp;pos=5&amp;m=4e4d0239a755caadf5d984b14816b1b267e929d0&amp;u=http%3A%2F%2Fcnews.chinadaily.com.cn%2F2015-09%2F11%2Fcontent_21845477.htm" data-pos="1"> <b>伊顿公学</b>咋招生?100多名尖子生曾全军覆没! </a>   <li> <a href="/transcode?q=%E4%BC%8A%E9%A1%BF%E5%85%AC%E5%AD%A6&amp;pn=1&amp;pos=6&amp;m=154c538b92e34c87466fb32ad3a9cbbce1166efd&amp;u=http%3A%2F%2Fnj.sell.house365.com%2Fnews%2F2016%2F0308%2F026129569.html" data-pos="2"> 南外确定开办江宁分校 参照<b>伊顿公学</b>品质 </a>   <li> <a href="/transcode?q=%E4%BC%8A%E9%A1%BF%E5%85%AC%E5%AD%A6&amp;pn=1&amp;pos=7&amp;m=04e87fcaa9daf3dcd9eb76657b133a118b6951a4&amp;u=http%3A%2F%2Fnews.china.com.cn%2Fworld%2F2015-06%2F23%2Fcontent_35883870.htm" data-pos="3"> BBC:英名校<b>伊顿公学</b>向中国学生提供网上课程 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '伊顿公学咋招生?100多名尖子生曾全军覆没!' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '伊顿公学咋招生?100多名尖子生曾全军覆没!'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";