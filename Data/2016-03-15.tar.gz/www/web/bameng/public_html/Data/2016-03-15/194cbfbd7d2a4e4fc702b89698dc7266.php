s:18455:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>不鸣则已一鸣惊人 《战意》制作人王希坦言心路历程- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">不鸣则已一鸣惊人 《战意》制作人王希坦言心路历程</h1> <p id="source-and-time"><span id=source>网易游戏</span><time id=time>2016-03-08 10:30:58</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E4%B8%8D%E9%B8%A3%E5%88%99%E5%B7%B2%EF%BC%8C%E4%B8%80%E9%B8%A3%E6%83%8A%E4%BA%BA&amp;src=newstranscode" class="qkw">不鸣则已，一鸣惊人</a>。这是一种厚积薄发的力量，也是一种守得云开见月明的自信，更是一种不达目的死不休的坚持。数年不鸣后的一声长鸣，往往格外响彻云霄，震惊世人。或许，这正是<a href="http://m.so.com/s?q=%E3%80%8A%E6%88%98%E6%84%8F%E3%80%8B&amp;src=newstranscode" class="qkw">《战意》</a>制作人王希将他的工作室命名为“不鸣”的原因。从低调内敛、蛰伏四年，到锋芒初显、一鸣惊人，<a href="http://m.so.com/s?q=%E7%8E%8B%E5%B8%8C&amp;src=newstranscode" class="qkw">王希</a>、 “不鸣”与《战意》走过了怎样的心路历程?一个寻梦人和一个执着的工作室，耗费四年时间制作出的网游，又怎能不让人期待万分?</p><p>《战意》制作人王希坦言心路历程 (来源:)</p><p><img src="http://p31.qhimg.com/t014c25fea8636ca97f.jpg?size=549x309"></p><p class="img-title">《战意》令人期待</p><p class="header">追梦--做属于中国的世界级游戏</p><p>回到中国，从头开始，这对于王希来说并非是一个轻松的决定。曾供职<a href="http://m.so.com/s?q=%E5%BE%AE%E8%BD%AF&amp;src=newstranscode" class="qkw">微软</a>、Bungie等知名企业的他本就拥有着无限的前景，但为了追寻制作属于中国的世界级游戏的梦想，他舍弃了异国优渥的条件，毅然回国。刚回国的时候，面对他的是无产品、无资金、无人员的三无场面;慢慢的，他凭借自己的能力、魅力与梦想，吸引了许多毕业<a href="http://m.so.com/s?q=%E4%BA%8E%E6%B8%85%E5%8D%8E&amp;src=newstranscode" class="qkw">于清华</a>、复旦、浙大等一流名校的优秀人才加入到他的团队中。</p><p><img src="http://p31.qhimg.com/t01c77c60811309e1f5.jpg?size=550x435"></p><p><a href="http://m.so.com/s?q=%E5%B8%A6%E5%88%BA%E7%8E%AB%E7%91%B0&amp;src=newstranscode" class="qkw">带刺玫瑰</a>--《战意》女武将</p><p>在王希看来，不鸣，表达的是一种坚持，一种态度，一种自信。不鸣工作室希望通过自己的努力，在亿万玩家心中，建立掷地有声的口碑，做出中国人自己的世界级游戏。对于这过程中的艰辛与挑战，王希和他的团队，早已有所准备。</p><p>四年，是不鸣蛰伏的时间，在快速消费的今天，用如此漫长的时间去制作一款游戏，近乎苛刻的打磨、调整、完善，似乎有些不合时宜，但正如一鸣惊人需要三年的沉寂，而创造全新的游戏品类，更需要旁人难及的偏执。</p><p><img src="http://p32.qhimg.com/t01235e07d0f3fe903c.jpg?size=549x309"></p><p class="img-title">精心刻画的古代战场</p><p class="header">惊艳--惊鸿一瞥引发热议</p><p>此次视频中还首次展示了游戏内的部分场景，效果十分惊艳。《战意》将自己定义为超真实3D战争网游，对于战争网游，大家的印象往往是粗犷宏大有余，而细腻精致不足。但《战意》却完全颠覆了这一认知--它不仅拥有着<a href="http://m.so.com/s?q=%E5%85%A8%E5%86%9B%E5%87%BA%E5%87%BB&amp;src=newstranscode" class="qkw">全军出击</a>攻打城池这种让人热血沸腾的史诗场景，战马奔跑时肌肉的颤动、士兵铠甲在阳光下反射的光泽、神机营射击的动作等等，都栩栩如生，令人赞叹不已。犹如好莱坞大片一般的真人动作采集技术，在网游中使用实属罕见。</p><p><img src="http://p35.qhimg.com/t01179c6ef402b59a99.jpg?size=549x309"></p><p class="img-title">光影效果出众</p><p>王希表示，像<a href="http://m.so.com/s?q=%E9%98%BF%E5%87%A1%E8%BE%BE&amp;src=newstranscode" class="qkw">阿凡达</a>那样宏大的世界，十年内，就可以用计算机技术实时的通过游戏的方式展现给玩家。而《战意》的惊艳表现，或许便是这过程中的一个里程碑式作品。</p><p class="header">交互--开放研发尊重玩家</p><p>在王希看来，一款优秀的游戏，绝不是制作人单方面的理念灌输，更是一种玩家和制作人之间通过互动、讨论甚至批评，共同创作出的智慧与技术结晶。在这种观点的引领下，《战意》对玩家的需求十分重视，为了使游戏尽可能的符合明朝的真实历史，《战意》请来许多专业人士对明朝的政治、军事、科技情况进行指导，确保还原一个原汁原味的明朝战场。</p><p><img src="http://p33.qhimg.com/t01735edffdc71290a2.jpg?size=443x640"></p><p>长枪无敌--《战意》<a href="http://m.so.com/s?q=%E5%BE%A1%E6%9E%97&amp;src=newstranscode" class="qkw">御林</a></p><p>近期，《战意》还启动了“开放式研发”系列活动，从征集NPC名称，到寻找脸模，再到邀请玩家品鉴明朝名人、军械等，玩家的建议都能直达不鸣工作室，作为研发人员工作的重要参考。在王希看来，这样制作出来的游戏，也许不会最大，但一定能够开创一个品类，更能够帮助不鸣工作室，代表中国人，站在游戏行业的最巅峰。</p><p><img src="http://p32.qhimg.com/t01f5e3a062ccb86fc1.jpg?size=549x309"></p><p class="img-title">肃杀战场，冷酷鬼使</p><p>这样执着的人，这样认真的团队，究竟将为我们带来怎样的一款战争网游?登录《战意》概念官网:http://z.163.com/，预约游戏首测激活码，进入战场，一探究竟!</p><p class="header">关于《战意》</p><p>《战意》为<a href="http://m.so.com/s?q=%E7%BD%91%E6%98%93&amp;src=newstranscode" class="qkw">网易</a>旗下“不鸣工作室”历时4年倾力打造的超真实3D战争网游。其基于明代背景，让玩家在游戏中征战四方、<a href="http://m.so.com/s?q=%E7%BA%B5%E6%A8%AA%E6%B2%99%E5%9C%BA&amp;src=newstranscode" class="qkw">纵横沙场</a>，还原了宏大的冷兵器<a href="http://m.so.com/s?q=%E6%88%98%E4%BA%89%E4%B8%96%E7%95%8C&amp;src=newstranscode" class="qkw">战争世界</a>。《战意》具有极精细画面品质与超高表现力，为网易2016年战略级产品。</p><p><img src="http://p31.qhimg.com/t01395e43b5a182ea39.jpg?size=549x309"></p><p class="img-title">《战意》四大武将出身</p><p>《战意》独创即时动作战术(Real-time Action Tactic)玩法。玩家可以在战场里英勇拼杀，也可以排兵布阵、指挥军团战斗。游戏使用较低的<a href="http://m.so.com/s?q=%E7%AC%AC%E4%B8%89%E4%BA%BA%E7%A7%B0%E8%A7%86%E8%A7%92&amp;src=newstranscode" class="qkw">第三人称视角</a>，具有高度战场代入感，既有灵活的、极富真实感的单武将操作，又有策略向、军团指挥上的变化和挖掘深度。战斗方面基于古代战争的真实战斗方式，武器、装备、器械、兵团均具有极高精度与物理材质还原度。战斗动作与招式充满张力与力量感，避免了割草式刷刷刷的无趣感，也毫无艰涩，战斗流畅爽快。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://play.163.com/16/0308/10/BHKLCN6U00314J6K.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='c57001c11ed32b9df35eadc267c8c22c'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>王希</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%8E%8B%E5%B8%8C&amp;pn=1&amp;pos=5&amp;m=40f7204b0fc846784834c1de1926c97abdc3fbe2&amp;u=http%3A%2F%2Fplay.163.com%2F16%2F0308%2F10%2FBHKLCN6U00314J6K.html" data-pos="1"> 不鸣则已一鸣惊人 《战意》制作人<b>王希</b>坦言心路历程 </a>   <li> <a href="/transcode?q=%E7%8E%8B%E5%B8%8C&amp;pn=1&amp;pos=6&amp;m=f35047ed03673bf627825ffa97f488581bf3aeb9&amp;u=http%3A%2F%2Fxin.52pk.com%2Fsp%2F20160308%2Fsp_6666808.shtml" data-pos="2"> 《战意》制作人<b>王希</b>坦言心路历程 </a>   <li> <a href="/transcode?q=%E7%8E%8B%E5%B8%8C&amp;pn=1&amp;pos=7&amp;m=3c4c0e31e86e73572d095193013cb1526dbb2425&amp;u=http%3A%2F%2Fnews.sina.com.cn%2Fm%2F2014-07-16%2F215930531130.shtml" data-pos="3"> <b>王希</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '不鸣则已一鸣惊人 《战意》制作人王希坦言心路历程' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '不鸣则已一鸣惊人 《战意》制作人王希坦言心路历程'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";