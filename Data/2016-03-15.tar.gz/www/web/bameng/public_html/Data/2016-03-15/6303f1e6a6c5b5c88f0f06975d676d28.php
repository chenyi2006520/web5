s:15686:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>大唐电信部署咸阳机场"航旅e巴"成功运行- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">大唐电信部署咸阳机场"航旅e巴"成功运行</h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2016-03-01 13:49:00</time></p> </header>  <div id="news-body"><p>为更好满足乘坐<a href="http://m.so.com/s?q=%E6%9C%BA%E5%9C%BA%E5%A4%A7%E5%B7%B4&amp;src=newstranscode" class="qkw">机场大巴</a>用户对于宽带上网的需求，2016年1月，由<a href="http://m.so.com/s?q=%E5%A4%A7%E5%94%90%E7%94%B5%E4%BF%A1&amp;src=newstranscode" class="qkw">大唐电信</a>旗下西安大唐公司携手西部机场集团实业(西安)有限公司、聚富网络、<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E8%81%94%E9%80%9A&amp;src=newstranscode" class="qkw">中国联通</a>而联合搭建的移动商业<a href="http://m.so.com/s?q=WiFi&amp;src=newstranscode" class="qkw">WiFi</a>整体方案“航旅e巴”项目正式上线运营。</p><p><img src="http://p32.qhimg.com/t013876796e60f23ce0.jpg?size=259x194"></p><p><img src="http://p31.qhimg.com/t0149a65631806d00c8.jpg?size=260x195"></p><p>随着WiFi技术的不断迭代更新，其所带来的建设模式、应用模式、<a href="http://m.so.com/s?q=%E5%95%86%E4%B8%9A%E6%A8%A1%E5%BC%8F&amp;src=newstranscode" class="qkw">商业模式</a>已经由大规模集中部署逐渐转变成细分人群的精细化部署，并衍生出了新的商业模式。“互联网+交通”是公共交通发展的必然趋势，也是智慧城市建设中的一个重要环节，是国家“互联网+”战略的重要体现。</p><p>“<a href="http://m.so.com/s?q=%E8%88%AA%E6%97%85e%E5%B7%B4&amp;src=newstranscode" class="qkw">航旅e巴</a>”项目的成功上线运行将为西安机场乃至全国机场商旅人群提供高品质互联网服务。旅客通过“西部机场实业安全服务微镜头”和“航旅e巴”<a href="http://m.so.com/s?q=%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%B9%B3%E5%8F%B0&amp;src=newstranscode" class="qkw">微信公众平台</a>浏览新闻、查询机场服务信息等相关内容，实现了机场服务的无缝延伸。通过“航旅e巴”应用抢占高端用户互联网入口，凭借每年500万次以上的商旅客户数据，依托大唐电信以及合作伙伴在“互联网+”应用领域深厚的技术和方案储备，实现以“互联网+交通、金融、保险、文化、旅游”等多行业的叠加应用，不断拓展业务范围，面向细分用户提供特色业务，提高网络应用价值，全面转型“硬件+互联网入口+<a href="http://m.so.com/s?q=%E5%A4%A7%E6%95%B0%E6%8D%AE&amp;src=newstranscode" class="qkw">大数据</a>+平台运营”。</p><p><img src="http://p31.qhimg.com/t01d303392c92169096.jpg?size=367x245"></p><p>大唐电信在本项目中部署了自主研发的<a href="http://m.so.com/s?q=Smart&amp;src=newstranscode" class="qkw">Smart</a> DT-Fi云管理平台和车载无线网关产品<a href="http://m.so.com/s?q=R3000&amp;src=newstranscode" class="qkw">R3000</a> AP-M。Smart <a href="http://m.so.com/s?q=DT-Fi&amp;src=newstranscode" class="qkw">DT-Fi</a>云平台采用智能<a href="http://m.so.com/s?q=%E4%BA%91%E8%AE%A1%E7%AE%97&amp;src=newstranscode" class="qkw">云计算</a>等技术，负责实现对车载无线网关集中管理，与其他业务平台对接和管理，堪称网络的“心脏”，可向大数据平台提供各类用户数据，是后期商业开发、精准运营的核心。车载无线网关R3000 <a href="http://m.so.com/s?q=AP-M&amp;src=newstranscode" class="qkw">AP-M</a>，上行通过3G/4G网络，下行通过WiFi网络实现大巴车内无线覆盖，为乘客提供高品质互联网服务，同时通过对接车辆安全监控设备为运营单位和监管部门提供可靠的安全运营保障。</p><p>作为国内知名的信息通信服务提供商，大唐电信拥有雄厚的综合解决方案提供能力。凭借深厚的技术实力和经验，大唐电信在“互联网+行业”领域持续探索和创新，已拥有交通、教育、旅游、金融、文化、商业物流等领域的完整解决方案，并取得了规模应用。“互联网+交通”是大唐电信深入布局的领域,同时也是公司WLAN无线接入行业重点拓展方向，通过“硬件+互联网入口+大数据平台+运营”打造全新商业模式。运用云计算、大数据等技术，致力为客户提供高性能网络解决方案、完善的数据增值及运营平台服务。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://game.people.com.cn/n1/2016/0301/c210053-28162086.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='33677b7dbbff7d02476b934b722fc003'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>机场运行</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9C%BA%E5%9C%BA%E8%BF%90%E8%A1%8C&amp;pn=1&amp;pos=8&amp;m=5cf22670f972df3ca0d4d655b9dbab2298022a70&amp;u=http%3A%2F%2Fwww.nxing.cn%2Fwap%2Farticle%2F3925751.html" data-pos="1"> 青岛<b>机场</b>全面<b>运行</b>大安保机制强化管控措施 </a>   <li> <a href="/transcode?q=%E6%9C%BA%E5%9C%BA%E8%BF%90%E8%A1%8C&amp;pn=1&amp;pos=9&amp;m=b4ba97e3a4857119877d8a75413ef4246072b186&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fkuaixun_0303%2F4506007.html" data-pos="2"> 海口飞往博鳌客机平稳降落 博鳌<b>机场</b>8日试<b>运行</b> </a>   <li> <a href="/transcode?q=%E6%9C%BA%E5%9C%BA%E8%BF%90%E8%A1%8C&amp;pn=1&amp;pos=10&amp;m=519a7b2c489a9be128733330ce6e75a2591cc4f5&amp;u=http%3A%2F%2Fwww.nxing.cn%2Farticle%2F3919900.html" data-pos="3"> 阿克苏<b>机场</b>参加阿克苏<b>运行</b>办组织的冬季航班<b>运行</b>协调会 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '大唐电信部署咸阳机场"航旅e巴"成功运行' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '大唐电信部署咸阳机场"航旅e巴"成功运行'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";