s:14552:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>陕西租赁型保障房验收后3个月内要完成配租 租赁期限不得超过3年- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">陕西租赁型保障房验收后3个月内要完成配租 租赁期限不得超过3年</h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2016-03-12 08:36:00</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t01b2e53b46b948139b.jpg?size=480x360"></p><p>来自省<a href="http://m.so.com/s?q=%E4%BF%9D%E9%9A%9C%E6%80%A7%E4%BD%8F%E6%88%BF&amp;src=newstranscode" class="qkw">保障性住房</a>管理中心的消息，根据陕西近日发布的<a href="http://m.so.com/s?q=%E3%80%8A%E5%8A%A0%E5%BC%BA%E7%A7%9F%E8%B5%81%E5%9E%8B%E4%BF%9D%E9%9A%9C%E6%88%BF%E5%90%8E%E7%BB%AD%E7%AE%A1%E7%90%86%E5%B7%A5%E4%BD%9C%E6%8C%87%E5%AF%BC%E6%84%8F%E8%A7%81%E3%80%8B&amp;src=newstranscode" class="qkw">《加强租赁型保障房后续管理工作指导意见》</a>的要求，租赁型<a href="http://m.so.com/s?q=%E4%BF%9D%E9%9A%9C%E6%88%BF&amp;src=newstranscode" class="qkw">保障房</a>项目应在规定时间内完成建设任务，<a href="http://m.so.com/s?q=%E7%AB%A3%E5%B7%A5%E9%AA%8C%E6%94%B6&amp;src=newstranscode" class="qkw">竣工验收</a>后3个月内要完成分配入住，租赁期限原则上不得超过3年。</p><p>租赁型保障房建好后多久能够入住?建设一栋租赁型保障房要多久?是否可以出售?价格怎么定……这些问题都在<a href="http://m.so.com/s?q=%E3%80%8A%E6%8C%87%E5%AF%BC%E6%84%8F%E8%A7%81%E3%80%8B&amp;src=newstranscode" class="qkw">《指导意见》</a>中有明确的规定。加快租赁型保障房建设进度，租赁型保障房项目应在规定时间内完成建设任务，在建设周期内竣工(项目建设周期为:多层18个月、小高层24个月、高层30个月)，并确保在项目竣工前6个月编制完成配租配售方案、竣工验收后3个月内完成分配入住。</p><p>租赁型保障房应贯彻以租为主的原则。确需出售的，应严格坚持先租后售，按照轮候次序先承租给保障对象，在承租人自愿的前提下，出售给承租者。出售比例以县(区)为单位，不得超过租赁型保障房总套数的40%;出售时<a href="http://m.so.com/s?q=%E5%85%B1%E6%9C%89%E4%BA%A7%E6%9D%83&amp;src=newstranscode" class="qkw">共有产权</a>比例应与承购人协商确定。鼓励共有产权个人所占比例高于60%，当达到60%以上时不再缴纳租金，未达到60%时仍需缴纳政府产权部分的租金。此外，记者了解到，租赁型保障房出售时，出售价格由当地政府价格主管部门会同保障性住房主管部门，在市场评估价的基础上自行确定;租赁型保障房出售收入和租金实行“收支两条线”管理。</p><p>租赁型保障房租赁期限原则上不得超过3年，合同期满后需要续租的，承租人须提前3个月提出申请，经审核符合条件的，准予续租并签订续租合同;不符合条件且退出有困难的，可续租原住房，同时应调整租金。共有产权租赁型保障房原则上不得转让，确需转让的，由政府优先回购，5年后方可自由转让，转让的收入，应当按照产权比例进行分配。(记者王嘉通讯员<a href="http://m.so.com/s?q=%E9%A9%AC%E7%92%87&amp;src=newstranscode" class="qkw">马璇</a>)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://house.people.com.cn/n1/2016/0312/c164220-28193383.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='05fc480a24a5e72db8735604b8d21977'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>保障房</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%BF%9D%E9%9A%9C%E6%88%BF&amp;pn=1&amp;pos=7&amp;m=d91dd38613b68b7db670bd22f16a9b60bdb0e501&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fkuaixun_0314%2F4729657.html" data-pos="1"> 简化程序 北京简化<b>保障房</b>申请少交5项材料 </a>   <li> <a href="/transcode?q=%E4%BF%9D%E9%9A%9C%E6%88%BF&amp;pn=1&amp;pos=8&amp;m=70b605d10da528d88cda4d0b1ccdba806f7af809&amp;u=http%3A%2F%2Fwww.ce.cn%2Fcysc%2Ffdc%2Ffc%2F201603%2F13%2Ft20160313_9456416.shtml" data-pos="2"> <b>保障房</b>申请材料"瘦身" </a>   <li> <a href="/transcode?q=%E4%BF%9D%E9%9A%9C%E6%88%BF&amp;pn=1&amp;pos=9&amp;m=7a29ef457653269a815f5b62bfc630a94fe658ed&amp;u=http%3A%2F%2Fwww.china.com.cn%2Ftravel%2Fhotel%2F2016-03%2F14%2Fcontent_38017279.htm" data-pos="3"> 北京住保:简化<b>保障房</b>申请材料 不必再交纳税材料 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '陕西租赁型保障房验收后3个月内要完成配租 租赁期限不得超过3年' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '陕西租赁型保障房验收后3个月内要完成配租 租赁期限不得超过3年'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";