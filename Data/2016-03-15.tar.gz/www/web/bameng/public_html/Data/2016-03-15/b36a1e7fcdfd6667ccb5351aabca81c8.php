s:28617:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>2016年猴年新春祝福语大全:欢乐拜年短信 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">2016年猴年新春祝福语大全:欢乐拜年短信 </h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-02-06 00:45:34</time></p> </header>  <div id="news-body"><p>来源标题: 2016年猴年新春祝福语大全:欢乐<a href="http://m.so.com/s?q=%E6%8B%9C%E5%B9%B4%E7%9F%AD%E4%BF%A1&amp;src=newstranscode" class="qkw">拜年短信</a></p><p>2016年猴年到来了，该给亲朋好友送去新年的祝福了，中国教育在线准备了2016年猴年新春祝福语大全七:欢乐拜年短信，供大家参考。</p><p><img src="http://p31.qhimg.com/t01064fb4c559c44ce0.jpg?size=300x235"></p><p>1、祝你猴年一帆风顺，二龙腾飞，三阳开泰，四季平安，<a href="http://m.so.com/s?q=%E4%BA%94%E7%A6%8F%E4%B8%B4%E9%97%A8&amp;src=newstranscode" class="qkw">五福临门</a>，六六大顺，七星高照，八方来财，九九同心，十全十美，百事亨通，千事吉祥，万事如意!</p><p>2、猴年第一天，一心一意送你祝福:祝你事业发达第一，平安健康第一，婚姻美满第一，家庭和谐第一，赚钱发财第一，开心快乐第一，轻松悠闲都是第一。</p><p>3、猴年恭喜你!你获得本公司头奖50万元。请带上安全防备用品到平价收银台凭密码领取奖金，密码是:把钱拿出来!!</p><p>4、悠悠的云柔柔的飘，红火的日子祝福到，蓝蓝的天青青的草，猴年的歌声真美妙，红红的春联长长的笑，热闹的美景你家绕，动听的歌欢快的舞，一条短信一生朋友，春节快乐!</p><p>5、祝你猴年里娶的老婆是小昭，交的朋友是令狐冲，做个男儿像乔峰，出来混得如小宝!</p><p>6、<a href="http://m.so.com/s?q=%E6%96%B0%E5%B9%B4%E5%8F%88%E6%9D%A5%E5%88%B0&amp;src=newstranscode" class="qkw">新年又来到</a>，我也不迟到，祝福早报道，短信问个好，办事<a href="http://m.so.com/s?q=%E6%AD%A5%E6%AD%A5%E9%AB%98&amp;src=newstranscode" class="qkw">步步高</a>，生活日日妙，好运天天交，越长越俊俏，地上长元宝，墙上出钞票!祝春节快乐!</p><p>7、值此新春，感谢您过去一年对我的支持，给您拜年了!祝您在猴年，位高权重责任轻，钱多事少离家近，每天睡到自然醒，工资领到手抽筋，奖金多到车来运，别人加班你加薪。猴年鸿运!</p><p>8、新年拉近了我们成长的距离，新年染红了我们快乐的生活，新年让我们截取下了四季的片段，在这一刻，我们已经感受到了春的气息。春节了，祝你在猴年里身体健康，宏图大展!</p><p>9、新年好心情，天天没烦恼;举头揽幸福，低头抱美好;一颗快乐心，一家温馨情;幸福身边在，健康迎未来;朋友，我在远方祝你:<a href="http://m.so.com/s?q=%E6%98%A5%E8%8A%82%E5%A5%BD&amp;src=newstranscode" class="qkw">春节好</a>!</p><p>10、猴年拜年祝福语_用遍地红叶铺成床，把碧空蓝天当做房，伴着鸟儿的歌唱，闻着桂花的清香，枕着天边的云霞，香香甜甜入梦乡。周末了，好好休息，祝幸福似秋水绵长。</p><p>11、新年到了，事儿多了吧?招待客人别累着，狼吞虎咽别撑着，啤的白的别掺着，孩子别忘照顾着，最后我的惦念常带着。</p><p>12、猴年猴胆，猴年猴威，中间猴年别以为只是猴乖乖，卧薪尝了苦胆，有谋敢为才能有事成的霸气猴威，让我们过个和谐有谋敢为的猴年，期待猴威的到来，新年好。</p><p>13、新年到，我将好运作邮票、真情作邮戳、幸福作信封，写上健康、填上快乐、加上好运、注上平安，附上吉祥，然后把它放进甜蜜的邮筒，祝你春节快乐。</p><p>14、新春的钟声已经响起，深深的思念已经传递，暖暖的问候藏在心底，真心的祝愿全部送给你。祝你春节快乐，万事如意，财运滚滚，一生平安!</p><p>15、喜庆的歌儿唱起来，欢快的音乐动起来，火舞的<a href="http://m.so.com/s?q=%E9%9D%92%E6%98%A5%E8%88%9E&amp;src=newstranscode" class="qkw">青春舞</a>起来，美好的生活颂起来，张灯又结彩，财源滚滚来，举杯共欢庆，生活更幸福。期待猴年的你像这律动的音乐，凑出生活美好乐章。</p><p>16、西风徐渐，流年暗偷换。月圆星灿，烟火重弥漫。钟响福现，雪花又飘散。新春问候，祝福永存在:喜度春节，身体健康，祝愿幸福平安。</p><p>17、我点击春节，搜索祥和画面;我复制笑脸，粘贴新春网站;我打开邮箱，编辑最美语言，发送最好祝愿:希望你删除烦恼，存储快乐每一天，备份幸福每一年。</p><p>18、<a href="http://m.so.com/s?q=%E9%99%A4%E5%A4%95&amp;src=newstranscode" class="qkw">除夕</a>到，放鞭炮，家家户户好热闹;舞龙灯，踩高跷，合家欢乐步步高!眼看大年初一快来到，人人开心齐欢笑，提前祝你春节好，猴年祝福我最早!</p><p>19、除夕到来菩萨忙，各路神仙送吉祥:财神送你金元宝，寿星保你身安康，文殊给你大智慧，观音佑你幸福长，弥勒让你乐不断，福星伴你走四方!春节快乐!</p><p>20、除夕焰火飞满天，春节歌声飘满天，猴年祝福写满天，各路财神站满天，节日礼物挂满天。祝你猴年财源滚滚，财福多多，财气粗粗，财富满满。</p><p><img src="http://p35.qhimg.com/t01c23f60af35d7e1f0.jpg?size=300x300"></p><p>21、春节到，挂红灯，生活就会红火火;踩高跷，事业就会步步高;放鞭炮，财富就会遍地有;互拜年，拜长辈恭敬叩首，平辈相互道贺;我送上短信拜年，祝你日子红红火火，事业蒸蒸日上，家庭和和睦睦。</p><p>22、春节到了，“幸福”、“快乐”、“财富”、“健康”等几位哥们想和你好好聚聚联络联络感情。到时候别忘了请客，这几位朋友都有好礼相送不会让你吃亏的。祝你春节快乐。</p><p>23、春节的礼炮轰开好运的通道，春节的红包带来新年的美好，春节的喜庆奉上吉祥的围绕，春节的祝福送去真诚的祈祷;祝你春节快乐美好，开心舒畅逍遥!</p><p>24、春联飘飘，烟火袅袅，鞭炮飞舞身旁绕，满堂热闹，吉祥围你转，如意跟你跑，腰包鼓鼓，烦恼少少，彩票期期中，快乐天天笑，春节快乐!</p><p>25、春运开始了，我的吉祥号列车已发车，现已沿幸福铁轨，以迅雷不及掩耳的速度，以大站不歇小站不停的气势，向你奔驰而去，将祝福捎给你!祝你春节快乐!</p><p>26、等待喜庆的鞭炮，等候吉祥来报到，等待手机凑热闹，等候朋友把信瞧，等候猴年喜气绕。春节未到短信到，鞭炮未响祝福捎。预祝猴年步步高!</p><p>27、短信来报道，祝福将你绕;春节过得好，节后也很妙;休息调整后，身轻忧愁抛;初春天仍凉，锻炼不能少;节后工作忙，切记健康保!</p><p>28、堆积365天的想念，凝聚千丝万缕的柔情，拼却春夏秋冬的痴恋，采撷夜空璀璨的星宿，淘尽碧海千年的珠玑，只为传送给你最精髓的祝愿，春节快乐!</p><p>29、风，吹来春天的暖阳;雪，飘走冬日的严寒;灯，点亮了归家的路程。无论你在何方，我的祝福已经起航，送你一年的平安健康。</p><p>30、根据春节特别法:判你快乐无期徒刑，剥夺郁闷权利终身，并处没收全部疾病烦恼，本判决为终审判决，立即执行。快乐到永远!退庭!</p><p>31、过年好，祝您:身体健康，万事如意，合家欢乐，生活美满，事业有成，珠玉满堂，多寿多富，财大气粗，攻无不克，战无不胜!春节祝福!</p><p>32、好一幅春节画卷，看两岸三地过年!赏四库<a href="http://m.so.com/s?q=%E4%B8%AD%E5%8D%8E%E5%A4%A7%E5%85%B8&amp;src=newstranscode" class="qkw">中华大典</a>，忆五千历史渊源!喜六秩祖国华诞，吟七子之歌绝版!闻八方深情呼唤，盼九州<a href="http://m.so.com/s?q=%E9%AA%A8%E8%82%89%E5%9B%A2%E5%9C%86&amp;src=newstranscode" class="qkw">骨肉团圆</a>!</p><p>33、好运是邮差，财神是信使，幸福是信笺，快乐是信纸。机会是邮票，平安是礼包。真心是邮戳，友谊是笔迹。快乐老家是地址，收件人是唯一的你。祝<a href="http://m.so.com/s?q=%E6%96%B0%E5%B9%B4%E5%BF%AB%E4%B9%90%21&amp;src=newstranscode" class="qkw">新年快乐!</a></p><p>34、花开花落，此消彼长，云卷云舒，又是一年。愿时间更替带给你漂亮心情，飘送着我的祝福，萦绕在您的身边。祝你新年快乐!快乐每一天!</p><p>35、吉祥如意庆新喜，百福齐聚贺新春;在一起<a href="http://m.so.com/s?q=%E5%9B%A2%E5%9C%86%E7%BE%8E%E6%BB%A1&amp;src=newstranscode" class="qkw">团圆美满</a>，聚一家和睦多福;恭喜发财财源广，喜迎好运运道旺。在春节即将来临之际，恭祝:新春愉快!</p><p>36、将一年的晦气，装进爆竹，带到九霄云外，炸它个粉身碎骨。把来年的运气，装进礼花，让幸福满地的萌发，漫天的飘洒。祝您春节快乐!</p><p>37、今年春节不收礼，送礼就发短信息。实惠周到无人拒，祝福送到表诚意。你一言来我一语，遍地都是新气息。如果谢我就回礼，金印钞票我不喜，唯独不拒短信息!春节送礼，祝福信息!</p><p>38、紧急通知:此短信含新年病毒，看完此信息你会全身中毒，刚中毒时你会圣诞快乐、元旦快乐、春节快乐、情人节快乐等症状，随后天天快乐缠身，此毒无药可解，特此告知。</p><p>39、景是新春美，花开新春艳，火遇新春旺，酒逢新春香，鱼为新春留，人在<a href="http://m.so.com/s?q=%E6%96%B0%E6%98%A5%E4%B9%90&amp;src=newstranscode" class="qkw">新春乐</a>，我在新春写，捎个新春信:幸福找你在新春，快乐缠你在新春，鸿运追你在新春，如意拥你在新春!祝你新春佳节快乐!</p><p>40、空调冷却不了<a href="http://m.so.com/s?q=%E9%9D%92%E6%98%A5%E7%9A%84%E7%81%AB%E7%84%B0&amp;src=newstranscode" class="qkw">青春的火焰</a>，彩电演绎不了年轻的色彩，MP3播放不了岁月的音色，电影远比不上生命的精彩，短信却能寄托我真诚的祝福:春节快乐!</p><p>41、来来来，废话不多说，春节在眼前。燃一束礼花，绽放好运给你;开一个红包，喜庆祝福给你;道一个万福，合家欢乐给你;发一条短信，真情友谊给你。</p><p>42、郎咯里咯朗，春运开始第一天，发个短信问问安;春节长假将到来，归家团聚心期待;车票争取提前买，贵重物品随身带;祝你春运旅途愉快!</p><p>43、猴年春节，你将会遇到极端天气:一阵幸运风，刮来金钱雨，飘来幸福云，洒下健康露，降下吉祥雪，响起开心雷，掠过快乐电，平安雾还会缠绕你一整年。</p><p>44、你是我冬天的棉袄，黑夜里的灯泡，饥饿中的面包，夏天里的雪糕。这个春节你不在我身边，我什么都没有了。只有把思念编成短信祝你新春快乐。</p><p>45、浓浓的情谊与祝福，绵绵的思念与问候，在这美好的日子，愿祝愿随着卡片带给你温馨的问候，盼你能时常想到我，也希望你能知道，无论天涯海角我都深深祝福你!新年快乐!</p><p>46、前程似锦，吉星高照，财运亨通，合家欢乐，飞黄腾达，福如东海，寿比南山!酒越久越醇，朋友相交越久越真;水越流越清，世间沧桑越流越淡。祝新年快乐，时时好心情!</p><p>47、情切切，意绵绵，祝你年年都美满。草青青，水甜甜，祝你天天都有钱。山高高，海深深，祝你分分都顺心。<a href="http://m.so.com/s?q=%E6%9C%88%E5%9C%86%E5%9C%86&amp;src=newstranscode" class="qkw">月圆圆</a>，星闪闪，liuxue86.com祝你秒秒都平安!春节愉快!</p><p>48、情如老酒封存愈久愈香醇，一句短短祝福就能开启坛盖品尝浓醇酒香;友情就如一轮红日默默付出而无求，一声轻轻问候就是一束温暖阳光。祝春节快乐!</p><p>49、晴天雨天阴天，愿您开心每一天;亲情友情爱情，愿您天天好心情;爱心真心关心，只愿您天天顺心;诚意情意心意，祝您万事如意---春节快乐!</p><p>50、热闹春节过，喜气洋洋走;度过团圆日，迎来浪漫时;<a href="http://m.so.com/s?q=%E6%83%85%E4%BA%BA%E4%BD%B3%E8%8A%82&amp;src=newstranscode" class="qkw">情人佳节</a>至，你我约会来;二人世界里，愿你多徜徉;幸福过节日，舒心享未来。情人节快乐!</p><p><img src="http://p35.qhimg.com/t013378aaacc03123b9.jpg?size=300x223"></p><p>51、人生从来不如意，咱又何必太在意，发条短信祝福你，春节过后是春意，一年四季花出奇，幸福美满无人及，身体健康如人意，来路享通金榜提!</p><p>52、别人祝你新年快乐，我祝你天天快乐;别人祝你幸福2016年，我祝你<a href="http://m.so.com/s?q=%E5%B9%B8%E7%A6%8F%E5%BF%AB%E4%B9%90%E5%88%B0%E6%B0%B8%E8%BF%9C&amp;src=newstranscode" class="qkw">幸福快乐到永远</a>!春节到了，真心祝愿你新年大吉!猴年好运!</p><p>53、本宫有点自命清高，一般人是不会理睬的。本宫发现你并非凡夫俗子，所以春节之际发短信犒劳你下，祝福你在新的一年春风得意，财源滚滚!还不接旨谢恩?</p><p>54、祝你:位高权重责任轻，事少钱多离家近，每天睡到自然醒，别人加班你加薪，领钱数得手抽筋，靓女爱你发神经。猴年大吉祥!</p><p>55、祝福不是一挂鞭炮，放了就完了;祝福不是一段日子，过了就算了;祝福不是一个承诺，久了就淡了。祝福是无数牵挂凝结成的一句话:天凉了，注意身体。</p><p>56、<a href="http://m.so.com/s?q=%E7%8C%B4%E5%B9%B4%E5%90%89%E7%A5%A5&amp;src=newstranscode" class="qkw">猴年吉祥</a>，祝您猴猴精神――心中收藏，猴飞凤舞――快乐飞扬，猴腾猴跃――活力显现，蛟猴得水――事业高升，望子成猴――家庭和睦，<a href="http://m.so.com/s?q=%E9%A3%9E%E7%8C%B4&amp;src=newstranscode" class="qkw">飞猴</a>在天――生活美满。新的一年，愿你天天快乐。</p><p>57、心底有个朋友，心情就会飞翔;心中<a href="http://m.so.com/s?q=%E6%9C%89%E4%B8%AA%E5%B8%8C%E6%9C%9B&amp;src=newstranscode" class="qkw">有个希望</a>，笑容就会清爽;人生有个缘分，梦想就会绵长;平常有个问候，幸福就会起航。愿您拥有一切最珍贵美好的东西!</p><p>58、新年到送你一个饺子:平安皮儿包着如意馅儿，用真情煮熟，吃一口快乐，两口幸福，三口顺利，然后喝全家健康汤，回味是温馨，余香是祝福!祝春节快乐!</p><p>59、最近好吗?工作累了，歇歇脚，让压力藏的藏、跑的跑;心情烦了，微微笑，让烦恼躲的躲、逃的逃;切记身体健康，开心过每天最为重要。</p><p>60、人之相惜惜于品，人之相敬敬于德，人之相信信于诚，人之相拥拥于礼，人之相伴伴于爱，人之相交交于情，人之相传传思念:天气多变，注意身体!</p><p>61、祝你:生活越来越好，年龄越看越小， 经济 再往上跑，别墅钻石珠宝，开着宝马炫耀，挣钱如同割草，感觉贼好!哈哈，为你这样的朋友骄傲!</p><p>62、新年临近百花香，一条信息带六香，一香送你摇钱树，二香送你贵人扶，三香送你工作好，四香送你没烦恼，五香送你钱满箱，六香送你永安康!祝春节快乐!</p><p>63、信息就像糖果，偶尔来一颗，甜啊!但糖吃多了，腻啊!怕你烦，所以我只偶尔给你一颗糖，这不代表我不重视你，因为我会把最甜的一颗给你哦:新年快乐!</p><p>64、有一种节日叫过年，有一种问候叫祝福，有一种生活叫幸福，有一种心情叫快乐，有一种心愿叫万事如意，有一种憧憬叫梦想成真，春节了，祝合家幸福快乐，万事如意，梦想成真。</p><p>65、最调皮奖:祝你猴年跑最快，永不失蹄!</p><p>66、祝你猴年一而再再而三事事如意五福临门六六大顺七彩生活八面玲珑久盛不衰十全十美百年好合千禧之初万贯家财慢慢享用以上祝福有效期一生。</p><p>67、新年到、春节到、有成绩、别骄傲、失败过、别死掉、齐努力、开大炮、好运气、天上掉、同分享、大家乐。天天好运道，日日福星照!</p><p>68、愿幸福挥之不去，让机遇只争朝夕，愿快乐如期而至，让情谊<a href="http://m.so.com/s?q=%E6%97%A5%E7%B4%AF%E6%9C%88%E7%A7%AF&amp;src=newstranscode" class="qkw">日累月积</a>，愿身体健康如一，让好运春风化雨，愿片言表我心语，愿春节你阖家幸福，事事称意!</p><p>69、有种喜欢不一定要说出，但彼此心知肚明;有种生活不求无疵，但快乐常在;有种朋友见少离多，但始终不忘;有种短信偶尔发出，但牵挂满怀。春节快乐!</p><p>70、猴年就要到了，提前祝愿幸运的清风时时吹拂你，幸福的雨滴四季淋着你，如意的月亮月月照耀你，健康的阳光天天温暖你。祝你天天开心、快乐无边!</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/2016/kuaixun_0206/3935919.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='ddc22e0469b9b93cace51516f4f5e20f'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>春节祝福语</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%98%A5%E8%8A%82%E7%A5%9D%E7%A6%8F%E8%AF%AD&amp;pn=1&amp;pos=6&amp;m=ffeff9cc0a2f6f749fe0511a7245e231585526ed&amp;u=http%3A%2F%2Flearning.sohu.com%2F20150217%2Fn409076955.shtml" data-pos="1"> <b>春节祝福语</b>集锦 </a>   <li> <a href="/transcode?q=%E6%98%A5%E8%8A%82%E7%A5%9D%E7%A6%8F%E8%AF%AD&amp;pn=1&amp;pos=7&amp;m=340aa4daac10067e238b536a7931844bca93fa2e&amp;u=http%3A%2F%2Fjs.people.com.cn%2Fn%2F2015%2F0218%2Fc360313-23945973.html" data-pos="2"> <b>春节</b>拜年也要洋气起来 最暖心英语<b>新春祝福语</b> </a>   <li> <a href="/transcode?q=%E6%98%A5%E8%8A%82%E7%A5%9D%E7%A6%8F%E8%AF%AD&amp;pn=1&amp;pos=8&amp;m=849926067a84d5f1a126f5e615ba830741fdebea&amp;u=http%3A%2F%2Ffinance.china.com.cn%2Froll%2F20150226%2F2972231.shtml" data-pos="3"> 写<b>新年祝语</b>,健身房"重启"自己 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '2016年猴年新春祝福语大全:欢乐拜年短信 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '2016年猴年新春祝福语大全:欢乐拜年短信 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";