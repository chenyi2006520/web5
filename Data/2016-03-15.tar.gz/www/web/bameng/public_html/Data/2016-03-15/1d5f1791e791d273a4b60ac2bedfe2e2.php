s:21638:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>【中国科学报】仇子龙:让猴子遇上自闭症- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">【中国科学报】仇子龙:让猴子遇上自闭症</h1> <p id="source-and-time"><span id=source>中国科学院</span><time id=time>2016-03-11 08:45:27</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t0155f3a5bc77d7c163.jpg?size=500x333"></p><p class="img-title">仇子龙</p><p><a href="http://m.so.com/s?q=%E8%87%AA%E9%97%AD%E7%97%87&amp;src=newstranscode" class="qkw">自闭症</a>猴模型的建立一经发表就在国内外学界引起了不小的关注。在从实验到发表文章的6年时间里，经历两次被拒、六轮修改，对仇子龙而言，倒是难得的“痛苦”体验。</p><p>在猴年，一群猴子遇到了复杂又神秘的自闭症，于是，它们登上了1月份的<a href="http://m.so.com/s?q=%E3%80%8A%E8%87%AA%E7%84%B6%E3%80%8B&amp;src=newstranscode" class="qkw">《自然》</a>杂志，被全世界所关注。也许有一天，这群特殊的猴子会将人们对自闭症的认识和干预能力大大向前推进。它们的创造者是<a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E7%A7%91%E5%AD%A6%E9%99%A2&amp;src=newstranscode" class="qkw">中国科学院</a>神经科学研究所研究员仇子龙和他的研究团队。</p><p>偶然遇见“<a href="http://m.so.com/s?q=MeCP2&amp;src=newstranscode" class="qkw">MeCP2</a>”</p><p>关于自闭症，科学家描述的是，半个多世纪以来，它都属于一种神经基础还很不清楚的症候群。可以说，自闭症的成因一直扑朔迷离。</p><p>1998年，著名国际医学学术期刊<a href="http://m.so.com/s?q=%E3%80%8A%E6%9F%B3%E5%8F%B6%E5%88%80%E3%80%8B&amp;src=newstranscode" class="qkw">《柳叶刀》</a>发表了一篇报道，英国韦克菲尔德医生发现，8位儿童在接种了<a href="http://m.so.com/s?q=%E9%BA%BB%E7%96%B9&amp;src=newstranscode" class="qkw">麻疹</a>、腮腺炎和风疹疫苗后一个月内开始出现了自闭症症状，因而怀疑MMR疫苗接种有可能导致自闭症。</p><p>尽管该结论从发表之日起，就争议不断，但之后几年，科学家也始终没办法证明，自闭症与遗传因素密切相关。</p><p>早在2003年博士毕业之前，做<a href="http://m.so.com/s?q=%E5%88%86%E5%AD%90%E7%94%9F%E7%89%A9%E5%AD%A6&amp;src=newstranscode" class="qkw">分子生物学</a>研究的仇子龙和自闭症并没有任何交集。走进这种疾病，得益于此后6年在<a href="http://m.so.com/s?q=%E7%BE%8E%E5%9B%BD%E5%8A%A0%E5%B7%9E%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">美国加州大学</a>圣迭戈分校神经生物学系从事博士后研究工作，以及一场生物学革命--基因技术的迅速发展。</p><p>仇子龙说，2006年前后的美国刚刚开始从遗传学层面认识自闭症，但也依然没有很好的线索。其间，因为申请一个博士后研究基金，仇子龙接触到了另一种与自闭症患者表型类似的疾病--瑞特综合征，它也被归为自闭症谱系障碍的一种。</p><p>上世纪60年代，科学家就发现瑞特综合征是一种严重影响儿童精神运动发育的疾病，却直到1999年才清楚它的致病原因。佐格比教授发现，瑞特综合征与MeCP2<a href="http://m.so.com/s?q=%E5%9F%BA%E5%9B%A0%E7%AA%81%E5%8F%98&amp;src=newstranscode" class="qkw">基因突变</a>密切相关，95%的瑞特综合征患者携带的MeCP2基因会发生缺失功能的突变。</p><p>于是，仇子龙可以说是偶然地从这个基因入手，开始接近自闭症成因的谜团的。</p><p>2012年，已经回国工作的仇子龙及其团队第一次在国际上发现了MeCP2基因过少会影响大脑<a href="http://m.so.com/s?q=%E7%A5%9E%E7%BB%8F%E5%85%83&amp;src=newstranscode" class="qkw">神经元</a>中突触稳态的可塑性，继而引发瑞特综合征。半年后，该研究成果也得到了国际同行的验证。</p><p>有意思的是，仇子龙注意到，2009年美国的医生和科学家在几名严重的自闭症患者中发现，他们的MeCP2 基因出现的是拷贝数的倍增，而不是递减。尽管自闭症不同于瑞特综合征，属于多基因遗传疾病，但MeCP2仍然是一个相关性很强的自闭症基因。</p><p>也正是因为MeCP2 与自闭症以及自闭症谱系障碍疾病之间这种微妙的关系，让团队意识到，想要破解这类疾病，必须从MeCP2 入手。</p><p class="header">如何证明猴子得了自闭症</p><p>从2009年回国至今，仇子龙的主要研究方向都是围绕MeCP2 展开的。事实上，在建立自闭症猴子模型的前期，团队在分子层面对<a href="http://m.so.com/s?q=%E7%AA%81%E5%8F%98%E5%9F%BA%E5%9B%A0&amp;src=newstranscode" class="qkw">突变基因</a>进行了详细的基础研究和分析。</p><p>2014年3月，仇子龙研究组先是在国际学术期刊<a href="http://m.so.com/s?q=%E3%80%8A%E5%8F%91%E8%82%B2%E7%BB%86%E8%83%9E%E3%80%8B&amp;src=newstranscode" class="qkw">《发育细胞》</a>发表文章，提出了一个新的潜在的自闭症致病机制。他们发现，MeCP2是通过直接调控DGCR8/Drosha复合物，影响microRNA加工及靶基因的表达，进而影响大脑发育的。</p><p>这对长期从事分子生物学研究的仇子龙来说，并不是最有挑战性的工作。但建立自闭症猴子模型可就不一样了。</p><p>仇子龙解释，之所以想到用猴子做模型，是因为此前科学家虽然在<a href="http://m.so.com/s?q=%E5%B0%8F%E9%BC%A0&amp;src=newstranscode" class="qkw">小鼠</a>中引入与人类自闭症相关的突变，进而研究自闭症基因突变如何影响大脑发育已经有很多重要发现，但是，人们始终疑惑的是，像自闭症这种复杂的精神疾病，小鼠的类自闭症状是否能够与人类的自闭症足够相像。</p><p>事实上，人类大脑的体积与复杂程度，是<a href="http://m.so.com/s?q=%E5%95%AE%E9%BD%BF%E7%B1%BB%E5%8A%A8%E7%89%A9&amp;src=newstranscode" class="qkw">啮齿类动物</a>的大脑完全无法比拟的。目前在小鼠中尝试成功的一些神经疾病药物结果，在人类病患身上的<a href="http://m.so.com/s?q=%E4%B8%B4%E5%BA%8A%E8%AF%95%E9%AA%8C&amp;src=newstranscode" class="qkw">临床试验</a>很少获得成功。因此，仇子龙认为，用进化上与人类尽可能相近的生物来构建自闭症动物模型是有意义的。当然，相较于改造老鼠，改造一只猴子要困难得多。</p><p>“实验头两年，我们的目标是能做出带自闭症基因的转基因猴，并且试图做得更有效率，数量更多。”仇子龙甚至没有更多时间思考，培养自闭症猴究竟可以干什么。</p><p>让他没想到的是，成功做出转基因猴之后才是真正挑战的开始。</p><p>“我们怎么确定这些转基因猴真的得了自闭症?”仇子龙说，什么参考文献，国际同行研究，都没有定义过这个问题，“这是一次全新的探索”。</p><p>从最初测量猴子血液中的代谢物，监测猴子的脑电波，研究人员都没有办法把自闭症的猴子区别出来。唯一的办法就是，观察这些转基因猴子。</p><p>团队参考了早期关于猴子行为学的文献，先是观察它们自发的重复性刻板行为，猴子自己会在笼子里打转。然后，测试了猴子的焦虑行为。当人走近笼子时，猴子会叫，反映它们害怕的情绪，而转基因猴的叫声会比一般的猴子更响。</p><p>此外还有社交行为。在<a href="http://m.so.com/s?q=%E4%B8%AD%E7%A7%91%E9%99%A2&amp;src=newstranscode" class="qkw">中科院</a>昆明动物所研究人员的帮助下，他们分析了猴群中猴子“并坐”时的交互行为。研究人员在连续一个多星期的时间内，每天选取一个固定的时间，将猴子们从生活笼转移到观察笼进行观察。实验细致到，需要进行不同时间的检测(即猴子一岁、两岁、三岁时)，注重不同猴子之间的搭配(即熟悉的猴子之间、以前不认识的猴子之间等)，最终确定MeCP2转基因猴确实有社交行为的异常。</p><p class="header">两次被拒、六轮修改</p><p>自闭症猴模型的建立一经发表就在国内外学界引起了不小的关注。但在仇子龙自己看来，团队的这项研究本身在目前诸多年轻科研人员出色的科研成果中，并没有格外特别。不过，在从实验到发表文章的6年时间里，经历两次被拒、六轮修改，对自己而言，倒是难得的“痛苦”体验。</p><p>从最初对研究本身重要性的质疑，到要求回答转入的外源基因在染色体里的分布，直到第二代转基因猴，研究团队罕见地获得了第二次修改后投稿的机会，进而重新组织了转基因猴的行为学试验。</p><p>然而，让研究一度陷入停滞的是，评审专家突然质疑，如何证明观察到的行为学表现是由转入的基因所引起的，而不是自然形成的。直到2014年底，有一只转基因猴因为身体原因意外死亡，研究人员才符合伦理规范，进行了解剖实验，从而给出了答案。</p><p>“科学发现总是有它的偶然性和曲折性。”仇子龙说，幸运的是，他所在的环境给了他这种选择冒险的机会。他反复提到的是，这篇文章的共同第一作者<a href="http://m.so.com/s?q=%E6%9D%8E%E9%9C%84&amp;src=newstranscode" class="qkw">李霄</a>。李霄是新近加入课题组的硕士研究生，在完全无法预知投入产出的情况下，最终独立完成了所有的行为学分析。</p><p>“这是因为，再好的实验条件和启动基金的支持，都敌不过评价机制能够给出的时间与空间的自由。”在仇子龙看来，这是年轻科学家踏踏实实做学问，敢于为原创性的基础研究自担风险的最好保障。</p><p>尽管成果发表已经过去一段时间，仇子龙的微博仍然会接到不少患者家长的来信，表达他们的关切。他告诉<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E5%9B%BD%E7%A7%91%E5%AD%A6%E6%8A%A5%E3%80%8B&amp;src=newstranscode" class="qkw">《中国科学报》</a>记者，下一步计划是希望与专门的医疗机构合作，对中国的自闭症儿童展开全基因组的筛查，从而为之后的精确诊断、治疗提供新的可能。</p><p>(原载于《中国科学报》 2016-03-11 第2版 人物)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.cas.cn/cm/201603/t20160311_4548686.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='d6b0d790a8a57cefe6dd9ac102e75cab'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>自闭症</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%87%AA%E9%97%AD%E7%97%87&amp;pn=1&amp;pos=10&amp;m=9e8157d2a4241c6c6aeccfc67ed5673ab2dedfcf&amp;u=http%3A%2F%2Fcaijing.chinadaily.com.cn%2F2016-03%2F10%2Fcontent_23817631.htm" data-pos="1"> Simons基金会和明码生物科技世界最大<b>自闭症</b>数据库上线 </a>   <li> <a href="/transcode?q=%E8%87%AA%E9%97%AD%E7%97%87&amp;pn=2&amp;pos=1&amp;m=31a2a278d9d4cecce5b50b83d9894e37ee9bd8b0&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Fzjnews_0312%2F4701729.html" data-pos="2"> 宁波举办<b>自闭症</b>教育干预临床指导技术培训 </a>   <li> <a href="/transcode?q=%E8%87%AA%E9%97%AD%E7%97%87&amp;pn=2&amp;pos=2&amp;m=66251d5a1b6698e576785ae6e6043291fe7d5bef&amp;u=http%3A%2F%2Fcn.chinadaily.com.cn%2F2016lianghui%2F2016-03%2F10%2Fcontent_23812252.htm" data-pos="3"> 郭乃硕:加强<b>自闭症</b>儿童社会支持体系建设 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '【中国科学报】仇子龙:让猴子遇上自闭症' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '【中国科学报】仇子龙:让猴子遇上自闭症'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";