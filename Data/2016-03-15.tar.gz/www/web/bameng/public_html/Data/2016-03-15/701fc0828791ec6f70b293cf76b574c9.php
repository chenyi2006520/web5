s:15967:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>超级女声海选开启!包小柏柯以敏坐镇评委- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">超级女声海选开启!包小柏柯以敏坐镇评委</h1> <p id="source-and-time"><span id=source>中国日报网</span><time id=time>2016-03-12 12:06:00</time></p> </header>  <div id="news-body"><p>今日，超级女声主战场及地面唱区将同步开启海选，将由<a href="http://m.so.com/s?q=%E5%8C%85%E4%BC%9F%E9%93%AD&amp;src=newstranscode" class="qkw">包伟铭</a>、包小松、包小柏三兄弟联手坐镇评委间。</p><p><img src="http://p35.qhimg.com/t01fe2ab441f030a900.jpg?size=423x604"></p><p><a href="http://m.so.com/s?q=%E5%8C%85%E5%B0%8F%E6%9F%8F&amp;src=newstranscode" class="qkw">包小柏</a></p><p><img src="http://p34.qhimg.com/t01ba3e5135ef5e6c1b.jpg?size=296x416"></p><p class="img-title">柯以敏</p><p>新浪娱乐讯 自<a href="http://m.so.com/s?q=%E3%80%8A%E8%B6%85%E7%BA%A7%E5%A5%B3%E5%A3%B0%E3%80%8B&amp;src=newstranscode" class="qkw">《超级女声》</a>新闻发布会召开后，海选的节奏就在一点点推进。今日，<a href="http://m.so.com/s?q=%E8%8A%92%E6%9E%9C&amp;src=newstranscode" class="qkw">芒果</a>TV主战场及地面唱区将同步开启海选。除了选手本身，各地的海选评委人选也成为众多媒体和网友猜测的对象。</p><p>根据官方公布的消息来看，芒果TV主战场将由包氏三兄弟坐镇海选，而地面唱区也将有多位资深音乐人出任评委，其中有不少是曾经的“熟脸”。</p><p class="header">地面唱区海选启幕 专业评委就位</p><p>十大地面唱区中已有三处率先完成海选报名，进入到晋级赛前的筹备阶段。据了解，今年地面唱区将依旧沿袭往届的做法，评委与选手将面对面地交流，音乐和梦想碰撞出火花。</p><p>3月12日、13日<a href="http://m.so.com/s?q=%E9%BB%84%E5%98%89%E5%8D%83&amp;src=newstranscode" class="qkw">黄嘉千</a>及李偲菘[微博]将会以评委身份现身“超女大本营”长沙唱区。去年，黄嘉千凭借<a href="http://m.so.com/s?q=%E6%B9%96%E5%8D%97%E5%8D%AB%E8%A7%86&amp;src=newstranscode" class="qkw">湖南卫视</a>《爸爸去哪儿》中的“小公主”夏天妈妈的身份，被大批观众知晓和喜爱。然而早年间，黄嘉千便以歌手身份出道。她不仅拥有极为丰富的演艺经验，而且通过多档综艺节目的主持和演出，在台湾拥有了较高的知名度。</p><p>而另一位评委，是曾经<a href="http://m.so.com/s?q=%E5%BC%A0%E6%83%A0%E5%A6%B9&amp;src=newstranscode" class="qkw">张惠妹</a>[微博]、孙燕姿[微博]等华语歌坛的超级歌星们的制作人。<a href="http://m.so.com/s?q=%E6%9D%8E%E5%81%B2%E8%8F%98&amp;src=newstranscode" class="qkw">李偲菘</a>的大名在音乐界可谓如雷贯耳，而他的严格更是众所周知。</p><p>据悉，天津唱区则由“超级女声”的老朋友、资深乐评人<a href="http://m.so.com/s?q=%E4%BC%8D%E6%B4%B2%E5%BD%A4&amp;src=newstranscode" class="qkw">伍洲彤</a>坐镇。敢ZUO敢为、饱受争议的<a href="http://m.so.com/s?q=%E6%9F%AF%E4%BB%A5%E6%95%8F&amp;src=newstranscode" class="qkw">柯以敏</a>也正在奔赴广州唱区的途中。</p><p>芒果TV主战场颠覆创新 明星评委与大咖陪聊团兼备</p><p>除地面唱区外，芒果TV主战场也将在今天开始进行为期三天的网络海选。主办方别具匠心的设置两个房间，其中一间专供评委。有“评审届第一家族”之称的包伟铭、<a href="http://m.so.com/s?q=%E5%8C%85%E5%B0%8F%E6%9D%BE&amp;src=newstranscode" class="qkw">包小松</a>、包小柏[微博]三兄弟联手坐镇评委间。与地面唱区不同，选手实力的展现有赖于互联网连线的方式，大屏幕前的评委们将视其综合素质给出“推荐”和“不推荐”两种结论。</p><p>除评审间外，主办方还设置了一个极为人性化的“现场bibi团”。在这个房间内，将有四位神秘大咖降临，他们直接扮演“陪聊者”的角色。面对上场的选手，四位明星红人将根据自身<a href="http://m.so.com/s?q=%E7%BA%B5%E6%A8%AA%E5%A8%B1%E4%B9%90%E5%9C%88&amp;src=newstranscode" class="qkw">纵横娱乐圈</a>多年的经验，给予评价或者猛烈的吐槽;面对千万网友，他们可以谈天说地，回应网友们的<a href="http://m.so.com/s?q=%E5%BC%B9%E5%B9%95%E9%A3%8E%E6%9A%B4&amp;src=newstranscode" class="qkw">弹幕风暴</a>。</p><p>3月12日，芒果TV将开启全程直播模式。中午12:45，直播长沙唱区海选情况，当晚20:18，芒果TV主战场网络海选直播上线!当这些深受网络文化浸润的新新选手，面对经验丰富的老道评委，究竟会一击即溃还是愈挫愈勇?直播见分晓!</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://cnews.chinadaily.com.cn/2016-03/12/content_23838471.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='01f3d0c75365ad1f3ca2def22261b8b3'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>纵横娱乐圈</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E7%BA%B5%E6%A8%AA%E5%A8%B1%E4%B9%90%E5%9C%88&amp;pn=1&amp;pos=9&amp;m=fd7b3646f7de696cb5fe9091b9fa7555c887dda6&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fent%2Fhot%2F4686195_1.html" data-pos="1"> 超级女声芒果主战场舞美曝光 线上互动赛制公布 </a>   <li> <a href="/transcode?q=%E7%BA%B5%E6%A8%AA%E5%A8%B1%E4%B9%90%E5%9C%88&amp;pn=1&amp;pos=10&amp;m=d3d3ab6277d07f4f4a6a1a783b012fad79154ce7&amp;u=http%3A%2F%2Fcnews.chinadaily.com.cn%2F2016-03%2F09%2Fcontent_23791378.htm" data-pos="2"> 可悲!林志玲关之琳 这些沦为富豪泄欲工具的女星 </a>   <li> <a href="/transcode?q=%E7%BA%B5%E6%A8%AA%E5%A8%B1%E4%B9%90%E5%9C%88&amp;pn=2&amp;pos=1&amp;m=ce1ffaa50d3ab1053b7f5025884b63b45e6e04e8&amp;u=http%3A%2F%2Fcnews.chinadaily.com.cn%2F2016-03%2F08%2Fcontent_23783010.htm" data-pos="3"> 林志玲关之琳蔡少芬 那些沦为富豪泄欲工具的女星 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '超级女声海选开启!包小柏柯以敏坐镇评委' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '超级女声海选开启!包小柏柯以敏坐镇评委'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";