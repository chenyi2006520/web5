s:14579:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>去这些地方吧!如果你现在在昆士兰不能错过- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">去这些地方吧!如果你现在在昆士兰不能错过</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-03 17:14:10</time></p> </header>  <div id="news-body"><p>导读:在摩登的城市间欣赏耀眼的焰火、同心爱的人在<a href="http://m.so.com/s?q=%E5%A4%A7%E5%A0%A1%E7%A4%81&amp;src=newstranscode" class="qkw">大堡礁</a>或海岛星空下露 营、与朋友一同参加派对或是享受与家人依偎在<a href="http://m.so.com/s?q=%E4%B8%80%E8%B5%B7%E7%9A%84%E7%BE%8E%E5%A5%BD%E6%97%B6%E5%85%89&amp;src=newstranscode" class="qkw">一起的美好时光</a>，在告别2015、迎接2016之际，我们为你精选了<a href="http://m.so.com/s?q=%E6%98%86%E5%A3%AB%E5%85%B0&amp;src=newstranscode" class="qkw">昆士兰</a>最热门的跨年迎新地点。来阳光明媚 的昆士兰，让我们用这些最温暖的方式，迎接新年的到来吧。</p><p>在摩登的城市间欣赏耀眼的焰火、同心爱的人在大堡礁或海岛星空下露营、与朋友一同参加派对或是享受与家人依偎 在一起的美好时光，在告别2015、迎接2016之际，我们为你精选了昆士兰最热门的跨年迎新地点。来阳光明媚的昆士兰，让我们用这些最温暖的方式，迎接 新年的到来吧。</p><p class="header">绚烂的焰火秀</p><p><img src="http://p35.qhimg.com/t01b96737f62cf75977.jpg?size=550x309"></p><p>如果你的迎新计划是“自由随意”与“阖家欢乐”，那么推荐你和家人一起去<a href="http://m.so.com/s?q=%E5%B8%83%E9%87%8C%E6%96%AF%E7%8F%AD&amp;src=newstranscode" class="qkw">布里斯班</a>南岸公园。你们可以在<a href="http://m.so.com/s?q=%E6%96%87%E5%8C%96%E5%B9%BF%E5%9C%BA&amp;src=newstranscode" class="qkw">文化广场</a>看一场晚间电影，随后欣赏午夜烟火表演。</p><p><img src="http://p34.qhimg.com/t01e2fb092f60866a6f.jpg?size=450x301"></p><p>著名旅游胜地<a href="http://m.so.com/s?q=%E9%BB%84%E9%87%91%E6%B5%B7%E5%B2%B8&amp;src=newstranscode" class="qkw">黄金海岸</a>从Coomera到Coolangatta地区，在跨年之夜整个夜空将被烟花映照得璀璨夺目。所以来到黄金海岸的海边上，自备野餐 静静欣赏一场免费的烟花演出吧;也可以盛装打扮，前往黄金海岸地标性建筑Q1大厦的星空塔(<a href="http://m.so.com/s?q=SkyPoint&amp;src=newstranscode" class="qkw">SkyPoint</a> Observation Deck)，今年SkyPoint的跨年庆祝主题是“皇家Casino”，每人只需缴纳195澳币即可参加所有娱乐活动，享用美食美酒，并从空中鸟瞰烟火 盛宴。</p><p>北部大堡礁的门户城市<a href="http://m.so.com/s?q=%E5%87%AF%E6%81%A9%E6%96%AF&amp;src=newstranscode" class="qkw">凯恩斯</a>也推出了热闹非凡的跨年庆典，晚9点及12点将在城市上空燃放烟花。同时以一场免费的音乐会，唱响新年的乐章!</p><p>与此同时，布里斯班以北的<a href="http://m.so.com/s?q=%E9%98%B3%E5%85%89%E6%B5%B7%E5%B2%B8&amp;src=newstranscode" class="qkw">阳光海岸</a>莫罗拉巴滨海大道在迎新之夜也将上演两场焰火秀。所以来阳光海岸迎新年也是个不错的选择。全讯网还可以在2016年4月1日的早上，跟着Noosa Running Tours，以跑步来迎接新年的第一轮<a href="http://m.so.com/s?q=%E6%9C%9D%E9%98%B3&amp;src=newstranscode" class="qkw">朝阳</a>。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://mt.sohu.com/20160303/n439281008.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='de26c79f44fedac2bf784543dd02807f'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>昆士兰</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%98%86%E5%A3%AB%E5%85%B0&amp;pn=1&amp;pos=6&amp;m=70e9250b934bda57a4fbc7e8f60c859ebe1d72f5&amp;u=http%3A%2F%2Fintl.ce.cn%2Fqqss%2F201602%2F26%2Ft20160226_9122741.shtml" data-pos="1"> 澳<b>昆士兰州</b>现寨卡病毒患者 卫生部门打响伊蚊消灭战 </a>   <li> <a href="/transcode?q=%E6%98%86%E5%A3%AB%E5%85%B0&amp;pn=1&amp;pos=7&amp;m=33e3435e3e8749ef29f656258c385fbb1c27c721&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Fabroad%2F2016-02%2F25%2Fc_128751444.htm" data-pos="2"> 中央<b>昆士兰</b>大学专升硕优势分析 </a>   <li> <a href="/transcode?q=%E6%98%86%E5%A3%AB%E5%85%B0&amp;pn=1&amp;pos=8&amp;m=469bb99810c79d47736aa4ca814ba9fa1f42819d&amp;u=http%3A%2F%2Fnews.xinhuanet.com%2Fabroad%2F2016-02%2F22%2Fc_128740255.htm" data-pos="3"> <b>昆士兰</b>大学预科课程种类及入学要求参考 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '去这些地方吧!如果你现在在昆士兰不能错过' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '去这些地方吧!如果你现在在昆士兰不能错过'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";