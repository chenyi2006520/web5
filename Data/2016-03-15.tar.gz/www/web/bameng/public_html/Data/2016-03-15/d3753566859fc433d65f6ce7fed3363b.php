s:15657:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>浦发银行信用卡深挖客户需求多渠道布局消费金融()- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">浦发银行信用卡深挖客户需求多渠道布局消费金融()</h1> <p id="source-and-time"><span id=source>和讯网</span><time id=time>2016-03-14 08:10:00</time></p> </header>  <div id="news-body"><p>第1财金专讯 2016年<a href="http://m.so.com/s?q=%E6%94%BF%E5%BA%9C%E5%B7%A5%E4%BD%9C%E6%8A%A5%E5%91%8A&amp;src=newstranscode" class="qkw">政府工作报告</a>再一次提及消费金融，“在全国开展消费金融公司试点，鼓励金融机构创新消费信贷产品。”这意味着，消费信贷市场将迎来巨大发展机遇。市场预计，2019年中国消费信贷规模将超过37万亿。如今，银行及非银金融机构、<a href="http://m.so.com/s?q=%E4%BA%92%E8%81%94%E7%BD%91%E9%87%91%E8%9E%8D&amp;src=newstranscode" class="qkw">互联网金融</a>平台等都在扎堆争抢布局消费金融，万亿级<a href="http://m.so.com/s?q=%E8%93%9D%E6%B5%B7&amp;src=newstranscode" class="qkw">蓝海</a>市场一触即发。</p><p>而随着春季消费潮来临，市场将迎来购物、旅游等消费高峰，多家银行纷纷出牌推出分期贷款业务，抢食消费金融蛋糕，市场竞争激烈。记者走访中发现，在各银行推出的众多分期产品中，<a href="http://m.so.com/s?q=%E6%B5%A6%E5%8F%91%E9%93%B6%E8%A1%8C&amp;src=newstranscode" class="qkw">浦发银行</a>(600000,股吧)信用卡另辟蹊径以不同人群的不同需求出发，围绕消费者日常生活各个场景推出了相关金融分期产品，以满足不同客户的消费需求。</p><p>记者了解到，当持卡人在日常消费中对现金有一定需求时，可以轻松申请浦发银行推出的现金分期产品“<a href="http://m.so.com/s?q=%E4%B8%87%E7%94%A8%E9%9A%8F%E5%80%9F%E9%87%91&amp;src=newstranscode" class="qkw">万用随借金</a>”，以在一定程度上缓解持卡人的资金压力，帮助客户解决燃眉之急。“万用随借金”实时到账，借款天数可根据客户需求灵活设定，这相比于其他银行的同类型产品，申请流程更为便捷，一直备受用户的推崇。3月底前，成功申请万用随借金业务的持卡人，可享日手续费5折的半价优惠，这对于有消费需求的客户来说无疑是“雪中送炭”。</p><p>正值<a href="http://m.so.com/s?q=%E6%96%B0%E6%98%A5%E4%BD%B3%E8%8A%82&amp;src=newstranscode" class="qkw">新春佳节</a>消费旺季后第一个还款月的到来，客户可以申请浦发银行信用卡账单分期业务，即根据自己的资金情况将当月账单分3个月、6个月或者12个月还款等，大大缓解了还款压力，这一产品持卡人可自由选择分期期数及手续费收取方式，申请便捷、灵活度大，受到了持卡人特别是年轻持卡人的欢迎。而针对短期内无法按时还款的客户，也可通过申请<a href="http://m.so.com/s?q=%E6%B5%A6%E5%8F%91%E4%BF%A1%E7%94%A8%E5%8D%A1&amp;src=newstranscode" class="qkw">浦发信用卡</a>延期还本业务，仅一次性支付一定金额的手续费，即可享消费本金延期还款的权利。</p><p>此外，随着消费观念的不断变化，越来越多的消费者选择分期支付的方式来购买私家车。浦发银行信用卡亦与众多汽车品牌开展合作，不仅仅可以分期还款为自己减轻集中消费的还款压力，更有多款车型推出特价让利让持卡人享受更多的福利。</p><p>记者还发现，有别于一般银行的分期产品仅供现有持卡人申请使用，浦发银行信用卡推出的“钱好贷”业务即便消费者手中尚无信用卡，也可申请办理，最快一天放款，这无疑满足了更多普通消费者的<a href="http://m.so.com/s?q=%E4%BF%A1%E8%B4%B7&amp;src=newstranscode" class="qkw">信贷</a>需求。</p><p>浦发银行信用卡相关负责人近日在接受记者的采访时表示，“随着<a href="http://m.so.com/s?q=%E4%BA%92%E8%81%94%E7%BD%91%E6%97%B6%E4%BB%A3&amp;src=newstranscode" class="qkw">互联网时代</a>深入推进，我们也将更加聚焦在消费者个性需求的探索和研究，致力开发出与消费者行为紧密相关的定制化金融产品与服务，多渠道布局消费金融，以期收获更多持卡人的好评。” (青岛财经日报/青岛<a href="http://m.so.com/s?q=%E8%B4%A2%E7%BB%8F%E7%BD%91&amp;src=newstranscode" class="qkw">财经网</a>(博客,微博)记者)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://bank.hexun.com/2016-03-14/182735848.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='4b53ee2fe134022666ae76f664761ce3'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>浦发信用卡</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%B5%A6%E5%8F%91%E4%BF%A1%E7%94%A8%E5%8D%A1&amp;pn=1&amp;pos=5&amp;m=3356ec311c8a94b7d86545004125a7494f83c88a&amp;u=http%3A%2F%2Ffinance.southcn.com%2Fqyxw%2Fcontent%2F2016-03%2F11%2Fcontent_143893088.htm" data-pos="1"> <b>浦发信用卡</b>全面渗透消费场景 普惠金融精耕细作 </a>   <li> <a href="/transcode?q=%E6%B5%A6%E5%8F%91%E4%BF%A1%E7%94%A8%E5%8D%A1&amp;pn=1&amp;pos=6&amp;m=934cd218c5757c65399283f3c18e806cadf4abd9&amp;u=http%3A%2F%2Ffinance.china.com.cn%2Froll%2F20160307%2F3616152.shtml" data-pos="2"> <b>浦发信用卡</b>构筑反诈骗体系 </a>   <li> <a href="/transcode?q=%E6%B5%A6%E5%8F%91%E4%BF%A1%E7%94%A8%E5%8D%A1&amp;pn=1&amp;pos=7&amp;m=3b9156b9ee3bc412bb92099eca7ad4c218053861&amp;u=http%3A%2F%2Fbank.hexun.com%2F2016-03-10%2F182684791.html" data-pos="3"> 客户被冒名办<b>浦发</b>银行<b>信用卡</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '浦发银行信用卡深挖客户需求多渠道布局消费金融()' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '浦发银行信用卡深挖客户需求多渠道布局消费金融()'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";