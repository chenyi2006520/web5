s:20855:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>温氏股份神话背后:十三家族“拧”成养猪第一股- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">温氏股份神话背后:十三家族“拧”成养猪第一股</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-03-15 08:53:20</time></p> </header>  <div id="news-body"><p>2015年11月2日，换股合并实现整体上市的温氏股份(300498.SZ)，股价出现暴涨，市值一度超过2000亿元，成为当之无愧的<a href="http://m.so.com/s?q=%E5%88%9B%E4%B8%9A%E6%9D%BF&amp;src=newstranscode" class="qkw">创业板</a>巨无霸，万千股民追捧的对象。</p><p>让外界颇为困惑的是，一家主营禽肉产品的温氏股份，何以能够拥有如此大规模的市值，围绕其发展轨迹，一直为外界所关注。3月6日，全国<a href="http://m.so.com/s?q=%E4%B8%A4%E4%BC%9A&amp;src=newstranscode" class="qkw">两会</a>召开期间，全国人大代表、温氏股份董事长<a href="http://m.so.com/s?q=%E6%B8%A9%E9%B9%8F%E7%A8%8B&amp;src=newstranscode" class="qkw">温鹏程</a>在北京首都大酒店，接受了时代周报记者的专访。</p><p>上世纪80年代初期，由7户农民<a href="http://m.so.com/s?q=%E9%9B%86%E8%B5%84&amp;src=newstranscode" class="qkw">集资</a>8000元起步，经过30余载的发展，到如今成为一家以畜禽养殖为主、跨地区的现代农牧企业集团，温氏股份一路走来，稳扎稳打。目前，温氏股份已在全国23个省(市、自治区)设立了170多家一体化公司，现有合作<a href="http://m.so.com/s?q=%E5%AE%B6%E5%BA%AD%E5%86%9C%E5%9C%BA&amp;src=newstranscode" class="qkw">家庭农场</a>5.3万户、员工4万余人。</p><p>作为一名老代表，今年是54岁的温鹏程第19次参加全国两会。面对外界关心的温氏股份“公司+农户”的发展模式、温氏家族化等问题，温鹏程毫不讳言，向时代周报记者娓娓道来。</p><p>神话背后 依赖“<a href="http://m.so.com/s?q=%E6%B8%A9%E6%B0%8F%E6%A8%A1%E5%BC%8F&amp;src=newstranscode" class="qkw">温氏模式</a>”</p><p>中国是世界<a href="http://m.so.com/s?q=%E7%8C%AA%E8%82%89&amp;src=newstranscode" class="qkw">猪肉</a>消费第一大国。温氏股份定位于畜禽养殖为主业，恰逢其时。温氏股份的主营业务为肉猪、<a href="http://m.so.com/s?q=%E8%82%89%E9%B8%A1&amp;src=newstranscode" class="qkw">肉鸡</a>等禽类产品，近几年其规模远超同行。</p><p>据温氏股份官网披露，2014年温氏集团上市肉猪1218万头、肉鸡6.97亿只、肉鸭1699万只，实现销售收入380亿元。而在刚刚过去的2015年，温氏股份的经营业绩再次迈上新台阶。</p><p>最新的业绩快报显示，2015年温氏股份实现营收达482.34亿元，同比增长24.56%;营业利润为67.17亿元，同比增长132.54%;归属于上市公司股东的净利润为62.76亿元，同比增长126.16%。</p><p>在业内人士看来，温氏股份的发展得益于其独有的“温氏模式”-以紧密型“公司+农户(家庭农场)”为核心、适度规模化养殖为基础的发展和经营管理模式。</p><p><a href="http://m.so.com/s?q=%E9%95%BF%E6%B1%9F%E8%AF%81%E5%88%B8&amp;src=newstranscode" class="qkw">长江证券</a> 分析师认为，温氏股份通过其“轻资产、全产业链、全员持股”的温氏模式解决了养殖业大规模化而因技术跟不上导致的高成本难题，成本优势显著。另外，温氏股份较高的生产效率及成本控制优势，能够保证合作农户利润持续增长，吸引更多农户加入温氏体系，实现规模的持续扩张。</p><p>温鹏程在接受时代周报记者专访时表示，畜牧业巨大的成本是饲料，大概占到总成本的70%。目前国家正在提倡“<a href="http://m.so.com/s?q=%E5%8E%BB%E5%BA%93%E5%AD%98&amp;src=newstranscode" class="qkw">去库存</a>”的发展思路，近年来玉米和粮食的库存完全跳出了正常年份的库存。温鹏程认为，在“去库存”的过程中，会让这些产品的价格大幅下降，“这可以让我们的畜牧产品，生产成本大幅下降。”</p><p>目前，温氏股份将产业触角伸至湖北、安徽和江苏等地，在发展过程中，温氏股份“公司+农户”的发展模式，引起了环保争议。对于国家越来越严格的环保政策和法规，温鹏程告诉时代周报记者，公司历来重视环境保护，并在5年前就已提出了环保问题解决方案，即环保“三同时”制度，另外这几年在环保方面的投入资金达到10亿-20亿元，“去年我们投入了2.7亿元的环保资金，新投产的项目，(环保)标准较高，达到了循环利用的标准。”</p><p>时代周报记者注意到，在50多分钟的专访时间里，温鹏程多次谈到环保话题，“我们三年前就明确了环保管理，是生产环节一项重要的工作，我们的环保压力不大”。</p><p>迈入2016年，温氏股份发展势头迅猛。3月7日，温氏股份披露了今年2月公司商品肉猪销售情况，2月销售商品肉猪109.81万头，收入22.15亿元，销售均价17.91元/公斤，环比变动分别为-31.74%、-27.66%、4.01%，对此温氏股份解释称，“受春节假期影响，公司商品肉猪出栏量减少;公司业务规模扩大、商品肉猪出栏量增长及销售价格上涨。”</p><p>近来，温氏股份再次将产业板块向全国布局。2月3日，该公司披露了一项定增预案，“本次募集资金投资项目以每年合计新增肉猪产能 182 万头为目标，拟使用募集资金投资 11.6亿元，用于建立4个肉猪养殖一体化建设项目。</p><p class="header">启动组织架构变革</p><p>温氏股份内部家族分散，共计有13个家族，其中以温鹏程家族和严居然家族影响最甚。据时代周报记者梳理发现，温氏股份的股本结构较为分散，无持有公司股份5%以上的单一股东，各股东的持股数及持股比例均较小。</p><p>截至目前，温氏家族成员中，包括温鹏程在内的11人在温氏股份持股，合计持有公司6.07亿股股票，持股比例为16.74%，为温氏股份实际控制人。在董事会层面，温氏股份共计有8名握有“实权”的非<a href="http://m.so.com/s?q=%E7%8B%AC%E7%AB%8B%E8%91%A3%E4%BA%8B&amp;src=newstranscode" class="qkw">独立董事</a>，其中温鹏程在公司担任董事长，温氏家族成员在非独立董事中拥有4名席位，占到1/2，对于公司董事会和股东大会形成决议，有重大影响。</p><p>另外，严氏家族在温氏股份的“影响力”也不容小觑。温氏股份总裁、技术总监严居然，以及严居能两兄弟，均在董事会担任董事，两人合计持有1.77亿股，持股比例达4.88%。</p><p>温鹏程在接受时代周报记者采访时，对于公司家族化倾向这一话题毫不讳言，“温氏从成立那一天起，我们就是一个带有家族烙印的公众公司。” 温鹏程表示，正是因为如此，早期的温氏集团才被拒于资本市场之外，“但我们完全是以公众公司的方式管理，所以管理团队的成长和民主化，得到了充分的体现。”</p><p>温鹏程进一步指出，虽然温氏带有家族烙印，但是管理团队的作用、决策的程序是非常科学、合理，而且高效的。</p><p>时代周报记者注意到，从去年11月份整体上市成为创业板“第一股”后，温氏股份经过资本市场震荡，依旧稳坐“一哥”宝座。截至3月10日收盘，温氏股份报收47.87元/股，总市值达到1735.41亿元，超过绿地控股(600606.SH，总市值1555.09亿元)和<a href="http://m.so.com/s?q=%E5%85%89%E5%A4%A7%E9%93%B6%E8%A1%8C&amp;src=newstranscode" class="qkw">光大银行</a>(601818.SH，总市值1699.12亿元)，在沪深股市2823家上市公司中， <a href="http://m.so.com/s?q=%E5%B9%B3%E5%AE%89%E9%93%B6%E8%A1%8C&amp;src=newstranscode" class="qkw">平安银行</a> 的总市值目前不到1500亿元，温氏股份总市值排名第25位，可谓深市的新“巨无霸”</p><p>在整体上市后，上述13个家族和个人身家已过亿，温氏创始人提出的共同<a href="http://m.so.com/s?q=%E5%88%86%E4%BA%AB%E8%B4%A2%E5%AF%8C&amp;src=newstranscode" class="qkw">分享财富</a>观念变成现实。今年以来，温氏股份继续加大对股东的财富共享。根据2015年度的经营情况，温氏股份发布了<a href="http://m.so.com/s?q=%E3%80%8A2015%E5%B9%B4%E5%BA%A6%E5%88%A9%E6%B6%A6%E5%88%86%E9%85%8D%E9%A2%84%E6%A1%88%E9%A2%84%E6%8A%AB%E9%9C%B2%E3%80%8B&amp;src=newstranscode" class="qkw">《2015年度利润分配预案预披露》</a>公告，向全体股东每10股派发现金不少于5元(含税)，合计派发现金股利不少于18.13亿元，同时以资本公积向股东每10股转增不少于2股，合计转增股本不少于7.25亿股。</p><p>不仅如此，温氏股份还启动了员工持股计划。2月3日，温氏股份披露称，该计划的资金总额不超过11.6亿元，参与对象包括本公司董监高管理人员，以及签订正式劳动合同的子公司员工，总人数达19097人。</p><p>温鹏程告诉时代周报记者，为了上市后更好地发展，温氏股份直接启动了关于组织架构变革的工作，已聘请了有关的第三方咨询公司，指导此次变革。</p><p>“我们很快会以原来的母公司来带动分公司发展，到下个阶段，组织变革(实施)以后，可能会让企业的管理更专业化，具体从业务队伍专业化、年轻化这几个方面体现出来。”温鹏程对时代周报记者称。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://finance.china.com.cn/stock/ssgs/20160315/3627532.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='f632b377b56b5090f50db21d9826153d'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>家族关系</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%AE%B6%E6%97%8F%E5%85%B3%E7%B3%BB&amp;pn=1&amp;pos=3&amp;m=e2038112ff6ea7148e9c3a751adddeb75ec85410&amp;u=http%3A%2F%2Fwww.china.com.cn%2Fguoqing%2F2016-03%2F15%2Fcontent_38026224.htm" data-pos="1"> 全球最显赫的十二大<b>家族</b> 第1名竟然在中国(图) </a>   <li> <a href="/transcode?q=%E5%AE%B6%E6%97%8F%E5%85%B3%E7%B3%BB&amp;pn=1&amp;pos=4&amp;m=aff0b3cb603a4e9733803cfab723434f6d4e88c2&amp;u=http%3A%2F%2Fnews.sina.com.cn%2Fc%2F2016-03-15%2Fdoc-ifxqhfvp1039661.shtml" data-pos="2"> 蔡英文<b>家族</b>争产案爆出内幕 炒房炒地"有玄机" </a>   <li> <a href="/transcode?q=%E5%AE%B6%E6%97%8F%E5%85%B3%E7%B3%BB&amp;pn=1&amp;pos=5&amp;m=16255e2f4c261063b9fd6d0b5ebf76a501df3008&amp;u=http%3A%2F%2Fstock.hexun.com%2F2016-03-15%2F182753721.html" data-pos="3"> 十三<b>家族</b>"拧"成养猪第一股 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '温氏股份神话背后:十三家族“拧”成养猪第一股' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '温氏股份神话背后:十三家族“拧”成养猪第一股'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";