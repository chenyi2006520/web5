s:14790:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>百慕大三角之谜或解开揭你不知道的事 百慕大三角传说从何而来- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">百慕大三角之谜或解开揭你不知道的事 百慕大三角传说从何而来</h1> <p id="source-and-time"><span id=source>长株潭网</span><time id=time>2016-03-15 09:31:35</time></p> </header>  <div id="news-body"><p>著名的<a href="http://m.so.com/s?q=%E7%99%BE%E6%85%95%E5%A4%A7%E4%B8%89%E8%A7%92&amp;src=newstranscode" class="qkw">百慕大三角</a>，自古以来流传多起船只失踪事件，神秘现象迟迟得不到解答。如今有科学家在百慕大三角附近的海域找到了多个巨大水底坑穴，他们认为这能够为该地区的船只神秘失踪作出一个可行的解释。</p><p><img src="http://p34.qhimg.com/t01993d925a34384c08.jpg?size=518x322"></p><p><a href="http://m.so.com/s?q=%E7%99%BE%E6%85%95%E5%A4%A7%E4%B8%89%E8%A7%92%E4%B9%8B%E8%B0%9C&amp;src=newstranscode" class="qkw">百慕大三角之谜</a>或解开揭你不知道的事 百慕大三角传说从何而来</p><p>据英国媒体3月13日报道，百慕大三角地处<a href="http://m.so.com/s?q=%E5%8C%97%E7%BE%8E&amp;src=newstranscode" class="qkw">北美</a>佛罗里达半岛东南部，具体是指<a href="http://m.so.com/s?q=%E7%99%BE%E6%85%95%E5%A4%A7%E7%BE%A4%E5%B2%9B&amp;src=newstranscode" class="qkw">百慕大群岛</a>、美国的迈阿密和<a href="http://m.so.com/s?q=%E6%B3%A2%E5%A4%9A%E9%BB%8E%E5%90%84&amp;src=newstranscode" class="qkw">波多黎各</a>的圣胡安三点连线形成的一个东<a href="http://m.so.com/s?q=%E5%A4%A7%E8%A5%BF%E6%B4%8B&amp;src=newstranscode" class="qkw">大西洋</a>三角地带。近百年来，这里屡屡发生海难事件，船只在极短的时间里便消失得无影无踪，似乎一下子“融化”在海洋里。</p><p>日前，来自<a href="http://m.so.com/s?q=%E6%8C%AA%E5%A8%81&amp;src=newstranscode" class="qkw">挪威</a>北极圈大学(Artic University of Norway)的研究人员在百慕大三角附近的巴伦支海海底发现了多个巨大的坑穴，这些坑穴的宽度达到半英里(约合805米)、深度为150英尺(约合46米)，据信是由临近海岸的甲烷累积爆炸形成。</p><p>据科学家介绍，该海域的海底深处存在丰富的天然气储备，天然气(主要成分为甲烷)慢慢泄露，积年累日之下甲烷堆积在海底形成空洞，这些内里充满甲烷的空洞最终发生爆炸。</p><p><img src="http://p33.qhimg.com/t01c92119beef3c9f56.jpg?size=465x305"></p><p>“在中西部巴伦支海的海床上存在许多巨大的坑穴……很有可能是天然气大爆炸造成的。这片海域极有可能代表了北极圈内浅海洋甲烷释放的最大一片热点区域。”研究人员表示，海底爆炸可能给爆炸时正好在海面上航行的船只造成危险，从而解释了百慕大三角地区船只失踪的真正原因所在。</p><p>有关此次研究的更多细节内容，将在下月举行的欧洲地球科学联合会年会上公布。</p><p>去年，俄罗斯托洛费穆克研究所副所长伊戈尔叶茨索夫表示，有观点认为百慕大三角是一系列<a href="http://m.so.com/s?q=%E5%A4%A9%E7%84%B6%E6%B0%94%E6%B0%B4%E5%90%88%E7%89%A9&amp;src=newstranscode" class="qkw">天然气水合物</a>反应的产物，“它们与甲烷冰分解变成气体，近似于<a href="http://m.so.com/s?q=%E6%A0%B8%E5%8F%8D%E5%BA%94&amp;src=newstranscode" class="qkw">核反应</a>生成巨量的气体，使海洋变热，造成沉船事故”。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://news.czt.cc/guoji/2016/0315/79147.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='617fcc2df7a2b90ea72fc65a0cf87e84'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>你不知道的是</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%BD%A0%E4%B8%8D%E7%9F%A5%E9%81%93%E7%9A%84%E6%98%AF&amp;pn=1&amp;pos=4&amp;m=8e11801428260b9fbfc52467be24238956354d8e&amp;u=http%3A%2F%2Fwww.nxing.cn%2Fwap%2Farticle%2F4047889.html" data-pos="1"> 瓦良格那些<b>你不知道的事</b>:并非乌克兰制造,土耳其为何三次找茬 </a>   <li> <a href="/transcode?q=%E4%BD%A0%E4%B8%8D%E7%9F%A5%E9%81%93%E7%9A%84%E6%98%AF&amp;pn=1&amp;pos=5&amp;m=c4717e7279b9454526ddbfc4995ac2ee8c42b084&amp;u=http%3A%2F%2Fnews.czt.cc%2Fguoji%2F2016%2F0315%2F79147.html" data-pos="2"> 百慕大三角之谜或解开揭<b>你不知道的事</b> 百慕大三角传说从何而来 </a>   <li> <a href="/transcode?q=%E4%BD%A0%E4%B8%8D%E7%9F%A5%E9%81%93%E7%9A%84%E6%98%AF&amp;pn=1&amp;pos=6&amp;m=821104234059e18c932b28691bde8d9da37b1fdf&amp;u=http%3A%2F%2Fmt.sohu.com%2F20160309%2Fn439856606.shtml" data-pos="3"> 明清瓷器中那些<b>你不知道的事</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '百慕大三角之谜或解开揭你不知道的事 百慕大三角传说从何而来' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '百慕大三角之谜或解开揭你不知道的事 百慕大三角传说从何而来'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";