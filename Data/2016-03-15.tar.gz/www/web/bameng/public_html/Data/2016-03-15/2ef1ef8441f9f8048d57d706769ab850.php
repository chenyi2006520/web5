s:15752:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>李治廷否认与林志玲假戏真做- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">李治廷否认与林志玲假戏真做</h1> <p id="source-and-time"><span id=source>人民网辽宁频道</span><time id=time>2016-03-15 14:09:00</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t01dca5c95df1385c02.jpg?size=300x450"></p><p><a href="http://m.so.com/s?q=%E6%9D%8E%E6%B2%BB%E5%BB%B7&amp;src=newstranscode" class="qkw">李治廷</a>在《花样姐姐2》中担任“挑夫”。</p><p><a href="http://m.so.com/s?q=%E4%B8%9C%E6%96%B9%E5%8D%AB%E8%A7%86&amp;src=newstranscode" class="qkw">东方卫视</a>的《花样姐姐2》首播告捷。<a href="http://m.so.com/s?q=%E6%9E%97%E5%BF%97%E7%8E%B2&amp;src=newstranscode" class="qkw">林志玲</a>和李治廷在机场重逢、激动拥抱的画面，让被浪漫感动的观众直呼“在一起”。昨日，李治廷接受记者采访时表示:“我和志玲姐姐好像亲人的关系。”</p><p class="header">感谢网友封“颜值”CP称号</p><p>新一季<a href="http://m.so.com/s?q=%E3%80%8A%E8%8A%B1%E6%A0%B7%E5%A7%90%E5%A7%90%E3%80%8B&amp;src=newstranscode" class="qkw">《花样姐姐》</a>一开场，李治廷与林志玲在机场激动相拥的场面让网友感到很温馨，期望这对“颜值”CP能够在一起。对于网友封的“颜值”CP称号，李治廷幽默地感谢大家对于自己和林志玲颜值的肯定。对于是否真的会考虑发展感情，李治廷却回避道:“我和志玲姐姐好像亲人的关系，就像我和<a href="http://m.so.com/s?q=%E7%8E%8B%E7%90%B3&amp;src=newstranscode" class="qkw">王琳</a>的关系一样，见到她们都很感动，大家不要想多了。”</p><p>“拜师”<a href="http://m.so.com/s?q=%E5%AE%8B%E4%B8%B9%E4%B8%B9&amp;src=newstranscode" class="qkw">宋丹丹</a>学相声</p><p>对新加盟节目的“姐姐”宋丹丹、<a href="http://m.so.com/s?q=%E5%A7%9C%E5%A6%8D&amp;src=newstranscode" class="qkw">姜妍</a>、金晨，李治廷赞不绝口。尽管在部分观众眼中宋丹丹强势、不好搞，但李治廷透露，宋丹丹会教大家说相声、快板，如今李治廷也能说得一口流利的“贯口”了，更表示以后有机会去当一个“相声演员”，“目前她还没有认我做干儿子，但我会朝这个方向努力”。</p><p>在第一季节目中，李治廷并不是一个讨喜的“挑夫”，为了精打细算，他成了姐姐们心中的“抠门大王”。这次李治廷学精了，决定学着当一个土豪“挑夫”:“我知道了节目的路子，这次会在节目中赚钱，该花就花。”</p><p>李治廷第一个大手笔的花费，就是为了迎接林志玲买了99朵玫瑰。对于被称“妇女之友”，他表示:“是姐姐之友，这个节目没有妇女，都是姐姐。真的不是开玩笑，我跟女人特别有缘分。”</p><p>学聪明了的李治廷，不仅学会了懂“女人心”，而且跟着“弟弟”<a href="http://m.so.com/s?q=Henry&amp;src=newstranscode" class="qkw">Henry</a>学会了化被动为主动，私下里，李治廷还向Henry拜师学艺:“我跟他学习了很多。”</p><p class="header">相关链接:</p><p><a href="http://m.so.com/s?q=%E3%80%8A%E8%8A%B1%E6%A0%B7%E5%A7%90%E5%A7%902%E3%80%8B&amp;src=newstranscode" class="qkw">《花样姐姐2》</a>风格突变 明星“穷游”变“乐游”</p><p>广州日报讯 (记者 曾俊)东方卫视的《花样姐姐2》3月12日回归。尽管首期节目里壮美奇险的旅途还未展开，但大部分观众看完后的第一观感是“很欢乐、很搞笑”。宋丹丹、林志玲、王琳、<a href="http://m.so.com/s?q=%E9%87%91%E6%99%A8&amp;src=newstranscode" class="qkw">金晨</a>、姜妍以及“挑夫”李治廷、Henry等新老成员一见面便<a href="http://m.so.com/s?q=%E7%81%AB%E8%8A%B1%E5%9B%9B%E6%BA%85&amp;src=newstranscode" class="qkw">火花四溅</a>，且在开篇就定下一个大家庭出游其乐融融的基调，而并非以往在旅游类节目中常见的互相抱怨、意见不统一等“内斗”戏码。</p><p>不少观众认为，除了成员有变化外，这一季的画风也完全改变，正能量提升。由于这次旅行的终极目标是南极，旅途的难度可见一斑。然而第一天就让老成员大吃一惊，旅行途中的最大开支--酒店竟然不用自己付费，每人每天有100美元可以花费，大有将“穷游”变“乐游”的趋势，节目组也希望明星能够把更多的精力放在对异域风情、人文的体验上，并收获过程中的友谊与真情。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://ln.people.com.cn/n2/2016/0315/c339835-27938888.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='702f212761e9f5710fbc17f4cc3f3e00'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>李治廷</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9D%8E%E6%B2%BB%E5%BB%B7&amp;pn=1&amp;pos=8&amp;m=e0846b89a734ca4e02dd563e0c9826658ddb7f9f&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2Fent%2Fgossip%2F4758177_1.html" data-pos="1"> <b>李治廷</b>回应与林志玲举动亲密:我们就像亲人 </a>   <li> <a href="/transcode?q=%E6%9D%8E%E6%B2%BB%E5%BB%B7&amp;pn=1&amp;pos=9&amp;m=1b0977eb834a46ff198280981c89e9153c165a36&amp;u=http%3A%2F%2Ffj.people.com.cn%2Fn2%2F2016%2F0315%2Fc234651-27939384.html" data-pos="2"> <b>李治廷</b>《花样姐姐2》当"挑夫" 否认与林志玲假戏真做:与她是亲人 </a>   <li> <a href="/transcode?q=%E6%9D%8E%E6%B2%BB%E5%BB%B7&amp;pn=1&amp;pos=10&amp;m=24ab1ebb161f105b5a01e781f649e48c0ee0edf3&amp;u=http%3A%2F%2Fcnews.chinadaily.com.cn%2F2016-03%2F15%2Fcontent_23868918.htm" data-pos="3"> 《花样姐姐2》<b>李治廷</b>否认与林志玲假戏真做:与她是亲人 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '李治廷否认与林志玲假戏真做' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '李治廷否认与林志玲假戏真做'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";