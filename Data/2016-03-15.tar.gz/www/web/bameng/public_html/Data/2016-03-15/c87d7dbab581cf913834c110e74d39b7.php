s:15676:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>首获奖金孙岩百感交集 资格赛借外套参赛- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">首获奖金孙岩百感交集 资格赛借外套参赛</h1> <p id="source-and-time"><span id=source>新华网江西频道</span><time id=time>2015-05-18 11:29:26</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t01cedab5b8c0eaa24e.jpg?size=550x371"></p><p><a href="http://m.so.com/s?q=%E5%AD%99%E5%B2%A9&amp;src=newstranscode" class="qkw">孙岩</a></p><p>北京时间5月17日，2015<a href="http://m.so.com/s?q=%E5%B9%B3%E5%AE%89%E9%93%B6%E8%A1%8C&amp;src=newstranscode" class="qkw">平安银行</a>中国巡回赛-美巡中国系列赛永恒的院子公开赛在郑州<a href="http://m.so.com/s?q=%E5%9C%A3%E5%AE%89%E5%BE%B7%E9%B2%81%E6%96%AF&amp;src=newstranscode" class="qkw">圣安德鲁斯</a>球场战罢，中华台北选手詹世昌以-9杆的成绩夺冠，孙岩打出四轮最高的74杆成绩，以总成绩+4排在并列第51位。转职业三年，27岁的孙岩终于在第一场正式的职业赛事晋级，也拿到了自己<a href="http://m.so.com/s?q=%E9%AB%98%E5%B0%94%E5%A4%AB&amp;src=newstranscode" class="qkw">高尔夫</a>的第一笔职业奖金--税前1万2人民币。</p><p>“前两天打完能晋级就挺高兴的，至少比前两年强多了，第三天打完后觉得自己能冲一下。前面一直打得不错，第八洞距离算错了打下水，从那开始心里有点波动，连续打了三个柏忌。”孙岩说，“总体感觉还不错，这也是我第一次拿到职业赛事的奖金。”</p><p>孙岩来自山东农村，父母对高尔夫一无所知也无力承担他打球的费用，在球场当过保安的孙岩接触高尔夫后很快就将成绩提高到了七字头。2012年孙岩参加了职业考试转为职业球员，但是因为足够的资金支持，孙岩有钱就去打比赛，没钱就中断比赛去挣钱。父母对于孙岩打高尔夫比赛也不支持，年前孙岩的爸爸打来电话，让儿子不要去打球了，说打了十年也没有赚到钱。孙岩跟爸爸说自己还要再拼两年，如果这两年拼不出来，就踏踏实实去工作挣钱。</p><p>今年三月，孙岩参加了中国<a href="http://m.so.com/s?q=%E7%BE%8E%E5%B7%A1%E8%B5%9B&amp;src=newstranscode" class="qkw">美巡赛</a>中国区资格赛的考试，最终名列第二获得本赛季的参赛全卡成为了他职业生涯的转折点。孙岩说:“海南的第一站比赛没能晋级，我还想如果没有钱了，可能还要停掉比赛去挣钱。这次能晋级对我而言是好的开端，我觉得自己挺满足的。”</p><p>在参加美巡中国赛资格赛考试的四天比赛中，孙岩穿的是一件蓝色<a href="http://m.so.com/s?q=%E6%B1%87%E4%B8%B0&amp;src=newstranscode" class="qkw">汇丰</a>青少年比赛的既不防风也不防水的外套，无论刮风下雨四天一直穿的是那件衣服，孙岩说这还是跟哥们借来的外套。这次参加比赛孙岩特意为自己购置了比赛服，打职业比赛就应该有点职业球员的样子。不过除了球具商提供的帽子、球和鞋子还有木杆和推杆，孙岩其他的球杆都是自己买的。“我想年底排名至少要进入前30才可能会有赞助，我现在已经达成了职业生涯的第一个目标，接下来就是一步步往前赶，希望到了年底打完比赛不用再打资格赛。”</p><p>孙岩的练球条件非常艰苦，住在上海的他平日就在一个练习场练球，“很多人看我推杆特别烂，因为我平时没有<a href="http://m.so.com/s?q=%E6%9E%9C%E5%B2%AD&amp;src=newstranscode" class="qkw">果岭</a>可以练球。如果这一站推杆更好些，成绩会更好些。”昨天十几洞攻上果岭距离都不远，但一共只打了<a href="http://m.so.com/s?q=%E5%9B%9B%E5%8F%AA%E5%B0%8F%E9%B8%9F&amp;src=newstranscode" class="qkw">四只小鸟</a>，“老鹰推推成了鸟，一码半的推杆进不去，只有死鸟才有可能进。”孙岩说。推杆太差不是个办法，孙岩说:“以后比赛前争取早点到球场练练推杆，在上海住的离<a href="http://m.so.com/s?q=%E7%BE%8E%E5%85%B0%E6%B9%96&amp;src=newstranscode" class="qkw">美兰湖</a>比较近，下场也会在那里，希望有时间能练练推杆。”</p><p>孙岩说到现在也也没打电话告诉父母自己晋级以及拿到奖金的消息，“我自己是百感交集，但还没跟父母打电话，跟他们讲了也不太懂，回家的时候带回钱去就好了。”</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.jx.xinhuanet.com/news/sports/2015-05/18/c_1115316872.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='ad91d5d8586c0424e44c21d2b3d41af0'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>孙岩</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%AD%99%E5%B2%A9&amp;pn=1&amp;pos=6&amp;m=383080205dd70836bad1b0d5fe6894c6cd1a73c3&amp;u=http%3A%2F%2Ftech.gmw.cn%2Fnewspaper%2F2015-01%2F15%2Fcontent_103763551.htm" data-pos="1"> 孙其峰 孙长康 <b>孙岩</b>山水画全国巡展(临沂站) </a>   <li> <a href="/transcode?q=%E5%AD%99%E5%B2%A9&amp;pn=1&amp;pos=7&amp;m=c4aef05f62717338bd00eb9fc0331f2d9f1ed0f2&amp;u=http%3A%2F%2Fnews.163.com%2F14%2F1126%2F13%2FABVV607A00014AED.html" data-pos="2"> 书画世家展妙笔丹青- 孙其峰孙长康<b>孙岩</b>山水画全国巡展启动 </a>   <li> <a href="/transcode?q=%E5%AD%99%E5%B2%A9&amp;pn=1&amp;pos=8&amp;m=ec880bc44d3a0b357a0f2df2ed9231ef23c772e6&amp;u=http%3A%2F%2Fwww.ha.chinanews.com%2FGNnews%2F7%2F2014%2F11%2F10%2F334489.shtml" data-pos="3"> 河南青年艺术家<b>孙岩</b>油画展在意大利美第奇皇宫开幕 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '首获奖金孙岩百感交集 资格赛借外套参赛' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '首获奖金孙岩百感交集 资格赛借外套参赛'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";