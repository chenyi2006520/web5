s:22259:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>漫威铸建电影宇宙!星战速激DC等体系庞大- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">漫威铸建电影宇宙!星战速激DC等体系庞大</h1> <p id="source-and-time"><span id=source>中国日报网</span><time id=time>2016-03-03 11:21:23</time></p> </header>  <div id="news-body"><p>近几年，<a href="http://m.so.com/s?q=%E6%BC%AB%E5%A8%81&amp;src=newstranscode" class="qkw">漫威</a>铸建电影宇宙，超级英雄们有时群体作战，有时串个门来助一臂之力，粉丝喜闻乐见、周边卖不断、主演登上收入榜前段，更让电影公司赚个饱。</p><p>“先驱者”漫威今年先后有《美国队长3:英雄内战》(5.6)、《奇异博士》(11.4)两部影片上映。<a href="http://m.so.com/s?q=%E6%BC%AB%E5%A8%81%E7%94%B5%E5%BD%B1%E5%AE%87%E5%AE%99&amp;src=newstranscode" class="qkw">漫威电影宇宙</a>继续扩张中，阶段计划绝对够“燃”。而有这把吸粉赚钱的好机会，好莱坞大佬们自不会错过。</p><p>所谓宇宙，当然不是拥有几部续集电影便可担此称号，独特的世界观、无限延伸的故事体系、庞杂的人物关系，都是成为电影宇宙的必要不充分条件。所以，也就有了<a href="http://m.so.com/s?q=%E3%80%8A%E9%AD%94%E5%85%BD%E3%80%8B&amp;src=newstranscode" class="qkw">《魔兽》</a>、《刺客信条》这些，虽暂定一部，却已提前锁定一席。</p><p class="header">1、DC电影宇宙</p><p>漫威<a href="http://m.so.com/s?q=%E5%AE%87%E5%AE%99%E9%9C%B8%E6%B0%94&amp;src=newstranscode" class="qkw">宇宙霸气</a>扩张，DC怎会没有动作，虽说人家都已经登上<a href="http://m.so.com/s?q=%E7%AC%AC%E4%B8%89%E5%B1%82%E6%A5%BC&amp;src=newstranscode" class="qkw">第三层楼</a>了，这里才走到第二步阶梯，但DC每一步也都走得稳扎稳打。</p><p>从已上映的《钢铁之躯》，到发布预告的《正义黎明》、《X特遣队》，包括特别节目中曝出的《神奇女侠》片段，处处看得出DC心血，美漫迷们绝对可以安心。而出彩的“小丑女”玛格特·罗比、“神奇女侠”盖尔·加朵更是在DC培育下，即将走上爆红之路。</p><p>DC自然走的也是长远路线，平均一年两部超级英雄大片的模式持续至2020年，而本·阿弗莱克版蝙蝠侠，已在公司高层间得到绝对肯定，被评价为“史上最棒蝙蝠侠”，还拉起大本重启<a href="http://m.so.com/s?q=Solo&amp;src=newstranscode" class="qkw">Solo</a>系列。漫威宇宙，DC<a href="http://m.so.com/s?q=%E5%AE%87%E5%AE%99%E6%9D%A5%E8%A2%AD&amp;src=newstranscode" class="qkw">宇宙来袭</a>，你准备好了吗?</p><p><img src="http://p31.qhimg.com/t019c0a2e9f6fd5b4e5.jpg?size=550x590"></p><p>2、“哈利·波特”<a href="http://m.so.com/s?q=%E9%AD%94%E6%B3%95%E4%B8%96%E7%95%8C&amp;src=newstranscode" class="qkw">魔法世界</a>宇宙</p><p>11年《哈利·波特》系列终章上映，可哈迷们怎舍得和这个风靡世界的超级IP说再见，《神奇动物在哪里》从立项起便备受关注，新科奥斯卡影帝小雀斑成为霍格沃滋教科书作者纽特·斯卡曼，时间穿越回上世纪20年代，魔法世界大门再度打开。</p><p>从先前曝光剧照、先导预告看，哈迷们实在等待太久，黑暗中，主角轻念“荧光闪烁咒” ，大批粉丝们已泪奔。拥有绝对数量粉丝人群，J·K·罗琳打造的魔法世界归来，这个宇宙，我看行!</p><p><img src="http://p34.qhimg.com/t0184b6e99eff570e56.jpg?size=400x410"></p><p class="img-title">3、“凯尔特神话”电影宇宙</p><p>凯尔特神话，与希腊神话、北欧神话并列，具有诸神、勇士、先知、魔法师、骑士等神族人类，<a href="http://m.so.com/s?q=%E3%80%8A%E5%9C%86%E6%A1%8C%E9%AA%91%E5%A3%AB%3A%E4%BA%9A%E7%91%9F%E7%8E%8B%E3%80%8B&amp;src=newstranscode" class="qkw">《圆桌骑士:亚瑟王》</a>、《石中剑》两部影片均以<a href="http://m.so.com/s?q=%E4%BA%9A%E7%91%9F%E7%8E%8B&amp;src=newstranscode" class="qkw">亚瑟王</a>，这位具有传奇色彩的国王为主角，华纳《圆桌骑士:亚瑟王》传闻将拍成六部曲，详述传奇。</p><p>凯尔特神话本身时间跨越度较大，分支也有好几项，再加上传说始于百姓们的口口相传，不乏许多争议点，<a href="http://m.so.com/s?q=%E5%A5%BD%E8%8E%B1%E5%9D%9E&amp;src=newstranscode" class="qkw">好莱坞</a>对该题材一直是又爱又恨，搜索关键词“圣杯、亚瑟王、圣剑、圆桌骑士”等，就能发现其踪迹。也许，“凯尔特神话”宇宙，也能在银幕上呈现如《指环王》、《霍比特人》系列的辉煌。</p><p>《圆桌骑士:亚瑟王》还未有剧照放出，除了神话迷人，导演盖·里奇、主演查理·汉纳姆、裘德·洛的组合也十分吸粉。</p><p><img src="http://p33.qhimg.com/t0135c84b1ce05a474e.jpg?size=550x284"></p><p class="img-title">4、“星球大战”电影宇宙</p><p>2015的北美电影市场，完全可以说是星战迷们的狂欢，票房纪录一天刷一纪录，粉丝们Cosplay盛装前往影院观看《星球大战:原力觉醒》，2016年，《侠盗一号》也已锁定票房前几位置，2018年那部年轻版韩·索罗Solo电影，更是吸引几乎所有适龄好莱坞小生。</p><p>美国人民对“星战”用情至深，迪士尼、卢卡斯影业也毫不吝啬，第八、第九部、外传、Solo片统统上纲上线，粉丝们!可以现在开始培养儿子女儿，从小做一个合格的<a href="http://m.so.com/s?q=%E6%98%9F%E6%88%98&amp;src=newstranscode" class="qkw">星战</a>粉!</p><p><img src="http://p31.qhimg.com/t01e5a55ebf78391987.jpg?size=550x578"></p><p>5、<a href="http://m.so.com/s?q=%E7%A6%8F%E6%96%AF&amp;src=newstranscode" class="qkw">福斯</a>“X战警”电影宇宙</p><p>“<a href="http://m.so.com/s?q=X%E6%88%98%E8%AD%A6&amp;src=newstranscode" class="qkw">X战警</a>”系列此前一直保持着两三年出一部的节奏，今年，福斯一下子拿出三部影片，再加上正在热映的<a href="http://m.so.com/s?q=%E3%80%8A%E6%AD%BB%E4%BE%8D%E3%80%8B&amp;src=newstranscode" class="qkw">《死侍》</a>票房爆火，士气大涨。</p><p>年初上映的《死侍》(左)<a href="http://m.so.com/s?q=%E8%B4%B1%E8%B4%B1%E6%83%B9%E4%BA%BA%E7%88%B1&amp;src=newstranscode" class="qkw">贱贱惹人爱</a>，暑期档又将迎来《天启》(右)，10月还有钱老板版《牌皇》，福斯占据了今年一整年的讨论热度。(本文原载于看电影APP，观看更多内容请搜索“看电影杂志”下载)</p><p>眼见着“X战警”成员们一批批换血，最经典成员“金刚狼”休·杰克曼也即将站完最后一班岗离开，福斯很可能推出全新“X战警”系列，不过成行与否，还要看看新秀们的表现。</p><p><img src="http://p34.qhimg.com/t01986941ce6aa5ae39.jpg?size=550x590"></p><p class="img-title">6、怪兽电影宇宙</p><p>别人家构筑超级英雄宇宙，传奇独辟蹊径，打造“怪兽电影宇宙”，尽管目前宇宙成员暂时仅招募了金刚、哥斯拉寥寥几位，但不久后，当宇宙成型，拉顿、魔斯拉、基多拉等知名怪兽均有望亮相。</p><p>怪兽吸睛，明星吸粉，两者结合更是无敌。《哥斯拉》里的亚伦·泰勒-约翰逊、<a href="http://m.so.com/s?q=%E4%BC%8A%E4%B8%BD%E8%8E%8E%E7%99%BD%C2%B7%E5%A5%A5%E5%B0%94%E6%A3%AE&amp;src=newstranscode" class="qkw">伊丽莎白·奥尔森</a>两位漫威家“双胞胎”、《金刚:骷髅岛》里更有汤姆·希德勒斯顿，看看这些当红炸子鸡被怪兽们狠虐，想想还有点小激动。</p><p><img src="http://p33.qhimg.com/t01b308ca06d65489c0.jpg?size=550x348"></p><p class="img-title">7、“速度与激情”电影宇宙</p><p>2月初，范·迪塞尔Ins放出新三部曲定档时间，开启系列新征程。“速激”系列上映以来，一直是赛车题材类型片中的龙头老大，每个角色都像是老朋友般陪伴着我们，所以保罗离去，所有人心伤不能自控。“速激”系列辗转美国、日本，不断增加新成员，魅力反派也个个出挑。</p><p>此前更有消息称，片方欲为道恩·强森等拍摄Solo影片，拓展“速激”宇宙，还有最新传闻，查理兹·塞隆有望加盟该系列，出演大反派。</p><p><img src="http://p32.qhimg.com/t01f11fd40cf195b6b1.jpg?size=550x524"></p><p>8、“<a href="http://m.so.com/s?q=%E6%98%9F%E9%99%85%E8%BF%B7%E8%88%AA&amp;src=newstranscode" class="qkw">星际迷航</a>”电影宇宙</p><p>2016年系老牌科幻“星际迷航”系列的50周年纪念，此前“星际”系列便电视剧、电影、动画多管齐下，自成体系，舰长与史波克的万年CP，也从原初系列，延续至今。</p><p><a href="http://m.so.com/s?q=%E6%9E%97%E8%AF%A3%E5%BD%AC&amp;src=newstranscode" class="qkw">林诣彬</a>接下J·J·艾布拉姆斯导筒，继续完成星际迷航新航程，但粉丝们微微有些担心此前多执导商业片的林诣彬是否能出色完成任务</p><p>此前有知情人士透露，克里斯·派恩和扎克瑞·昆图第三部片酬上涨，而作为提薪条件，派拉蒙要求两人继续加盟《星际迷航4》，该风声虽未得到官方确认，但成行可能性极大。</p><p><img src="http://p31.qhimg.com/t01be30f85a184b35be.jpg?size=550x320"></p><p class="img-title">9、“刺客信条”电影宇宙</p><p>育碧旗下人气游戏改编，电影在游戏基础上引入全新故事情节，法鲨角色卡勒姆·林奇正是在游戏同一次元中创造出的新角色。</p><p><a href="http://m.so.com/s?q=%E3%80%8A%E5%88%BA%E5%AE%A2%E4%BF%A1%E6%9D%A1%E3%80%8B&amp;src=newstranscode" class="qkw">《刺客信条》</a>同样具有超长时间轴，卡勒姆作为刺客后代，被解锁遗传记忆，重温了祖先的伟大冒险，习得高超本领，将在现世对抗圣殿骑士团。</p><p>此番电影可说只汲取了游戏海洋中的几滴水滴，真正庞大复杂的游戏故事仍未被开发，“刺客”这一独特的角色设定，也能填补如今大红电影宇宙中的空档。</p><p><img src="http://p32.qhimg.com/t0119382cff3b07dd68.jpg?size=550x260"></p><p class="img-title">10、“魔兽世界”电影宇宙</p><p>暴雪旗下同名游戏改编电影，影片从传出开拍到如今即将上映历经十年之久，将游戏中粗暴却有细节多多的人物还原最具难度，工业光魔全程负责影片特效。</p><p>作为80后、90后最熟悉的游戏，暴雪在开发之初便已将“魔兽”宇宙体系规划得十分完整，各种传说、职业种族、大陆都可供片方好好琢磨提取出电影故事。</p><p>《魔兽》与其他宇宙的更大不同，在于基数惊人的游戏迷们，当年联机打游戏的伙伴们，这回可以结伴去电影院，重温部落与联盟之争。</p><p><img src="http://p31.qhimg.com/t0182feef07b08c1402.jpg?size=550x264"></p><p>(责编: 荔枝)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://cnews.chinadaily.com.cn/2016-03/03/content_23721762.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='5c17e12e7afab2585969b8956c25547b'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>漫威电影宇宙</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%BC%AB%E5%A8%81%E7%94%B5%E5%BD%B1%E5%AE%87%E5%AE%99&amp;pn=1&amp;pos=3&amp;m=f114707afc9bb16bf4815c0f845b32f0de31143d&amp;u=http%3A%2F%2Fcnews.chinadaily.com.cn%2F2016-03%2F03%2Fcontent_23719640.htm" data-pos="1"> 2016展望之十大<b>电影宇宙</b>:<b>漫威</b>大法好 咱也整一个 </a>   <li> <a href="/transcode?q=%E6%BC%AB%E5%A8%81%E7%94%B5%E5%BD%B1%E5%AE%87%E5%AE%99&amp;pn=1&amp;pos=4&amp;m=af58e0edaaa8bdfa27b9a4beb26ac233aa290c07&amp;u=http%3A%2F%2Fwww.gmw.cn%2Fcg%2F2016-03%2F03%2Fcontent_19151491.htm" data-pos="2"> <b>漫威</b>呼吁粉丝为洛基投票竞选<b>漫威宇宙</b>总统 </a>   <li> <a href="/transcode?q=%E6%BC%AB%E5%A8%81%E7%94%B5%E5%BD%B1%E5%AE%87%E5%AE%99&amp;pn=1&amp;pos=5&amp;m=2cc7290fcf82f9c76094d900a6d4a7b5f6dd1498&amp;u=http%3A%2F%2Fent.qq.com%2Fa%2F20160225%2F041755.htm" data-pos="3"> 《美队3》或改变<b>漫威电影宇宙</b> 结尾极具争议性 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '漫威铸建电影宇宙!星战速激DC等体系庞大' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '漫威铸建电影宇宙!星战速激DC等体系庞大'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";