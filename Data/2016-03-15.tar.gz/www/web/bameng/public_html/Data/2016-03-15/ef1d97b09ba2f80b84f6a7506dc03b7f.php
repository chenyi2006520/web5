s:17405:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>左晔:用“互联网+”加速公用事业的市场化改革- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">左晔:用“互联网+”加速公用事业的市场化改革</h1> <p id="source-and-time"><span id=source>中国青年网</span><time id=time>2016-03-09 17:46:21</time></p> </header>  <div id="news-body"><p><a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E7%BB%8F%E6%B5%8E%E7%BD%91&amp;src=newstranscode" class="qkw">中国经济网</a>北京3月9日讯 今日，<a href="http://m.so.com/s?q=%E5%85%A8%E5%9B%BD%E6%94%BF%E5%8D%8F&amp;src=newstranscode" class="qkw">全国政协</a>委员、天津市工商联副主席、天津赛恩投资集团董事长左晔做客“聚焦2016<a href="http://m.so.com/s?q=%E4%B8%A4%E4%BC%9A&amp;src=newstranscode" class="qkw">两会</a>--中经在线访谈特别节目”，深入解读了“互联网+”时代的<a href="http://m.so.com/s?q=%E5%85%AC%E7%94%A8%E4%BA%8B%E4%B8%9A&amp;src=newstranscode" class="qkw">公用事业</a>改革进程。</p><p>左晔委员指出，公用事业改革目前存在市场化程度低、改革进程较慢、管理意识僵化等问题，他认为公用事业应当按照企业的发展规律办事，积极使用“互联网+”的技术手段和服务意识，让公用事业提高效率、降低成本，从而和公益性、服务性进行互补，让百姓满意，让地方财政减轻负担。 &gt;&gt;点击进入专题</p><p><img src="http://p33.qhimg.com/t01ac2eff87b401f2a8.jpg?size=550x367"></p><p>全国政协委员、天津市工商联副主席、天津赛恩投资集团董事长左晔。中国经济网记者裴小阁摄</p><p>左晔委员介绍了我国公用事业目前的现状，他指出像<a href="http://m.so.com/s?q=%E8%87%AA%E6%9D%A5%E6%B0%B4%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">自来水公司</a>、燃气公司、热力公司这样的公共事业部门，许多都是微利甚至亏损，在日常经营管理中效率比较低，成本居高不下，市场化进程也落后于其他经济领域。“公益性不等于亏损性，不能说一句话遮百丑。”</p><p>对于公用事业改革落后的原因，左晔委员指出，首先是公用事业部门的管理思想比较僵化，管理者不是企业化的思维。“公用事业部门改革不是技术的问题，是思想的问题，你想不想主动变革的问题。最重要的是管理班子的思想意识要跟上。”他说道。</p><p>左晔委员在访谈中谈到，“一个<a href="http://m.so.com/s?q=%E7%87%83%E6%B0%94%E9%9B%86%E5%9B%A2&amp;src=newstranscode" class="qkw">燃气集团</a>有的城市一万多个职工，每年要亏损多少亿，这实在说不过去。反过来有一个很奇怪的现象，整体在亏损，但是日子过得还不错，收入并不低。老百姓常说的庙穷和尚富，这是很不正常的。深化改革走到今天，这个问题无论是要思考和关心的，不可能公用事业总让地区财政补贴你。”</p><p>其次是公用事业没有形成科学的价格形成机制，在服务方面仍需改进。左晔委员指出，目前如水电、燃气的价格一般采取听证机制，相对垄断的现象没有改变，并不是完全贴近市场的价格，也没有贴近百姓的服务，跟其他行业相比仍有较大差距。</p><p>因此，左晔委员表示，放开民间资本进入、理顺价格机制、进行市场化改革已经成为公用事业领域的不二选择。“通过市场化的改革不但可以体现公用事业的公益属性，同时也能体现企业的经济性。”</p><p>在放开民间资本进入方面，左晔委员指出，目前我国有的城市和地区已经引进资本参与到公共事业领域。“据我了解，燃气供应有200多个城市引入企业资本，形成51:49这样的合作比例，这是贴近市场的企业化改革。这些年的经验看，并没有因为企业化运作就形成了新的垄断，特别是所谓价格垄断。可见通过企业化的运作，通过高科技的技术和产品的注入和使用，包括理顺价格机制，老百姓满意度还是提高了。公用事业服务老百姓，其实更体现了社会效应。”</p><p>而在技术手段层面，左晔委员特别强调，公用事业部门信息化程度和其他行业有比较大的差距。在公用事业四大能源当中，电力的信息化程度、自动化程度最好，但是水务、燃气、热力信息化程度相对滞后。</p><p>他指出，“互联网+”将给公用事业提升服务带来技术便利。“比如购水、购气，以前方式是收费员敲你家门，计量、抄收、服务几个环节要投入很大的人力，而使用‘互联网+’服务，任何时间、地点不受限制，通过手机APP就可以完成。”</p><p>另外，如<a href="http://m.so.com/s?q=%E6%99%BA%E6%85%A7%E6%B0%B4%E5%8A%A1&amp;src=newstranscode" class="qkw">智慧水务</a>、智慧城市所采用的“互联网+”方式，不是简单使用新的计量方式，而是从计量到传输、收费，整个水务的管理运营是整套的软硬件解决方案。左晔委员表示，“互联网+”让公用事业能够大大降低成本、提高效率，把提高的效率和降低的成本和公益性、服务性进行互补，让百姓满意，让地方财政减轻负担。</p><p>在理顺价格机制方面，左晔委员表示，公用事业的价格体系首先要让老百姓明白，合理的市场价格是什么样。“<a href="http://m.so.com/s?q=%E5%8D%97%E6%B0%B4%E5%8C%97%E8%B0%83&amp;src=newstranscode" class="qkw">南水北调</a>到北京，真正贴近市场的民用水价格是40元一吨，卖40元一吨是不可能的，但是我们可以推行阶梯水价，推动农业用水的精准灌溉，来弥补价格上的缺失。”</p><p>而在市场化改革方面，左晔委员提出，政府、民众应该给公用事业外部推力，加大竞争强度，改变公共事业自然垄断属性带来的僵化管理现状。“没有外力推动，仅仅靠某一个公共事业部门的领导班子想事、干事的意识不够，我希望是全行业的合力，这对供给侧改革贡献非常大。”</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://finance.youth.cn/finance_jsxw/201603/t20160309_7724792.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='efc538107f211f0d044a5a96b0fc3c8e'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>公用事业</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%85%AC%E7%94%A8%E4%BA%8B%E4%B8%9A&amp;pn=1&amp;pos=5&amp;m=3d6a2ee560725213cb6576ec5e2464671bbfc280&amp;u=http%3A%2F%2Ffinance.qq.com%2Fa%2F20160314%2F044100.htm" data-pos="1"> <b>公用事业</b>行业周报:长江经济带生态环境修复是继"土十条"之后关注热点 </a>   <li> <a href="/transcode?q=%E5%85%AC%E7%94%A8%E4%BA%8B%E4%B8%9A&amp;pn=1&amp;pos=6&amp;m=a9659c265f2c9ee3ea15b0e6348b246246ce5249&amp;u=http%3A%2F%2Fjiangsu.china.com.cn%2Fhtml%2F2016%2Ftjnews_0312%2F4701507.html" data-pos="2"> 左晔委员: "互联网+"推进城市<b>公用事业</b>改革 </a>   <li> <a href="/transcode?q=%E5%85%AC%E7%94%A8%E4%BA%8B%E4%B8%9A&amp;pn=1&amp;pos=7&amp;m=444deee61cb7b34a48e990004b71ada2e6ddad20&amp;u=http%3A%2F%2Fwww.cs.com.cn%2Fssgs%2Fhyfx%2F201603%2Ft20160314_4923869.html" data-pos="3"> <b>公用事业</b>行业周报:投资是稳增长驾辕之马 关注市政领域环保公司 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '左晔:用“互联网+”加速公用事业的市场化改革' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '左晔:用“互联网+”加速公用事业的市场化改革'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";