s:15624:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>苍井优以往男朋友照片曝光 权志龙告白苍井优 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">苍井优以往男朋友照片曝光 权志龙告白苍井优 </h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-12 17:59:58</time></p> </header>  <div id="news-body"><p><img src="http://p32.qhimg.com/t017cc15989630f732c.jpg?size=437x314"></p><p><a href="http://m.so.com/s?q=%E8%8B%8D%E4%BA%95%E4%BC%98&amp;src=newstranscode" class="qkw">苍井优</a>历任男友大盘点 <a href="http://m.so.com/s?q=%E6%9D%83%E5%BF%97%E9%BE%99&amp;src=newstranscode" class="qkw">权志龙</a>曾当众告白</p><p>日本女星苍井优的绯闻自出道以来一直没有断过，随着苍井优的知名度爆炸，她的的绯闻也成为媒体与粉丝们关注的焦点。那么，苍井优共有多少个男友呢?下面我们就一起来看看。</p><p><img src="http://p32.qhimg.com/t01bd88828823d10f32.jpg?size=413x314"></p><p>苍井优与<a href="http://m.so.com/s?q=v6&amp;src=newstranscode" class="qkw">v6</a>冈田准一两人是在2008年相恋，<a href="http://m.so.com/s?q=%E5%86%88%E7%94%B0%E5%87%86%E4%B8%80&amp;src=newstranscode" class="qkw">冈田准一</a>是日本艺能界着名男性偶像、演员及歌手。1995年通过天才少年中<a href="http://m.so.com/s?q=%E6%9D%B0%E5%B0%BC%E6%96%AF&amp;src=newstranscode" class="qkw">杰尼斯</a>预备校单元而进入<a href="http://m.so.com/s?q=%E6%9D%B0%E5%B0%BC%E6%96%AF%E4%BA%8B%E5%8A%A1%E6%89%80&amp;src=newstranscode" class="qkw">杰尼斯事务所</a>。</p><p>苍井优与冈田准一的恋情是在2010年春宣告结束，早年有报道称两人的恋情告吹最要是因为冈田准一移情别恋所致，不过后来网上又曝出该消息不实，实际上是因苍井优太专注事业忽略<a href="http://m.so.com/s?q=%E7%BB%8F%E8%90%A5%E7%88%B1%E6%83%85&amp;src=newstranscode" class="qkw">经营爱情</a>，最终导致这段感情的破灭。</p><p><img src="http://p31.qhimg.com/t01207746447ec13d20.jpg?size=450x314"></p><p>2010年，苍井再与共演大河剧<a href="http://m.so.com/s?q=%E3%80%8A%E9%BE%99%E9%A9%AC%E4%BC%A0%E3%80%8B&amp;src=newstranscode" class="qkw">《龙马传》</a>的大森南朋热恋，两人相差13岁。<a href="http://m.so.com/s?q=%E5%A4%A7%E6%A3%AE%E5%8D%97%E6%9C%8B&amp;src=newstranscode" class="qkw">大森南朋</a>是日本着名舞蹈家麿赤儿的次子。是日本大众所熟悉的演技派男星，参演<a href="http://m.so.com/s?q=%E3%80%8A%E6%9D%80%E6%89%8B%E9%98%BF%E4%B8%80%E3%80%8B&amp;src=newstranscode" class="qkw">《杀手阿一》</a>、《vaibrata》等影视作品。</p><p>苍井优与大森南朋在相恋一年后，于2011年7月已正式分手。据相关人士透露，开始两人的感情早就开始产生分歧了。交往之初大森<a href="http://m.so.com/s?q=%E5%8D%97%E9%B9%8F&amp;src=newstranscode" class="qkw">南鹏</a>看起来是对苍井优投入了很多热情，但原本他就是那种朋友如手足女人如衣服的类型。比起跟苍井优相处更喜欢去跟朋友喝酒，两人的争吵永无止尽。</p><p>2012年5月，苍井优和年长她11岁的男演员<a href="http://m.so.com/s?q=%E9%93%83%E6%9C%A8%E6%B5%A9%E4%BB%8B&amp;src=newstranscode" class="qkw">铃木浩介</a>相恋，两人因合作舞台剧而认识，之后相恋。</p><p>原本已经传出有计划步入礼堂的苍井优与铃木浩介在2013年3月宣告分手，有报道称苍井优突然告诉铃木浩介，自己有了另外喜欢的人，单方面提出分手。但事后苍井优则表示自己没有新恋人，因此惹来网友诸多猜测。</p><p>有媒体报道称，苍井优与铃木浩介分手就是因为苍井优恋上了小她五岁的<a href="http://m.so.com/s?q=%E4%B8%89%E6%B5%A6%E6%98%A5%E9%A9%AC&amp;src=newstranscode" class="qkw">三浦春马</a>，苍井优，还特意搬家和对方住在同一栋公寓，多次被当地居民目击早上散步约会，关系亲密。据爆料称，苍井优可能对年长男子有心理阴影，不能怪她喜新厌旧。</p><p>不过对于这段绯闻恋情，苍井优与三浦春马两人均没有在媒体面前公开承认过，三浦春马事务所对外表示，两人私下确实有来往，但仅仅只是好朋友。</p><p>苍井优是日本小清新范代表女星，就连韩国歌手权志龙也曾公开对其表白，说苍井优是自己的理想型女生，因此让不少人误以为苍井优权志龙是情侣关系，其实两人没有什么关系的。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.taihuwang.com/mingxing/47065.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='aee85c6e2ae34c66fd082c0feb738bb8'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>铃木浩介</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%93%83%E6%9C%A8%E6%B5%A9%E4%BB%8B&amp;pn=1&amp;pos=2&amp;m=cf7d76bc63f4713b455da62e695126d8077f5c9b&amp;u=http%3A%2F%2Fent.ce.cn%2Fnews%2F201602%2F27%2Ft20160227_9139241.shtml" data-pos="1"> 北川景子首演松本清张作品 穿和服美艳动人 </a>   <li> <a href="/transcode?q=%E9%93%83%E6%9C%A8%E6%B5%A9%E4%BB%8B&amp;pn=1&amp;pos=3&amp;m=0f92cef7f16ee1a9fb5f06a869096fd6863a211a&amp;u=http%3A%2F%2Fnews.china.com.cn%2Flive%2F2016-01%2F31%2Fcontent_35131214.htm" data-pos="2"> 北川景子接拍松本清张《黑色树海》 </a>   <li> <a href="/transcode?q=%E9%93%83%E6%9C%A8%E6%B5%A9%E4%BB%8B&amp;pn=1&amp;pos=4&amp;m=3e5012d54a9a5d3667c7d1afcee7c1a0066ac22f&amp;u=http%3A%2F%2Fgb.cri.cn%2F27564%2F2015%2F06%2F23%2F3465s5005690.htm" data-pos="3"> 2015夏季日剧前瞻 死亡笔记等漫改剧众多 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '苍井优以往男朋友照片曝光 权志龙告白苍井优 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '苍井优以往男朋友照片曝光 权志龙告白苍井优 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";