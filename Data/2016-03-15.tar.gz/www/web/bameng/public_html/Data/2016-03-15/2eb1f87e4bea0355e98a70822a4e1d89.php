s:13868:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>朝阳岩再发现摩崖石刻 为唐代安南都护真迹- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">朝阳岩再发现摩崖石刻 为唐代安南都护真迹</h1> <p id="source-and-time"><span id=source>中国网</span><time id=time>2016-03-10 10:52:07</time></p> </header>  <div id="news-body"><p><img src="http://p34.qhimg.com/t01d22d055fe26f33d8.jpg?size=401x267"></p><p><a href="http://m.so.com/s?q=%E6%9C%9D%E9%98%B3%E5%B2%A9&amp;src=newstranscode" class="qkw">朝阳岩</a>摩崖石刻来源网络</p><p>记者从湖南永州市<a href="http://m.so.com/s?q=%E9%9B%B6%E9%99%B5%E5%8C%BA&amp;src=newstranscode" class="qkw">零陵区</a>文物部门获悉，湖南科技学院教授<a href="http://m.so.com/s?q=%E5%BC%A0%E4%BA%AC%E5%8D%8E&amp;src=newstranscode" class="qkw">张京华</a>等专家近日通过反复考证后认定，在永州市零陵区朝阳岩新发现的一处<a href="http://m.so.com/s?q=%E6%91%A9%E5%B4%96%E7%9F%B3%E5%88%BB&amp;src=newstranscode" class="qkw">摩崖石刻</a>，为唐代大历十三年<a href="http://m.so.com/s?q=%E5%AE%89%E5%8D%97&amp;src=newstranscode" class="qkw">安南</a>都护张舟的真迹，这也是朝阳岩被发现的最早的摩崖石刻。至此，朝阳岩新近发现的摩崖石刻达到36处，朝阳岩的摩崖石刻总数增至150处。</p><p>朝阳岩摩崖石刻，位于永州市零陵城区大西门河对岸的朝阳岩岩洞内外及周围，自唐、宋、元、明、清及民国以来历代名人石刻星罗棋布。朝阳岩东邻湘江上游潇水，奇石遍布，岩洞深幽。唐代文学家、政治家，时任道州刺史的<a href="http://m.so.com/s?q=%E5%85%83%E7%BB%93&amp;src=newstranscode" class="qkw">元结</a>乘舟路过此地，将其命名为“朝阳岩”，并写下“<a href="http://m.so.com/s?q=%E6%9C%9D%E9%98%B3%E5%B2%A9%E4%B8%8B%E6%B9%98%E6%B0%B4%E6%B7%B1&amp;src=newstranscode" class="qkw">朝阳岩下湘水深</a>，朝阳洞口寒泉清。<a href="http://m.so.com/s?q=%E9%9B%B6%E9%99%B5%E5%9F%8E%E9%83%AD%E5%A4%B9%E6%B9%98%E5%B2%B8&amp;src=newstranscode" class="qkw">零陵城郭夹湘岸</a>，岩洞幽奇当郡城”等诗句。之后，历代文人、书法家柳宗元、黄庭坚、何绍基等在这里留下大量墨宝。</p><p>朝阳岩洞口还有清湖南巡抚吴大澄题刻的石碑一块，右侧石壁有广西巡抚林绍年诗刻。清咸丰、同治年间，时任永州知府的<a href="http://m.so.com/s?q=%E6%9D%A8%E7%BF%B0&amp;src=newstranscode" class="qkw">杨翰</a>，于其东侧石上补刻元结《朝阳岩铭》及《游朝阳岩诗》，字为篆体，由当时书法家邓守之所书。</p><p>据永州文物处专家介绍，位于零陵城郊的朝阳岩摩崖石刻之多、之奇、之怪，在国内外均属罕见。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://jiangsu.china.com.cn/html/Culture/focus/4649341_1.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='b4723fb786edad7783f7a130b42ea083'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>杨翰</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9D%A8%E7%BF%B0&amp;pn=1&amp;pos=4&amp;m=6728bdd1bed5b53ff9deeb14eeb8462157965165&amp;u=http%3A%2F%2Fwww.tianshui.gov.cn%2Fnews%2Fzhangchuan%2F2014%2F617%2F1461782424G7AGKD998EG99EGA65EA.html" data-pos="1"> 张家川农民<b>杨翰</b>林化朽木为神奇 雕出艺术品 </a>   <li> <a href="/transcode?q=%E6%9D%A8%E7%BF%B0&amp;pn=1&amp;pos=5&amp;m=7e796ded02dff4b67e030374beb5107151fbe7d1&amp;u=http%3A%2F%2Fhunan.ifeng.com%2Fa%2F20160310%2F4352482_0.shtml" data-pos="2"> 永州朝阳岩新发现一处唐代真迹摩崖石刻 </a>   <li> <a href="/transcode?q=%E6%9D%A8%E7%BF%B0&amp;pn=1&amp;pos=6&amp;m=833cec5862bc5ceaf3e2c48ccb8b657e69da4953&amp;u=http%3A%2F%2Fnews.sina.com.cn%2Fc%2Fnd%2F2016-03-09%2Fdoc-ifxqaffy3792596.shtml" data-pos="3"> 湖南永州朝阳岩新发现唐代真迹摩崖石刻 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '朝阳岩再发现摩崖石刻 为唐代安南都护真迹' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '朝阳岩再发现摩崖石刻 为唐代安南都护真迹'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";