s:26634:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>香港铜锣湾书店老板非法贩书4000册 被押回再审 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">香港铜锣湾书店老板非法贩书4000册 被押回再审 </h1> <p id="source-and-time"><span id=source></span><time id=time>2016-02-29 09:14:08</time></p> </header>  <div id="news-body"><p>香港<a href="http://m.so.com/s?q=%E4%B9%A6%E5%BA%97%E8%80%81%E6%9D%BF&amp;src=newstranscode" class="qkw">书店老板</a>失踪案再起波澜。车祸肇事潜逃11年后，变身书商赚得千万身家的香港巨流传媒有限公司老板桂敏海，于2015年10月回到中国向公安机关投案自首。但在收监期间，他被发现另涉非法经营罪的线索，被公安机关解回再审。【<a href="http://m.so.com/s?q=%E9%93%9C%E9%94%A3%E6%B9%BE&amp;src=newstranscode" class="qkw">铜锣湾</a>书店事件始末】</p><p><img src="http://p31.qhimg.com/t01f3870e93f60c081f.jpg?size=550x346"></p><p class="img-title">桂敏海此前接受采访的视频截图。</p><p>据澎湃新闻28日报道，近日，相关办案机关透露，桂敏海为牟取非法利益，指使公司总经理<a href="http://m.so.com/s?q=%E5%90%95%E6%B3%A2&amp;src=newstranscode" class="qkw">吕波</a>、下属铜锣湾书店店长<a href="http://m.so.com/s?q=%E6%9E%97%E8%8D%A3%E5%9F%BA&amp;src=newstranscode" class="qkw">林荣基</a>等人，在明知书籍未取得我国新闻出版部门发行许可的情况下，以对书籍封面进行伪装的方式，躲避海关检查，通过邮寄方式，大肆向境内销售，并在境内开设专用银行卡结算境内购书款。</p><p>警方还透露，2014年10月以来，铜锣湾书店共向内地380名购书人邮寄书籍4000余册，涉及全国28个省市自治区。目前，该案在进一步侦办。</p><p>伪造身份证复印件骗领中国驾照，肇事后潜逃出境</p><p>桂敏海原籍是浙江宁波，1964年5月出生，毕业于<a href="http://m.so.com/s?q=%E5%8C%97%E4%BA%AC%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">北京大学</a>，1996年取得瑞典国籍。2003年12月，在宁波经商的他<a href="http://m.so.com/s?q=%E9%86%89%E9%85%92%E9%A9%BE%E9%A9%B6&amp;src=newstranscode" class="qkw">醉酒驾驶</a>，撞死宁波一高校的女大学生沈某，因交通肇事罪被判有期徒刑二年，缓刑二年。</p><p>桂敏海供述称，在法院判决不久，民事赔偿还未全部执行完的时候，因沈某家属提出异议，强烈要求给予其严厉惩处，他害怕坐牢，于是，在2004年11月他以出境旅游的名义偷越国边境，一直潜逃在外。而此时，他还处于缓刑期间，依法不能出境。</p><p>2006年8月，法院裁定撤销对罪犯桂敏海宣告缓刑两年的执行部分，收监执行原判有期徒刑两年。随后公安机关对其展开网上追逃。</p><p>时隔11年之后，桂敏海才向警方坦陈，在当年事故处理过程中，他向有关部门隐瞒了一个事实:他在中国的驾照是骗领的，他还伪造瑞典的法律文书，掩盖这一骗领行为。</p><p>桂敏海说，他用一个伪造的身份证复印件骗领中国驾照，但驾照上的出生日期是1958年，而<a href="http://m.so.com/s?q=%E7%91%9E%E5%85%B8&amp;src=newstranscode" class="qkw">瑞典</a>护照上的出生日期是1964年。为此，在事故发生后，当交警部门要求其提供一份由瑞典官方出具的身份证明时，他为了掩盖伪造驾照的事实，用自己从瑞典带来的一种水纹纸，伪造了一份瑞典西哥特兰省警察局出具的身份证明。他还编造了两个警官的名字，并伪造了他们的签名。</p><p>“这些事情都是违反中国法律的，也是一种罪上加罪的行为，我对此悔恨不已。”桂敏海说。</p><p>明知未取得许可，仍向内地大量销售书籍</p><p>桂敏海潜逃出境后，辗转到香港生活。据其供述称，他从一个偶然的机会开始从事书籍编纂和出版工作，2012年，他和别人合伙成立香港巨流传媒有限公司，从事书籍发行工作，销售的对象主要是中国内地人士。</p><p>2014年，他收购了位于<a href="http://m.so.com/s?q=%E9%A6%99%E6%B8%AF&amp;src=newstranscode" class="qkw">香港</a>闹市区的铜锣湾书店，并返聘原店主林荣基(男，1955年12月生，香港人)为店长。“收购铜锣湾书店后，通过网上邮购的方式，将未经许可的书籍销往中国内地。”</p><p>警方透露，正是在老板桂敏海的授意下，林荣基、吕波(男，1969年2月生，原籍北京，少时移民香港)、<a href="http://m.so.com/s?q=%E5%BC%A0%E5%BF%97%E5%B9%B3&amp;src=newstranscode" class="qkw">张志平</a>(男，1983年5月生，原籍东莞，1999年移居香港)三员工“各司其职”，向内地销售未经许可的书籍。仅2014年10月以来，他们就向内地380名购书人邮寄书籍达4000余册，涉及全国28个省市自治区。</p><p>其中，林荣基作为下属铜锣湾书店店长，负责书店实体销售和网络销售，并负责将书籍伪装后邮寄至境内;吕波作为巨流公司股东兼总经理，负责书籍发行、销售等工作，参与实施将书籍向内地发行;张志平作为巨流公司总经理助理，协助实施将书籍向内地发行。</p><p><img src="http://p35.qhimg.com/t01eda85142cde143f7.jpg?size=562x313"></p><p><img src="http://p35.qhimg.com/t01d66a3a3ed11ae8a8.jpg?size=530x217"></p><p>吕波供述称，他明知书店销往内地的书籍未取得任何许可，但为了提高公司业绩，增加收入，在桂敏海的指使下，他们大量地向内地销售。为方便内地顾客汇款，桂敏海还专门让他在内地银行开户，收取内地顾客的书款。</p><p>林荣基供述了他通过网络向内地销售书籍的流程。他说，内地顾客通过QQ跟其联系，确认书名、数量、价格后，将钱汇至巨流公司在境内开设的银行账户，巨流公司再设法将书寄到内地。“一些地方因为直接寄不好寄，我就找朋友帮我在内地转寄。巨流公司在国内还开了一个户头，国内的人把书款打进去，我确认之后，就把书邮过去。”</p><p>张志平也知道公司和书店销往内地的书籍都是未经许可的。“我还继续帮他们将这些书籍的封面伪装好，再邮寄销售到内地。”张志平供述称，他还把书款在内地提现后，带回香港。</p><p class="header">桂敏海:对非法经营行为，悔恨不已</p><p>变身书商后，虽赚得千万身家，但桂敏海内心未安定下来过。“因<a href="http://m.so.com/s?q=%E8%B4%9F%E6%A1%88%E5%9C%A8%E9%80%83&amp;src=newstranscode" class="qkw">负案在逃</a>，我不敢回家乡，无法在父母身边尽孝。我不止一次想回国自首，却始终无法鼓起勇气迈出这一步。”</p><p>2015年6月，桂敏海父亲去世，他未能回国奔丧，这促使他下定决心，回国自首。“我的母亲也80多岁了，已是风烛残年，我一直在考虑自首，想把车祸肇事这件事解决了，能够在母亲的有生之年再见她一面。”同年10月，他向公安机关投案自首。</p><p>在收监期间，公安机关发现桂敏海另有涉嫌非法经营罪的犯罪线索，将其解回再审。桂敏海对犯罪事实供认不讳。他说，其书籍销售的对象主要是内地人士，他们几经商量，通过更换书籍封面等方式，规避检查。</p><p>他忏悔道:“我现在已经深刻认识到这些方式都是严重违反中国法律的，应该受到法律的惩处，我自己也是悔恨不已。”</p><p>据悉，瑞典使领馆日前已派人对桂敏海进行了领事探视。</p><p class="header">员工:受老板教唆误入歧途</p><p>老板桂敏海被公安机关解回再审后，吕波和林荣基、张志平也因涉嫌非法经营罪，先后于2015年10月17日和2015年10月24日，在深圳、东莞被抓获。他们对自己的犯罪事实均供认不讳，还指证桂敏海涉嫌非法经营的行为。</p><p>“我所做的都是桂敏海教唆的，是桂敏海把我拖下水，走上犯罪道路。”吕波说，桂敏海一直用各种渠道销售，获利丰厚，但答应给他的分红却未兑现。张志平供称，他的非法经营活动均是桂敏海指使的。</p><p>林荣基则说，在他被桂敏海返聘为书店店长，重新掌管书店业务后，桂敏海要求他加大力度，把书往内地邮寄销售。他还说，桂敏海写的书都是胡编乱造、从网络上下载的，或从杂志上拼凑的，制造了很多谣言，对社会造成了不良的影响。</p><p>此外，据媒体此前报道，铜锣湾书店另一股东<a href="http://m.so.com/s?q=%E6%9D%8E%E6%B3%A2&amp;src=newstranscode" class="qkw">李波</a>已于去年底自愿回内地配合桂敏海案调查，指证了桂敏海涉嫌犯罪的事实。</p><p>他们也对自己的行为表示悔恨不已，希望得到宽大处理。吕波说，他深刻认识到自己的错误，保证不会再做这种非法经营行为，以后一定遵纪守法，希望对他宽大处理，让他重新开始。</p><p>60岁的林荣基自称年纪较大，身体不好，他表示已深刻认识到错误，希望给他一次机会，他不再从事书籍的非法经营活动。</p><p>张志平流下了眼泪，他请求政府考虑其家庭实际情况，给予他从轻处理的机会。“我违反了国家的法律，自愿接受法律对我的处罚。我真正的悔过了!”</p><p>办案民警表示，由于林荣基、吕波、张志平认罪态度较好，有机会获取保候审，有望在近日返回香港。</p><p class="header">铜锣湾书店事件始末</p><p class="header">去年11月</p><p>●铜锣湾书店老板桂敏海友人声称桂于10月17日离开<a href="http://m.so.com/s?q=%E6%B3%B0%E5%9B%BD&amp;src=newstranscode" class="qkw">泰国</a>芭堤雅一座公寓后便下落不明。其后，相继传出在去年10月，铜锣湾书店母公司“巨流传媒有限公司”总经理吕波及铜锣湾书店创办人林荣基在深圳失踪，而业务经理张志平在东莞失踪。</p><p class="header">去年12月30日</p><p>●铜锣湾书店股东李波在<a href="http://m.so.com/s?q=%E6%9F%B4%E6%B9%BE&amp;src=newstranscode" class="qkw">柴湾</a>仓库取书给客人后失踪。</p><p class="header">今年1月1日</p><p>●李波太太到<a href="http://m.so.com/s?q=%E5%8C%97%E8%A7%92&amp;src=newstranscode" class="qkw">北角</a>警署报案，警方将案件列作“失踪人士”，由港岛总区失踪人口调查组跟进。</p><p class="header">1月4日</p><p>●香港特首<a href="http://m.so.com/s?q=%E6%A2%81%E6%8C%AF%E8%8B%B1&amp;src=newstranscode" class="qkw">梁振英</a>主动联同署理保安局局长李家超会见媒体，表达特区政府对此事高度关注，强调根据“一国两制”的安排及基本法的规定，只有香港的执法人员有权在香港执法，不接受香港以外的执法人员在港执法。同日下午，李波妻子到警署销案，指自己已收到李波传真亲笔书函，指“我(李波)急需处理有关问题，不能让外界知道，已采取了自己的方式返回内地，配合有关方面调查”。</p><p class="header">1月5日</p><p>●外交部部长<a href="http://m.so.com/s?q=%E7%8E%8B%E6%AF%85&amp;src=newstranscode" class="qkw">王毅</a>会见到访的英国外交大臣哈蒙德后指出，根据香港基本法和中华人民共和国国籍法，李波是中国公民，“在他本人和他的家属，以及特区政府和中央政府还没有作出表态之前，各方，我看没有必要作出一些、作各种各样的无谓的猜测。”</p><p class="header">1月9日</p><p>●有媒体报道指李波的太太收到李波寄来的短视频，以及一封附有李波签名的书信，而书信内容大意与视频相同。片中李波精神饱满，坐在沙发前面，神情平静，并称今次返回内地纯属个人行为，只是有个人事务需要处理，与其他人无关。他表示，不明白为什么会有人拿这件事情来大做文章，令他和自己的家人受到很大的压力，又表示不希望再有人用他回内地这件事情来做文章，这样才是真正关心他的行为。</p><p class="header">1月10日</p><p>●反对派就李波事件发起游行抗议，有参与示威的激进组织更趁机叫嚣“港独”。</p><p class="header">1月17日</p><p>●<a href="http://m.so.com/s?q=%E4%B8%AD%E5%A4%AE%E7%94%B5%E8%A7%86%E5%8F%B0&amp;src=newstranscode" class="qkw">中央电视台</a>及新华社报道，指桂敏海因醉驾撞死少女而畏罪潜逃，最终于去年十月向公安机关投案自首。桂敏海又现身强调，回国投案自首是个人自愿的选择，不希望任何个人和机构介入或者干预，甚至进行恶意炒作。同日有媒体报道指出，李波妻子再收到李波的亲笔家书，称最近才了解桂敏海这个人很复杂，且涉及其他犯罪，更直指是被其所累，希望大家不要将其自愿回内地配合调查一事放大炒作。</p><p class="header">1月18日</p><p>●香港警方收到广东省公安厅覆函，指“经了解，李波现在内地”，并附上其本人致特区政府有关部门的信件，内容与媒体报道他在1月17日写给妻子的信相若。警方表示，已联络李波妻子，她确认该信的字迹属于李波。警方又去信广东省公安厅要求安排与李波会面，进一步了解事件。</p><p class="header">1月24日</p><p>●香港警方凌晨表示，1月23日接获李波妻子通知，表示23日下午曾与李波于内地一间宾馆会面，而李波也透过妻子将信件交给香港警方。同日，有媒体报道，信中提到李波是自愿返回内地协助调查，在内地是自由及安全的，而妻子是被人唆使故此报案，希望警方不要浪费警力调查下去。</p><p class="header">1月29日</p><p>●广东省公安厅函覆香港媒体有关铜锣湾书店股东李波的查询，指李波日前已去信香港警务处，说明“不是被绑架”，而是自愿返回内地接受调查，其在内地是自由和安全，目前没有更多消息。</p><p class="header">2月12日</p><p>●英政府向国会提交新一期<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E8%8B%B1%E8%81%94%E5%90%88%E5%A3%B0%E6%98%8E%E3%80%8B&amp;src=newstranscode" class="qkw">《中英联合声明》</a>在港实施半年报告书，声称铜锣湾书店负责人李波是“非自愿地被移送往中国大陆”，并称已接触中国最高领导层，要求李波即时返港。外交部表示，英政府发表所谓香港问题半年报告对香港事务说三道四，指手画脚，报告中一些内容对中方无理指摘，中方表示强烈不满和坚决反对。</p><p class="header">2月28日</p><p>●澎湃新闻报道，铜锣湾书店老板桂敏海去年回国为一宗车祸自首，收监期间被发现另涉非法经营罪，通过伪装书籍封面，将未获内地部门许可的书籍通过伪装封面，邮寄回内地销售，截至2014年10月，共寄出4000余册。而林荣基、吕波、张志平三名铜锣湾书店员工帮助桂非法销售，也涉非法经营罪。桂与三人对犯罪事实供认不讳。办案民警表示，由于林荣基等三人认罪态度较好，有机会获取保候审，有望在近日返港。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.qzcns.com/2016/0229/433885.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='0276fe50507f0b4beba7ea66dc5a9f84'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>铜锣湾</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%93%9C%E9%94%A3%E6%B9%BE&amp;pn=1&amp;pos=8&amp;m=b26ed255ab38502bed77d5439f66fb99e868b9fc&amp;u=http%3A%2F%2Fphtv.ifeng.com%2Fa%2F20160301%2F41557137_0.shtml" data-pos="1"> <b>铜锣湾</b>书店老板接受凤凰采访:说我"被失踪"是别有用心 </a>   <li> <a href="/transcode?q=%E9%93%9C%E9%94%A3%E6%B9%BE&amp;pn=1&amp;pos=9&amp;m=5e610f783e250cd333696a8be96ba67182f9d2cb&amp;u=http%3A%2F%2Ffinance.sina.com.cn%2Fsf%2Fnews%2F2016-02-29%2F115922117.html" data-pos="2"> 香港<b>铜锣湾</b>书店向内地邮寄禁书 3名员工被捕 </a>   <li> <a href="/transcode?q=%E9%93%9C%E9%94%A3%E6%B9%BE&amp;pn=1&amp;pos=10&amp;m=03659b85ea32a13e8ec266801479df2a44a022b3&amp;u=http%3A%2F%2Ffinance.ifeng.com%2Fa%2F20160229%2F14240876_0.shtml" data-pos="3"> 香港<b>铜锣湾</b>书店向内地邮寄禁书 3员工去年在广东被捕 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '香港铜锣湾书店老板非法贩书4000册 被押回再审 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '香港铜锣湾书店老板非法贩书4000册 被押回再审 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";