s:14720:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>electronica China2016前瞻:开拓小型化电路保护设计的新标准- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">electronica China2016前瞻:开拓小型化电路保护设计的新标准</h1> <p id="source-and-time"><span id=source>电子产品世界</span><time id=time>2016-03-10 18:31:17</time></p> </header>  <div id="news-body"><p>高可靠性、恶劣环境和品质承诺是工业、交通运输、军事/航空和医药市场的必备特性。随着电气化和数字化趋势，这些市场也在不断演变和扩张。此演变通过利用智能传感器和互联网连接，实现了能源效率、功能和安全性的持续监控。</p><p><img src="http://p33.qhimg.com/t01223fcdca294a318e.png?size=255x185"></p><p><a href="http://m.so.com/s?q=Bourns&amp;src=newstranscode" class="qkw">Bourns</a>(慕尼黑上海电子展 展位号3500)是电子零组件业界的龙头制造供货商，专注于为这些高要求市场提供电路保护、电路调节和运动控制。公司总部位于美国加州的河边市，其产品包含:传感器、电路保护解决方案、磁性零组件、微电子模块、面板控制器及电阻产品，服务产业涵盖汽车、工业、消费、通信、非关键性的生命支持医疗、音频以及其他各种市场。</p><p><img src="http://p35.qhimg.com/t01396bfd43c06845c7.jpg?size=264x243"></p><p>日前宣布在2016慕尼黑上海电子展上推出全新的PTVS-PTVS3 系列，此全新15V 双向高功率<a href="http://m.so.com/s?q=PTVS&amp;src=newstranscode" class="qkw">PTVS</a>产品能够满足直流电源及12V电池电源管理系统的保护。最新型号PTVS3-015C-TH提供双向接口保护，符合IEC 61000-4-5 8/20 μs电流浪涌标准，与传统MOV技术比较，Bourns使用先进的硅技术于PTVS产品，在浪涌发生时能有较低的嵌位电压、更稳定的效能，及更佳的可靠度。本次推出新款可提供较低工作电压的15V PTVS型号，能够满足客户对于暴露或是恶劣环境下电源保护的需求。且新器件在过温时仍能展现出色的浪涌反应-相对于25 °C，最大浪涌电流在150 °C时仍有超过70%的额定值，堪称是工程师首选。</p><p>全新薄型双极气体放电管<a href="http://m.so.com/s?q=FLAT&amp;src=newstranscode" class="qkw">FLAT</a>®GDT 2017系列，创新的扁平式的封装以及水平式的电路设计，可应用于电信与工业通讯设备、浪涌保护装置以及电路板组装，满足现今高密度、受空间限制的应用以及更加敏感的过电压保护需求。相较于一般8毫米的Bourns®气体放电管，新器件在体积上节省了75%的空间，且同样在传统8毫米气体放电管的电路板空间上，能垂直地多放置两倍数量的FLAT®GDT 2017，对电路保护设计的体积与空间节省上具有突破性的发展。</p><p>Bourns以创新研发、优异服务品质作为对客户的目标及承诺。Bourns非常重视提供卓越的服务质量，整合并有效率的解决客户疑难。未來我们仍将持续致力于人才、技术、系统、产品与服务等全方位的进步，以满足客户及市场需求。</p><p>2016慕尼黑上海电子展将吸引国内外1100余家厂商参加，本届展览规模将再次打破记录，展示面积达62,000平方米，预计有超过56,000名的行业精英和买家将共赴此次盛会。</p><p>欲了解更多展商或产品信息，请即刻登陆官网，免费观众注册:</p><p>http://www.electronicachina.com.cn/cn/visitor/register.html</p><p>3月15-17日，期待你的莅临!</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.eepw.com.cn/article/201603/288105.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='787acad11daf95e16ec90cfe2a3a1285'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>通信电路</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E9%80%9A%E4%BF%A1%E7%94%B5%E8%B7%AF&amp;pn=1&amp;pos=10&amp;m=a7ed0dc1762f973686dff8cc9204cd993516116e&amp;u=http%3A%2F%2Fwww.senn.com.cn%2Fdz%2F2016%2F03%2F08%2F123609.html" data-pos="1"> 周玉梅:集成<b>电路</b>产业要全盘规划,不能任由地方发展 </a>   <li> <a href="/transcode?q=%E9%80%9A%E4%BF%A1%E7%94%B5%E8%B7%AF&amp;pn=2&amp;pos=1&amp;m=4c53967868c258c2dcd10734e24a2e3efcfdd2ed&amp;u=http%3A%2F%2Fpaper.ce.cn%2Fjjrb%2Fhtml%2F2016-02%2F27%2Fcontent_294053.htm" data-pos="2"> 紫光集团:站到集成<b>电路</b>产业"舞台"中央 </a>   <li> <a href="/transcode?q=%E9%80%9A%E4%BF%A1%E7%94%B5%E8%B7%AF&amp;pn=2&amp;pos=2&amp;m=1bc60b953e01bb7481c34f8c0cca92a425142305&amp;u=http%3A%2F%2Fwww.eeworld.com.cn%2Fqrs%2Farticle_2016031126917.html" data-pos="3"> 解读车载AM/FM收音机<b>电路</b> </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + 'electronica China2016前瞻:开拓小型化电路保护设计的新标准' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + 'electronica China2016前瞻:开拓小型化电路保护设计的新标准'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";