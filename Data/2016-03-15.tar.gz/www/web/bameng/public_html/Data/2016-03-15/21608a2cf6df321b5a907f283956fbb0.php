s:14174:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>闽侯花果山有座猴王庙猴面龙身石刻造像罕见闽侯(图)- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">闽侯花果山有座猴王庙猴面龙身石刻造像罕见闽侯(图)</h1> <p id="source-and-time"><span id=source></span><time id=time>2016-03-13 02:46:34</time></p> </header>  <div id="news-body"><p><img src="http://p33.qhimg.com/t0187c11c948252eb0f.jpg?size=600x443"></p><p>九<a href="http://m.so.com/s?q=%E4%BB%99%E5%B2%A9&amp;src=newstranscode" class="qkw">仙岩</a>“天王宫”古庙的猴面龙身古代石刻造像。</p><p>福州新闻网3月12日讯(福州日报记者 廖云岚文/摄)昨日，喜欢远足的市民林先生带记者走进<a href="http://m.so.com/s?q=%E9%97%BD%E4%BE%AF&amp;src=newstranscode" class="qkw">闽侯</a>小箬乡尚锦村九仙岩“天王宫”古庙。这座建于明代的古庙，因为供奉的是<a href="http://m.so.com/s?q=%E9%BD%90%E5%A4%A9%E5%A4%A7%E5%9C%A3&amp;src=newstranscode" class="qkw">齐天大圣</a>，也被称为猴王庙，大殿内外两面猴面龙身的石刻造像极为罕见。</p><p>“天王宫”古庙位于尚锦村海拔730米深山顶的九<a href="http://m.so.com/s?q=%E4%BB%99%E5%B2%A9%E6%99%AF%E5%8C%BA&amp;src=newstranscode" class="qkw">仙岩景区</a>，坐西面东，前后五进。站在高处俯视，可远眺<a href="http://m.so.com/s?q=%E9%97%BD%E6%B1%9F&amp;src=newstranscode" class="qkw">闽江</a>，远山环绕间有多条瀑布飞流直下，加上庙里敬奉的是齐天大圣，不禁使人浮想联翩，仿佛身临传说中的<a href="http://m.so.com/s?q=%E8%8A%B1%E6%9E%9C%E5%B1%B1&amp;src=newstranscode" class="qkw">花果山</a>秘境。</p><p>庙前碑刻记载，明孝宗年间闽江沿线大旱，生灵涂炭。传说齐天大圣显灵，使<a href="http://m.so.com/s?q=%E5%A4%A9%E9%99%8D%E7%94%98%E9%9C%96&amp;src=newstranscode" class="qkw">天降甘霖</a>。民众摆脱灾荒后，相约在九仙岩棋盘石设坛焚香，供奉齐天大圣，引来各地上香者络绎不绝。此后，民众又在九仙岩凤冠顶建起齐天大圣庙，庙内还供奉鸦王大圣、<a href="http://m.so.com/s?q=%E9%9B%80%E7%8E%8B&amp;src=newstranscode" class="qkw">雀王</a>大圣。</p><p>记者看到，大殿内外有包括鸦王、雀王、麒麟等多面造型独特的石刻造像，其中以两面猴面龙身石刻造像最罕见。只见长长的龙身层层盘旋，头部却是亦庄亦谐的猴子模样。林先生说，庙门外石墙至今保留着记载古代信众为建庙捐献银两的刻字，这是庙宇历史悠久的证明。</p><p>林先生说，这些<a href="http://m.so.com/s?q=%E5%8F%A4%E4%BB%A3%E7%9F%B3%E5%88%BB&amp;src=newstranscode" class="qkw">古代石刻</a>造型独特古朴，有一定<a href="http://m.so.com/s?q=%E8%89%BA%E6%9C%AF%E5%92%8C%E4%BA%BA%E6%96%87&amp;src=newstranscode" class="qkw">艺术和人文</a>价值，但因为缺乏保护措施，存在严重风化问题，其中一面猴面龙身石刻有被香客踩踏痕迹，“希望有关文物部门督促管理人员加强保护。”</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.nxing.cn/article/4001389.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='434c9ef740ed57501bc38477907077b7'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>花果山</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%8A%B1%E6%9E%9C%E5%B1%B1&amp;pn=1&amp;pos=7&amp;m=52e819f9b2eaf96aca22901b57d1fc8529faa8f9&amp;u=http%3A%2F%2Fgameonline.yesky.com%2F69%2F101074069.shtml" data-pos="1"> 武神3新服<b>花果山</b>众多势力崛起,激战洛阳城! </a>   <li> <a href="/transcode?q=%E8%8A%B1%E6%9E%9C%E5%B1%B1&amp;pn=1&amp;pos=8&amp;m=1243ae59fd1d5c7d24ce7a949e40535dc2b7b06d&amp;u=http%3A%2F%2Fcq.cqnews.net%2Fcqqx%2Fhtml%2F2016-03%2F08%2Fcontent_36488512.htm" data-pos="2"> 铜梁"<b>花果山</b>"桃花李花朵朵 赏花游客纷至沓来 </a>   <li> <a href="/transcode?q=%E8%8A%B1%E6%9E%9C%E5%B1%B1&amp;pn=1&amp;pos=9&amp;m=6e39fdb59162353e67e2cacedb3e4762d92d05d1&amp;u=http%3A%2F%2Fcq.cqnews.net%2Fcqqx%2Fhtml%2F2016-03%2F09%2Fcontent_36490371.htm" data-pos="3"> 铜梁"<b>花果山</b>"桃花李花朵朵开 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '闽侯花果山有座猴王庙猴面龙身石刻造像罕见闽侯(图)' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '闽侯花果山有座猴王庙猴面龙身石刻造像罕见闽侯(图)'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";