s:23311:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>柯以柔:她是最早的网红，曾恐婚当“落跑新娘”，现运气好到连小S都羡慕(图) - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">柯以柔:她是最早的网红，曾恐婚当“落跑新娘”，现运气好到连小S都羡慕(图) </h1> <p id="source-and-time"><span id=source></span><time id=time>2016-02-29 20:53:28</time></p> </header>  <div id="news-body"><p>还记得在<a href="http://m.so.com/s?q=%E3%80%8A%E7%86%8F%E8%A1%A3%E8%8D%89%E3%80%8B&amp;src=newstranscode" class="qkw">《熏衣草》</a>里面饰演女主角以熏的同事晶晶的女生吗?现在她已经是三个孩子的妈妈了。《熏衣草》是她的处女作。当时因为她在里面只是充当一个打酱油的小配角，那时候电视剧主推的又是主角<a href="http://m.so.com/s?q=%E9%99%88%E6%80%A1%E8%93%89&amp;src=newstranscode" class="qkw">陈怡蓉</a>，所以观众对她的印象都不会太深。有不少网友说她长得不如陈怡蓉，更没有杨丞琳一样长相甜美。而她却是人生赢家哦~小编个人觉得她长得挺美的，尤其笑起来的时候眼睛很美，很甜，最主要是身材一顶一的好，和她合作过的女星很多现在状况都比不上她呢~</p><p><img src="http://p35.qhimg.com/t016b732fe5b335cd5d.jpg?size=278x230"></p><p>她叫<a href="http://m.so.com/s?q=%E6%9F%AF%E4%BB%A5%E6%9F%94&amp;src=newstranscode" class="qkw">柯以柔</a>，本名柯育婷，1979年10月3日出生于台湾省台北市。</p><p><img src="http://p33.qhimg.com/t01458a8cb2372e8d6c.jpg?size=300x233"></p><p>柯以柔从小童年就会在市场的水果摊帮爸妈卖水果，18岁时家里正式开了<a href="http://m.so.com/s?q=%E6%B0%B4%E6%9E%9C%E8%A1%8C&amp;src=newstranscode" class="qkw">水果行</a>，她不但帮爸妈顾店，也是店里的活招牌，被称为“甜蜜蜜的水果妹”。</p><p><img src="http://p34.qhimg.com/t0106ec3bb22623d5ec.jpg?size=500x350"></p><p>因一次在路上闲逛时被模特儿经纪公司的人看中，并要求留下了资料，原本以为只是骗人的，想不到的就是不久之后被通知去参加<a href="http://m.so.com/s?q=%E8%B6%85%E7%BA%A7%E6%98%9F%E6%9C%9F%E5%A4%A9&amp;src=newstranscode" class="qkw">超级星期天</a>的《徐怀钰明星脸》节目。柯以柔当时也是受宠若惊啊!</p><p><img src="http://p33.qhimg.com/t0173613962eb52de60.jpg?size=400x268"></p><p>之后以柔又报名参加了gogorock<a href="http://m.so.com/s?q=%E6%98%8E%E6%98%9F%E5%AD%A6%E5%9B%AD&amp;src=newstranscode" class="qkw">明星学园</a>‘网路美女甄选活动’，并入围了人气最高的前十名网路美女。曾在滚石唱片缔造徐怀钰、杜德伟..等成功歌手的资深唱片工作人姚凤群当时正自立门成立了‘最佳娱乐经纪公司’，从网路上发现了以柔甜美而又开朗的独特气质， 正式的为以柔经营起演艺事业。</p><p><img src="http://p33.qhimg.com/t0120bf40a40a84f120.jpg?size=320x488"></p><p>开朗<a href="http://m.so.com/s?q=%E6%B0%B4%E6%9E%9C%E5%A6%B9&amp;src=newstranscode" class="qkw">水果妹</a>赢得了学生和小朋友的支持，交大水果妹、清大水果妹的话题喧腾一时，网路上和各大新闻频道都争相报导着2位水果妹的生活，但当时，正宗的甜蜜蜜水果妹柯以柔却早已和师兄许绍洋一起在<a href="http://m.so.com/s?q=%E9%A3%9E%E7%89%9B%E7%89%A7%E5%9C%BA&amp;src=newstranscode" class="qkw">飞牛牧场</a>没日没夜赶拍三立偶像剧《熏衣草》 了。《熏衣草》播出之后，以柔亮眼的表现立刻为她自己赢得了更多的邀约，不但又再演出了八大偶像剧《新不了情》，以及民视最受学生欢迎的戏剧《超人气学园》。开朗健康的形象更受到唱片界的瞩目，华纳唱片特别邀请她担任儿童音乐“幼幼摇摇”的代言人，以柔开朗的个性也大受小朋友的欢迎，从&quot;水果妹&quot;摇身一变成为小朋友口中的&quot;水果姐姐&quot;。</p><p><img src="http://p35.qhimg.com/t0152fbae03c95aa2fd.jpg?size=260x346"></p><p>接着参演林韦君、霍建华主演的八点档连续剧<a href="http://m.so.com/s?q=%E3%80%8A%E5%8D%83%E9%87%91%E7%99%BE%E5%88%86%E7%99%BE%E3%80%8B&amp;src=newstranscode" class="qkw">《千金百分百》</a>，这也是她的首部八点档作品。</p><p><img src="http://p33.qhimg.com/t01b49d450264cd55fe.jpg?size=280x330"></p><p>在江宏恩、江祖平主演的长篇连续剧<a href="http://m.so.com/s?q=%E3%80%8A%E5%86%8D%E8%A7%81%E9%98%BF%E9%83%8E%E3%80%8B&amp;src=newstranscode" class="qkw">《再见阿郎》</a>中她也饰演过小燕。</p><p>不过最厉害的就是柯以柔搭档李佳豫主持台湾三立都会台晚间十点线世界地理杂志系列节目<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%AD%E5%9B%BD%E9%82%A3%E4%B9%88%E5%A4%A7%E3%80%8B&amp;src=newstranscode" class="qkw">《中国那么大》</a>和《世界那么大》。那时候很多人都会看这个节目，只是那时候并没有多少人会记住她的名字。</p><p>2006年出版旅游书籍<a href="http://m.so.com/s?q=%E3%80%8A%E4%B8%96%E7%95%8C%E9%82%A3%E4%B9%88%E5%A4%A7-%E6%9F%AF%E4%BB%A5%E6%9F%94%E3%80%81%E5%B0%8F%E8%B1%AB%E5%84%BF%E7%9A%84%E6%97%85%E8%A1%8C%E4%BA%A4%E6%8D%A2%E6%97%A5%E8%AE%B0%E3%80%8B&amp;src=newstranscode" class="qkw">《世界那么大-柯以柔、小豫儿的旅行交换日记》</a>。</p><p><img src="http://p32.qhimg.com/t01624918c1076aa621.jpg?size=450x340"></p><p>隔一年主持台湾三立电视公司节目部制作台湾地理杂志的系列节目之一<a href="http://m.so.com/s?q=%E3%80%8A%E5%87%A4%E4%B8%AD%E5%A5%87%E7%BC%98%E3%80%8B&amp;src=newstranscode" class="qkw">《凤中奇缘》</a>。次年出版美食类书籍<a href="http://m.so.com/s?q=%E3%80%8A%E5%8F%AB%E6%88%91%E7%BE%8E%E9%A3%9F%E5%A4%A9%E5%90%8E%E3%80%8B&amp;src=newstranscode" class="qkw">《叫我美食天后》</a>。</p><p><img src="http://p31.qhimg.com/t0162d12934d691f929.jpg?size=522x655"></p><p>圈内的人对她的评价是:“柯以柔在圈内以乖巧出名，认识4年的电视台伙伴淑芬形容她“天生少根筋”，在好友们眼中，柯以柔是演艺圈边缘人，去夜店的次数屈指可数，是标准宅女。”</p><p>柯以柔自称“台湾好媳|“，代表她能“入得厨房，出得厅堂”。外型走亲切路线的柯以柔，除了烧得一手好菜，“斤斤计较”的买菜本领，连前往拍照的摄影师都点头服输，她能一边分析着卖场和传统市场利弊优缺，一边碎碎念怎样挑里肌肉，一付精明的主妇模样。</p><p><img src="http://p33.qhimg.com/t01f2af038599af5c16.jpg?size=640x359"></p><p>不过这完全是因柯以柔的父母在汐止中正市场卖水果，在菜市场长大的水果妹，常常半夜跟父母去批发，天未亮就帮忙摆摊，从小学习察言观色，练就出一身论斤论两的叫卖好本领。</p><p class="header">她曾因为恐婚当作”落跑“新娘</p><p>柯以柔08年，与交往两年，论及婚嫁的<a href="http://m.so.com/s?q=%E7%BE%8E%E5%9B%BD%E7%94%B7%E5%8F%8B&amp;src=newstranscode" class="qkw">美国男友</a>J君分手了。她坦言自己是“落跑新娘”，原因是她恐婚，害J君白花了30多万买婚戒，J君对她很不谅解，这1个月光是喝闷酒就喝掉21万。不过，面对人生大事，柯以柔不得不理智谨慎。她与J君是小学同学，J君5年级时全家移民美国，两人10多年没联络，没想到两年前同学会上重逢竟然擦出爱火。</p><p><img src="http://p32.qhimg.com/t019c89f529fcd0696f.jpg?size=465x648"></p><p>圈内曾传柯以柔的男友是企业小开，她一路低调呵护，唯一一次差点曝光是上《康熙来》时被小S逮到照片与简讯，她昨终于透露，“他在威达电美国分公司上班，是工业计算机工程师。”</p><p>两人交往以来一直都很甜蜜。柯以柔表示，J君会制造意外的惊喜，像有一次她去南非的摩里西斯出外景，J君竟然从网络上订当地的<a href="http://m.so.com/s?q=%E6%B0%B4%E6%9E%9C%E8%8A%B1%E7%AF%AE&amp;src=newstranscode" class="qkw">水果花篮</a>送到饭店给她，且双方家长对这段恋情都很支持，两年下来，J君已主动改口叫她“老婆”，小两口面临“婚不婚”这道关卡。柯以柔说:“真正谈到婚姻，我才突然觉得我跟他一直是远距离恋爱，从来没有实际地真正相处过。“他俩平均每3个月见一次面，相处时间最多两周，尽管对方因为柯以柔放不下父母，不愿<a href="http://m.so.com/s?q=%E8%BF%9C%E5%AB%81%E7%BE%8E%E5%9B%BD&amp;src=newstranscode" class="qkw">远嫁美国</a>，已向公司申请要调回台湾任务，柯以柔依然却步，她昨说:“我觉得自己不能承受他放弃一切回来台湾这种压力，而且毕竟是在东、西不同的环境长大，价值观也存在差异。”</p><p><img src="http://p34.qhimg.com/t01a8f3724257831d61.jpg?size=640x352"></p><p>最后柯以柔主动提分手，惨的是对方连婚戒都已买好，受伤的心情可想而知。柯以柔自己也好不到哪去，她苦笑说，幸好最近因为出书，并接下<a href="http://m.so.com/s?q=%E4%B8%89%E7%AB%8B&amp;src=newstranscode" class="qkw">三立</a>美食节目《凤中奇缘》，忙碌的任务刚好可以让她没心思多想，麻痹失恋伤痛。</p><p><img src="http://p31.qhimg.com/t01775f3edefed21943.jpg?size=510x708"></p><p>水果妹最终还是找到了她的Mr.Riaht</p><p>柯以柔2010年与任职上海公关公司的D君分手，之后与日本料理店主厨<a href="http://m.so.com/s?q=%E9%83%AD%E5%AE%97%E5%9D%A4&amp;src=newstranscode" class="qkw">郭宗坤</a>交往。2011年4月24日，柯以柔与男友去试婚纱，小两口很甜蜜，二人见被记者发现亦大方受访，男方被要求重现求婚戏码，他立刻甜蜜宣誓说:“我希望能在往后的日子中，能够一起走过。”让她感动飙泪。柯以柔解释，当初透过厨师明星詹姆士认识郭宗坤，两人认识近5年，因为她身边总不乏追求者，他只能偷偷暗恋，直到2010年她挥别旧爱，他才展开热烈追求，两人热恋半年。之后，他特地安排日本“求婚之旅”，让她很感动。6月18日将举行婚宴，对于突然闪婚，她否认已怀孕:“我没有<a href="http://m.so.com/s?q=%E6%80%80%E5%AD%95&amp;src=newstranscode" class="qkw">怀孕</a>，很怕大家多作联想，连婚纱都挑合身的，之前还刻意瘦身8公斤。”</p><p><img src="http://p31.qhimg.com/t0191fd31b080346ac4.jpg?size=550x390"></p><p>婚后四年顺产三胎，网友都称她“太适合生小孩”</p><p>她怀孕期间都会普及一些育儿的知识与网友们分享，比如哺乳什么样的姿势更好。当然她曾经发过一张怀孕照引起争议遭骂“se情”，不过还是有很多粉丝站在她那一边帮她说话。</p><p><img src="http://p31.qhimg.com/t0112a46515cbce2d98.jpg?size=550x361"></p><p>当她怀第三胎的时候网友都很为他们开心，粉丝留言“恭喜恭喜!小幸福呀!情商智商都高的女人，感觉在台湾女明星里过得幸福的一个。”但也有人说她“哇!你这要跟屈家(屈中恒)四姐妹PK的节奏呀!”</p><p><img src="http://p34.qhimg.com/t0127d9e5030515cec4.jpg?size=500x333"></p><p>当她怀孕34周的时候，她说自己只胖了15斤，粉丝惊叹柯以柔根本“养胎不养肉”，甚至大赞她“太适合生小孩了”，纷纷好奇求问保持身材的秘方。事实上，柯以柔平时就很注重维护体态，虽然生完第2胎后一度身材走样，但当时坚持每周快走2次、每次6公里，再加上穿塑身衣、按摩SPA，产后4个月就健康地甩掉14公斤。</p><p>柯以柔结婚四年顺产3年，现在还是拥有一副傲人的身材。大儿子叫“小味留”郭尚杰。二女儿叫小水果。小女儿叫做“小柠檬”。印证网友的那一句话，她现在是台湾女星中最幸福的一个。</p><p><img src="http://p35.qhimg.com/t0164ee9e40ee82e9d5.jpg?size=600x899"></p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://yule.qlwb.com.cn/2016/0229/559084.shtml">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='db83bf3206a06aa40667f1c0d45c3881'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>柯以柔</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E6%9F%AF%E4%BB%A5%E6%9F%94&amp;pn=1&amp;pos=6&amp;m=9be6384bcf2d28006cbe3ebdc8035f9ac6ed8b07&amp;u=http%3A%2F%2Fent.ifeng.com%2Fa%2F20150727%2F42461054_0.shtml" data-pos="1"> <b>柯以柔</b>母乳喂养25天瘦8公斤 小腹平坦惊现腰线(图) </a>   <li> <a href="/transcode?q=%E6%9F%AF%E4%BB%A5%E6%9F%94&amp;pn=1&amp;pos=7&amp;m=0b9aeb848e8adf645215e4cabcbde205eed7edb6&amp;u=http%3A%2F%2Fent.163.com%2Fphotoview%2F00AJ0003%2F541239.html" data-pos="2"> 辣妈<b>柯以柔</b>着比基尼度假 与老公戏水秀美胸 </a>   <li> <a href="/transcode?q=%E6%9F%AF%E4%BB%A5%E6%9F%94&amp;pn=1&amp;pos=8&amp;m=14de328254e26fd1c0d8d11efd068008ff7adb60&amp;u=http%3A%2F%2Fent.qq.com%2Fa%2F20140928%2F000335.htm" data-pos="3"> 辣妈<b>柯以柔</b>巴厘岛大解放 晒比基尼照网友热赞 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '柯以柔:她是最早的网红，曾恐婚当“落跑新娘”，现运气好到连小S都羡慕(图) ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '柯以柔:她是最早的网红，曾恐婚当“落跑新娘”，现运气好到连小S都羡慕(图) '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";