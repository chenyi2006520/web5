s:16154:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>翟墨驾&quot;东南卫视号&quot;抵新加坡 《扬帆走海丝》今首播 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">翟墨驾&quot;东南卫视号&quot;抵新加坡 《扬帆走海丝》今首播 </h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2015-05-18 10:04:00</time></p> </header>  <div id="news-body"><p><img src="http://p31.qhimg.com/t01f66dbc5c3766766d.jpg?size=550x412"></p><p>“<a href="http://m.so.com/s?q=%E4%B8%9C%E5%8D%97%E5%8D%AB%E8%A7%86%E5%8F%B7&amp;src=newstranscode" class="qkw">东南卫视号</a>”抵达新加坡 <a href="http://m.so.com/s?q=%E7%BF%9F%E5%A2%A8&amp;src=newstranscode" class="qkw">翟墨</a>做客新加坡国立大学</p><p>自4月20日从福建<a href="http://m.so.com/s?q=%E5%B9%B3%E6%BD%AD&amp;src=newstranscode" class="qkw">平潭</a>启航，由“无动力帆船环球航海中国第一人”翟墨领航的“2015重走海上丝绸之路”船队经三亚、香港等地的短暂停靠之后，领航船“东南卫视号”于5月14日抵达境外第一站--<a href="http://m.so.com/s?q=%E6%96%B0%E5%8A%A0%E5%9D%A1&amp;src=newstranscode" class="qkw">新加坡</a>，当地相关机构及华人代表在新加坡115游艇码头为船舶进港举行了盛大的迎接仪式，而<a href="http://m.so.com/s?q=%E4%B8%9C%E5%8D%97%E5%8D%AB%E8%A7%86&amp;src=newstranscode" class="qkw">东南卫视</a>为此量身定制的大型新<a href="http://m.so.com/s?q=%E6%B5%B7%E4%B8%8A%E4%B8%9D%E7%BB%B8%E4%B9%8B%E8%B7%AF&amp;src=newstranscode" class="qkw">海上丝绸之路</a>跨国特别节目《扬帆走海丝》也将于5月18日晚间22:00首播，全景呈现“2015重走海上丝绸之路”的壮举。</p><p><a href="http://m.so.com/s?q=%E9%A9%AC%E5%85%AD%E7%94%B2%E6%B5%B7%E5%B3%A1&amp;src=newstranscode" class="qkw">马六甲海峡</a>自古便是中国海洋贸易的重要中转站，而新加坡地处马六甲海峡,一直被誉为“东方的十字路口”。今年恰逢中国和新加坡建交25周年 新加坡建国50周年，“东南卫视号”在新加坡短暂停留期间，除了参加“2015海上丝绸之路艺术展”等系列活动开幕式以外，翟墨还于5月16日应邀做客<a href="http://m.so.com/s?q=%E6%96%B0%E5%8A%A0%E5%9D%A1%E5%9B%BD%E7%AB%8B%E5%A4%A7%E5%AD%A6&amp;src=newstranscode" class="qkw">新加坡国立大学</a>发表“细雨中起航，<a href="http://m.so.com/s?q=%E9%A3%8E%E9%9B%A8%E4%B8%AD%E5%89%8D%E8%A1%8C&amp;src=newstranscode" class="qkw">风雨中前行</a>”主题演讲，详细介绍此次重走海上丝绸之路的情况，并与在场师生亲切互动。此外，在新加坡国立大学做客期间，翟墨还将与师生进行国画、茶文化等传统文化方面的深度交流，并向新加坡国立大学赠送国礼“四特东方韵”酒。</p><p><a href="http://m.so.com/s?q=%E3%80%8A%E6%89%AC%E5%B8%86%E8%B5%B0%E6%B5%B7%E4%B8%9D%E3%80%8B&amp;src=newstranscode" class="qkw">《扬帆走海丝》</a>5月18日首播 全景呈现“重走海丝”壮举</p><p>翟墨和他的团队接下来将驾驶“东南卫视号”沿着古代海上丝绸之路的路线继续航行，途经新加坡、<a href="http://m.so.com/s?q=%E9%A9%AC%E6%9D%A5%E8%A5%BF%E4%BA%9A&amp;src=newstranscode" class="qkw">马来西亚</a>、斯里兰卡、塞舌尔、<a href="http://m.so.com/s?q=%E5%9F%83%E5%8F%8A&amp;src=newstranscode" class="qkw">埃及</a>、希腊、马耳他等七个国家，最终抵达目的地<a href="http://m.so.com/s?q=%E6%84%8F%E5%A4%A7%E5%88%A9&amp;src=newstranscode" class="qkw">意大利</a>，整个航程逾万海里。为了全景呈现“2015重走海上丝绸之路”活动，东南卫视特别制作的国内首档跨国航海特别节目《扬帆走海丝》也将于5月18日开播。据节目组制片人介绍，不同于一般的航海纪录片，《扬帆走海丝》节目将结合翟墨航海过程的实际拍摄与卫星连线、演播室专家访谈、海丝文化系列短片等多种形式，尽可能全方位展现海丝文化的历史、内涵，沿途各国的风土人情，以及中国对外经贸文化交流等方方面面，还将以东南卫视号为媒介，串联起整个<a href="http://m.so.com/s?q=%E6%B5%B7%E4%B8%8A%E4%B8%9D%E8%B7%AF&amp;src=newstranscode" class="qkw">海上丝路</a>沿线的文化、经贸、体育、科考、旅游、探险等多领域、多学科，全景呈现 “2015重走海上丝绸之路”这项综合探访行动和大型海洋文化交流盛会。</p><p><img src="http://p35.qhimg.com/t01f3d9026f32733f4f.jpg?size=550x412"></p><p>据悉，《扬帆走海丝》将于5月18日首播，每周一至周四在东南卫视晚间<a href="http://m.so.com/s?q=%E5%8D%81%E7%82%B9%E6%A1%A3&amp;src=newstranscode" class="qkw">十点档</a>播出，节目播出将持续到今年九月份。“2015重走海上丝绸之路”活动和《扬帆走海丝》节目一方面是东南卫视“精品综艺，人文关怀”节目理念的产物，另一方面更是东南卫视致力于传播“一带一路”战略的重要成果。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://ent.people.com.cn/n/2015/0518/c86955-27016625.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='3635b7b96c8616770bc3b855d72f85d0'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>东南卫视</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E4%B8%9C%E5%8D%97%E5%8D%AB%E8%A7%86&amp;pn=1&amp;pos=8&amp;m=19f590d909b990778cd1d7654d9db3e5406d9491&amp;u=http%3A%2F%2Fwww.39yst.com%2Fslyz%2F381779.shtml" data-pos="1"> 20160226<b>东南卫视</b>食来运转:蔬菜沙拉的做法 </a>   <li> <a href="/transcode?q=%E4%B8%9C%E5%8D%97%E5%8D%AB%E8%A7%86&amp;pn=1&amp;pos=9&amp;m=3cdc10c9325616e0d47b558209dceb61f089d126&amp;u=http%3A%2F%2Fwww.39yst.com%2Fslyz%2F381802.shtml" data-pos="2"> 20160227<b>东南卫视</b>食来运转:菜粥的做法 </a>   <li> <a href="/transcode?q=%E4%B8%9C%E5%8D%97%E5%8D%AB%E8%A7%86&amp;pn=1&amp;pos=10&amp;m=47bf19d586e5c876df0cb10b0d609a3cffb68717&amp;u=http%3A%2F%2Fwww.39yst.com%2Fslyz%2F381768.shtml" data-pos="3"> 20160225<b>东南卫视</b>食来运转:炒猪肝的做法 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '翟墨驾&quot;东南卫视号&quot;抵新加坡 《扬帆走海丝》今首播 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '翟墨驾&quot;东南卫视号&quot;抵新加坡 《扬帆走海丝》今首播 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";