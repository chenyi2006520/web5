s:22833:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>一家5兄弟4个是老兵 3人参加过抗战1人支援新疆- 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">一家5兄弟4个是老兵 3人参加过抗战1人支援新疆</h1> <p id="source-and-time"><span id=source>贵阳网</span><time id=time>2015-06-10 10:20:26</time></p> </header>  <div id="news-body"><p>摘要:在<a href="http://m.so.com/s?q=%E7%93%AE%E5%AE%89%E5%8E%BF&amp;src=newstranscode" class="qkw">瓮安县</a>平定营镇万龙村曹土寨，有一家5兄弟，有4个军人，其中3人是参加抗日战争的老兵，1人是和平年代参加支援新疆建设的老兵，目前，仅有一位抗战老兵健在。6月6日，贵州都市报记者来到这个“光荣之家”进行了采访。</p><p><img src="http://p35.qhimg.com/t01a6fc4f4167e7f452.jpg?size=399x600"></p><p class="img-title">刘崇武还能提笔写字。</p><p><img src="http://p31.qhimg.com/t01b85b9fe01486b60f.jpg?size=400x266"></p><p>刘崇武在养<a href="http://m.so.com/s?q=%E8%9C%9C%E8%9C%82&amp;src=newstranscode" class="qkw">蜜蜂</a>。</p><p class="header">本报记者文隽永 摄影报道</p><p>在瓮安县<a href="http://m.so.com/s?q=%E5%B9%B3%E5%AE%9A%E8%90%A5%E9%95%87&amp;src=newstranscode" class="qkw">平定营镇</a>万龙村曹土寨，有一家5兄弟，有4个军人，其中3人是参加抗日战争的老兵，1人是和平年代参加支援新疆建设的老兵，目前，仅有一位抗战老兵健在。6月6日，贵州都市报记者来到这个“光荣之家”进行了采访。</p><p class="header">回归故土</p><p>曹土寨现住有几十户人家。一百多年前，寨子上有户名叫刘昌荣和刘郑氏夫妇，生育了7孩子，其中5男2女。主要从事农耕和小商发家致富，成为当地富裕人家，重视培养子女读书长见识，子女都好学上进。</p><p>央陆军军官学校(<a href="http://m.so.com/s?q=%E9%BB%84%E5%9F%94%E5%86%9B%E6%A0%A1&amp;src=newstranscode" class="qkw">黄埔军校</a>)四分校(校址在贵州独山县)18期，学成毕业后分赴山东青岛等地抗日战场。1949年新中国成立前夕，<a href="http://m.so.com/s?q=%E5%88%98%E5%B4%87%E6%96%87&amp;src=newstranscode" class="qkw">刘崇文</a>从海南岛到台湾。</p><p>刘崇文随部队去台湾前，在<a href="http://m.so.com/s?q=%E7%93%AE%E5%AE%89&amp;src=newstranscode" class="qkw">瓮安</a>老家与姓逄的农村姑娘结婚，并生育一儿一女，现在其女儿76岁，系罗甸县退休教师，儿子在瓮安老家务农。由于历史原因，信息中断，不了解家乡信息，刘崇文在台湾部队转业后，在台湾苗栗县一所学校当教师，结婚组建家庭，1985年退休。</p><p>1987年，海峡两岸可以通邮见亲人时，刘崇文写信通知在瓮安的女儿等亲属到香港见面。随后，他们互相通信倾诉亲情。每次通信，他在信中字里行间透露出思乡心切，总想落叶归根。</p><p>1988年，刘崇文告别台湾，回到贵州，虽然见到了中断40多年没有音讯的结发妻子逄氏，但由于文化、认识、观念等诸多方面差异原因，他俩最终没有再住在一起，而是用退休金来扶持瓮安老家的子孙，以此弥补心里之憾。</p><p>1999年，刘崇文因病辞世，享年80岁。其子女按照他生前遗愿，把他送回老家瓮安曹土。2008年12月，他的结发妻子逄氏也因病医治无效辞世。</p><p>5月30日，远在台湾居住的刘崇文的女儿刘定丽，通过短信向记者和都匀亲人介绍了他父亲的一些情况:“我小时曾听家父谈起，他投考黄埔军校首要目标是为了保乡为民，家父曾多次参与抗日战役，战役中已把生死置之度外，故能多次以少敌多，以寡声众，把日本鬼子抵抗在外，唯每当天气变化，加上粮配不足时，吃野菜挖树根果腹。”</p><p class="header">九旬老兵</p><p>记者见到老兵刘崇武时，他正在破旧的老房子屋檐下，精心养护他的蜜蜂。刘崇武说，他这一辈子是搞畜牧业，养了半辈子的蜜蜂，为相邻医治猪牛羊马等牲口几十年，是当地有名的“<a href="http://m.so.com/s?q=%E8%B5%A4%E8%84%9A%E5%85%BD%E5%8C%BB&amp;src=newstranscode" class="qkw">赤脚兽医</a>”。</p><p>至今，刘崇武对自己70年前抗战期间就读军校，参加抗日救亡运动的事情记忆犹新。</p><p>刘崇武说，他在家排行老三。1922年10月25日出生，刘崇武先后在瓮安、<a href="http://m.so.com/s?q=%E9%BB%84%E5%B9%B3&amp;src=newstranscode" class="qkw">黄平</a>等地读书。1939年考入贵州省立贵阳初级农业职业学校，校址在贵阳市油榨街，校长胡礽同，当时学校人数仅100多学生。1939年2月，为避日机轰炸，学校由油榨街迁清镇县芦荻村，次年又迁中曹司麦兆村。1940年底，赵发智继龙之田后任校长。</p><p>1942年，刘崇武从省立贵阳初级农业职业学校毕业后，恰逢中央陆军<a href="http://m.so.com/s?q=%E5%85%BD%E5%8C%BB%E5%AD%A6%E6%A0%A1&amp;src=newstranscode" class="qkw">兽医学校</a>(从北京迁移到<a href="http://m.so.com/s?q=%E5%AE%89%E9%A1%BA&amp;src=newstranscode" class="qkw">安顺</a>办学)来学校招生，刘崇武有幸考上了这所学校，来到安顺接受军事化教育。当时学校大概有2000多人，学生来自贵州、湖南、广西、广东、新疆、菲律宾、新加坡等海内外。开设有骨科、解剖、畜牧、兽医、畜牧兽医等专业。有美军少校教官，主要教细菌学、药物学及外语等学科。刘崇武学的是畜牧兽医专业(学制3年)，全队40多人，既要学习专业课，还要野外训练军事及实验解剖动物标本等，还要学习英语，接受思想教育，主要是抗日救亡宣传思想，激发学生爱国热情。至今，刘崇武还会用英语对话和写英语字句。</p><p>当时，中央陆军兽医学校与同样驻在安顺的中央陆军军医学校相距仅1里左右。两校经常开展联谊活动，师生互相认识交流，谈论学成之后如何抗日战斗，报效国家。</p><p>1943年，何应钦将军和陈纳德将军等一行军官，从印缅<a href="http://m.so.com/s?q=%E6%8A%97%E6%97%A5%E5%89%8D%E7%BA%BF&amp;src=newstranscode" class="qkw">抗日前线</a>回国到重庆，经过安顺时，专程到学校视察训话。全体师生列队欢迎，要大家好好学习，练好本领后好到前线抗日杀敌。</p><p>在安顺读书时，刘崇武收到弟弟<a href="http://m.so.com/s?q=%E5%88%98%E5%B4%87%E6%9D%B0&amp;src=newstranscode" class="qkw">刘崇杰</a>从印度抗日前线写的书信，弟弟是中央航校学生，讲述他们在<a href="http://m.so.com/s?q=%E5%8D%B0%E5%BA%A6&amp;src=newstranscode" class="qkw">印度</a>加尔各答前线抗日经过，战事很紧张。鼓励刘崇武好好学习后积极参加抗日。</p><p>1944年“黔南事变”前夕，刘崇武看到大量难民从昆明方向和贵阳方向涌入，满大街都是流亡难民，有的活活饿死，惨不忍睹，公路上的汽车慢慢爬行，车上像插笋子一样，人挤人，根本看不见车身子。全校师生都配发枪支，作好到黔南参加抗日战斗的准备。</p><p>就在抗战胜利前夕，学校领导到重庆开会回来，宣传抗战即将胜利了，学校不搬迁了，要大家安心学习。</p><p>1945年8月15日，日本人宣布无条件投降的消息传到了学校，全体师生开展联欢活动，鸣枪放炮，帽子抛向空中，黑压压的一片，大家互相拥抱，欢呼雀跃，全城庆祝这伟大胜利。</p><p>刘崇武在学校学习两年后，又到重庆沙坪坝招生点报名，考入中央航空学校入伍生总队，学习半年后，到铜梁县旧市坝校本部复试，因化学成绩没有及格而被淘汰。</p><p>刘崇武在航校门口徘徊失望准备回家时，偶然遇到在黄平旧州读初中的同学<a href="http://m.so.com/s?q=%E5%91%A8%E5%85%8B&amp;src=newstranscode" class="qkw">周克</a>，9年没有见面的周克，此时在中央航校总队。周克让刘崇武去重庆新华日报找他的朋友龚如生(成儒)想办法开路条，到张家口航空队试一试。但是刘崇武找到龚先生后，他说现在路上国民党封锁很严，不敢开路条。刘崇武只好作罢，回到瓮安老家务农。</p><p>解放初期，刘崇武在瓮安一小、二小等学校教书两年多。后来，刘崇武回到老家营定街公社当农村赤脚兽医，又在公社中学教书(英语)一段时间后回家，一边四处行医，为民服务，一边种植果树，养蜜蜂等。</p><p>刘崇武的老伴早年就去世了，现在，刘崇武虽然93岁高龄了，但身体健康，记忆清晰，每天出门劳动，喂养蜜蜂，还有群众来请他去为牲口治病。</p><p>1991年，瓮安县农业局为刘崇武颁发光荣退休奖状，每年可以享受2000元的补助。</p><p class="header">驾机抗日</p><p>刘崇杰是刘崇武的胞弟，排行老四。1925年8月12日出生，1942年，年仅17岁的刘崇杰从瓮安初中毕业后，考入四川<a href="http://m.so.com/s?q=%E9%93%9C%E6%A2%81&amp;src=newstranscode" class="qkw">铜梁</a>笕桥航空学校(23期)读书。<a href="http://m.so.com/s?q=%E7%AC%95%E6%A1%A5&amp;src=newstranscode" class="qkw">笕桥</a>航空学校是中国空军的摇篮。从此，他开始新的人生历程，先学飞行式(即今天的飞行专业)，由于抗战时间紧迫，急需人员参战，23期同学共40人参战，有的为国殉职、有的受伤残疾。</p><p>1945年抗战胜利后，刘崇杰回到瓮安县读高中，1948年考入贵阳师范学院(贵州师范大学前身)先修班学习，1950年在瓮安考入军干校，后转为财干校(校址贵阳花溪)，1952年任<a href="http://m.so.com/s?q=%E7%BD%97%E7%94%B8&amp;src=newstranscode" class="qkw">罗甸</a>粮食局副局长，1958年任罗甸把霸铁厂厂长，1964年任罗甸<a href="http://m.so.com/s?q=%E5%86%9C%E7%A7%91%E6%89%80&amp;src=newstranscode" class="qkw">农科所</a>副所长，1985年，他从黔南州农科所副所长岗位退休，2005年12月14日，因病医治无效辞世。</p><p>刘崇杰的儿子<a href="http://m.so.com/s?q=%E5%88%98%E5%88%9A&amp;src=newstranscode" class="qkw">刘刚</a>说，他父亲从没有跟他说过他1942年到1945年期间，在四川铜梁、云南昆明、印度<a href="http://m.so.com/s?q=%E5%8A%A0%E5%B0%94%E5%90%84%E7%AD%94&amp;src=newstranscode" class="qkw">加尔各答</a>、巴基斯坦卡拉奇等地航校培训学习，在印缅战场打过日本鬼子的经经历。这些情况都是在父亲去世后，从他与同学和战友的通信往来中才知道的。刘崇杰是23期笕桥航校第一批40余人首先参加抗日战争的学员之一，抗战中，他们的战绩受到了许多学员羡慕和夸奖，他与其他4个同学(何伟钦、肖远端、冯振宽、髙成楷)被23期笕桥航校同学和战友称为“抗战五虎”。</p><p>23期笕桥航空学校学员唐积敏(后任国民革命军空军中将，曾在美国通讯学校学习，接受过罗斯福总统的检阅，并任旗手)，在与刘崇杰的通信中写道:“本期同学我最尊敬你们参加抗战的一届，同学们经常谈起你们在缅甸作战旧事，这就是中国人的民族气节。”</p><p>刘刚说，父亲的弟弟刘崇义，1928年出生，受3个哥哥的抗日经历影响，中专毕业后于1951年应征入伍，编入中国人民解放军新疆农业建设第7师126团服役，是建筑设计师，他在新疆服役成家到退休，一生都在军营度过。2013年，刘崇义因病去世，享年85岁，安葬在新疆。</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://www.gywb.cn/content/2015-06/10/content_3227854.htm">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='72aa64f8ab2d7e9bef89f66016e3a3ef'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>赤脚兽医</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E8%B5%A4%E8%84%9A%E5%85%BD%E5%8C%BB&amp;pn=1&amp;pos=10&amp;m=1d58c30d9a6251c682ef64f7583a077651a6eb5e&amp;u=http%3A%2F%2Fdy.qq.com%2Farticle.htm%3Fid%3D20140913A0008U00" data-pos="1"> <b>赤脚</b>医生传奇--财新周末 </a>   <li> <a href="/transcode?q=%E8%B5%A4%E8%84%9A%E5%85%BD%E5%8C%BB&amp;pn=2&amp;pos=1&amp;m=6eb141424c5a69e539544c172e13c9cd64aa5638&amp;u=http%3A%2F%2Fdangjian.people.com.cn%2Fn%2F2015%2F0215%2Fc78694-26571054.html" data-pos="2"> 为官为民,无愧"时代楷模" </a>   <li> <a href="/transcode?q=%E8%B5%A4%E8%84%9A%E5%85%BD%E5%8C%BB&amp;pn=2&amp;pos=2&amp;m=610a7630152c541dce077c7f9a66f231e5f8cdfe&amp;u=http%3A%2F%2Fworld.huanqiu.com%2Fhot%2F2015-01%2F5511312.html" data-pos="3"> 追记毛丰美:"我就是为农民说话的" </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '一家5兄弟4个是老兵 3人参加过抗战1人支援新疆' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '一家5兄弟4个是老兵 3人参加过抗战1人支援新疆'
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";