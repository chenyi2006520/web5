s:17909:" <!DOCTYPE html><html><head><meta charset="utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>1分钟分拣800个包裹 日本“宅急送”东京配送站点大揭秘 - 360新闻搜索</title><link type="image/x-icon"rel="shortcut icon"href="/faviconso.ico"><link rel=stylesheet href="http://s8.qhimg.com/static/05e96eb2b81f370b/article.css"><script>var ENV_MONITOR={},WPO={};WPO.data={dcl:[+(new Date)]}</script><script>var $pro = 'm_news', $pid='result_view';</script></head><body class="body_SO"><script>/(mso_app|360newsapp|360 Aphone Browser|QHBrowser)/ig.test(navigator.userAgent)&&(document.body.className+=" notop"),!navigator.userAgent.match(/(i[^;]+\;( ?U;)? CPU.+Mac OS X)/)||(document.body.className+=" ios",document.downUrl="https://itunes.apple.com/cn/app/id990129323")</script>  <header class=header> <a class=back href="javascript:void('back');"></a> <h1 class=logo><a href="/"></a></h1> <dl class=fontsize> <dt> <dd> <a class=subFontSize href="javascript:void('subFontSize');"></a> <a class=addFontSize href="javascript:void('addFontSize');"></a> </dl> </header>   <article id=news> <header> <h1 id="news-title">1分钟分拣800个包裹 日本“宅急送”东京配送站点大揭秘 </h1> <p id="source-and-time"><span id=source>人民网</span><time id=time>2016-02-22 08:09:00</time></p> </header>  <div id="news-body"><p>随着电商业务的发展，中国的快递业务也迎来了迅猛发展的时机。然而众多的快递业务在给我们带来方便的同时，也不时会有包裹姗姗来迟、收到的物品七零八乱等感慨。日本的物流业务全球领先，而<a href="http://m.so.com/s?q=%E5%8D%A0%E9%A2%86%E6%97%A5%E6%9C%AC&amp;src=newstranscode" class="qkw">占领日本</a>快递市场40%以上份额的不是日本<a href="http://m.so.com/s?q=%E9%82%AE%E6%94%BF%E5%85%AC%E5%8F%B8&amp;src=newstranscode" class="qkw">邮政公司</a>、不是佐川急送，而是那只穿梭在日本大街小巷灵活的“黑猫”快递公司--日本大和<a href="http://m.so.com/s?q=%E5%AE%85%E6%80%A5%E9%80%81&amp;src=newstranscode" class="qkw">宅急送</a>。</p><p>日本黑猫宅急送<a href="http://m.so.com/s?q=%E4%B8%9C%E4%BA%AC&amp;src=newstranscode" class="qkw">东京</a>羽田物流中心，建筑面积约20万平方米，相当于4个东京足球场。图片来源:日本经济新闻网网页截图。</p><p>近日，日本媒体探访了大和宅急送位于东京羽田的的超大型物流分拣中心，跟随一个包裹，用360度的视角拍摄了其被自动分拣的过程。我们也透过这篇文章来参观一下大和宅急送的物流中心。</p><p><img src="http://p32.qhimg.com/t0168c061bd71eb515a.jpg?size=487x293"></p><p>日本大和宅急送每年的发货量统计图。2014年发货16.22亿个。(图片来源:网页截图)</p><p>日本大和宅急送成立于1976年1月，从开业第一天配送11个包裹，到现在全国日均配送400-500万个包裹，大和宅急送经历了40年不断的发展。</p><p>(责编:袁蒙、<a href="http://m.so.com/s?q=%E9%99%88%E5%BB%BA%E5%86%9B&amp;src=newstranscode" class="qkw">陈建军</a>)</p><p class="header">【千米交叉分拣带智能分配货物】</p><p><img src="http://p33.qhimg.com/t017f9e5f8149ecd6f2.jpg?size=462x260"></p><p>错综交叉的智能交叉分拣带。(图片来源:网页截图)</p><p>大和宅急送公司是如何实现每日准确无误地分拣400-500万个包裹的呢?单纯依靠人工是不太可能实现的。在这个建筑面积达20万平方米的巨大物流中心里，公司靠智能IT系统匀速运转着一条长达1070米的智能交叉分拣<a href="http://m.so.com/s?q=%E4%BC%A0%E9%80%81%E5%B8%A6&amp;src=newstranscode" class="qkw">传送带</a>。这条传送上带共有25个入口，48个出口。可以同时承载1336个大小约50cm*140cm的包裹在上面运转。</p><p>【重速度更重服务 温柔对待每个包裹】</p><p><img src="http://p32.qhimg.com/t01b531041a02ed16d8.jpg?size=514x230"></p><p>分拣员将包裹轻拿轻放至传送带。(图片来源:网页截图)</p><p>在这里，你看不到包裹满天飞、箱子满地扔的情景。分拣员们工作较轻松，只需站在一个分拣入口，将从全国邮寄过来的包裹轻拿轻放至传送带即可。</p><p class="header">【红色扫描门 即刻识别包裹数据】</p><p><img src="http://p32.qhimg.com/t01296151534c90fb2b.jpg?size=497x214"></p><p class="img-title">红色扫描门。(图片来源:网页截图)</p><p>当包裹通过这个红光扫描门时，贴在其身上的数据信息会被读取。为了提高信息读取的准确率，一般都会要求分拣员将包裹尽量靠近扫描门一侧，这样包裹的信息就可以在通过扫描门的时更方便地被扫描到了。</p><p class="header">【25口进48口出】</p><p>你可以把这个智能交叉分拣带想象成一个错综交叉的交通图。来自全国各地的货物，从25个投递口进入传送带。然后传送带根据扫描货物身上的数字信息，再将货物分送至48个出口，对应东京都48个送货区域。快递货车只需在出口等待，装车后就可立即开车将货物配送至客户手中。</p><p>【1分钟800个 全国全年分发16亿个包裹 】</p><p>这条智能交叉分拣带以时速9.7公里的速度不间断地运行，每小时最多可以分拣4万8000个包裹，也就是1分钟可以分发800个包裹。然而，这个巨大的物流配送站点还只是大和宅急送分布于全国各地的服务站点之一。据日媒报道，有数据显示，2014年年底，大和宅急送配送的包裹数量达16亿个，占全日本快递市场份额的45%。这对于40年前，首日开业只配送11个包裹的公司来说，估计没有人会想象到今天的结果。</p><p>另数据分析显示，大和宅急送按照日前的业务发展态势，在2020年前后其全国的包裹年分拣量将突破每年40亿个，甚至有可能挑战50亿个。</p><p class="header">【智能物流提高发货的便捷性】</p><p><img src="http://p33.qhimg.com/t01f6a7a9620a426af1.jpg?size=428x285"></p><p>大和宅急送在社交平台<a href="http://m.so.com/s?q=LINE&amp;src=newstranscode" class="qkw">LINE</a>上的快递服务。(图片来源:网页截图)</p><p>在不断增强的物流需求面前，大和宅急送公司通过不断强化业务的自动化、智能化来提高发货的效率及便捷性。大和宅急送在日本类似微信的社交平台LINE上开通了快递服务。在这里，如果你想将物品发送给的自己<a href="http://m.so.com/s?q=%E6%9C%8B%E5%8F%8B%E5%9C%88&amp;src=newstranscode" class="qkw">朋友圈</a>的好友的话，你无需输入对方地址，只需选择好友就可以实现快递的发送了。这里利用的不是朋友提前输入的地址数据，而是利用朋友的地理位置。利用地理位置，快递公司可以提前规划好货物发送流程及快递人员，可以更有效地缩短“最后一公里”的配送时间，提高发货效率及快递业务的便捷性。</p><p>【借鉴经验 <a href="http://m.so.com/s?q=%E4%B8%AD%E5%9B%BD%E7%89%A9%E6%B5%81&amp;src=newstranscode" class="qkw">中国物流</a>仍有更广阔的发展空间】</p><p>目前，中国的电商发展世界一流，从城市到乡村的电商革命必将为中国的物流产业带来更广阔的发展前景。</p><p>期待日本物流业的智能分拣系统、将位置信息等<a href="http://m.so.com/s?q=%E5%A4%A7%E6%95%B0%E6%8D%AE&amp;src=newstranscode" class="qkw">大数据</a>与物流结合的配送方式、善待包裹、轻拿轻放的温柔服务等特色也能对我国的物流业发展带来一些启示。(责编:袁蒙、陈建军)</p></div>  <footer>  <p class=tip_quick>文章内容由搜索引擎自动发现并显示为快照，不代表360新闻的立场和观点，<a target=_blank class=viewsource href="http://japan.people.com.cn/n1/2016/0222/c35467-28138154.html">查看原文</a></p>      </footer> </article> <section class=sohu_cy> <div id=SOHUCS sid='509fa88db591e92448c9a144578874b3'></div><script id=changyan_mobile_js charset="utf-8" src="http://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=cyrTywwWs&conf=prod_c56aa5a54e89138d855c5ca9b31470a0" ></script> </section>  <aside id="next-news"> <h3><em>宅急送</em>的其它新闻:</h3> <ul>    <li> <a href="/transcode?q=%E5%AE%85%E6%80%A5%E9%80%81&amp;pn=1&amp;pos=7&amp;m=07cdc7d2b2ce1893a4dc34349af6d623f463b966&amp;u=http%3A%2F%2Fworld.chinadaily.com.cn%2Fguoji%2F2016-02%2F22%2Fcontent_23580338.htm" data-pos="1"> 1分钟分拣800个包裹 日本"<b>宅急送</b>"配送站点大揭秘 </a>   <li> <a href="/transcode?q=%E5%AE%85%E6%80%A5%E9%80%81&amp;pn=1&amp;pos=8&amp;m=044318316b3dd1352931f8583d56aee6f542b8ea&amp;u=http%3A%2F%2Fjapan.people.com.cn%2Fn1%2F2016%2F0222%2Fc35467-28138154.html" data-pos="2"> 1分钟分拣800个包裹 日本"<b>宅急送</b>"东京配送站点大揭秘 </a>   <li> <a href="/transcode?q=%E5%AE%85%E6%80%A5%E9%80%81&amp;pn=1&amp;pos=9&amp;m=03febaad537ba8b07f24b711fcbcf7285560bf3a&amp;u=http%3A%2F%2Fnews.163.com%2F16%2F0223%2F21%2FBGHQMUEV00014AEE.html" data-pos="3"> <b>宅急送</b>二轮融资或已敲定 仓、运、配三事业部独立运营 </a>  </ul> </aside>  <div class=mask style="display:none"></div> <div class="open-in-browser-tip" style="display:none"> <p>好无奈，微信君不让直接下载，别担心，点击<b>右上角</b>，选择“<b>在浏览器中打开</b>”就能下载啦~</p> <a class=close href="javascript:;"><img src="http://p3.qhimg.com/d/inn/a8960a66/close.png"></a> </div><script>(function(){var e=document.getElementById("news-body"),t=e.getElementsByTagName("img");for(var n=0;n<t.length;n++)t[n].parentNode.tagName.toUpperCase()==="P"&&(t[n].parentNode.style.textAlign="center",t[n].parentNode.style.textIndent="0")})()</script><script>WPO.data.dcl.push(+(new Date))</script><script src="http://s0.qhimg.com/static/0b149a613e414574.js" ></script><script src="http://s0.qhimg.com/monitor/;monitor/4f1853e5.js" ></script><script src="http://s2.qhimg.com/!d0a90f5b/cookie.js" ></script>
<script>(function() {
		// 获取location.href信息
		var getUrlParams = function(strKeys) {
			//var url = url || location.search;
			var keys = strKeys.split(','), pattern = '', ret = [];

			for (var i = 0, len = keys.length; i < len; i++) {
				if (i > 0) {
					pattern += '|';
				}
				pattern += '[?&](' + encodeURIComponent(keys[i]) + '=[^&]*)';
			}

			location.search.replace(new RegExp(pattern, 'g'), function(match) {
				var parts = match.substr(1).split('=');
				ret[parts[0]] = decodeURIComponent(parts[1]);
			});

			return ret;
		};

		var initSoMonitor = function(pro, pid) {
			monitor.util.getSid = function() {
				var key = '___sid', val = Cookie.get(key);

				if (!val) {
					val = monitor.util.getGuid() + '.' + (+new Date);
					Cookie.set(key, val);
				}

				return val;
			};

			monitor.data.getBase = function() {
				var base = {
					pro : pro,
					pid : pid,
					u : monitor.util.getLocation(),
					guid : monitor.util.getGuid(),
					sid : monitor.util.getSid()
				};

				if ( typeof window.ENV_MONITOR === 'object') {
					var env = window.ENV_MONITOR;
					for (var prop in env) {
						base[prop] = env[prop];
					}
				}
				return base;
			};

			// 设置好3种数据统计类型的URL
			monitor.setConf('srpUrl', 'http://s.360.cn/so/srp.gif').setConf('dispUrl', 'http://s.360.cn/so/disp.gif').setConf('clickUrl', 'http://s.360.cn/so/click.gif');
		};

		initSoMonitor($pro, $pid);

		// suggest提示词点击统计
		$('.search-box').delegate('.suggest-item-title', 'mousedown', function(e) {
			var params = {
				mod : 'suggest',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// suggest填充按钮点击统计
		$('.search-box').delegate('.suggest-item-add', 'mousedown', function(e) {
			var params = {
				mod : 'suggest_add',
				input : $('.q').val(),
				click : parseInt($(this.parentNode).attr('data-index'), 10) + 1
			};

			monitor.log(params, 'click');
		});

		// PV统计
		var params = getUrlParams('q,src,u');
		params.fe = WPO.data.dcl[1] - WPO.data.dcl[0];
		params.referer = document.referrer;
		params.source = params.u;
		delete params.u;
		monitor.log(params, 'srp');

		// 点击原网页
		$('.viewsource').on('tap', function(e) {
			var params = getUrlParams('q');
			params.mod = 'source';
			params.value = this.href;
			monitor.log(params, 'click');
		});

		$('#next-news a').on('tap', function(e) {
			var params = getUrlParams('q'), $self = $(this);
			params.mod = 'other';
			params.word = $self.text();
			params.pos = $self.attr('data-pos');
			monitor.log(params, 'click');
		});

		// 检查有木有 transcode_fontsize
		var fontSizeRange = [15, 27];
		var transcodeFontsize = Cookie.get('transcode_fontsize', function(s) {
			return Math.max(Math.min(parseInt((s - 18) / 3) * 3 + 18, fontSizeRange[1]), fontSizeRange[0]);
		});
		
		if (transcodeFontsize) {
			$('body').css('font-size', transcodeFontsize);
			if (transcodeFontsize === fontSizeRange[0]) {
				$('.subFontSize').addClass('disabled');
			}
			if (transcodeFontsize === fontSizeRange[1]) {
				$('.addFontSize').addClass('disabled');
			}
		} else {
			Cookie.set('transcode_fontsize', parseInt($('body').css('font-size')), {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
		}
		
		var $header = $('header.header'), $body = $('body'), $fontnav = $header.find('.fontsize dd');
		var fontOptions = {
			fontSize : parseInt($body.css('font-size')),
			fontSizeStep : 3
		};
		var handleFontSize = function(fontSize, type) {
			fontOptions.fontSize = fontSize;
			$body.css('font-size', fontSize);
			Cookie.set('transcode_fontsize', fontSize, {
				path : '/',
				expires : 30 * 24 * 3600 * 1000
			});
			
			var params = getUrlParams('q');
			params.mod = type;
			params.fontSize = fontSize;
			monitor.log(params, 'click');
		};
		// topbar 字体改变，以及返回按钮
		var $subFontSize = $header.find('.subFontSize'), $addFontSize = $header.find('.addFontSize'), fontnav_show = false;
		$body.on('touchstart', function(ev) {
			if (!$(ev.target).closest('.fontsize').length) {
				fontnav_show = false;
				$fontnav.hide();
			}
		});
		$header.on('touchstart', '.fontsize dt', function(){
			fontnav_show = !fontnav_show;
			if (fontnav_show) {
				$fontnav.show();
			} else {
				$fontnav.hide();
			}
		}).on('tap', '.subFontSize', function(e) {
			if ($subFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize - fontOptions.fontSizeStep;
			if (newFontSize <= fontSizeRange[0]) {
				$subFontSize.addClass('disabled');
			}
			if ($addFontSize.hasClass('disabled')) {
				$addFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'subFontSize');
		}).on('tap', '.addFontSize', function(e) {
			if ($addFontSize.hasClass('disabled')) {
				return false;
			}
			
			var newFontSize = fontOptions.fontSize + fontOptions.fontSizeStep;
			if (newFontSize >= fontSizeRange[1]) {
				$addFontSize.addClass('disabled');
			}
			if ($subFontSize.hasClass('disabled')) {
				$subFontSize.removeClass('disabled');
			}
			
			handleFontSize(newFontSize, 'addFontSize');
		}).on('click', '.back', function() {
			history.back();
		});

		//微信提示
		var mask = $('.mask'), tip = $('.open-in-browser-tip'), closeButton = tip.find('.close');
		closeButton.click(function() {
			mask.hide();
			tip.hide();
		}), isWeiXin = (navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1) ? true : false;
		function showTip() {
			mask.show();
			tip.show();
		}
		function bindDownloadButton(sel) {
			if (!isWeiXin)
				return true;
			$(sel).tap(function() {
				showTip();
				return false;
			});
		}

		mask.tap(function() {
			mask.hide();
			tip.hide();
		});

		if(window.ShakeLotteryJsInterface && window.ShakeLotteryJsInterface.shareV2){
			var getSharedImg = function(){
					var newsBody = document.getElementById('news-body'),
						newsImg = newsBody && newsBody.getElementsByTagName('img');
					if(newsImg && newsImg.length){
						return newsImg[0].src;
					}else{
						return 'http://p5.qhimg.com/t01a1342bb65cb15360.png';
					}
				},
				getSharedLink = window.location.href,
				shareHandle = function(shareLink){
					window.ShakeLotteryJsInterface.shareV2(JSON.stringify({
						weibo : {
							desc : '#360新闻，精彩推荐#' + '1分钟分拣800个包裹 日本“宅急送”东京配送站点大揭秘 ' + '。新闻地址：' + shareLink,
							img_url : getSharedImg()
						},
						weixin : {
							desc : '我发现了一个很有意思的新闻，推荐你看下',
							img_url : getSharedImg(),
							link : shareLink,
							title : '360新闻 - ' + '1分钟分拣800个包裹 日本“宅急送”东京配送站点大揭秘 '
						}
					}));
				};

			$.ajax({
				url : 'http://tran.news.so.com/index.php?c=news&a=putprofile&f=jsonp&callback=?',
				data : {
					uid : monitor.util.getSid() || monitor.util.getGuid(),
					url : getSharedLink,
					version : '1.0.0',
					channel : 'youlike',
					category : 'youlike',
					nt : 'h',
					t : Math.floor((+new Date) / 1000),
					x : '',
					y : '',
					sign : 'sjws_yyy',
					source : ''
				},
				type : 'get',
				dataType : 'jsonp',
				success : function(data) {}
			});

			$.ajax({
				url : '/index.php?a=getshorturl',
				data : {
					url : encodeURIComponent(getSharedLink)
				},
				dataType : 'json',
				success : function(data){
					if(data.errno === 0){
						shareHandle(data.data.url);
					}else{
						shareHandle(getSharedLink);
					}
				}
			});
		}

	})();</script></body></html> ";